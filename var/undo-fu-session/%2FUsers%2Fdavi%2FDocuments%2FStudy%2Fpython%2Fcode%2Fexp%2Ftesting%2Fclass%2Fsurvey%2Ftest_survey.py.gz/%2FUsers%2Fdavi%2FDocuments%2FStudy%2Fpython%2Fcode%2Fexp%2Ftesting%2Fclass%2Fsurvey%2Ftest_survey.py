((buffer-size . 874) (buffer-checksum . "ebc8221687c253d2e49b6ca769cd634b95cda368"))
((emacs-pending-undo-list (744 . 752) ("rps" . 744) nil (788 . 796) ("rs" . 788) (789 . 790) ("ps" . 789) nil (661 . 669) ("rps" . 661) nil (716 . 724) ("rps" . 716) ((marker . 675) . -2) ((marker . 723) . -2) ((marker . 723) . -2) ((marker . 723) . -2) ((marker . 723) . -2) ((marker . 723) . -2) ((marker . 723) . -2) ((marker . 723) . -2) (t 24242 39408 716929 586000) nil (716 . 719) ("response" . 716) nil (661 . 664) ("response" . 661) (t 24242 39403 273707 701000) nil (789 . 791) ("s" . -789) ((marker . 505) . -1) 790 (788 . 790) ("response" . 788) ((marker . 796) . -1) ((marker . 796) . -1) ((marker . 796) . -1) ((marker . 796) . -1) (t 24242 39399 688058 595000) nil (744 . 747) ("response" . 744) (t 24242 39390 797943 318000) nil (744 . 752) ("rps" . 744) nil (788 . 796) ("p" . 788) ((marker . 505) . -1) ((marker . 795) . -1) ((marker . 795) . -1) ((marker . 795) . -1) (788 . 789) ("rps" . 788) ((marker . 675) . -2) ((marker . 505) . -2) ((marker . 795) . -2) ((marker . 795) . -2) ((marker . 795) . -2) ((marker . 795) . -2) (t 24242 39387 780573 544000) nil (788 . 791) ("p" . -788) ((marker . 505) . -1) ((marker . 795) . -1) ((marker) . -1) ((marker . 795) . -1) ((marker . 795) . -1) ((marker) . -1) 789 (788 . 789) ("response" . 788) ((marker . 796) . -1) ((marker . 796) . -1) ((marker . 796) . -1) ((marker . 796) . -1) nil (744 . 747) ("response" . 744) (t 24242 39074 823768 583000) nil ("s" . 729) (t 24242 39030 889798 828000) nil (1 . 874) ("#!/usr/bin/env python3

import unittest
from survey import AnonSurvey


class TestAnonSurvey(unittest.TestCase):
    \"\"\"Tests for class AnonSurvey\"\"\"

    def test_store_response(self):
        \"\"\"Test a single response is stored.\"\"\"
        question = \"What's your mother tongue?\"
        my_survey = AnonSurvey(question)
        my_survey.store_response(\"English\")
        self.assertIn(\"English\", my_survey.responses)

    def test_three_responses(self):
        \"\"\"Test three reponses are stored.\"\"\"
        question = \"What's your mother tongue?\"
        my_survey = AnonSurvey(question)
        responses = [\"english\", \"spanish\", \"mandarin\"]
        for response in responses:
            my_survey.store_response(responses)

        for response in responses:
            self.assertIn(response, my_survey.responses)

if __name__ == \"__main__\":
    unittest.main()
" . 1) ((marker . 505) . -767) ((marker . 506) . -824) ((marker* . 684) . 50) ((marker . 675) . -779) ((marker . 505) . -821) ("            " . 825) 822 nil (814 . 823) ("res" . -814) ((marker . 505) . -3) 817 (814 . 817) (804 . 814) ("my" . -804) ((marker . 505) . -2) 806 (802 . 806) ("," . -802) 803 (802 . 803) (794 . 802) ("res" . -794) ((marker . 505) . -3) 797 (t 24242 39023 28190 32000) (794 . 797) (785 . 795) ("ass" . -785) ((marker . 505) . -3) 788 (785 . 788) (apply yas--snippet-revive 780 785 #s(yas--snippet nil nil #s(yas--exit 785 nil) 112 nil nil nil nil)) (apply yas--take-care-of-redo #s(yas--snippet nil nil #s(yas--exit 785 nil) 112 nil nil nil nil)) (780 . 785) ("." . 780) ((marker . 505) . -1) 781 nil (780 . 781) (t 24242 39014 558180 590000) (766 . 780) (757 . 766) ("respo" . -757) ((marker . 505) . -5) 762 (741 . 762) ("    " . -741) ((marker . 505) . -4) 745 (733 . 745) nil (734 . 746) ("        " . 733) ((marker . 505) . -8) (741 . 742) ("    " . -741) ((marker . 505) . -4) 745 (732 . 745) 732 nil ("
" . 732) ((marker . 506) . -1) (t 24242 39003 134395 181000) nil (1 . 781) ("#!/usr/bin/env python3

import unittest
from survey import AnonSurvey


class TestAnonSurvey(unittest.TestCase):
    \"\"\"Tests for class AnonSurvey\"\"\"

    def test_store_response(self):
        \"\"\"Test a single response is stored.\"\"\"
        question = \"What's your mother tongue?\"
        my_survey = AnonSurvey(question)
        my_survey.store_response(\"English\")
        self.assertIn(\"English\", my_survey.responses)

    def test_three_responses(self):
        \"\"\"Test three reponses are stored.\"\"\"
        question = \"What's your mother tongue?\"
        my_survey = AnonSurvey(question)
        responses = [\"english\", \"spanish\", \"mandarin\"]
        for response in responses:
            my_survey.store_response(responses)




if __name__ == \"__main__\":
    unittest.main()
" . 1) ((marker . 505) . -731) ((marker . 506) . -732) ((marker . 746) . -732) ((marker . 746) . -512) ((marker* . 684) . 50) ((marker . 1) . -552) ((marker . 1) . -592) ((marker . 1) . -512) ((marker . 1) . -466) ((marker . 1) . -551) ((marker . 1) . -512) ((marker . 1) . -512) ((marker . 1) . -512) ((marker . 1) . -512) ((marker . 1) . -504) ((marker . 1) . -504) ((marker . 1) . -504) ((marker . 1) . -512) ((marker . 1) . -504) ((marker . 1) . -512) ((marker . 1) . -512) ((marker . 1) . -512) ((marker . 1) . -512) ((marker . 1) . -560) ((marker . 1) . -512) ((marker . 1) . -592) ((marker . 1) . -560) ((marker . 1) . -560) ((marker . 1) . -560) ((marker . 1) . -560) ((marker . 1) . -560) ((marker . 1) . -560) ((marker . 1) . -512) ((marker . 1) . -512) ((marker . 675) . -732) ((marker . 505) . -731) ((marker . 1) . -512) ((marker . 1) . -512) ((marker . 1) . -512) ((marker . 1) . -512) ((marker . 1) . -560) ((marker . 1) . -512) ((marker . 1) . -601) ((marker . 1) . -560) ((marker . 1) . -656) ((marker . 1) . -601) ((marker . 1) . -691) ((marker . 1) . -656) ((marker . 1) . -729) ((marker . 1) . -691) ((marker . 1) . -729) ((marker . 1) . -729) ((marker . 1) . -601) ((marker . 1) . -601) ((marker . 1) . -613) ((marker . 1) . -601) ((marker . 1) . -601) ((marker . 1) . -613) ((marker . 1) . -601) ((marker . 1) . -601) ((marker . 1) . -613) ((marker . 1) . -735) ((marker . 1) . -735) ((marker . 1) . -729) ((marker . 1) . -729) ((marker . 1) . -683) ((marker . 1) . -729) ((marker . 1) . -683) ((marker . 1) . -683) ((marker . 1) . -683) ((marker . 1) . -683) ((marker . 1) . -683) ((marker . 1) . -683) ((marker . 1) . -683) ((marker . 1) . -683) ((marker . 1) . -683) ((marker . 1) . -683) ((marker . 1) . -683) ((marker . 1) . -683) ((marker . 1) . -683) ((marker . 1) . -683) ((marker . 1) . -683) ((marker . 1) . -683) ((marker . 1) . -683) ((marker . 1) . -683) ((marker . 1) . -683) ((marker . 1) . -683) ((marker . 1) . -683) ((marker . 1) . -683) ((marker . 1) . -683) ((marker . 1) . -683) ((marker . 1) . -683) ((marker . 1) . -683) ((marker . 1) . -648) ((marker . 1) . -683) ((marker . 1) . -683) ((marker . 1) . -648) ((marker . 1) . -731) ((marker . 1) . -695) ((marker . 1) . -695) ((marker . 1) . -731) ((marker . 1) . -731) ((marker . 1) . -683) ((marker . 1) . -735) ((marker . 1) . -735) ((marker* . 875) . 51) ((marker . 1) . -732) ((marker . 1) . -695) ((marker . 1) . -695) ((marker . 1) . -732) ((marker . 1) . -732) ((marker . 1) . -731) ((marker . 1) . -732) ((marker . 1) . -695) ((marker . 1) . -695) ((marker . 1) . -732) ((marker . 1) . -732) ((marker . 1) . -732) ((marker . 1) . -735) ((marker . 1) . -735) ((marker . 1) . -732) ((marker . 1) . -732) ((marker . 1) . -732) ((marker . 1) . -732) ((marker . 1) . -732) ((marker . 1) . -732) ((marker . 1) . -735) ((marker . 1) . -735) ((marker . 1) . -732) ((marker . 1) . -732) ((marker . 1) . -735) ((marker . 1) . -735) ((marker . 1) . -732) ((marker . 1) . -732) ((marker . 1) . -732) ((marker . 1) . -732) ((marker . 1) . -560) ((marker . 1) . -732) ((marker . 1) . -732) ((marker . 1) . -732) ((marker . 1) . -732) ((marker . 1) . -732) ((marker . 1) . -732) ((marker . 1) . -732) ((marker . 1) . -732) ((marker . 1) . -732) ((marker . 1) . -732) ((marker . 1) . -731) ((marker . 1) . -732) 732 nil (1 . 783) ("#!/usr/bin/env python3

import unittest
from survey import AnonSurvey


class TestAnonSurvey(unittest.TestCase):
    \"\"\"Tests for class AnonSurvey\"\"\"

    def test_store_response(self):
        \"\"\"Test a single response is stored.\"\"\"
        question = \"What's your mother tongue?\"
        my_survey = AnonSurvey(question)
        my_survey.store_response(\"English\")
        self.assertIn(\"English\", my_survey.responses)

    def test_three_responses(self):
        \"\"\"Test three reponses are stored.\"\"\"
        question = \"What's your mother tongue?\"
        my_survey = AnonSurvey(question)
        responses = [\"english\", \"spanish\", \"mandarin\"]
        for response in responses:
            my_survey.store_response(responses)


if __name__ == \"__main__\":
    unittest.main()
" . 1) ((marker . 506) . -732) ((marker . 746) . -732) ((marker* . 684) . 49) ((marker . 505) . -731) ((marker . 1) . -117) ((marker . 1) . -117) ((marker . 1) . -117) ((marker . 1) . -117) ((marker . 1) . -149) ((marker . 1) . -117) ((marker . 1) . -72) ((marker . 1) . -112) ((marker . 1) . -72) ((marker . 1) . -112) ((marker . 1) . -72) ((marker . 1) . -72) ((marker . 1) . -72) ((marker . 1) . -72) ((marker . 1) . -72) ((marker . 1) . -194) ((marker . 1) . -194) ((marker . 1) . -194) ((marker . 1) . -194) ((marker . 1) . -233) ((marker . 1) . -194) ((marker . 1) . -155) ((marker . 1) . -185) ((marker . 1) . -155) ((marker . 1) . -185) ((marker . 1) . -155) ((marker . 1) . -155) ((marker . 1) . -155) ((marker . 1) . -155) ((marker . 1) . -155) ((marker . 1) . -242) ((marker . 1) . -242) ((marker . 1) . -253) ((marker . 1) . -331) ((marker . 1) . -331) ((marker . 1) . -375) ((marker . 1) . -375) ((marker . 1) . -466) ((marker . 1) . -466) ((marker . 1) . -466) ((marker . 1) . -466) ((marker . 1) . -503) ((marker . 1) . -466) ((marker . 1) . -426) ((marker . 1) . -457) ((marker . 1) . -426) ((marker . 1) . -457) ((marker . 1) . -426) ((marker . 1) . -426) ((marker . 1) . -426) ((marker . 1) . -426) ((marker . 1) . -426) ((marker . 1) . -512) ((marker . 1) . -512) ((marker . 1) . -523) ((marker . 1) . -601) ((marker . 1) . -601) ((marker . 1) . -613) ((marker . 1) . -601) ((marker . 1) . -601) ((marker . 1) . -613) ((marker . 1) . -601) ((marker . 1) . -601) ((marker . 1) . -613) (t 24242 38999 965582 445000) (1 . 732) nil ("
" . 1) ((marker . 505) . -1) ((marker . 505) . -1) nil (1 . 2) 1 nil ("#!/usr/bin/env python3

import unittest
from survey import AnonSurvey


class TestAnonSurvey(unittest.TestCase):
    \"\"\"Tests for class AnonSurvey\"\"\"

    def test_store_response(self):
        \"\"\"Test a single response is stored.\"\"\"
        question = \"What's your mother tongue?\"
        my_survey = AnonSurvey(question)
        my_survey.store_response(\"English\")
        self.assertIn(\"English\", my_survey.responses)

    def test_three_responses(self):
        \"\"\"Test three reponses are stored.\"\"\"
        question = \"What's your mother tongue?\"
        my_survey = AnonSurvey(question)
        responses = [\"english\", \"spanish\", \"mandarin\"]
        for response in responses:
            my_survey.store_response(responses)
" . 1) ((marker . 505) . -731) ((marker . 1) . -117) ((marker . 1) . -117) ((marker . 1) . -117) ((marker . 1) . -117) ((marker . 1) . -149) ((marker . 1) . -117) ((marker . 1) . -72) ((marker . 1) . -112) ((marker . 1) . -72) ((marker . 1) . -112) ((marker . 1) . -72) ((marker . 1) . -72) ((marker . 1) . -72) ((marker . 1) . -72) ((marker . 1) . -72) ((marker . 1) . -194) ((marker . 1) . -194) ((marker . 1) . -194) ((marker . 1) . -194) ((marker . 1) . -233) ((marker . 1) . -194) ((marker . 1) . -155) ((marker . 1) . -185) ((marker . 1) . -155) ((marker . 1) . -185) ((marker . 1) . -155) ((marker . 1) . -155) ((marker . 1) . -155) ((marker . 1) . -155) ((marker . 1) . -155) ((marker . 1) . -242) ((marker . 1) . -242) ((marker . 1) . -253) ((marker . 1) . -331) ((marker . 1) . -331) ((marker . 1) . -375) ((marker . 1) . -375) ((marker . 1) . -466) ((marker . 1) . -466) ((marker . 1) . -466) ((marker . 1) . -466) ((marker . 1) . -503) ((marker . 1) . -466) ((marker . 1) . -426) ((marker . 1) . -457) ((marker . 1) . -426) ((marker . 1) . -457) ((marker . 1) . -426) ((marker . 1) . -426) ((marker . 1) . -426) ((marker . 1) . -426) ((marker . 1) . -426) ((marker . 1) . -512) ((marker . 1) . -512) ((marker . 1) . -523) ((marker . 1) . -601) ((marker . 1) . -601) ((marker . 1) . -613) ((marker . 1) . -601) ((marker . 1) . -601) ((marker . 1) . -613) ((marker . 1) . -601) ((marker . 1) . -601) ((marker . 1) . -613) ((marker) . -683) ((marker) . -684) ((marker) . -687) ((marker) . -688) ((marker) . -691) ((marker) . -692) ((marker) . -648) ((marker) . -649) ((marker) . -652) ((marker) . -653) ((marker) . -593) ((marker) . -594) ((marker) . -597) ((marker) . -598) ((marker) . -552) ((marker) . -553) ((marker) . -556) ((marker) . -557) ((marker) . -504) ((marker) . -505) ((marker) . -508) ((marker) . -509) ((marker) . -458) ((marker) . -459) ((marker) . -462) ((marker) . -463) ((marker) . -422) ((marker) . -423) ((marker) . -367) ((marker) . -368) ((marker) . -371) ((marker) . -372) ((marker) . -323) ((marker) . -324) ((marker) . -327) ((marker) . -328) ((marker) . -282) ((marker) . -283) ((marker) . -286) ((marker) . -287) ((marker) . -234) ((marker) . -235) ((marker) . -238) ((marker) . -239) ((marker) . -186) ((marker) . -187) ((marker) . -190) ((marker) . -191) ((marker) . -151) ((marker) . -152) ((marker) . -113) ((marker) . -114) (t 24242 38999 965582 445000) (1 . 781) ("#!/usr/bin/env python3

import unittest
from survey import AnonSurvey


class TestAnonSurvey(unittest.TestCase):
    \"\"\"Tests for class AnonSurvey\"\"\"

    def test_store_response(self):
        \"\"\"Test a single response is stored.\"\"\"
        question = \"What's your mother tongue?\"
        my_survey = AnonSurvey(question)
        my_survey.store_response(\"English\")
        self.assertIn(\"English\", my_survey.responses)

    def test_three_responses(self):
        \"\"\"Test three reponses are stored.\"\"\"
        question = \"What's your mother tongue?\"
        my_survey = AnonSurvey(question)
        responses = [\"english\", \"spanish\", \"mandarin\"]
        for response in responses:
            my_survey.store_response(responses)




if __name__ == \"__main__\":
    unittest.main()
" . 1) ((marker . 505) . -731) ((marker . 506) . -732) ((marker . 746) . -732) ((marker . 746) . -512) ((marker* . 684) . 50) ((marker . 1) . -552) ((marker . 1) . -592) ((marker . 1) . -512) ((marker . 1) . -466) ((marker . 1) . -551) ((marker . 1) . -512) ((marker . 1) . -512) ((marker . 1) . -512) ((marker . 1) . -512) ((marker . 1) . -504) ((marker . 1) . -504) ((marker . 1) . -504) ((marker . 1) . -512) ((marker . 1) . -504) ((marker . 1) . -512) ((marker . 1) . -512) ((marker . 1) . -512) ((marker . 1) . -512) ((marker . 1) . -560) ((marker . 1) . -512) ((marker . 1) . -592) ((marker . 1) . -560) ((marker . 1) . -560) ((marker . 1) . -560) ((marker . 1) . -560) ((marker . 1) . -560) ((marker . 1) . -560) ((marker . 1) . -512) ((marker . 1) . -512) ((marker . 675) . -732) ((marker . 505) . -731) ((marker) . -762) ((marker) . -763) ((marker) . -648) ((marker) . -649) ((marker) . -652) ((marker) . -653) ((marker) . -593) ((marker) . -594) ((marker) . -597) ((marker) . -598) ((marker) . -552) ((marker) . -553) ((marker) . -556) ((marker) . -557) ((marker) . -458) ((marker) . -459) ((marker) . -462) ((marker) . -463) ((marker) . -422) ((marker) . -423) ((marker) . -367) ((marker) . -368) ((marker) . -371) ((marker) . -372) ((marker) . -323) ((marker) . -324) ((marker) . -327) ((marker) . -328) ((marker) . -282) ((marker) . -283) ((marker) . -286) ((marker) . -287) ((marker) . -234) ((marker) . -235) ((marker) . -238) ((marker) . -239) ((marker) . -186) ((marker) . -187) ((marker) . -190) ((marker) . -191) ((marker) . -151) ((marker) . -152) ((marker) . -113) ((marker) . -114) ((marker) . -552) ((marker) . -553) ((marker) . -556) ((marker) . -557) ((marker) . -552) ((marker) . -553) ((marker) . -556) ((marker) . -557) ((marker) . -504) ((marker) . -505) ((marker) . -508) ((marker) . -509) ((marker . 1) . -512) ((marker . 1) . -512) ((marker . 1) . -512) ((marker . 1) . -512) ((marker . 1) . -560) ((marker . 1) . -512) ((marker . 1) . -601) ((marker . 1) . -560) ((marker . 1) . -656) ((marker . 1) . -601) ((marker . 1) . -691) ((marker . 1) . -656) ((marker . 1) . -729) ((marker . 1) . -691) ((marker . 1) . -729) ((marker . 1) . -729) ((marker . 1) . -601) ((marker . 1) . -601) ((marker . 1) . -613) ((marker . 1) . -601) ((marker . 1) . -601) ((marker . 1) . -613) ((marker . 1) . -601) ((marker . 1) . -601) ((marker . 1) . -613) ((marker . 1) . -735) ((marker . 1) . -735) ((marker . 1) . -729) ((marker . 1) . -729) ((marker . 1) . -683) ((marker . 1) . -729) ((marker . 1) . -683) ((marker . 1) . -683) ((marker . 1) . -683) ((marker . 1) . -683) ((marker . 1) . -683) ((marker . 1) . -683) ((marker . 1) . -683) ((marker . 1) . -683) ((marker . 1) . -683) ((marker . 1) . -683) ((marker . 1) . -683) ((marker . 1) . -683) ((marker . 1) . -683) ((marker . 1) . -683) ((marker . 1) . -683) ((marker . 1) . -683) ((marker . 1) . -683) ((marker . 1) . -683) ((marker . 1) . -683) ((marker . 1) . -683) ((marker . 1) . -683) ((marker . 1) . -683) ((marker . 1) . -683) ((marker . 1) . -683) ((marker . 1) . -683) ((marker . 1) . -683) ((marker . 1) . -648) ((marker . 1) . -683) ((marker . 1) . -683) ((marker . 1) . -648) ((marker) . -683) ((marker) . -684) ((marker) . -687) ((marker) . -688) ((marker) . -691) ((marker) . -692) ((marker . 1) . -731) ((marker . 1) . -695) ((marker . 1) . -695) ((marker . 1) . -731) ((marker . 1) . -731) ((marker . 1) . -683) ((marker . 1) . -735) ((marker . 1) . -735) ((marker* . 875) . 51) ((marker . 1) . -732) ((marker . 1) . -695) ((marker . 1) . -695) ((marker . 1) . -732) ((marker . 1) . -732) ((marker . 1) . -731) ((marker . 1) . -732) ((marker . 1) . -695) ((marker . 1) . -695) ((marker . 1) . -732) ((marker . 1) . -732) ((marker . 1) . -732) ((marker . 1) . -735) ((marker . 1) . -735) ((marker . 1) . -732) ((marker . 1) . -732) ((marker . 1) . -732) ((marker . 1) . -732) ((marker . 1) . -732) ((marker . 1) . -732) ((marker . 1) . -735) ((marker . 1) . -735) ((marker . 1) . -732) ((marker . 1) . -732) ((marker . 1) . -735) ((marker . 1) . -735) ((marker . 1) . -732) ((marker . 1) . -732) ((marker . 1) . -732) ((marker . 1) . -732) ((marker . 1) . -560) ((marker . 1) . -732) ((marker . 1) . -732) ((marker . 1) . -732) ((marker . 1) . -732) ((marker . 1) . -732) ((marker . 1) . -732) ((marker . 1) . -732) ((marker . 1) . -732) ((marker) . -735) ((marker) . -737) ((marker) . -735) ((marker) . -737) ((marker . 1) . -732) ((marker . 1) . -732) ((marker . 1) . -731) ((marker . 1) . -732) ((marker) . -731) 732 (t 24242 38997 346966 323000) nil ("        or " . -733) ((marker . 505) . -11) ((marker . 1) . -8) ((marker . 1) . -8) ((marker . 1) . -8) ((marker . 1) . -8) ((marker . 1) . -8) ((marker . 1) . -8) ((marker . 1) . -9) ((marker . 1) . -8) ((marker . 1) . -10) ((marker . 1) . -9) ((marker) . -1) ((marker) . -4) ((marker) . -5) ((marker . 1) . -11) ((marker . 1) . -10) ((marker) . -8) ((marker) . -10) ((marker) . -10) ((marker) . -11) 744 (741 . 744) ("    " . -741) ((marker . 505) . -4) ((marker) . -1) ((marker . 1) . -4) ((marker . 1) . -4) ((marker) . -4) ((marker . 1) . -4) 745 (733 . 745) ("            " . 732) ((marker . 505) . -12) ((marker . 1) . -12) ((marker . 1) . -12) ((marker) . -1) ((marker) . -1) ((marker) . -4) ((marker) . -5) ((marker) . -8) ((marker) . -9) (744 . 745) (731 . 744) (t 24242 38967 614562 734000) 684 nil (" " . 513) ((marker) . -1) ((marker) . -1) ((marker) . -1) ((marker) . -1) ((marker) . -1) (t 24242 38964 591312 263000) nil (513 . 514) (t 24242 38937 492557 670000) nil (721 . 730) ("res" . -721) ((marker . 505) . -3) 724 (721 . 724) (706 . 722) ("s" . -706) ((marker . 505) . -1) 707 (706 . 707) (696 . 706) ("my" . -696) ((marker . 505) . -2) 698 (696 . 698) (682 . 696) (681 . 682) ("s" . -681) ((marker . 505) . -1) (" " . -682) ((marker . 505) . -1) ("=" . -683) ((marker . 505) . -1) (" " . -684) ((marker . 505) . -1) 685 (673 . 685) ("respon" . -673) ((marker . 505) . -6) 679 (676 . 679) (657 . 676) (648 . 657) (637 . 646) ("\"" . -637) (637 . 638) ("\"" . -637) (637 . 639) ("\"" . -637) (637 . 638) (nil fontified nil 635 . 637) (nil face font-lock-string-face 635 . 637) (635 . 637) ("," . -635) 636 (635 . 636) (632 . 634) (629 . 632) ("n" . -629) ((marker . 505) . -1) 630 (626 . 630) ("\"" . -626) (626 . 627) ("\"" . -626) (626 . 628) ("\"" . -626) (626 . 627) (nil fontified nil 624 . 626) (nil face font-lock-string-face 624 . 626) (624 . 626) ("," . -624) 625 (624 . 625) (615 . 623) ("\"" . -615) (615 . 616) ("\"" . -615) (615 . 617) ("\"" . -615) (614 . 616) ("[" . -614) (614 . 616) ("[" . -614) (611 . 615) ("=" . -611) 612 (611 . 612) (602 . 611) ("respo" . -602) ((marker . 505) . -5) 607 (602 . 607) (593 . 602) (t 24242 38885 935084 601000) 561 nil ("        my_survey.store_response(\"English\")
" . 553) ((marker . 506) . -44) ((marker . 505) . -8) nil (553 . 597) (t 24242 38885 935084 601000) nil ("        my_survey.store_response(\"English\")
" . 553) ((marker . 506) . -44) nil (553 . 597) 561 (t 24242 38885 935084 601000) nil (nil rear-nonsticky nil 560 . 561) ("
" . -593) (553 . 594) (nil face font-lock-string-face 552 . 553) (nil fontified t 552 . 553) (552 . 553) 513 nil ("        my_survey = AnonSurvey(question)
" . 505) ((marker . 506) . -41) ((marker . 505) . -8) 513 (t 24242 38875 671809 860000) nil (505 . 546) (t 24242 38853 633126 617000) nil ("        my_survey = AnonSurvey(question)
" . 505) ((marker . 505) . -41) nil (505 . 546) 513 (t 24242 38853 633126 617000) nil ("        question = \"What's your mother tongue?\"
" . 505) ((marker . 506) . -48) ((marker) . -48) ((marker) . -1) ((marker) . -4) ((marker) . -5) ((marker . 1) . -8) ((marker . 1) . -8) ((marker . 1) . -19) nil (505 . 553) 513 (t 24242 38853 633126 617000) nil (nil rear-nonsticky nil 512 . 513) ("
" . -552) (505 . 553) (nil face font-lock-doc-face 504 . 505) (nil fontified t 504 . 505) (504 . 505) 467 (t 24242 38846 811332 867000) nil (1 . 554) ("#!/usr/bin/env python3

import unittest
from survey import AnonSurvey


class TestAnonSurvey(unittest.TestCase):
    \"\"\"Tests for class AnonSurvey\"\"\"

    def test_store_response(self):
        \"\"\"Test a single response is stored.\"\"\"
        question = \"What's your mother tongue?\"
        my_survey = AnonSurvey(question)
        my_survey.store_response(\"English\")
        self.assertIn(\"English\", my_survey.responses)

    def test_three_responses(self):
        \"\"\"Test three reponses are stored.\"\"\"



if __name__ == \"__main__\":
    unittest.main()
" . 1) ((marker . 505) . -504) ((marker . 506) . -505) ((marker* . 684) . 50) ((marker . 675) . -554) ((marker . 505) . -504) ((marker . 1) . -507) ((marker . 1) . -507) ((marker . 1) . -507) ((marker . 1) . -507) ((marker . 1) . -363) ((marker . 1) . -363) ((marker . 1) . -363) ((marker . 1) . -363) ("        " . 505) ((marker . 505) . -7) 512 nil (504 . 513) (485 . 501) ("s" . -485) ((marker . 505) . -1) ("n" . -486) ((marker . 505) . -1) 487 (471 . 487) ("h" . -471) ((marker . 505) . -1) ("e" . -472) ((marker . 505) . -1) 473 (470 . 473) ("Thest " . -470) ((marker . 505) . -6) 476 (470 . 476) (470 . 472) (470 . 471) (nil face font-lock-doc-face 469 . 470) (nil fontified nil 469 . 470) (469 . 470) ("\"" . -469) (469 . 470) ("\"" . -469) (469 . 470) (nil face font-lock-doc-face 468 . 469) (nil fontified nil 468 . 469) (468 . 469) ("\"" . -468) (nil face font-lock-doc-face 468 . 469) (nil fontified nil 468 . 469) (468 . 469) ("\"" . -468) ("\"" . 469) (467 . 469) ("\"" . -467) (467 . 468) ("\"" . -467) (467 . 469) ("\"" . -467) (467 . 468) (457 . 467) 456 (451 . 456) ("(" . -451) (451 . 453) ("(" . -451) (442 . 452) (427 . 442) ("    " . -427) ((marker . 505) . -4) 431 (423 . 431) ("        " . 422) ((marker . 505) . -8) (430 . 431) (421 . 430) (t 24242 38784 584809 995000) 376 nil (358 . 365) ("e" . -358) ((marker . 505) . -1) 359 (357 . 359) ("\"" . -357) (357 . 358) ("\"" . -357) (357 . 359) ("\"" . -357) (357 . 358) (342 . 358) ("s" . -342) ((marker . 505) . -1) 343 (342 . 343) (332 . 342) ("my" . -332) ((marker . 505) . -2) 334 (332 . 334) (323 . 332) (t 24242 38742 88096 500000) 291 nil (1 . 427) ("#!/usr/bin/env python3

import unittest
from survey import AnonSurvey


class TestAnonSurvey(unittest.TestCase):
    \"\"\"Tests for class AnonSurvey\"\"\"

    def test_store_response(self):
        \"\"\"Test a single response is stored.\"\"\"
        question = \"What's your mother tongue?\"
        my_survey = AnonSurvey(question)
        self.assertIn(\"English\", my_survey.responses)

if __name__ == \"__main__\":
    unittest.main()
" . 1) ((marker . 505) . -405) ((marker . 506) . -425) ((marker . 746) . -322) ((marker . 746) . -280) ((marker* . 684) . 2) ((marker . 1) . -217) ((marker . 1) . -217) ((marker . 1) . -217) ((marker . 1) . -217) ((marker . 1) . -217) ((marker . 1) . -217) ((marker . 1) . -220) ((marker . 1) . -220) ((marker . 1) . -220) ((marker . 1) . -224) ((marker . 1) . -217) ((marker . 1) . -229) ((marker . 1) . -229) ((marker . 1) . -242) ((marker . 1) . -242) ((marker . 1) . -242) ((marker . 1) . -242) ((marker . 1) . -242) ((marker . 1) . -242) ((marker . 1) . -242) ((marker . 1) . -242) ((marker . 1) . -242) ((marker . 1) . -242) ((marker . 1) . -242) ((marker . 1) . -242) ((marker . 1) . -242) ((marker . 1) . -242) ((marker* . 875) . 1) ((marker . 1) . -242) ((marker . 1) . -242) ((marker . 1) . -282) ((marker . 1) . -322) ((marker . 1) . -280) ((marker . 1) . -242) ((marker . 1) . -242) ((marker . 1) . -280) ((marker . 675) . -418) ((marker . 505) . -418) ((marker . 1) . -418) ((marker . 1) . -417) ((marker . 1) . -418) ((marker . 1) . -418) 419 nil (419 . 425) ("ma" . -419) ((marker . 505) . -2) 421 (419 . 421) (410 . 419) ("un" . -410) ((marker . 505) . -2) 412 (410 . 412) (405 . 410) (nil face font-lock-string-face 404 . 405) (nil fontified t 404 . 405) (404 . 405) (401 . 403) (394 . 401) ("\"" . -394) (394 . 395) ("\"" . -394) (394 . 396) ("\"" . -394) (394 . 395) ("\"" . -394) ((marker . 505) . -1) ("\"" . 395) (394 . 395) ("\"" . -394) (394 . 395) ("\"" . -394) (394 . 396) ("\"" . -394) (390 . 395) (" = =" . -390) ((marker . 505) . -3) 394 (390 . 394) ("=" . -390) 391 (390 . 391) (382 . 390) ("__" . -382) ((marker . 505) . -2) 384 (382 . 384) ("__name__()" . 382) ((marker* . 684) . 1) nil (382 . 392) ("__n" . -382) ((marker . 505) . -3) 385 (379 . 385) nil ("    if" . -379) ((marker . 505) . -6) 385 ("_" . -385) ((marker . 505) . -1) 386 (383 . 386) ("    " . -383) ((marker . 505) . -4) 387 (379 . 387) ("        " . 378) ((marker . 505) . -8) (386 . 387) (377 . 386) (t 24242 38702 182606 786000) 332 nil (367 . 376) ("r" . -367) ((marker . 505) . -1) 368 (367 . 368) (357 . 367) ("my" . -357) ((marker . 505) . -2) 359 (357 . 359) (nil fontified nil 355 . 357) (nil face font-lock-string-face 355 . 357) (355 . 357) ("," . -355) 356 (355 . 356) (347 . 354) ("e" . -347) ((marker . 505) . -1) 348 ("n" . -348) ((marker . 505) . -1) 349 (346 . 349) ("\"" . -346) (346 . 347) ("\"" . -346) (346 . 348) ("\"" . -346) (345 . 347) ("(" . -345) (345 . 347) ("(" . -345) (345 . 346) (" " . -345) ((marker . 505) . -1) ("=" . -346) ((marker . 505) . -1) (" " . -347) ((marker . 505) . -1) 348 (345 . 348) ("=" . -345) 346 (345 . 346) (337 . 345) ("ass" . -337) ((marker . 505) . -3) 340 (337 . 340) (apply yas--snippet-revive 332 337 #s(yas--snippet nil nil #s(yas--exit 337 nil) 106 nil nil nil nil)) (apply yas--take-care-of-redo #s(yas--snippet nil nil #s(yas--exit 337 nil) 106 nil nil nil nil)) (332 . 337) ("." . 332) ((marker . 505) . -1) 333 nil (332 . 333) (323 . 332) (t 24242 38680 404788 286000) 291 nil ("    " . -291) (283 . 291) nil (283 . 287) nil ("
" . 283) ((marker . 506) . -1) ((marker . 1) . -1) nil (nil rear-nonsticky nil 283 . 284) ("
" . -316) (283 . 317) nil (282 . 283) 281 (t 24242 38673 504637 592000) nil (nil rear-nonsticky nil 281 . 282) (nil fontified nil 243 . 282) (243 . 282) 259 ("question = \"Wha\"" . 243) ((marker . 746) . -16) ((marker . 746) . -15) ((marker* . 684) . 1) ((marker . 1) . -12) ((marker . 1) . -15) ((marker . 1) . -14) ((marker . 1) . -15) ((marker . 1) . -15) ((marker . 1) . -15) ((marker . 1) . -15) ((marker . 1) . -15) ((marker . 1) . -15) ((marker . 1) . -15) ((marker . 1) . -15) ((marker . 1) . -15) ((marker . 1) . -15) ((marker . 675) . -15) ((marker . 505) . -15) ((marker . 1) . -15) ((marker) . -15) 259 (t 24242 38663 659818 35000) nil (255 . 258) (t 24242 38610 918803 282000) (254 . 255) ("\"" . -254) (254 . 255) ("\"" . -254) (254 . 256) ("\"" . -254) (251 . 255) ("=" . -251) 252 (243 . 252) ("quest " . -243) ((marker . 505) . -6) 249 ("= " . -249) ((marker . 505) . -2) 251 (248 . 251) ("=" . -248) 249 (243 . 249) ("pass" . 243) (t 24242 38595 700710 259000) nil ("that " . 203) nil (208 . 209) nil ("a" . 208) ((marker) . -1) 235 nil (230 . 236) ("o" . -230) ((marker . 505) . -1) ((marker . 1) . -1) 231 (226 . 231) ("w" . -226) ((marker . 505) . -1) ((marker . 1) . -1) ((marker) . -1) ((marker . 1) . -1) ((marker . 1) . -1) 227 (223 . 227) (t 24242 38572 219988 182000) nil (1 . 240) ("#!/usr/bin/env python3

import unittest
from survey import AnonSurvey

class TestAnonSurvey(unittest.TestCase):
    \"\"\"Tests for class AnonSurvey\"\"\"
    def test_store_response(self):
        \"\"\"Test that a single respon\"\"\"
        pass
" . 1) ((marker . 505) . -184) ((marker . 506) . -224) ((marker . 746) . -162) ((marker . 746) . -162) ((marker* . 684) . 14) ((marker . 1) . -70) ((marker . 1) . -70) ((marker . 1) . -70) ((marker . 1) . -70) ((marker . 1) . -162) ((marker . 1) . -161) ((marker . 1) . -162) ((marker . 675) . -162) ((marker . 505) . -222) 223 nil ("i" . 220) nil (219 . 222) (198 . 219) (196 . 198) (196 . 198) (196 . 197) (nil face font-lock-doc-face 195 . 196) (nil fontified nil 195 . 196) (195 . 196) ("\"" . -195) (195 . 196) ("\"" . -195) (195 . 196) (nil face font-lock-doc-face 194 . 195) (nil fontified nil 194 . 195) (194 . 195) ("\"" . -194) (nil face font-lock-doc-face 194 . 195) (nil fontified nil 194 . 195) (194 . 195) ("\"" . -194) ("\"" . 195) (193 . 195) ("\"" . -193) (193 . 194) ("\"" . -193) (193 . 195) ("\"" . -193) (193 . 194) nil (apply yas--snippet-revive 154 207 #s(yas--snippet nil (#s(yas--field 1 158 177 nil nil nil t #s(yas--field 2 178 182 nil nil nil t #s(yas--field 3 183 183 nil nil nil nil #s(yas--exit 193 nil)))) #s(yas--field 2 178 182 nil nil nil t #s(yas--field 3 183 183 nil nil nil nil #s(yas--exit 193 nil))) #s(yas--field 3 183 183 nil nil nil nil #s(yas--exit 193 nil))) #s(yas--exit 193 nil) 105 nil #s(yas--field 3 183 183 nil nil nil nil #s(yas--exit 193 nil)) nil nil)) (179 . 182) ("arg" . 179) (178 . 179) (163 . 177) (t 24242 38547 667956 899000) (159 . 163) ("funcname" . 159) (158 . 159) (apply yas--take-care-of-redo #s(yas--snippet nil (#s(yas--field 1 158 177 nil nil nil t #s(yas--field 2 178 182 nil nil nil t #s(yas--field 3 183 183 nil nil nil nil #s(yas--exit 193 nil)))) #s(yas--field 2 178 182 nil nil nil t #s(yas--field 3 183 183 nil nil nil nil #s(yas--exit 193 nil))) #s(yas--field 3 183 183 nil nil nil nil #s(yas--exit 193 nil))) #s(yas--exit 193 nil) 105 nil #s(yas--field 3 183 183 nil nil nil nil #s(yas--exit 193 nil)) nil nil)) (182 . 186) (173 . 177) (154 . 187) ("def" . 154) ((marker . 506) . -3) ((marker . 505) . -3) 157 nil (154 . 157) (t 24242 38534 606966 736000) (149 . 154) (t 24242 38530 58168 312000) (148 . 149) ("\"" . -148) (148 . 149) ("\"" . -148) (147 . 149) ("\"" . -147) (147 . 148) ("\"" . -147) (146 . 148) ("\"" . -146) (146 . 147) ("\"" . -146) (146 . 147) (136 . 146) ("Anon" . -136) ((marker . 506) . -4) ((marker . 505) . -4) 140 (123 . 140) (119 . 123) ("\"" . -119) (119 . 120) ("\"" . -119) (119 . 120) (nil fontified nil 118 . 119) (nil face font-lock-doc-face 118 . 119) (118 . 119) ("\"" . -118) (nil fontified nil 118 . 119) (nil face font-lock-doc-face 118 . 119) (118 . 119) ("\"" . -118) ((marker . 506) . -1) ("\"" . 119) ((marker . 506) . -1) (117 . 119) ("\"" . -117) (117 . 118) ("\"" . -117) (117 . 119) ("\"" . -117) (117 . 118) (112 . 117) ("
" . -112) ((marker . 505) . -1) ((marker . 506) . -1) ((marker . 675) . -1) ((marker . 505) . -1) 113 ("    " . -113) ((marker . 506) . -4) ((marker . 675) . -4) ((marker . 505) . -4) 117 ("\"" . -117) ((marker . 506) . -1) ((marker . 505) . -1) ("\"" . -118) ((marker . 506) . -1) ((marker . 505) . -1) ("\"" . -119) ((marker . 506) . -1) ((marker . 505) . -1) 120 (119 . 120) ("\"" . -119) (119 . 120) ("\"" . -119) (119 . 120) (nil fontified nil 118 . 119) (nil face font-lock-doc-face 118 . 119) (118 . 119) ("\"" . -118) (nil fontified nil 118 . 119) (nil face font-lock-doc-face 118 . 119) (118 . 119) ("\"" . -118) ((marker . 506) . -1) ("\"" . 119) ((marker . 506) . -1) (117 . 119) ("\"" . -117) (117 . 118) ("\"" . -117) (117 . 119) ("\"" . -117) (117 . 118) ("\"" . -117) ((marker . 506) . -1) ((marker . 505) . -1) ("\"" . -118) ((marker . 506) . -1) ((marker . 505) . -1) ("\"" . -119) ((marker . 506) . -1) ((marker . 505) . -1) ("\"" . -120) ((marker . 506) . -1) ((marker . 505) . -1) ("\"" . -121) ((marker . 506) . -1) ((marker . 505) . -1) ("=" . -122) ((marker . 506) . -1) ((marker . 505) . -1) 123 (121 . 123) ("\"" . -121) (121 . 122) ("\"" . -121) (120 . 122) ("\"" . -120) (120 . 121) ("\"" . -120) (119 . 121) ("\"" . -119) (119 . 120) ("\"" . -119) (119 . 120) (nil fontified nil 118 . 119) (nil face font-lock-doc-face 118 . 119) (118 . 119) ("\"" . -118) (nil fontified nil 118 . 119) (nil face font-lock-doc-face 118 . 119) (118 . 119) ("\"" . -118) ((marker . 506) . -1) ("\"" . 119) ((marker . 506) . -1) (117 . 119) ("\"" . -117) (117 . 118) ("\"" . -117) (117 . 119) ("\"" . -117) (117 . 118) (t 24242 38490 977724 235000) (111 . 117) 110 (102 . 110) (93 . 102) ("un" . -93) ((marker . 505) . -2) 95 (92 . 95) ("(" . -92) (92 . 94) ("(" . -92) (83 . 93) (82 . 83) (" " . -82) ((marker . 506) . -1) ((marker . 505) . -1) 83 (72 . 83) ("l" . -72) ((marker . 506) . -1) ((marker . 505) . -1) 73 (72 . 73) (71 . 72) (t 24242 38463 390228 424000) 71 nil ("a" . 71) ((marker . 506) . -1) nil (71 . 72) (t 24242 38463 390228 424000) nil ("
" . 71) ((marker . 746) . -1) ((marker) . -1) ((marker . 1) . -1) ((marker . 1) . -1) 1 nil (70 . 72) (t 24242 38458 774289 591000) (60 . 70) ("anon" . -60) ((marker . 506) . -4) ((marker . 505) . -4) 64 (60 . 64) (41 . 60) (40 . 41) (32 . 40) ("uni" . -32) ((marker . 506) . -3) ((marker . 505) . -3) 35 (25 . 35) nil (1 . 25) (t 24242 38383 634507 131000)) (emacs-buffer-undo-list nil (504 . 505) 459 (t 24242 39427 520908 776000) nil (648 . 649) 594 (t 24242 39425 431514 160000) nil (673 . 682) ("rps" . 673) ((marker . 675) . -2) ((marker . 505) . -2) ((marker . 675) . -1) ((marker . 675) . -1) ((marker . 675) . -1) ((marker . 675) . -2) ((marker . 675) . -1) ((marker . 675) . -3) ((marker . 675) . -2) ((marker . 675) . -2) ((marker . 675) . -2) ((marker . 675) . -2) ((marker . 675) . -2) ((marker) . -3) ((marker) . -3) ((marker . 675) . -2) ((marker . 675) . -2) ((marker . 675) . -2) ((marker . 675) . -2) (t 24242 39422 787516 389000) nil (673 . 676) ("responses" . 673) ((marker . 684) . -9) ((marker . 684) . -9) (t 24242 39419 267037 252000) nil (744 . 752) ("rps" . 744) nil (788 . 796) ("rs" . 788) (789 . 790) ("ps" . 789) nil (661 . 669) ("rps" . 661) nil (716 . 724) ("rps" . 716) ((marker . 675) . -2) ((marker . 723) . -2) ((marker . 723) . -2) ((marker . 723) . -2) ((marker . 723) . -2) ((marker . 723) . -2) ((marker . 723) . -2) ((marker . 723) . -2) (t 24242 39408 716929 586000) nil (716 . 719) ("response" . 716) nil (661 . 664) ("response" . 661) (t 24242 39403 273707 701000) nil (789 . 791) ("s" . -789) ((marker . 505) . -1) 790 (788 . 790) ("response" . 788) ((marker . 796) . -1) ((marker . 796) . -1) ((marker . 796) . -1) ((marker . 796) . -1) (t 24242 39399 688058 595000) nil (744 . 747) ("response" . 744) (t 24242 39390 797943 318000) nil (744 . 752) ("rps" . 744) nil (788 . 796) ("p" . 788) ((marker . 505) . -1) ((marker . 795) . -1) ((marker . 795) . -1) ((marker . 795) . -1) (788 . 789) ("rps" . 788) ((marker . 675) . -2) ((marker . 505) . -2) ((marker . 795) . -2) ((marker . 795) . -2) ((marker . 795) . -2) ((marker . 795) . -2) (t 24242 39387 780573 544000) nil (788 . 791) ("p" . -788) ((marker . 505) . -1) ((marker . 795) . -1) ((marker) . -1) ((marker . 795) . -1) ((marker . 795) . -1) ((marker) . -1) 789 (788 . 789) ("response" . 788) ((marker . 796) . -1) ((marker . 796) . -1) ((marker . 796) . -1) ((marker . 796) . -1) nil (744 . 747) ("response" . 744) (t 24242 39074 823768 583000) nil ("s" . 729) (t 24242 39030 889798 828000) nil (1 . 874) ("#!/usr/bin/env python3

import unittest
from survey import AnonSurvey


class TestAnonSurvey(unittest.TestCase):
    \"\"\"Tests for class AnonSurvey\"\"\"

    def test_store_response(self):
        \"\"\"Test a single response is stored.\"\"\"
        question = \"What's your mother tongue?\"
        my_survey = AnonSurvey(question)
        my_survey.store_response(\"English\")
        self.assertIn(\"English\", my_survey.responses)

    def test_three_responses(self):
        \"\"\"Test three reponses are stored.\"\"\"
        question = \"What's your mother tongue?\"
        my_survey = AnonSurvey(question)
        responses = [\"english\", \"spanish\", \"mandarin\"]
        for response in responses:
            my_survey.store_response(responses)

        for response in responses:
            self.assertIn(response, my_survey.responses)

if __name__ == \"__main__\":
    unittest.main()
" . 1) ((marker . 505) . -767) ((marker . 506) . -824) ((marker* . 684) . 50) ((marker . 675) . -779) ((marker . 505) . -821) ("            " . 825) 822 nil (814 . 823) ("res" . -814) ((marker . 505) . -3) 817 (814 . 817) (804 . 814) ("my" . -804) ((marker . 505) . -2) 806 (802 . 806) ("," . -802) 803 (802 . 803) (794 . 802) ("res" . -794) ((marker . 505) . -3) 797 (t 24242 39023 28190 32000) (794 . 797) (785 . 795) ("ass" . -785) ((marker . 505) . -3) 788 (785 . 788) (apply yas--snippet-revive 780 785 #s(yas--snippet nil nil #s(yas--exit 785 nil) 112 nil nil nil nil)) (apply yas--take-care-of-redo #s(yas--snippet nil nil #s(yas--exit 785 nil) 112 nil nil nil nil)) (780 . 785) ("." . 780) ((marker . 505) . -1) 781 nil (780 . 781) (t 24242 39014 558180 590000) (766 . 780) (757 . 766) ("respo" . -757) ((marker . 505) . -5) 762 (741 . 762) ("    " . -741) ((marker . 505) . -4) 745 (733 . 745) nil (734 . 746) ("        " . 733) ((marker . 505) . -8) (741 . 742) ("    " . -741) ((marker . 505) . -4) 745 (732 . 745) 732 nil ("
" . 732) ((marker . 506) . -1) (t 24242 39003 134395 181000) nil (1 . 781) ("#!/usr/bin/env python3

import unittest
from survey import AnonSurvey


class TestAnonSurvey(unittest.TestCase):
    \"\"\"Tests for class AnonSurvey\"\"\"

    def test_store_response(self):
        \"\"\"Test a single response is stored.\"\"\"
        question = \"What's your mother tongue?\"
        my_survey = AnonSurvey(question)
        my_survey.store_response(\"English\")
        self.assertIn(\"English\", my_survey.responses)

    def test_three_responses(self):
        \"\"\"Test three reponses are stored.\"\"\"
        question = \"What's your mother tongue?\"
        my_survey = AnonSurvey(question)
        responses = [\"english\", \"spanish\", \"mandarin\"]
        for response in responses:
            my_survey.store_response(responses)




if __name__ == \"__main__\":
    unittest.main()
" . 1) ((marker . 505) . -731) ((marker . 506) . -732) ((marker . 746) . -732) ((marker . 746) . -512) ((marker* . 684) . 50) ((marker . 1) . -552) ((marker . 1) . -592) ((marker . 1) . -512) ((marker . 1) . -466) ((marker . 1) . -551) ((marker . 1) . -512) ((marker . 1) . -512) ((marker . 1) . -512) ((marker . 1) . -512) ((marker . 1) . -504) ((marker . 1) . -504) ((marker . 1) . -504) ((marker . 1) . -512) ((marker . 1) . -504) ((marker . 1) . -512) ((marker . 1) . -512) ((marker . 1) . -512) ((marker . 1) . -512) ((marker . 1) . -560) ((marker . 1) . -512) ((marker . 1) . -592) ((marker . 1) . -560) ((marker . 1) . -560) ((marker . 1) . -560) ((marker . 1) . -560) ((marker . 1) . -560) ((marker . 1) . -560) ((marker . 1) . -512) ((marker . 1) . -512) ((marker . 675) . -732) ((marker . 505) . -731) ((marker . 1) . -512) ((marker . 1) . -512) ((marker . 1) . -512) ((marker . 1) . -512) ((marker . 1) . -560) ((marker . 1) . -512) ((marker . 1) . -601) ((marker . 1) . -560) ((marker . 1) . -656) ((marker . 1) . -601) ((marker . 1) . -691) ((marker . 1) . -656) ((marker . 1) . -729) ((marker . 1) . -691) ((marker . 1) . -729) ((marker . 1) . -729) ((marker . 1) . -601) ((marker . 1) . -601) ((marker . 1) . -613) ((marker . 1) . -601) ((marker . 1) . -601) ((marker . 1) . -613) ((marker . 1) . -601) ((marker . 1) . -601) ((marker . 1) . -613) ((marker . 1) . -735) ((marker . 1) . -735) ((marker . 1) . -729) ((marker . 1) . -729) ((marker . 1) . -683) ((marker . 1) . -729) ((marker . 1) . -683) ((marker . 1) . -683) ((marker . 1) . -683) ((marker . 1) . -683) ((marker . 1) . -683) ((marker . 1) . -683) ((marker . 1) . -683) ((marker . 1) . -683) ((marker . 1) . -683) ((marker . 1) . -683) ((marker . 1) . -683) ((marker . 1) . -683) ((marker . 1) . -683) ((marker . 1) . -683) ((marker . 1) . -683) ((marker . 1) . -683) ((marker . 1) . -683) ((marker . 1) . -683) ((marker . 1) . -683) ((marker . 1) . -683) ((marker . 1) . -683) ((marker . 1) . -683) ((marker . 1) . -683) ((marker . 1) . -683) ((marker . 1) . -683) ((marker . 1) . -683) ((marker . 1) . -648) ((marker . 1) . -683) ((marker . 1) . -683) ((marker . 1) . -648) ((marker . 1) . -731) ((marker . 1) . -695) ((marker . 1) . -695) ((marker . 1) . -731) ((marker . 1) . -731) ((marker . 1) . -683) ((marker . 1) . -735) ((marker . 1) . -735) ((marker* . 875) . 51) ((marker . 1) . -732) ((marker . 1) . -695) ((marker . 1) . -695) ((marker . 1) . -732) ((marker . 1) . -732) ((marker . 1) . -731) ((marker . 1) . -732) ((marker . 1) . -695) ((marker . 1) . -695) ((marker . 1) . -732) ((marker . 1) . -732) ((marker . 1) . -732) ((marker . 1) . -735) ((marker . 1) . -735) ((marker . 1) . -732) ((marker . 1) . -732) ((marker . 1) . -732) ((marker . 1) . -732) ((marker . 1) . -732) ((marker . 1) . -732) ((marker . 1) . -735) ((marker . 1) . -735) ((marker . 1) . -732) ((marker . 1) . -732) ((marker . 1) . -735) ((marker . 1) . -735) ((marker . 1) . -732) ((marker . 1) . -732) ((marker . 1) . -732) ((marker . 1) . -732) ((marker . 1) . -560) ((marker . 1) . -732) ((marker . 1) . -732) ((marker . 1) . -732) ((marker . 1) . -732) ((marker . 1) . -732) ((marker . 1) . -732) ((marker . 1) . -732) ((marker . 1) . -732) ((marker . 1) . -732) ((marker . 1) . -732) ((marker . 1) . -731) ((marker . 1) . -732) 732 nil (1 . 783) ("#!/usr/bin/env python3

import unittest
from survey import AnonSurvey


class TestAnonSurvey(unittest.TestCase):
    \"\"\"Tests for class AnonSurvey\"\"\"

    def test_store_response(self):
        \"\"\"Test a single response is stored.\"\"\"
        question = \"What's your mother tongue?\"
        my_survey = AnonSurvey(question)
        my_survey.store_response(\"English\")
        self.assertIn(\"English\", my_survey.responses)

    def test_three_responses(self):
        \"\"\"Test three reponses are stored.\"\"\"
        question = \"What's your mother tongue?\"
        my_survey = AnonSurvey(question)
        responses = [\"english\", \"spanish\", \"mandarin\"]
        for response in responses:
            my_survey.store_response(responses)


if __name__ == \"__main__\":
    unittest.main()
" . 1) ((marker . 506) . -732) ((marker . 746) . -732) ((marker* . 684) . 49) ((marker . 505) . -731) ((marker . 1) . -117) ((marker . 1) . -117) ((marker . 1) . -117) ((marker . 1) . -117) ((marker . 1) . -149) ((marker . 1) . -117) ((marker . 1) . -72) ((marker . 1) . -112) ((marker . 1) . -72) ((marker . 1) . -112) ((marker . 1) . -72) ((marker . 1) . -72) ((marker . 1) . -72) ((marker . 1) . -72) ((marker . 1) . -72) ((marker . 1) . -194) ((marker . 1) . -194) ((marker . 1) . -194) ((marker . 1) . -194) ((marker . 1) . -233) ((marker . 1) . -194) ((marker . 1) . -155) ((marker . 1) . -185) ((marker . 1) . -155) ((marker . 1) . -185) ((marker . 1) . -155) ((marker . 1) . -155) ((marker . 1) . -155) ((marker . 1) . -155) ((marker . 1) . -155) ((marker . 1) . -242) ((marker . 1) . -242) ((marker . 1) . -253) ((marker . 1) . -331) ((marker . 1) . -331) ((marker . 1) . -375) ((marker . 1) . -375) ((marker . 1) . -466) ((marker . 1) . -466) ((marker . 1) . -466) ((marker . 1) . -466) ((marker . 1) . -503) ((marker . 1) . -466) ((marker . 1) . -426) ((marker . 1) . -457) ((marker . 1) . -426) ((marker . 1) . -457) ((marker . 1) . -426) ((marker . 1) . -426) ((marker . 1) . -426) ((marker . 1) . -426) ((marker . 1) . -426) ((marker . 1) . -512) ((marker . 1) . -512) ((marker . 1) . -523) ((marker . 1) . -601) ((marker . 1) . -601) ((marker . 1) . -613) ((marker . 1) . -601) ((marker . 1) . -601) ((marker . 1) . -613) ((marker . 1) . -601) ((marker . 1) . -601) ((marker . 1) . -613) (t 24242 38999 965582 445000) (1 . 732) nil ("
" . 1) ((marker . 505) . -1) ((marker . 505) . -1) nil (1 . 2) 1 nil ("#!/usr/bin/env python3

import unittest
from survey import AnonSurvey


class TestAnonSurvey(unittest.TestCase):
    \"\"\"Tests for class AnonSurvey\"\"\"

    def test_store_response(self):
        \"\"\"Test a single response is stored.\"\"\"
        question = \"What's your mother tongue?\"
        my_survey = AnonSurvey(question)
        my_survey.store_response(\"English\")
        self.assertIn(\"English\", my_survey.responses)

    def test_three_responses(self):
        \"\"\"Test three reponses are stored.\"\"\"
        question = \"What's your mother tongue?\"
        my_survey = AnonSurvey(question)
        responses = [\"english\", \"spanish\", \"mandarin\"]
        for response in responses:
            my_survey.store_response(responses)
" . 1) ((marker . 505) . -731) ((marker . 1) . -117) ((marker . 1) . -117) ((marker . 1) . -117) ((marker . 1) . -117) ((marker . 1) . -149) ((marker . 1) . -117) ((marker . 1) . -72) ((marker . 1) . -112) ((marker . 1) . -72) ((marker . 1) . -112) ((marker . 1) . -72) ((marker . 1) . -72) ((marker . 1) . -72) ((marker . 1) . -72) ((marker . 1) . -72) ((marker . 1) . -194) ((marker . 1) . -194) ((marker . 1) . -194) ((marker . 1) . -194) ((marker . 1) . -233) ((marker . 1) . -194) ((marker . 1) . -155) ((marker . 1) . -185) ((marker . 1) . -155) ((marker . 1) . -185) ((marker . 1) . -155) ((marker . 1) . -155) ((marker . 1) . -155) ((marker . 1) . -155) ((marker . 1) . -155) ((marker . 1) . -242) ((marker . 1) . -242) ((marker . 1) . -253) ((marker . 1) . -331) ((marker . 1) . -331) ((marker . 1) . -375) ((marker . 1) . -375) ((marker . 1) . -466) ((marker . 1) . -466) ((marker . 1) . -466) ((marker . 1) . -466) ((marker . 1) . -503) ((marker . 1) . -466) ((marker . 1) . -426) ((marker . 1) . -457) ((marker . 1) . -426) ((marker . 1) . -457) ((marker . 1) . -426) ((marker . 1) . -426) ((marker . 1) . -426) ((marker . 1) . -426) ((marker . 1) . -426) ((marker . 1) . -512) ((marker . 1) . -512) ((marker . 1) . -523) ((marker . 1) . -601) ((marker . 1) . -601) ((marker . 1) . -613) ((marker . 1) . -601) ((marker . 1) . -601) ((marker . 1) . -613) ((marker . 1) . -601) ((marker . 1) . -601) ((marker . 1) . -613) ((marker) . -683) ((marker) . -684) ((marker) . -687) ((marker) . -688) ((marker) . -691) ((marker) . -692) ((marker) . -648) ((marker) . -649) ((marker) . -652) ((marker) . -653) ((marker) . -593) ((marker) . -594) ((marker) . -597) ((marker) . -598) ((marker) . -552) ((marker) . -553) ((marker) . -556) ((marker) . -557) ((marker) . -504) ((marker) . -505) ((marker) . -508) ((marker) . -509) ((marker) . -458) ((marker) . -459) ((marker) . -462) ((marker) . -463) ((marker) . -422) ((marker) . -423) ((marker) . -367) ((marker) . -368) ((marker) . -371) ((marker) . -372) ((marker) . -323) ((marker) . -324) ((marker) . -327) ((marker) . -328) ((marker) . -282) ((marker) . -283) ((marker) . -286) ((marker) . -287) ((marker) . -234) ((marker) . -235) ((marker) . -238) ((marker) . -239) ((marker) . -186) ((marker) . -187) ((marker) . -190) ((marker) . -191) ((marker) . -151) ((marker) . -152) ((marker) . -113) ((marker) . -114) (t 24242 38999 965582 445000) (1 . 781) ("#!/usr/bin/env python3

import unittest
from survey import AnonSurvey


class TestAnonSurvey(unittest.TestCase):
    \"\"\"Tests for class AnonSurvey\"\"\"

    def test_store_response(self):
        \"\"\"Test a single response is stored.\"\"\"
        question = \"What's your mother tongue?\"
        my_survey = AnonSurvey(question)
        my_survey.store_response(\"English\")
        self.assertIn(\"English\", my_survey.responses)

    def test_three_responses(self):
        \"\"\"Test three reponses are stored.\"\"\"
        question = \"What's your mother tongue?\"
        my_survey = AnonSurvey(question)
        responses = [\"english\", \"spanish\", \"mandarin\"]
        for response in responses:
            my_survey.store_response(responses)




if __name__ == \"__main__\":
    unittest.main()
" . 1) ((marker . 505) . -731) ((marker . 506) . -732) ((marker . 746) . -732) ((marker . 746) . -512) ((marker* . 684) . 50) ((marker . 1) . -552) ((marker . 1) . -592) ((marker . 1) . -512) ((marker . 1) . -466) ((marker . 1) . -551) ((marker . 1) . -512) ((marker . 1) . -512) ((marker . 1) . -512) ((marker . 1) . -512) ((marker . 1) . -504) ((marker . 1) . -504) ((marker . 1) . -504) ((marker . 1) . -512) ((marker . 1) . -504) ((marker . 1) . -512) ((marker . 1) . -512) ((marker . 1) . -512) ((marker . 1) . -512) ((marker . 1) . -560) ((marker . 1) . -512) ((marker . 1) . -592) ((marker . 1) . -560) ((marker . 1) . -560) ((marker . 1) . -560) ((marker . 1) . -560) ((marker . 1) . -560) ((marker . 1) . -560) ((marker . 1) . -512) ((marker . 1) . -512) ((marker . 675) . -732) ((marker . 505) . -731) ((marker) . -762) ((marker) . -763) ((marker) . -648) ((marker) . -649) ((marker) . -652) ((marker) . -653) ((marker) . -593) ((marker) . -594) ((marker) . -597) ((marker) . -598) ((marker) . -552) ((marker) . -553) ((marker) . -556) ((marker) . -557) ((marker) . -458) ((marker) . -459) ((marker) . -462) ((marker) . -463) ((marker) . -422) ((marker) . -423) ((marker) . -367) ((marker) . -368) ((marker) . -371) ((marker) . -372) ((marker) . -323) ((marker) . -324) ((marker) . -327) ((marker) . -328) ((marker) . -282) ((marker) . -283) ((marker) . -286) ((marker) . -287) ((marker) . -234) ((marker) . -235) ((marker) . -238) ((marker) . -239) ((marker) . -186) ((marker) . -187) ((marker) . -190) ((marker) . -191) ((marker) . -151) ((marker) . -152) ((marker) . -113) ((marker) . -114) ((marker) . -552) ((marker) . -553) ((marker) . -556) ((marker) . -557) ((marker) . -552) ((marker) . -553) ((marker) . -556) ((marker) . -557) ((marker) . -504) ((marker) . -505) ((marker) . -508) ((marker) . -509) ((marker . 1) . -512) ((marker . 1) . -512) ((marker . 1) . -512) ((marker . 1) . -512) ((marker . 1) . -560) ((marker . 1) . -512) ((marker . 1) . -601) ((marker . 1) . -560) ((marker . 1) . -656) ((marker . 1) . -601) ((marker . 1) . -691) ((marker . 1) . -656) ((marker . 1) . -729) ((marker . 1) . -691) ((marker . 1) . -729) ((marker . 1) . -729) ((marker . 1) . -601) ((marker . 1) . -601) ((marker . 1) . -613) ((marker . 1) . -601) ((marker . 1) . -601) ((marker . 1) . -613) ((marker . 1) . -601) ((marker . 1) . -601) ((marker . 1) . -613) ((marker . 1) . -735) ((marker . 1) . -735) ((marker . 1) . -729) ((marker . 1) . -729) ((marker . 1) . -683) ((marker . 1) . -729) ((marker . 1) . -683) ((marker . 1) . -683) ((marker . 1) . -683) ((marker . 1) . -683) ((marker . 1) . -683) ((marker . 1) . -683) ((marker . 1) . -683) ((marker . 1) . -683) ((marker . 1) . -683) ((marker . 1) . -683) ((marker . 1) . -683) ((marker . 1) . -683) ((marker . 1) . -683) ((marker . 1) . -683) ((marker . 1) . -683) ((marker . 1) . -683) ((marker . 1) . -683) ((marker . 1) . -683) ((marker . 1) . -683) ((marker . 1) . -683) ((marker . 1) . -683) ((marker . 1) . -683) ((marker . 1) . -683) ((marker . 1) . -683) ((marker . 1) . -683) ((marker . 1) . -683) ((marker . 1) . -648) ((marker . 1) . -683) ((marker . 1) . -683) ((marker . 1) . -648) ((marker) . -683) ((marker) . -684) ((marker) . -687) ((marker) . -688) ((marker) . -691) ((marker) . -692) ((marker . 1) . -731) ((marker . 1) . -695) ((marker . 1) . -695) ((marker . 1) . -731) ((marker . 1) . -731) ((marker . 1) . -683) ((marker . 1) . -735) ((marker . 1) . -735) ((marker* . 875) . 51) ((marker . 1) . -732) ((marker . 1) . -695) ((marker . 1) . -695) ((marker . 1) . -732) ((marker . 1) . -732) ((marker . 1) . -731) ((marker . 1) . -732) ((marker . 1) . -695) ((marker . 1) . -695) ((marker . 1) . -732) ((marker . 1) . -732) ((marker . 1) . -732) ((marker . 1) . -735) ((marker . 1) . -735) ((marker . 1) . -732) ((marker . 1) . -732) ((marker . 1) . -732) ((marker . 1) . -732) ((marker . 1) . -732) ((marker . 1) . -732) ((marker . 1) . -735) ((marker . 1) . -735) ((marker . 1) . -732) ((marker . 1) . -732) ((marker . 1) . -735) ((marker . 1) . -735) ((marker . 1) . -732) ((marker . 1) . -732) ((marker . 1) . -732) ((marker . 1) . -732) ((marker . 1) . -560) ((marker . 1) . -732) ((marker . 1) . -732) ((marker . 1) . -732) ((marker . 1) . -732) ((marker . 1) . -732) ((marker . 1) . -732) ((marker . 1) . -732) ((marker . 1) . -732) ((marker) . -735) ((marker) . -737) ((marker) . -735) ((marker) . -737) ((marker . 1) . -732) ((marker . 1) . -732) ((marker . 1) . -731) ((marker . 1) . -732) ((marker) . -731) 732 (t 24242 38997 346966 323000) nil ("        or " . -733) ((marker . 505) . -11) ((marker . 1) . -8) ((marker . 1) . -8) ((marker . 1) . -8) ((marker . 1) . -8) ((marker . 1) . -8) ((marker . 1) . -8) ((marker . 1) . -9) ((marker . 1) . -8) ((marker . 1) . -10) ((marker . 1) . -9) ((marker) . -1) ((marker) . -4) ((marker) . -5) ((marker . 1) . -11) ((marker . 1) . -10) ((marker) . -8) ((marker) . -10) ((marker) . -10) ((marker) . -11) 744 (741 . 744) ("    " . -741) ((marker . 505) . -4) ((marker) . -1) ((marker . 1) . -4) ((marker . 1) . -4) ((marker) . -4) ((marker . 1) . -4) 745 (733 . 745) ("            " . 732) ((marker . 505) . -12) ((marker . 1) . -12) ((marker . 1) . -12) ((marker) . -1) ((marker) . -1) ((marker) . -4) ((marker) . -5) ((marker) . -8) ((marker) . -9) (744 . 745) (731 . 744) (t 24242 38967 614562 734000) 684 nil (" " . 513) ((marker) . -1) ((marker) . -1) ((marker) . -1) ((marker) . -1) ((marker) . -1) (t 24242 38964 591312 263000) nil (513 . 514) (t 24242 38937 492557 670000) nil (721 . 730) ("res" . -721) ((marker . 505) . -3) 724 (721 . 724) (706 . 722) ("s" . -706) ((marker . 505) . -1) 707 (706 . 707) (696 . 706) ("my" . -696) ((marker . 505) . -2) 698 (696 . 698) (682 . 696) (681 . 682) ("s" . -681) ((marker . 505) . -1) (" " . -682) ((marker . 505) . -1) ("=" . -683) ((marker . 505) . -1) (" " . -684) ((marker . 505) . -1) 685 (673 . 685) ("respon" . -673) ((marker . 505) . -6) 679 (676 . 679) (657 . 676) (648 . 657) (637 . 646) ("\"" . -637) (637 . 638) ("\"" . -637) (637 . 639) ("\"" . -637) (637 . 638) (nil fontified nil 635 . 637) (nil face font-lock-string-face 635 . 637) (635 . 637) ("," . -635) 636 (635 . 636) (632 . 634) (629 . 632) ("n" . -629) ((marker . 505) . -1) 630 (626 . 630) ("\"" . -626) (626 . 627) ("\"" . -626) (626 . 628) ("\"" . -626) (626 . 627) (nil fontified nil 624 . 626) (nil face font-lock-string-face 624 . 626) (624 . 626) ("," . -624) 625 (624 . 625) (615 . 623) ("\"" . -615) (615 . 616) ("\"" . -615) (615 . 617) ("\"" . -615) (614 . 616) ("[" . -614) (614 . 616) ("[" . -614) (611 . 615) ("=" . -611) 612 (611 . 612) (602 . 611) ("respo" . -602) ((marker . 505) . -5) 607 (602 . 607) (593 . 602) (t 24242 38885 935084 601000) 561 nil ("        my_survey.store_response(\"English\")
" . 553) ((marker . 506) . -44) ((marker . 505) . -8) nil (553 . 597) (t 24242 38885 935084 601000) nil ("        my_survey.store_response(\"English\")
" . 553) ((marker . 506) . -44) nil (553 . 597) 561 (t 24242 38885 935084 601000) nil (nil rear-nonsticky nil 560 . 561) ("
" . -593) (553 . 594) (nil face font-lock-string-face 552 . 553) (nil fontified t 552 . 553) (552 . 553) 513 nil ("        my_survey = AnonSurvey(question)
" . 505) ((marker . 506) . -41) ((marker . 505) . -8) 513 (t 24242 38875 671809 860000) nil (505 . 546) (t 24242 38853 633126 617000) nil ("        my_survey = AnonSurvey(question)
" . 505) ((marker . 505) . -41) nil (505 . 546) 513 (t 24242 38853 633126 617000) nil ("        question = \"What's your mother tongue?\"
" . 505) ((marker . 506) . -48) ((marker) . -48) ((marker) . -1) ((marker) . -4) ((marker) . -5) ((marker . 1) . -8) ((marker . 1) . -8) ((marker . 1) . -19) nil (505 . 553) 513 (t 24242 38853 633126 617000) nil (nil rear-nonsticky nil 512 . 513) ("
" . -552) (505 . 553) (nil face font-lock-doc-face 504 . 505) (nil fontified t 504 . 505) (504 . 505) 467 (t 24242 38846 811332 867000) nil (1 . 554) ("#!/usr/bin/env python3

import unittest
from survey import AnonSurvey


class TestAnonSurvey(unittest.TestCase):
    \"\"\"Tests for class AnonSurvey\"\"\"

    def test_store_response(self):
        \"\"\"Test a single response is stored.\"\"\"
        question = \"What's your mother tongue?\"
        my_survey = AnonSurvey(question)
        my_survey.store_response(\"English\")
        self.assertIn(\"English\", my_survey.responses)

    def test_three_responses(self):
        \"\"\"Test three reponses are stored.\"\"\"



if __name__ == \"__main__\":
    unittest.main()
" . 1) ((marker . 505) . -504) ((marker . 506) . -505) ((marker* . 684) . 50) ((marker . 675) . -554) ((marker . 505) . -504) ((marker . 1) . -507) ((marker . 1) . -507) ((marker . 1) . -507) ((marker . 1) . -507) ((marker . 1) . -363) ((marker . 1) . -363) ((marker . 1) . -363) ((marker . 1) . -363) ("        " . 505) ((marker . 505) . -7) 512 nil (504 . 513) (485 . 501) ("s" . -485) ((marker . 505) . -1) ("n" . -486) ((marker . 505) . -1) 487 (471 . 487) ("h" . -471) ((marker . 505) . -1) ("e" . -472) ((marker . 505) . -1) 473 (470 . 473) ("Thest " . -470) ((marker . 505) . -6) 476 (470 . 476) (470 . 472) (470 . 471) (nil face font-lock-doc-face 469 . 470) (nil fontified nil 469 . 470) (469 . 470) ("\"" . -469) (469 . 470) ("\"" . -469) (469 . 470) (nil face font-lock-doc-face 468 . 469) (nil fontified nil 468 . 469) (468 . 469) ("\"" . -468) (nil face font-lock-doc-face 468 . 469) (nil fontified nil 468 . 469) (468 . 469) ("\"" . -468) ("\"" . 469) (467 . 469) ("\"" . -467) (467 . 468) ("\"" . -467) (467 . 469) ("\"" . -467) (467 . 468) (457 . 467) 456 (451 . 456) ("(" . -451) (451 . 453) ("(" . -451) (442 . 452) (427 . 442) ("    " . -427) ((marker . 505) . -4) 431 (423 . 431) ("        " . 422) ((marker . 505) . -8) (430 . 431) (421 . 430) (t 24242 38784 584809 995000) 376 nil (358 . 365) ("e" . -358) ((marker . 505) . -1) 359 (357 . 359) ("\"" . -357) (357 . 358) ("\"" . -357) (357 . 359) ("\"" . -357) (357 . 358) (342 . 358) ("s" . -342) ((marker . 505) . -1) 343 (342 . 343) (332 . 342) ("my" . -332) ((marker . 505) . -2) 334 (332 . 334) (323 . 332) (t 24242 38742 88096 500000) 291 nil (1 . 427) ("#!/usr/bin/env python3

import unittest
from survey import AnonSurvey


class TestAnonSurvey(unittest.TestCase):
    \"\"\"Tests for class AnonSurvey\"\"\"

    def test_store_response(self):
        \"\"\"Test a single response is stored.\"\"\"
        question = \"What's your mother tongue?\"
        my_survey = AnonSurvey(question)
        self.assertIn(\"English\", my_survey.responses)

if __name__ == \"__main__\":
    unittest.main()
" . 1) ((marker . 505) . -405) ((marker . 506) . -425) ((marker . 746) . -322) ((marker . 746) . -280) ((marker* . 684) . 2) ((marker . 1) . -217) ((marker . 1) . -217) ((marker . 1) . -217) ((marker . 1) . -217) ((marker . 1) . -217) ((marker . 1) . -217) ((marker . 1) . -220) ((marker . 1) . -220) ((marker . 1) . -220) ((marker . 1) . -224) ((marker . 1) . -217) ((marker . 1) . -229) ((marker . 1) . -229) ((marker . 1) . -242) ((marker . 1) . -242) ((marker . 1) . -242) ((marker . 1) . -242) ((marker . 1) . -242) ((marker . 1) . -242) ((marker . 1) . -242) ((marker . 1) . -242) ((marker . 1) . -242) ((marker . 1) . -242) ((marker . 1) . -242) ((marker . 1) . -242) ((marker . 1) . -242) ((marker . 1) . -242) ((marker* . 875) . 1) ((marker . 1) . -242) ((marker . 1) . -242) ((marker . 1) . -282) ((marker . 1) . -322) ((marker . 1) . -280) ((marker . 1) . -242) ((marker . 1) . -242) ((marker . 1) . -280) ((marker . 675) . -418) ((marker . 505) . -418) ((marker . 1) . -418) ((marker . 1) . -417) ((marker . 1) . -418) ((marker . 1) . -418) 419 nil (419 . 425) ("ma" . -419) ((marker . 505) . -2) 421 (419 . 421) (410 . 419) ("un" . -410) ((marker . 505) . -2) 412 (410 . 412) (405 . 410) (nil face font-lock-string-face 404 . 405) (nil fontified t 404 . 405) (404 . 405) (401 . 403) (394 . 401) ("\"" . -394) (394 . 395) ("\"" . -394) (394 . 396) ("\"" . -394) (394 . 395) ("\"" . -394) ((marker . 505) . -1) ("\"" . 395) (394 . 395) ("\"" . -394) (394 . 395) ("\"" . -394) (394 . 396) ("\"" . -394) (390 . 395) (" = =" . -390) ((marker . 505) . -3) 394 (390 . 394) ("=" . -390) 391 (390 . 391) (382 . 390) ("__" . -382) ((marker . 505) . -2) 384 (382 . 384) ("__name__()" . 382) ((marker* . 684) . 1) nil (382 . 392) ("__n" . -382) ((marker . 505) . -3) 385 (379 . 385) nil ("    if" . -379) ((marker . 505) . -6) 385 ("_" . -385) ((marker . 505) . -1) 386 (383 . 386) ("    " . -383) ((marker . 505) . -4) 387 (379 . 387) ("        " . 378) ((marker . 505) . -8) (386 . 387) (377 . 386) (t 24242 38702 182606 786000) 332 nil (367 . 376) ("r" . -367) ((marker . 505) . -1) 368 (367 . 368) (357 . 367) ("my" . -357) ((marker . 505) . -2) 359 (357 . 359) (nil fontified nil 355 . 357) (nil face font-lock-string-face 355 . 357) (355 . 357) ("," . -355) 356 (355 . 356) (347 . 354) ("e" . -347) ((marker . 505) . -1) 348 ("n" . -348) ((marker . 505) . -1) 349 (346 . 349) ("\"" . -346) (346 . 347) ("\"" . -346) (346 . 348) ("\"" . -346) (345 . 347) ("(" . -345) (345 . 347) ("(" . -345) (345 . 346) (" " . -345) ((marker . 505) . -1) ("=" . -346) ((marker . 505) . -1) (" " . -347) ((marker . 505) . -1) 348 (345 . 348) ("=" . -345) 346 (345 . 346) (337 . 345) ("ass" . -337) ((marker . 505) . -3) 340 (337 . 340) (apply yas--snippet-revive 332 337 #s(yas--snippet nil nil #s(yas--exit 337 nil) 106 nil nil nil nil)) (apply yas--take-care-of-redo #s(yas--snippet nil nil #s(yas--exit 337 nil) 106 nil nil nil nil)) (332 . 337) ("." . 332) ((marker . 505) . -1) 333 nil (332 . 333) (323 . 332) (t 24242 38680 404788 286000) 291 nil ("    " . -291) (283 . 291) nil (283 . 287) nil ("
" . 283) ((marker . 506) . -1) ((marker . 1) . -1) nil (nil rear-nonsticky nil 283 . 284) ("
" . -316) (283 . 317) nil (282 . 283) 281 (t 24242 38673 504637 592000) nil (nil rear-nonsticky nil 281 . 282) (nil fontified nil 243 . 282) (243 . 282) 259 ("question = \"Wha\"" . 243) ((marker . 746) . -16) ((marker . 746) . -15) ((marker* . 684) . 1) ((marker . 1) . -12) ((marker . 1) . -15) ((marker . 1) . -14) ((marker . 1) . -15) ((marker . 1) . -15) ((marker . 1) . -15) ((marker . 1) . -15) ((marker . 1) . -15) ((marker . 1) . -15) ((marker . 1) . -15) ((marker . 1) . -15) ((marker . 1) . -15) ((marker . 1) . -15) ((marker . 675) . -15) ((marker . 505) . -15) ((marker . 1) . -15) ((marker) . -15) 259 (t 24242 38663 659818 35000) nil (255 . 258) (t 24242 38610 918803 282000) (254 . 255) ("\"" . -254) (254 . 255) ("\"" . -254) (254 . 256) ("\"" . -254) (251 . 255) ("=" . -251) 252 (243 . 252) ("quest " . -243) ((marker . 505) . -6) 249 ("= " . -249) ((marker . 505) . -2) 251 (248 . 251) ("=" . -248) 249 (243 . 249) ("pass" . 243) (t 24242 38595 700710 259000) nil ("that " . 203) nil (208 . 209) nil ("a" . 208) ((marker) . -1) 235 nil (230 . 236) ("o" . -230) ((marker . 505) . -1) ((marker . 1) . -1) 231 (226 . 231) ("w" . -226) ((marker . 505) . -1) ((marker . 1) . -1) ((marker) . -1) ((marker . 1) . -1) ((marker . 1) . -1) 227 (223 . 227) (t 24242 38572 219988 182000) nil (1 . 240) ("#!/usr/bin/env python3

import unittest
from survey import AnonSurvey

class TestAnonSurvey(unittest.TestCase):
    \"\"\"Tests for class AnonSurvey\"\"\"
    def test_store_response(self):
        \"\"\"Test that a single respon\"\"\"
        pass
" . 1) ((marker . 505) . -184) ((marker . 506) . -224) ((marker . 746) . -162) ((marker . 746) . -162) ((marker* . 684) . 14) ((marker . 1) . -70) ((marker . 1) . -70) ((marker . 1) . -70) ((marker . 1) . -70) ((marker . 1) . -162) ((marker . 1) . -161) ((marker . 1) . -162) ((marker . 675) . -162) ((marker . 505) . -222) 223 nil ("i" . 220) nil (219 . 222) (198 . 219) (196 . 198) (196 . 198) (196 . 197) (nil face font-lock-doc-face 195 . 196) (nil fontified nil 195 . 196) (195 . 196) ("\"" . -195) (195 . 196) ("\"" . -195) (195 . 196) (nil face font-lock-doc-face 194 . 195) (nil fontified nil 194 . 195) (194 . 195) ("\"" . -194) (nil face font-lock-doc-face 194 . 195) (nil fontified nil 194 . 195) (194 . 195) ("\"" . -194) ("\"" . 195) (193 . 195) ("\"" . -193) (193 . 194) ("\"" . -193) (193 . 195) ("\"" . -193) (193 . 194) nil (apply yas--snippet-revive 154 207 #s(yas--snippet nil (#s(yas--field 1 158 177 nil nil nil t #s(yas--field 2 178 182 nil nil nil t #s(yas--field 3 183 183 nil nil nil nil #s(yas--exit 193 nil)))) #s(yas--field 2 178 182 nil nil nil t #s(yas--field 3 183 183 nil nil nil nil #s(yas--exit 193 nil))) #s(yas--field 3 183 183 nil nil nil nil #s(yas--exit 193 nil))) #s(yas--exit 193 nil) 105 nil #s(yas--field 3 183 183 nil nil nil nil #s(yas--exit 193 nil)) nil nil)) (179 . 182) ("arg" . 179) (178 . 179) (163 . 177) (t 24242 38547 667956 899000) (159 . 163) ("funcname" . 159) (158 . 159) (apply yas--take-care-of-redo #s(yas--snippet nil (#s(yas--field 1 158 177 nil nil nil t #s(yas--field 2 178 182 nil nil nil t #s(yas--field 3 183 183 nil nil nil nil #s(yas--exit 193 nil)))) #s(yas--field 2 178 182 nil nil nil t #s(yas--field 3 183 183 nil nil nil nil #s(yas--exit 193 nil))) #s(yas--field 3 183 183 nil nil nil nil #s(yas--exit 193 nil))) #s(yas--exit 193 nil) 105 nil #s(yas--field 3 183 183 nil nil nil nil #s(yas--exit 193 nil)) nil nil)) (182 . 186) (173 . 177) (154 . 187) ("def" . 154) ((marker . 506) . -3) ((marker . 505) . -3) 157 nil (154 . 157) (t 24242 38534 606966 736000) (149 . 154) (t 24242 38530 58168 312000) (148 . 149) ("\"" . -148) (148 . 149) ("\"" . -148) (147 . 149) ("\"" . -147) (147 . 148) ("\"" . -147) (146 . 148) ("\"" . -146) (146 . 147) ("\"" . -146) (146 . 147) (136 . 146) ("Anon" . -136) ((marker . 506) . -4) ((marker . 505) . -4) 140 (123 . 140) (119 . 123) ("\"" . -119) (119 . 120) ("\"" . -119) (119 . 120) (nil fontified nil 118 . 119) (nil face font-lock-doc-face 118 . 119) (118 . 119) ("\"" . -118) (nil fontified nil 118 . 119) (nil face font-lock-doc-face 118 . 119) (118 . 119) ("\"" . -118) ((marker . 506) . -1) ("\"" . 119) ((marker . 506) . -1) (117 . 119) ("\"" . -117) (117 . 118) ("\"" . -117) (117 . 119) ("\"" . -117) (117 . 118) (112 . 117) ("
" . -112) ((marker . 505) . -1) ((marker . 506) . -1) ((marker . 675) . -1) ((marker . 505) . -1) 113 ("    " . -113) ((marker . 506) . -4) ((marker . 675) . -4) ((marker . 505) . -4) 117 ("\"" . -117) ((marker . 506) . -1) ((marker . 505) . -1) ("\"" . -118) ((marker . 506) . -1) ((marker . 505) . -1) ("\"" . -119) ((marker . 506) . -1) ((marker . 505) . -1) 120 (119 . 120) ("\"" . -119) (119 . 120) ("\"" . -119) (119 . 120) (nil fontified nil 118 . 119) (nil face font-lock-doc-face 118 . 119) (118 . 119) ("\"" . -118) (nil fontified nil 118 . 119) (nil face font-lock-doc-face 118 . 119) (118 . 119) ("\"" . -118) ((marker . 506) . -1) ("\"" . 119) ((marker . 506) . -1) (117 . 119) ("\"" . -117) (117 . 118) ("\"" . -117) (117 . 119) ("\"" . -117) (117 . 118) ("\"" . -117) ((marker . 506) . -1) ((marker . 505) . -1) ("\"" . -118) ((marker . 506) . -1) ((marker . 505) . -1) ("\"" . -119) ((marker . 506) . -1) ((marker . 505) . -1) ("\"" . -120) ((marker . 506) . -1) ((marker . 505) . -1) ("\"" . -121) ((marker . 506) . -1) ((marker . 505) . -1) ("=" . -122) ((marker . 506) . -1) ((marker . 505) . -1) 123 (121 . 123) ("\"" . -121) (121 . 122) ("\"" . -121) (120 . 122) ("\"" . -120) (120 . 121) ("\"" . -120) (119 . 121) ("\"" . -119) (119 . 120) ("\"" . -119) (119 . 120) (nil fontified nil 118 . 119) (nil face font-lock-doc-face 118 . 119) (118 . 119) ("\"" . -118) (nil fontified nil 118 . 119) (nil face font-lock-doc-face 118 . 119) (118 . 119) ("\"" . -118) ((marker . 506) . -1) ("\"" . 119) ((marker . 506) . -1) (117 . 119) ("\"" . -117) (117 . 118) ("\"" . -117) (117 . 119) ("\"" . -117) (117 . 118) (t 24242 38490 977724 235000) (111 . 117) 110 (102 . 110) (93 . 102) ("un" . -93) ((marker . 505) . -2) 95 (92 . 95) ("(" . -92) (92 . 94) ("(" . -92) (83 . 93) (82 . 83) (" " . -82) ((marker . 506) . -1) ((marker . 505) . -1) 83 (72 . 83) ("l" . -72) ((marker . 506) . -1) ((marker . 505) . -1) 73 (72 . 73) (71 . 72) (t 24242 38463 390228 424000) 71 nil ("a" . 71) ((marker . 506) . -1) nil (71 . 72) (t 24242 38463 390228 424000) nil ("
" . 71) ((marker . 746) . -1) ((marker) . -1) ((marker . 1) . -1) ((marker . 1) . -1) 1 nil (70 . 72) (t 24242 38458 774289 591000) (60 . 70) ("anon" . -60) ((marker . 506) . -4) ((marker . 505) . -4) 64 (60 . 64) (41 . 60) (40 . 41) (32 . 40) ("uni" . -32) ((marker . 506) . -3) ((marker . 505) . -3) 35 (25 . 35) nil (1 . 25) (t 24242 38383 634507 131000)) (emacs-undo-equiv-table (3 . -1) (-1 . -9) (-2 . -8) (-3 . -7) (-4 . -6) (-9 . -13) (-10 . -12) (-20 . -24) (-21 . -23) (-28 . -32) (-29 . -31) (-30 . -32) (-34 . -36) (-35 . -37) (-37 . -39) (-65 . -67) (-57 . -59)))