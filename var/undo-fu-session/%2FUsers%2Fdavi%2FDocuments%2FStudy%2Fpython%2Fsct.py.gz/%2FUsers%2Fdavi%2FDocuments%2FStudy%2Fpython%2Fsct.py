((buffer-size . 648) (buffer-checksum . "aca9dab41c607028d1d7fc8f8f1125e5c8ad1289"))
((emacs-pending-undo-list (26 . 649) ("import items
import world


class Player:
    def __init__(self):
        self.inventory = [items.Rock(),
                          items.Dagger(),
                          items.CrustyBread()]
        self.x = world.start_tile_location[0]
        self.y = world.start_tile_location[1]
        self.hp = 100
        self.gold = 5
        self.victory = False

    def is_alive(self):
        return self.hp > 0

    def print_inventory(self):
        print(\"Inventory:\")
        for item in self.inventory:
            print('* ' + str(item))
        print(\"Gold: {}\".format(self.gold))

    def heal(self):
        consumables = [item for item in self.inventory
                       if isinstance(item, items.Consumable)]
        if not consumables:
            print(\"You don't have any items to heal you!\")
            return

        for i, item in enumerate(consumables, 1):
            print(\"Choose an item to use to heal: \")
            print(\"{}. {}\".format(i, item))

        valid = False
        while not valid:
            choice = input(\"\")
            try:
                to_eat = consumables[int(choice) - 1]
                self.hp = min(100, self.hp + to_eat.healing_value)
                self.inventory.remove(to_eat)
                print(\"Current HP: {}\".format(self.hp))
                valid = True
            except (ValueError, IndexError):
                print(\"Invalid choice, try again.\")

    def most_powerful_weapon(self):
        max_damage = 0
        best_weapon = None
        for item in self.inventory:
            try:
                if item.damage > max_damage:
                    best_weapon = item
                    max_damage = item.damage
            except AttributeError:
                pass

        return best_weapon

    def move(self, dx, dy):
        self.x += dx
        self.y += dy

    def move_north(self):
        self.move(dx=0, dy=-1)

    def move_south(self):
        self.move(dx=0, dy=1)

    def move_east(self):
        self.move(dx=1, dy=0)

    def move_west(self):
        self.move(dx=-1, dy=0)

    def attack(self):
        best_weapon = self.most_powerful_weapon()
        room = world.tile_at(self.x, self.y)
        enemy = room.enemy
        print(\"You use {} against {}!\".format(best_weapon.name, enemy.name))
        enemy.hp -= best_weapon.damage
        if not enemy.is_alive():
            print(\"You killed {}!\".format(enemy.name))
        else:
            print(\"{} HP is {}.\".format(enemy.name, enemy.hp))

    def trade(self):
        room = world.tile_at(self.x, self.y)
        room.check_if_trade(self)" . 26) (nil fontified nil 2595 . 2596) (nil fontified nil 2594 . 2595) (nil fontified nil 2593 . 2594) (nil fontified nil 2592 . 2593) (nil fontified nil 2588 . 2592) (nil fontified nil 2587 . 2588) (nil fontified nil 2586 . 2587) (nil fontified nil 2585 . 2586) (nil fontified nil 2584 . 2585) (nil fontified nil 2580 . 2584) (nil fontified nil 2579 . 2580) (nil fontified nil 2572 . 2579) (nil fontified nil 2571 . 2572) (nil fontified nil 2565 . 2571) (nil fontified nil 2564 . 2565) (nil fontified nil 2563 . 2564) (nil fontified nil 2559 . 2563) (nil fontified nil 2551 . 2559) (nil fontified nil 2550 . 2551) (nil fontified nil 2549 . 2550) (nil fontified nil 2548 . 2549) (nil fontified nil 2546 . 2548) (nil fontified nil 2544 . 2546) (nil fontified nil 2543 . 2544) (nil fontified nil 2538 . 2543) (nil fontified nil 2537 . 2538) (nil fontified nil 2534 . 2537) (nil fontified nil 2529 . 2534) (nil fontified nil 2528 . 2529) (nil fontified nil 2527 . 2528) (nil fontified nil 2526 . 2527) (nil fontified nil 2524 . 2526) (nil fontified nil 2523 . 2524) (nil fontified nil 2517 . 2523) (nil fontified nil 2516 . 2517) (nil fontified nil 2512 . 2516) (nil fontified nil 2511 . 2512) (nil fontified nil 2506 . 2511) (nil fontified nil 2505 . 2506) (nil fontified nil 2499 . 2505) (nil fontified nil 2498 . 2499) (nil fontified nil 2497 . 2498) (nil fontified nil 2485 . 2497) (nil fontified nil 2484 . 2485) (nil fontified nil 2483 . 2484) (nil fontified nil 2478 . 2483) (nil fontified nil 2465 . 2478) (nil fontified nil 2464 . 2465) (nil fontified nil 2460 . 2464) (nil fontified nil 2451 . 2460) (nil fontified nil 2450 . 2451) (nil fontified nil 2449 . 2450) (nil fontified nil 2445 . 2449) (nil fontified nil 2444 . 2445) (nil fontified nil 2439 . 2444) (nil fontified nil 2438 . 2439) (nil fontified nil 2432 . 2438) (nil fontified nil 2431 . 2432) (nil fontified nil 2430 . 2431) (nil fontified nil 2416 . 2430) (nil fontified nil 2415 . 2416) (nil fontified nil 2414 . 2415) (nil fontified nil 2409 . 2414) (nil fontified nil 2396 . 2409) (nil fontified nil 2395 . 2396) (nil fontified nil 2394 . 2395) (nil fontified nil 2393 . 2394) (nil fontified nil 2385 . 2393) (nil fontified nil 2384 . 2385) (nil fontified nil 2378 . 2384) (nil fontified nil 2375 . 2378) (nil fontified nil 2374 . 2375) (nil fontified nil 2372 . 2374) (nil fontified nil 2357 . 2372) (nil fontified nil 2356 . 2357) (nil fontified nil 2344 . 2356) (nil fontified nil 2343 . 2344) (nil fontified nil 2342 . 2343) (nil fontified nil 2339 . 2342) (nil fontified nil 2338 . 2339) (nil fontified nil 2324 . 2338) (nil fontified nil 2323 . 2324) (nil fontified nil 2322 . 2323) (nil fontified nil 2318 . 2322) (nil fontified nil 2317 . 2318) (nil fontified nil 2311 . 2317) (nil fontified nil 2310 . 2311) (nil fontified nil 2306 . 2310) (nil fontified nil 2305 . 2306) (nil fontified nil 2294 . 2305) (nil fontified nil 2293 . 2294) (nil fontified nil 2287 . 2293) (nil fontified nil 2286 . 2287) (nil fontified nil 2285 . 2286) (nil fontified nil 2263 . 2285) (nil fontified nil 2262 . 2263) (nil fontified nil 2261 . 2262) (nil fontified nil 2256 . 2261) (nil fontified nil 2242 . 2256) (nil fontified nil 2241 . 2242) (nil fontified nil 2236 . 2241) (nil fontified nil 2235 . 2236) (nil fontified nil 2234 . 2235) (nil fontified nil 2229 . 2234) (nil fontified nil 2220 . 2229) (nil fontified nil 2219 . 2220) (nil fontified nil 2218 . 2219) (nil fontified nil 2217 . 2218) (nil fontified nil 2213 . 2217) (nil fontified nil 2212 . 2213) (nil fontified nil 2211 . 2212) (nil fontified nil 2210 . 2211) (nil fontified nil 2209 . 2210) (nil fontified nil 2205 . 2209) (nil fontified nil 2204 . 2205) (nil fontified nil 2197 . 2204) (nil fontified nil 2196 . 2197) (nil fontified nil 2190 . 2196) (nil fontified nil 2189 . 2190) (nil fontified nil 2188 . 2189) (nil fontified nil 2184 . 2188) (nil fontified nil 2175 . 2184) (nil fontified nil 2174 . 2175) (nil fontified nil 2173 . 2174) (nil fontified nil 2153 . 2173) (nil fontified nil 2152 . 2153) (nil fontified nil 2148 . 2152) (nil fontified nil 2147 . 2148) (nil fontified nil 2146 . 2147) (nil fontified nil 2145 . 2146) (nil fontified nil 2134 . 2145) (nil fontified nil 2125 . 2134) (nil fontified nil 2124 . 2125) (nil fontified nil 2123 . 2124) (nil fontified nil 2119 . 2123) (nil fontified nil 2118 . 2119) (nil fontified nil 2112 . 2118) (nil fontified nil 2111 . 2112) (nil fontified nil 2108 . 2111) (nil fontified nil 2102 . 2108) (nil fontified nil 2101 . 2102) (nil fontified nil 2100 . 2101) (nil fontified nil 2099 . 2100) (nil fontified nil 2096 . 2099) (nil fontified nil 2095 . 2096) (nil fontified nil 2094 . 2095) (nil fontified nil 2093 . 2094) (nil fontified nil 2092 . 2093) (nil fontified nil 2090 . 2092) (nil fontified nil 2089 . 2090) (nil fontified nil 2085 . 2089) (nil fontified nil 2084 . 2085) (nil fontified nil 2080 . 2084) (nil fontified nil 2071 . 2080) (nil fontified nil 2070 . 2071) (nil fontified nil 2069 . 2070) (nil fontified nil 2065 . 2069) (nil fontified nil 2064 . 2065) (nil fontified nil 2055 . 2064) (nil fontified nil 2054 . 2055) (nil fontified nil 2051 . 2054) (nil fontified nil 2046 . 2051) (nil fontified nil 2045 . 2046) (nil fontified nil 2044 . 2045) (nil fontified nil 2043 . 2044) (nil fontified nil 2042 . 2043) (nil fontified nil 2039 . 2042) (nil fontified nil 2038 . 2039) (nil fontified nil 2037 . 2038) (nil fontified nil 2036 . 2037) (nil fontified nil 2034 . 2036) (nil fontified nil 2033 . 2034) (nil fontified nil 2029 . 2033) (nil fontified nil 2028 . 2029) (nil fontified nil 2024 . 2028) (nil fontified nil 2016 . 2024) (nil fontified nil 1449 . 2016) (nil fontified nil 1448 . 1449) (nil fontified nil 1422 . 1448) (nil fontified nil 1421 . 1422) (nil fontified nil 1307 . 1421) (nil fontified nil 1306 . 1307) (nil fontified nil 1292 . 1306) (nil fontified nil 1291 . 1292) (nil fontified nil 1083 . 1291) (nil fontified nil 1082 . 1083) (nil fontified nil 1081 . 1082) (nil fontified nil 1054 . 1081) (nil fontified t 1053 . 1054) (nil fontified t 1052 . 1053) (nil fontified t 1046 . 1052) (nil fontified t 1043 . 1046) (nil fontified t 1042 . 1043) (nil fontified t 1037 . 1042) (nil fontified t 1034 . 1037) (nil fontified t 1028 . 1034) (nil fontified t 1023 . 1028) (nil fontified t 1022 . 1023) (nil fontified t 1021 . 1022) (nil fontified t 1020 . 1021) (nil fontified t 1015 . 1020) (nil fontified t 1005 . 1015) (nil fontified t 1004 . 1005) (nil fontified t 1003 . 1004) (nil fontified t 998 . 1003) (nil fontified t 997 . 998) (nil fontified t 996 . 997) (nil fontified t 995 . 996) (nil fontified t 989 . 995) (nil fontified t 988 . 989) (nil fontified t 987 . 988) (nil fontified t 981 . 987) (nil fontified t 980 . 981) (nil fontified t 979 . 980) (nil fontified t 974 . 979) (nil fontified t 961 . 974) (nil fontified t 960 . 961) (nil fontified t 959 . 960) (nil fontified t 928 . 959) (nil fontified t 927 . 928) (nil fontified t 926 . 927) (nil fontified t 921 . 926) (nil fontified t 908 . 921) (nil fontified t 907 . 908) (nil fontified t 906 . 907) (nil fontified t 905 . 906) (nil fontified t 904 . 905) (nil fontified t 903 . 904) (nil fontified t 892 . 903) (nil fontified t 891 . 892) (nil fontified t 882 . 891) (nil fontified t 881 . 882) (nil fontified t 879 . 881) (nil fontified t 873 . 879) (nil fontified t 872 . 873) (nil fontified t 870 . 872) (nil fontified t 867 . 870) (nil fontified t 857 . 867) (nil fontified t 851 . 857) (nil fontified t 838 . 851) (nil fontified t 837 . 838) (nil fontified t 836 . 837) (nil fontified t 799 . 836) (nil fontified t 798 . 799) (nil fontified t 797 . 798) (nil fontified t 792 . 797) (nil fontified t 779 . 792) (nil fontified t 778 . 779) (nil fontified t 766 . 778) (nil fontified t 763 . 766) (nil fontified t 762 . 763) (nil fontified t 760 . 762) (nil fontified t 751 . 760) (nil fontified t 750 . 751) (nil fontified t 749 . 750) (nil fontified t 739 . 749) (nil fontified t 738 . 739) (nil fontified t 732 . 738) (nil fontified t 731 . 732) (nil fontified t 727 . 731) (nil fontified t 726 . 727) (nil fontified t 716 . 726) (nil fontified t 715 . 716) (nil fontified t 713 . 715) (nil fontified t 680 . 713) (nil fontified t 679 . 680) (nil fontified t 675 . 679) (nil fontified t 674 . 675) (nil fontified t 672 . 674) (nil fontified t 666 . 672) (nil fontified t 663 . 666) (nil fontified t 658 . 663) (nil fontified t 657 . 658) (nil fontified t 656 . 657) (nil fontified t 655 . 656) (nil fontified t 654 . 655) (nil fontified t 643 . 654) (nil fontified t 634 . 643) (nil fontified t 633 . 634) (nil fontified t 632 . 633) (nil fontified t 628 . 632) (nil fontified t 627 . 628) (nil fontified t 623 . 627) (nil fontified t 622 . 623) (nil fontified t 619 . 622) (nil fontified t 613 . 619) (nil fontified t 612 . 613) (nil fontified t 611 . 612) (nil fontified t 607 . 611) (nil fontified t 606 . 607) (nil fontified t 602 . 606) (nil fontified t 601 . 602) (nil fontified t 595 . 601) (nil fontified t 594 . 595) (nil fontified t 593 . 594) (nil fontified t 585 . 593) (nil fontified t 584 . 585) (nil fontified t 583 . 584) (nil fontified t 578 . 583) (nil fontified t 569 . 578) (nil fontified t 568 . 569) (nil fontified t 567 . 568) (nil fontified t 563 . 567) (nil fontified t 562 . 563) (nil fontified t 559 . 562) (nil fontified t 558 . 559) (nil fontified t 557 . 558) (nil fontified t 556 . 557) (nil fontified t 555 . 556) (nil fontified t 553 . 555) (nil fontified t 552 . 553) (nil fontified t 551 . 552) (nil fontified t 546 . 551) (nil fontified t 534 . 546) (nil fontified t 533 . 534) (nil fontified t 532 . 533) (nil fontified t 526 . 532) (nil fontified t 523 . 526) (nil fontified t 522 . 523) (nil fontified t 518 . 522) (nil fontified t 517 . 518) (nil fontified t 515 . 517) (nil fontified t 509 . 515) (nil fontified t 506 . 509) (nil fontified t 501 . 506) (nil fontified t 497 . 501) (nil fontified t 496 . 497) (nil fontified t 495 . 496) (nil fontified t 485 . 495) (nil fontified t 484 . 485) (nil fontified t 483 . 484) (nil fontified t 478 . 483) (nil fontified t 469 . 478) (nil fontified t 468 . 469) (nil fontified t 467 . 468) (nil fontified t 463 . 467) (nil fontified t 462 . 463) (nil fontified t 447 . 462) (nil fontified t 446 . 447) (nil fontified t 443 . 446) (nil fontified t 437 . 443) (nil fontified t 436 . 437) (nil fontified t 435 . 436) (nil fontified t 434 . 435) (nil fontified t 431 . 434) (nil fontified t 430 . 431) (nil fontified t 426 . 430) (nil fontified t 425 . 426) (nil fontified t 419 . 425) (nil fontified t 410 . 419) (nil fontified t 409 . 410) (nil fontified t 408 . 409) (nil fontified t 404 . 408) (nil fontified t 403 . 404) (nil fontified t 395 . 403) (nil fontified t 394 . 395) (nil fontified t 391 . 394) (nil fontified t 385 . 391) (nil fontified t 380 . 385) (nil fontified t 379 . 380) (nil fontified t 378 . 379) (nil fontified t 370 . 378) (nil fontified t 369 . 370) (nil fontified t 365 . 369) (nil fontified t 356 . 365) (nil fontified t 355 . 356) (nil fontified t 354 . 355) (nil fontified t 353 . 354) (nil fontified t 348 . 353) (nil fontified t 347 . 348) (nil fontified t 343 . 347) (nil fontified t 334 . 343) (nil fontified t 331 . 334) (nil fontified t 330 . 331) (nil fontified t 329 . 330) (nil fontified t 326 . 329) (nil fontified t 325 . 326) (nil fontified t 321 . 325) (nil fontified t 312 . 321) (nil fontified t 311 . 312) (nil fontified t 310 . 311) (nil fontified t 309 . 310) (nil fontified t 290 . 309) (nil fontified t 289 . 290) (nil fontified t 283 . 289) (nil fontified t 282 . 283) (nil fontified t 280 . 282) (nil fontified t 279 . 280) (nil fontified t 275 . 279) (nil fontified t 266 . 275) (nil fontified t 265 . 266) (nil fontified t 264 . 265) (nil fontified t 263 . 264) (nil fontified t 244 . 263) (nil fontified t 243 . 244) (nil fontified t 237 . 243) (nil fontified t 236 . 237) (nil fontified t 234 . 236) (nil fontified t 233 . 234) (nil fontified t 229 . 233) (nil fontified t 220 . 229) (nil fontified t 219 . 220) (nil fontified t 218 . 219) (nil fontified t 217 . 218) (nil fontified t 206 . 217) (nil fontified t 205 . 206) (nil fontified t 173 . 205) (nil fontified t 172 . 173) (nil fontified t 171 . 172) (nil fontified t 170 . 171) (nil fontified t 164 . 170) (nil fontified t 163 . 164) (nil fontified t 131 . 163) (nil fontified t 130 . 131) (nil fontified t 129 . 130) (nil fontified t 128 . 129) (nil fontified t 124 . 128) (nil fontified t 123 . 124) (nil fontified t 118 . 123) (nil fontified t 117 . 118) (nil fontified t 116 . 117) (nil fontified t 115 . 116) (nil fontified t 105 . 115) (nil fontified t 104 . 105) (nil fontified t 100 . 104) (nil fontified t 91 . 100) (nil fontified t 90 . 91) (nil fontified t 89 . 90) (nil fontified t 85 . 89) (nil fontified t 84 . 85) (nil fontified t 76 . 84) (nil fontified t 75 . 76) (nil fontified t 72 . 75) (nil fontified t 67 . 72) (nil fontified t 66 . 67) (nil fontified t 60 . 66) (nil fontified t 59 . 60) (nil fontified t 54 . 59) (nil fontified t 45 . 54) (nil fontified t 39 . 45) (nil fontified t 32 . 39) (nil fontified t 26 . 32) (nil rear-nonsticky t 2628 . 2629) nil (1 . 2629) ("#!/usr/bin/env python3


import items
import world


class Player:
    def __init__(self):
        self.inventory = [items.Rock(), items.Dagger(), items.CrustyBread()]
        self.x = world.start_tile_location[0]
        self.y = world.start_tile_location[1]
        self.hp = 100
        self.gold = 5
        self.victory = False

    def is_alive(self):
        return self.hp > 0

    def print_inventory(self):
        print(\"Inventory:\")
        for item in self.inventory:
            print(\"* \" + str(item))
        print(\"Gold: {}\".format(self.gold))

    def heal(self):
        consumables = [
            item
            for item in self.inventory
            if isinstance(item, items.Consumable)
        ]
        if not consumables:
            print(\"You don't have any items to heal you!\")
            return

        for i, item in enumerate(consumables, 1):
            print(\"Choose an item to use to heal: \")
            print(\"{}. {}\".format(i, item))

        valid = False
        while not valid:
            choice = input(\"\")
            try:
                to_eat = consumables[int(choice) - 1]
                self.hp = min(100, self.hp + to_eat.healing_value)
                self.inventory.remove(to_eat)
                print(\"Current HP: {}\".format(self.hp))
                valid = True
            except (ValueError, IndexError):
                print(\"Invalid choice, try again.\")

    def most_powerful_weapon(self):
        max_damage = 0
        best_weapon = None
        for item in self.inventory:
            try:
                if item.damage > max_damage:
                    best_weapon = item
                    max_damage = item.damage
            except AttributeError:
                pass

        return best_weapon

    def move(self, dx, dy):
        self.x += dx
        self.y += dy

    def move_north(self):
        self.move(dx=0, dy=-1)

    def move_south(self):
        self.move(dx=0, dy=1)

    def move_east(self):
        self.move(dx=1, dy=0)

    def move_west(self):
        self.move(dx=-1, dy=0)

    def attack(self):
        best_weapon = self.most_powerful_weapon()
        room = world.tile_at(self.x, self.y)
        enemy = room.enemy
        print(\"You use {} against {}!\".format(best_weapon.name, enemy.name))
        enemy.hp -= best_weapon.damage
        if not enemy.is_alive():
            print(\"You killed {}!\".format(enemy.name))
        else:
            print(\"{} HP is {}.\".format(enemy.name, enemy.hp))

    def trade(self):
        room = world.tile_at(self.x, self.y)
        room.check_if_trade(self)
" . 1) (t 24235 32732 40461 660000) nil (1 . 2601) ("#!/usr/bin/env python3


import items
import world


class Player:
    def __init__(self):
        self.inventory = [items.Rock(),
                          items.Dagger(),
                          items.CrustyBread()]
        self.x = world.start_tile_location[0]
        self.y = world.start_tile_location[1]
        self.hp = 100
        self.gold = 5
        self.victory = False

    def is_alive(self):
        return self.hp > 0

    def print_inventory(self):
        print(\"Inventory:\")
        for item in self.inventory:
            print('* ' + str(item))
        print(\"Gold: {}\".format(self.gold))

    def heal(self):
        consumables = [item for item in self.inventory
                       if isinstance(item, items.Consumable)]
        if not consumables:
            print(\"You don't have any items to heal you!\")
            return

        for i, item in enumerate(consumables, 1):
            print(\"Choose an item to use to heal: \")
            print(\"{}. {}\".format(i, item))

        valid = False
        while not valid:
            choice = input(\"\")
            try:
                to_eat = consumables[int(choice) - 1]
                self.hp = min(100, self.hp + to_eat.healing_value)
                self.inventory.remove(to_eat)
                print(\"Current HP: {}\".format(self.hp))
                valid = True
            except (ValueError, IndexError):
                print(\"Invalid choice, try again.\")

    def most_powerful_weapon(self):
        max_damage = 0
        best_weapon = None
        for item in self.inventory:
            try:
                if item.damage > max_damage:
                    best_weapon = item
                    max_damage = item.damage
            except AttributeError:
                pass

        return best_weapon

    def move(self, dx, dy):
        self.x += dx
        self.y += dy

    def move_north(self):
        self.move(dx=0, dy=-1)

    def move_south(self):
        self.move(dx=0, dy=1)

    def move_east(self):
        self.move(dx=1, dy=0)

    def move_west(self):
        self.move(dx=-1, dy=0)

    def attack(self):
        best_weapon = self.most_powerful_weapon()
        room = world.tile_at(self.x, self.y)
        enemy = room.enemy
        print(\"You use {} against {}!\".format(best_weapon.name, enemy.name))
        enemy.hp -= best_weapon.damage
        if not enemy.is_alive():
            print(\"You killed {}!\".format(enemy.name))
        else:
            print(\"{} HP is {}.\".format(enemy.name, enemy.hp))

    def trade(self):
        room = world.tile_at(self.x, self.y)
        room.check_if_trade(self)" . 1) nil (1 . 2629) ("#!/usr/bin/env python3


import items
import world


class Player:
    def __init__(self):
        self.inventory = [items.Rock(), items.Dagger(), items.CrustyBread()]
        self.x = world.start_tile_location[0]
        self.y = world.start_tile_location[1]
        self.hp = 100
        self.gold = 5
        self.victory = False

    def is_alive(self):
        return self.hp > 0

    def print_inventory(self):
        print(\"Inventory:\")
        for item in self.inventory:
            print(\"* \" + str(item))
        print(\"Gold: {}\".format(self.gold))

    def heal(self):
        consumables = [
            item
            for item in self.inventory
            if isinstance(item, items.Consumable)
        ]
        if not consumables:
            print(\"You don't have any items to heal you!\")
            return

        for i, item in enumerate(consumables, 1):
            print(\"Choose an item to use to heal: \")
            print(\"{}. {}\".format(i, item))

        valid = False
        while not valid:
            choice = input(\"\")
            try:
                to_eat = consumables[int(choice) - 1]
                self.hp = min(100, self.hp + to_eat.healing_value)
                self.inventory.remove(to_eat)
                print(\"Current HP: {}\".format(self.hp))
                valid = True
            except (ValueError, IndexError):
                print(\"Invalid choice, try again.\")

    def most_powerful_weapon(self):
        max_damage = 0
        best_weapon = None
        for item in self.inventory:
            try:
                if item.damage > max_damage:
                    best_weapon = item
                    max_damage = item.damage
            except AttributeError:
                pass

        return best_weapon

    def move(self, dx, dy):
        self.x += dx
        self.y += dy

    def move_north(self):
        self.move(dx=0, dy=-1)

    def move_south(self):
        self.move(dx=0, dy=1)

    def move_east(self):
        self.move(dx=1, dy=0)

    def move_west(self):
        self.move(dx=-1, dy=0)

    def attack(self):
        best_weapon = self.most_powerful_weapon()
        room = world.tile_at(self.x, self.y)
        enemy = room.enemy
        print(\"You use {} against {}!\".format(best_weapon.name, enemy.name))
        enemy.hp -= best_weapon.damage
        if not enemy.is_alive():
            print(\"You killed {}!\".format(enemy.name))
        else:
            print(\"{} HP is {}.\".format(enemy.name, enemy.hp))

    def trade(self):
        room = world.tile_at(self.x, self.y)
        room.check_if_trade(self)
" . 1) (t 24235 32729 427077 62000) nil (1 . 2601) ("#!/usr/bin/env python3


import items
import world


class Player:
    def __init__(self):
        self.inventory = [items.Rock(),
                          items.Dagger(),
                          items.CrustyBread()]
        self.x = world.start_tile_location[0]
        self.y = world.start_tile_location[1]
        self.hp = 100
        self.gold = 5
        self.victory = False

    def is_alive(self):
        return self.hp > 0

    def print_inventory(self):
        print(\"Inventory:\")
        for item in self.inventory:
            print('* ' + str(item))
        print(\"Gold: {}\".format(self.gold))

    def heal(self):
        consumables = [item for item in self.inventory
                       if isinstance(item, items.Consumable)]
        if not consumables:
            print(\"You don't have any items to heal you!\")
            return

        for i, item in enumerate(consumables, 1):
            print(\"Choose an item to use to heal: \")
            print(\"{}. {}\".format(i, item))

        valid = False
        while not valid:
            choice = input(\"\")
            try:
                to_eat = consumables[int(choice) - 1]
                self.hp = min(100, self.hp + to_eat.healing_value)
                self.inventory.remove(to_eat)
                print(\"Current HP: {}\".format(self.hp))
                valid = True
            except (ValueError, IndexError):
                print(\"Invalid choice, try again.\")

    def most_powerful_weapon(self):
        max_damage = 0
        best_weapon = None
        for item in self.inventory:
            try:
                if item.damage > max_damage:
                    best_weapon = item
                    max_damage = item.damage
            except AttributeError:
                pass

        return best_weapon

    def move(self, dx, dy):
        self.x += dx
        self.y += dy

    def move_north(self):
        self.move(dx=0, dy=-1)

    def move_south(self):
        self.move(dx=0, dy=1)

    def move_east(self):
        self.move(dx=1, dy=0)

    def move_west(self):
        self.move(dx=-1, dy=0)

    def attack(self):
        best_weapon = self.most_powerful_weapon()
        room = world.tile_at(self.x, self.y)
        enemy = room.enemy
        print(\"You use {} against {}!\".format(best_weapon.name, enemy.name))
        enemy.hp -= best_weapon.damage
        if not enemy.is_alive():
            print(\"You killed {}!\".format(enemy.name))
        else:
            print(\"{} HP is {}.\".format(enemy.name, enemy.hp))

    def trade(self):
        room = world.tile_at(self.x, self.y)
        room.check_if_trade(self)" . 1) nil (1 . 2629) ("#!/usr/bin/env python3


import items
import world


class Player:
    def __init__(self):
        self.inventory = [items.Rock(), items.Dagger(), items.CrustyBread()]
        self.x = world.start_tile_location[0]
        self.y = world.start_tile_location[1]
        self.hp = 100
        self.gold = 5
        self.victory = False

    def is_alive(self):
        return self.hp > 0

    def print_inventory(self):
        print(\"Inventory:\")
        for item in self.inventory:
            print(\"* \" + str(item))
        print(\"Gold: {}\".format(self.gold))

    def heal(self):
        consumables = [
            item
            for item in self.inventory
            if isinstance(item, items.Consumable)
        ]
        if not consumables:
            print(\"You don't have any items to heal you!\")
            return

        for i, item in enumerate(consumables, 1):
            print(\"Choose an item to use to heal: \")
            print(\"{}. {}\".format(i, item))

        valid = False
        while not valid:
            choice = input(\"\")
            try:
                to_eat = consumables[int(choice) - 1]
                self.hp = min(100, self.hp + to_eat.healing_value)
                self.inventory.remove(to_eat)
                print(\"Current HP: {}\".format(self.hp))
                valid = True
            except (ValueError, IndexError):
                print(\"Invalid choice, try again.\")

    def most_powerful_weapon(self):
        max_damage = 0
        best_weapon = None
        for item in self.inventory:
            try:
                if item.damage > max_damage:
                    best_weapon = item
                    max_damage = item.damage
            except AttributeError:
                pass

        return best_weapon

    def move(self, dx, dy):
        self.x += dx
        self.y += dy

    def move_north(self):
        self.move(dx=0, dy=-1)

    def move_south(self):
        self.move(dx=0, dy=1)

    def move_east(self):
        self.move(dx=1, dy=0)

    def move_west(self):
        self.move(dx=-1, dy=0)

    def attack(self):
        best_weapon = self.most_powerful_weapon()
        room = world.tile_at(self.x, self.y)
        enemy = room.enemy
        print(\"You use {} against {}!\".format(best_weapon.name, enemy.name))
        enemy.hp -= best_weapon.damage
        if not enemy.is_alive():
            print(\"You killed {}!\".format(enemy.name))
        else:
            print(\"{} HP is {}.\".format(enemy.name, enemy.hp))

    def trade(self):
        room = world.tile_at(self.x, self.y)
        room.check_if_trade(self)
" . 1) (t 24235 32727 719070 50000) nil (1 . 2601) ("#!/usr/bin/env python3


import items
import world


class Player:
    def __init__(self):
        self.inventory = [items.Rock(),
                          items.Dagger(),
                          items.CrustyBread()]
        self.x = world.start_tile_location[0]
        self.y = world.start_tile_location[1]
        self.hp = 100
        self.gold = 5
        self.victory = False

    def is_alive(self):
        return self.hp > 0

    def print_inventory(self):
        print(\"Inventory:\")
        for item in self.inventory:
            print('* ' + str(item))
        print(\"Gold: {}\".format(self.gold))

    def heal(self):
        consumables = [item for item in self.inventory
                       if isinstance(item, items.Consumable)]
        if not consumables:
            print(\"You don't have any items to heal you!\")
            return

        for i, item in enumerate(consumables, 1):
            print(\"Choose an item to use to heal: \")
            print(\"{}. {}\".format(i, item))

        valid = False
        while not valid:
            choice = input(\"\")
            try:
                to_eat = consumables[int(choice) - 1]
                self.hp = min(100, self.hp + to_eat.healing_value)
                self.inventory.remove(to_eat)
                print(\"Current HP: {}\".format(self.hp))
                valid = True
            except (ValueError, IndexError):
                print(\"Invalid choice, try again.\")

    def most_powerful_weapon(self):
        max_damage = 0
        best_weapon = None
        for item in self.inventory:
            try:
                if item.damage > max_damage:
                    best_weapon = item
                    max_damage = item.damage
            except AttributeError:
                pass

        return best_weapon

    def move(self, dx, dy):
        self.x += dx
        self.y += dy

    def move_north(self):
        self.move(dx=0, dy=-1)

    def move_south(self):
        self.move(dx=0, dy=1)

    def move_east(self):
        self.move(dx=1, dy=0)

    def move_west(self):
        self.move(dx=-1, dy=0)

    def attack(self):
        best_weapon = self.most_powerful_weapon()
        room = world.tile_at(self.x, self.y)
        enemy = room.enemy
        print(\"You use {} against {}!\".format(best_weapon.name, enemy.name))
        enemy.hp -= best_weapon.damage
        if not enemy.is_alive():
            print(\"You killed {}!\".format(enemy.name))
        else:
            print(\"{} HP is {}.\".format(enemy.name, enemy.hp))

    def trade(self):
        room = world.tile_at(self.x, self.y)
        room.check_if_trade(self)" . 1) 2628 nil (nil rear-nonsticky nil 2628 . 2629) (nil fontified nil 26 . 2629) (26 . 2629) 649 ("class User:
    def __init__(self, first, last, age):
        self.first = first.title()
        self.last = last.title()
        self.age = age

    def describe_user(self):
        print(\"## User Info ##\\n\")
        print(f\"Name: {self.first} {self.last}\")
        print(f\"Age: {self.age}\")
        print(f\"Birth Year: {self.age}\")

    def greet_user(self):
        print(f\"\\n>> Welcome, {self.first} {self.last}!<<\\n\")


u1 = User(\"dave\", \"jones\", 37)
u2 = User(\"mr\", \"big\", 27)
u3 = User(\"laura\", \"black\", 15)

u1.describe_user()
u1.greet_user()

u2.describe_user()
u2.greet_user()

u3.describe_user()
u3.greet_user()
" . 26) 649 (t 24235 32551 724855 611000) nil (26 . 649) ("/Users/davi/.pyenv/versions/3.8.2/bin" . 26) (nil rear-nonsticky t 62 . 63) nil (nil rear-nonsticky nil 62 . 63) (nil fontified nil 26 . 63) (26 . 63) 649 ("class User:
    def __init__(self, first, last, age):
        self.first = first.title()
        self.last = last.title()
        self.age = age

    def describe_user(self):
        print(\"## User Info ##\\n\")
        print(f\"Name: {self.first} {self.last}\")
        print(f\"Age: {self.age}\")
        print(f\"Birth Year: {self.age}\")

    def greet_user(self):
        print(f\"\\n>> Welcome, {self.first} {self.last}!<<\\n\")


u1 = User(\"dave\", \"jones\", 37)
u2 = User(\"mr\", \"big\", 27)
u3 = User(\"laura\", \"black\", 15)

u1.describe_user()
u1.greet_user()

u2.describe_user()
u2.greet_user()

u3.describe_user()
u3.greet_user()
" . 26) 649 (t 24235 32551 724855 611000)) (emacs-buffer-undo-list nil (26 . 649) ("md = {\"aaaa\": \"bbbb\", \"aaaa\": \"bbbb\", \"aaaa\": \"bbbb\", \"aaaa\": \"bbbb\", \"aaaa\": \"bbbb\"}" . 26) ((marker . 649) . -85) ((marker . 649) . -84) ((marker . 649) . -84) ((marker . 26) . -84) ((marker . 26) . -5) ((marker . 26) . -5) ((marker . 26) . -5) ((marker . 26) . -5) ((marker . 26) . -5) ((marker . 26) . -5) ((marker . 26) . -5) ((marker . 26) . -5) ((marker . 26) . -5) ((marker . 26) . -5) ((marker*) . 1) ((marker) . -85) ((marker*) . 80) ((marker) . -6) ((marker) . -85) (nil rear-nonsticky nil 110 . 111) (t 24237 1452 994786 107000) nil (1 . 111) ("#!/usr/bin/env python3


md = {
    \"aaaa\": \"bbbb\",
    \"aaaa\": \"bbbb\",
    \"aaaa\": \"bbbb\",
    \"aaaa\": \"bbbb\",
    \"aaaa\": \"bbbb\",
}
" . 1) ((marker . 649) . -23) ((marker) . -112) ((marker) . -113) ((marker) . -92) ((marker) . -93) ((marker) . -72) ((marker) . -73) ((marker) . -52) ((marker) . -53) ((marker) . -32) ((marker) . -33) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -30) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -30) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -30) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -30) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -30) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -30) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -30) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -30) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -30) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -30) (t 24237 1452 352194 709000) nil (1 . 135) ("#!/usr/bin/env python3


md = {\"aaaa\": \"bbbb\", \"aaaa\": \"bbbb\", \"aaaa\": \"bbbb\", \"aaaa\": \"bbbb\", \"aaaa\": \"bbbb\"}" . 1) ((marker . 649) . -25) ((marker . 649) . -110) ((marker . 649) . -109) ((marker . 649) . -109) ((marker . 1) . -109) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -30) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -30) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -30) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -30) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -30) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -30) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -30) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -30) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -30) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -30) ((marker*) . 1) ((marker) . -110) ((marker*) . 80) ((marker) . -31) (t 24237 1450 923026 837000) nil (1 . 111) ("#!/usr/bin/env python3


md = {
    \"aaaa\": \"bbbb\",
    \"aaaa\": \"bbbb\",
    \"aaaa\": \"bbbb\",
    \"aaaa\": \"bbbb\",
    \"aaaa\": \"bbbb\",
}
" . 1) ((marker . 649) . -23) ((marker) . -112) ((marker) . -113) ((marker) . -92) ((marker) . -93) ((marker) . -72) ((marker) . -73) ((marker) . -52) ((marker) . -53) ((marker) . -32) ((marker) . -33) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -30) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -30) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -30) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -30) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -30) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -30) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -30) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -30) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -30) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -30) (t 24237 1450 485005 882000) nil (1 . 135) ("#!/usr/bin/env python3


md = {\"aaaa\": \"bbbb\", \"aaaa\": \"bbbb\", \"aaaa\": \"bbbb\", \"aaaa\": \"bbbb\", \"aaaa\": \"bbbb\"}" . 1) ((marker . 649) . -23) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -30) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -30) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -30) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -30) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -30) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -30) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -30) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -30) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -30) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -30) ((marker . 1) . -25) ((marker . 1) . -110) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -30) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -30) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -30) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -30) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -30) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -30) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -30) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -30) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -30) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -30) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -30) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -30) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -30) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -30) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -30) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -30) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -30) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -30) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -30) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -30) ((marker) . -25) ((marker) . -110) ((marker) . -109) ((marker) . -110) (t 24237 1449 753815 720000) nil (1 . 111) ("#!/usr/bin/env python3


md = {
    \"aaaa\": \"bbbb\",
    \"aaaa\": \"bbbb\",
    \"aaaa\": \"bbbb\",
    \"aaaa\": \"bbbb\",
    \"aaaa\": \"bbbb\",
}
" . 1) ((marker) . -112) ((marker) . -113) ((marker) . -92) ((marker) . -93) ((marker) . -72) ((marker) . -73) ((marker) . -52) ((marker) . -53) ((marker) . -32) ((marker) . -33) (1 . 135) ("#!/usr/bin/env python3


md = {\"aaaa\": \"bbbb\", \"aaaa\": \"bbbb\", \"aaaa\": \"bbbb\", \"aaaa\": \"bbbb\", \"aaaa\": \"bbbb\"}" . 1) ((marker . 649) . -25) ((marker . 649) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -23) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -24) ((marker . 1) . -24) ((marker . 649) . -25) ((marker . 649) . -25) ((marker . 1) . -25) ((marker . 1) . -24) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) (nil rear-nonsticky nil 110 . 111) (26 . 111) ("class User:
    def __init__(self, first, last, age):
        self.first = first.title()
        self.last = last.title()
        self.age = age

    def describe_user(self):
        print(\"## User Info ##\\n\")
        print(f\"Name: {self.first} {self.last}\")
        print(f\"Age: {self.age}\")
        print(f\"Birth Year: {self.age}\")

    def greet_user(self):
        print(f\"\\n>> Welcome, {self.first} {self.last}!<<\\n\")


u1 = User(\"dave\", \"jones\", 37)
u2 = User(\"mr\", \"big\", 27)
u3 = User(\"laura\", \"black\", 15)

u1.describe_user()
u1.greet_user()

u2.describe_user()
u2.greet_user()

u3.describe_user()
u3.greet_user()
" . 26) ((marker . 649) . -12) ((marker . 1) . -456) ((marker . 1) . -623) ((marker . 1) . -456) ((marker . 1) . -623) ((marker . 1) . -210) ((marker . 1) . -259) ((marker . 1) . -145) ((marker . 1) . -210) ((marker . 1) . -210) ((marker . 1) . -145) ((marker . 1) . -210) ((marker . 1) . -210) ((marker . 1) . -145) ((marker . 1) . -210) ((marker . 1) . -210) ((marker . 1) . -145) ((marker . 1) . -210) ((marker . 1) . -210) ((marker . 1) . -145) ((marker . 1) . -210) ((marker . 1) . -210) ((marker . 1) . -145) ((marker . 1) . -210) ((marker . 1) . -145) ((marker . 1) . -210) ((marker . 1) . -210) ((marker . 1) . -210) ((marker . 1) . -145) ((marker . 1) . -210) ((marker . 1) . -210) ((marker . 1) . -145) ((marker . 1) . -145) ((marker . 1) . -210) ((marker . 1) . -210) ((marker . 1) . -210) ((marker . 1) . -145) ((marker* . 649) . 413) ((marker . 1) . -210) ((marker . 1) . -175) ((marker . 1) . -145) ((marker . 1) . -145) ((marker . 1) . -210) ((marker . 1) . -210) ((marker . 1) . -210) ((marker . 1) . -145) ((marker . 1) . -210) ((marker . 1) . -210) ((marker . 1) . -145) ((marker . 1) . -145) ((marker . 1) . -210) ((marker . 1) . -210) ((marker . 1) . -210) ((marker . 1) . -145) ((marker . 1) . -210) ((marker . 1) . -210) ((marker . 1) . -145) ((marker . 1) . -145) ((marker . 1) . -210) ((marker . 1) . -210) ((marker . 1) . -210) ((marker . 1) . -145) ((marker . 1) . -210) ((marker . 1) . -210) ((marker . 1) . -145) ((marker . 1) . -145) ((marker . 1) . -210) ((marker . 1) . -210) ((marker . 1) . -210) ((marker . 1) . -145) ((marker . 1) . -210) ((marker . 1) . -210) ((marker . 1) . -145) ((marker . 1) . -210) ((marker . 1) . -259) ((marker . 1) . -145) ((marker . 1) . -210) ((marker . 1) . -210) ((marker . 1) . -210) ((marker . 1) . -210) ((marker . 1) . -145) ((marker . 1) . -210) ((marker . 1) . -210) ((marker . 1) . -145) ((marker . 1) . -210) ((marker . 1) . -259) ((marker . 1) . -145) ((marker . 1) . -145) ((marker . 1) . -210) ((marker . 1) . -210) ((marker . 1) . -210) ((marker . 1) . -145) ((marker . 1) . -210) ((marker . 1) . -210) ((marker . 1) . -145) ((marker . 1) . -145) ((marker . 1) . -210) ((marker . 1) . -210) ((marker . 1) . -210) ((marker . 1) . -145) ((marker . 1) . -424) ((marker . 1) . -339) ((marker . 1) . -210) ((marker . 1) . -424) ((marker . 1) . -145) ((marker . 1) . -424) ((marker . 1) . -424) ((marker . 1) . -424) ((marker . 1) . -175) ((marker . 1) . -424) ((marker . 1) . -424) ((marker . 1) . -175) ((marker . 1) . -145) ((marker . 1) . -424) ((marker . 1) . -424) ((marker . 1) . -424) ((marker . 1) . -175) ((marker . 1) . -516) ((marker . 1) . -483) ((marker . 1) . -456) ((marker . 1) . -210) ((marker . 1) . -483) ((marker . 1) . -210) ((marker . 1) . -483) ((marker . 1) . -483) ((marker . 1) . -483) ((marker . 1) . -210) ((marker . 1) . -516) ((marker . 1) . -516) ((marker . 1) . -516) ((marker . 1) . -516) ((marker . 1) . -483) ((marker . 1) . -516) ((marker . 1) . -516) ((marker . 1) . -516) ((marker . 1) . -516) ((marker . 1) . -424) ((marker . 1) . -339) ((marker . 1) . -516) ((marker . 1) . -424) ((marker . 1) . -424) ((marker . 1) . -424) ((marker . 1) . -424) ((marker . 1) . -424) ((marker . 1) . -424) ((marker . 1) . -424) ((marker . 1) . -424) ((marker . 1) . -424) ((marker . 1) . -424) ((marker . 1) . -424) ((marker . 1) . -424) ((marker . 1) . -424) ((marker . 1) . -424) ((marker . 1) . -424) ((marker . 1) . -424) ((marker . 1) . -424) ((marker . 1) . -424) ((marker . 1) . -424) ((marker . 1) . -424) ((marker . 1) . -424) ((marker . 1) . -424) ((marker . 1) . -424) ((marker . 1) . -424) ((marker . 1) . -424) ((marker . 1) . -423) ((marker . 1) . -424) ((marker . 1) . -424) ((marker . 1) . -424) ((marker . 1) . -456) ((marker . 1) . -483) ((marker . 1) . -424) ((marker . 1) . -456) ((marker . 1) . -456) ((marker . 1) . -456) ((marker . 1) . -456) ((marker . 1) . -456) ((marker . 1) . -456) ((marker . 1) . -456) ((marker . 1) . -456) ((marker . 1) . -456) ((marker . 1) . -456) ((marker . 1) . -476) ((marker . 1) . -456) ((marker . 1) . -456) ((marker . 1) . -456) ((marker . 1) . -456) ((marker . 1) . -456) ((marker . 1) . -456) ((marker . 1) . -456) ((marker . 1) . -456) ((marker . 1) . -456) ((marker . 1) . -456) ((marker . 1) . -456) ((marker . 1) . -456) ((marker . 1) . -456) ((marker . 1) . -456) ((marker . 1) . -456) ((marker . 1) . -456) ((marker . 1) . -456) ((marker . 1) . -456) ((marker . 1) . -456) ((marker . 1) . -421) ((marker . 1) . -421) ((marker . 1) . -183) ((marker . 1) . -183) ((marker . 1) . -218) ((marker . 1) . -218) ((marker . 1) . -267) ((marker . 1) . -267) ((marker . 1) . -301) ((marker . 1) . -301) ((marker . 1) . -369) ((marker . 1) . -369) ((marker . 1) . -425) ((marker . 1) . -425) ((marker . 1) . -430) ((marker . 1) . -425) ((marker . 1) . -425) ((marker . 1) . -430) ((marker . 1) . -456) ((marker . 1) . -456) ((marker . 1) . -461) ((marker . 1) . -456) ((marker . 1) . -456) ((marker . 1) . -461) ((marker . 1) . -483) ((marker . 1) . -483) ((marker . 1) . -488) ((marker . 1) . -483) ((marker . 1) . -483) ((marker . 1) . -488) ((marker) . -361) ((marker) . -362) ((marker) . -365) ((marker) . -366) ((marker) . -335) ((marker) . -336) ((marker) . -293) ((marker) . -294) ((marker) . -297) ((marker) . -298) ((marker) . -259) ((marker) . -260) ((marker) . -263) ((marker) . -264) ((marker) . -210) ((marker) . -211) ((marker) . -214) ((marker) . -215) ((marker) . -175) ((marker) . -176) ((marker) . -179) ((marker) . -180) ((marker) . -146) ((marker) . -147) ((marker) . -122) ((marker) . -123) ((marker) . -126) ((marker) . -127) ((marker) . -89) ((marker) . -90) ((marker) . -93) ((marker) . -94) ((marker) . -54) ((marker) . -55) ((marker) . -58) ((marker) . -59) ((marker) . -12) ((marker) . -13) ((marker . 1) . -183) ((marker . 1) . -183) ((marker . 1) . -218) ((marker . 1) . -218) ((marker . 1) . -267) ((marker . 1) . -267) ((marker . 1) . -301) ((marker . 1) . -301) ((marker . 1) . -369) ((marker . 1) . -369) ((marker . 1) . -425) ((marker . 1) . -425) ((marker . 1) . -430) ((marker . 1) . -425) ((marker . 1) . -425) ((marker . 1) . -430) ((marker . 1) . -456) ((marker . 1) . -456) ((marker . 1) . -461) ((marker . 1) . -456) ((marker . 1) . -456) ((marker . 1) . -461) ((marker . 1) . -483) ((marker . 1) . -483) ((marker . 1) . -488) ((marker . 1) . -483) ((marker . 1) . -483) ((marker . 1) . -488) (t 24237 1448 624536 772000) nil (26 . 649) ("md = {\"aaaa\": \"bbbb\", \"aaaa\": \"bbbb\", \"aaaa\": \"bbbb\", \"aaaa\": \"bbbb\", \"aaaa\": \"bbbb\"}" . 26) (nil rear-nonsticky t 110 . 111) (1 . 111) ("#!/usr/bin/env python3


md = {
    \"aaaa\": \"bbbb\",
    \"aaaa\": \"bbbb\",
    \"aaaa\": \"bbbb\",
    \"aaaa\": \"bbbb\",
    \"aaaa\": \"bbbb\",
}
" . 1) ((marker) . -112) ((marker) . -113) ((marker) . -92) ((marker) . -93) ((marker) . -72) ((marker) . -73) ((marker) . -52) ((marker) . -53) ((marker) . -32) ((marker) . -33) (1 . 135) ("#!/usr/bin/env python3


md = {\"aaaa\": \"bbbb\", \"aaaa\": \"bbbb\", \"aaaa\": \"bbbb\", \"aaaa\": \"bbbb\", \"aaaa\": \"bbbb\"}" . 1) ((marker . 649) . -23) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -30) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -30) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -30) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -30) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -30) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -30) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -30) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -30) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -30) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -30) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -30) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -30) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -30) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -30) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -30) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -30) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -30) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -30) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -30) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -30) (t 24237 1448 484524 663000) nil (1 . 111) ("#!/usr/bin/env python3


md = {
    \"aaaa\": \"bbbb\",
    \"aaaa\": \"bbbb\",
    \"aaaa\": \"bbbb\",
    \"aaaa\": \"bbbb\",
    \"aaaa\": \"bbbb\",
}
" . 1) ((marker . 649) . -23) ((marker) . -112) ((marker) . -113) ((marker) . -92) ((marker) . -93) ((marker) . -72) ((marker) . -73) ((marker) . -52) ((marker) . -53) ((marker) . -32) ((marker) . -33) (t 24237 1448 391082 715000) nil (1 . 135) ("#!/usr/bin/env python3


md = {\"aaaa\": \"bbbb\", \"aaaa\": \"bbbb\", \"aaaa\": \"bbbb\", \"aaaa\": \"bbbb\", \"aaaa\": \"bbbb\"}" . 1) ((marker . 649) . -25) ((marker . 649) . -110) ((marker . 649) . -109) ((marker . 649) . -109) ((marker*) . 1) ((marker) . -110) ((marker*) . 80) ((marker) . -31) (t 24237 1448 92 844000) nil (1 . 111) ("#!/usr/bin/env python3


md = {
    \"aaaa\": \"bbbb\",
    \"aaaa\": \"bbbb\",
    \"aaaa\": \"bbbb\",
    \"aaaa\": \"bbbb\",
    \"aaaa\": \"bbbb\",
}
" . 1) ((marker . 649) . -23) (t 24237 1447 373166 712000) nil (1 . 135) ("#!/usr/bin/env python3


md = {\"aaaa\": \"bbbb\", \"aaaa\": \"bbbb\", \"aaaa\": \"bbbb\", \"aaaa\": \"bbbb\", \"aaaa\": \"bbbb\"}" . 1) ((marker . 649) . -23) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -30) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -30) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -30) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -30) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -30) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -30) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -30) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -30) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -30) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -30) ((marker) . -25) ((marker) . -110) ((marker) . -109) ((marker) . -110) (t 24237 1446 455249 279000) nil (1 . 111) ("#!/usr/bin/env python3


md = {
    \"aaaa\": \"bbbb\",
    \"aaaa\": \"bbbb\",
    \"aaaa\": \"bbbb\",
    \"aaaa\": \"bbbb\",
    \"aaaa\": \"bbbb\",
}
" . 1) ((marker) . -112) ((marker) . -113) ((marker) . -92) ((marker) . -93) ((marker) . -72) ((marker) . -73) ((marker) . -52) ((marker) . -53) ((marker) . -32) ((marker) . -33) (1 . 135) ("#!/usr/bin/env python3


md = {\"aaaa\": \"bbbb\", \"aaaa\": \"bbbb\", \"aaaa\": \"bbbb\", \"aaaa\": \"bbbb\", \"aaaa\": \"bbbb\"}" . 1) ((marker . 649) . -25) ((marker . 649) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -23) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -24) ((marker . 1) . -24) ((marker . 649) . -25) ((marker . 649) . -25) ((marker . 1) . -25) ((marker . 1) . -24) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) (nil rear-nonsticky nil 110 . 111) (26 . 111) ("class User:
    def __init__(self, first, last, age):
        self.first = first.title()
        self.last = last.title()
        self.age = age

    def describe_user(self):
        print(\"## User Info ##\\n\")
        print(f\"Name: {self.first} {self.last}\")
        print(f\"Age: {self.age}\")
        print(f\"Birth Year: {self.age}\")

    def greet_user(self):
        print(f\"\\n>> Welcome, {self.first} {self.last}!<<\\n\")


u1 = User(\"dave\", \"jones\", 37)
u2 = User(\"mr\", \"big\", 27)
u3 = User(\"laura\", \"black\", 15)

u1.describe_user()
u1.greet_user()

u2.describe_user()
u2.greet_user()

u3.describe_user()
u3.greet_user()
" . 26) ((marker . 649) . -12) ((marker . 1) . -456) ((marker . 1) . -623) ((marker . 1) . -456) ((marker . 1) . -623) ((marker . 1) . -210) ((marker . 1) . -259) ((marker . 1) . -145) ((marker . 1) . -210) ((marker . 1) . -210) ((marker . 1) . -145) ((marker . 1) . -210) ((marker . 1) . -210) ((marker . 1) . -145) ((marker . 1) . -210) ((marker . 1) . -210) ((marker . 1) . -145) ((marker . 1) . -210) ((marker . 1) . -210) ((marker . 1) . -145) ((marker . 1) . -210) ((marker . 1) . -210) ((marker . 1) . -145) ((marker . 1) . -210) ((marker . 1) . -145) ((marker . 1) . -210) ((marker . 1) . -210) ((marker . 1) . -210) ((marker . 1) . -145) ((marker . 1) . -210) ((marker . 1) . -210) ((marker . 1) . -145) ((marker . 1) . -145) ((marker . 1) . -210) ((marker . 1) . -210) ((marker . 1) . -210) ((marker . 1) . -145) ((marker* . 649) . 413) ((marker . 1) . -210) ((marker . 1) . -175) ((marker . 1) . -145) ((marker . 1) . -145) ((marker . 1) . -210) ((marker . 1) . -210) ((marker . 1) . -210) ((marker . 1) . -145) ((marker . 1) . -210) ((marker . 1) . -210) ((marker . 1) . -145) ((marker . 1) . -145) ((marker . 1) . -210) ((marker . 1) . -210) ((marker . 1) . -210) ((marker . 1) . -145) ((marker . 1) . -210) ((marker . 1) . -210) ((marker . 1) . -145) ((marker . 1) . -145) ((marker . 1) . -210) ((marker . 1) . -210) ((marker . 1) . -210) ((marker . 1) . -145) ((marker . 1) . -210) ((marker . 1) . -210) ((marker . 1) . -145) ((marker . 1) . -145) ((marker . 1) . -210) ((marker . 1) . -210) ((marker . 1) . -210) ((marker . 1) . -145) ((marker . 1) . -210) ((marker . 1) . -210) ((marker . 1) . -145) ((marker . 1) . -210) ((marker . 1) . -259) ((marker . 1) . -145) ((marker . 1) . -210) ((marker . 1) . -210) ((marker . 1) . -210) ((marker . 1) . -210) ((marker . 1) . -145) ((marker . 1) . -210) ((marker . 1) . -210) ((marker . 1) . -145) ((marker . 1) . -210) ((marker . 1) . -259) ((marker . 1) . -145) ((marker . 1) . -145) ((marker . 1) . -210) ((marker . 1) . -210) ((marker . 1) . -210) ((marker . 1) . -145) ((marker . 1) . -210) ((marker . 1) . -210) ((marker . 1) . -145) ((marker . 1) . -145) ((marker . 1) . -210) ((marker . 1) . -210) ((marker . 1) . -210) ((marker . 1) . -145) ((marker . 1) . -424) ((marker . 1) . -339) ((marker . 1) . -210) ((marker . 1) . -424) ((marker . 1) . -145) ((marker . 1) . -424) ((marker . 1) . -424) ((marker . 1) . -424) ((marker . 1) . -175) ((marker . 1) . -424) ((marker . 1) . -424) ((marker . 1) . -175) ((marker . 1) . -145) ((marker . 1) . -424) ((marker . 1) . -424) ((marker . 1) . -424) ((marker . 1) . -175) ((marker . 1) . -516) ((marker . 1) . -483) ((marker . 1) . -456) ((marker . 1) . -210) ((marker . 1) . -483) ((marker . 1) . -210) ((marker . 1) . -483) ((marker . 1) . -483) ((marker . 1) . -483) ((marker . 1) . -210) ((marker . 1) . -516) ((marker . 1) . -516) ((marker . 1) . -516) ((marker . 1) . -516) ((marker . 1) . -483) ((marker . 1) . -516) ((marker . 1) . -516) ((marker . 1) . -516) ((marker . 1) . -516) ((marker . 1) . -424) ((marker . 1) . -339) ((marker . 1) . -516) ((marker . 1) . -424) ((marker . 1) . -424) ((marker . 1) . -424) ((marker . 1) . -424) ((marker . 1) . -424) ((marker . 1) . -424) ((marker . 1) . -424) ((marker . 1) . -424) ((marker . 1) . -424) ((marker . 1) . -424) ((marker . 1) . -424) ((marker . 1) . -424) ((marker . 1) . -424) ((marker . 1) . -424) ((marker . 1) . -424) ((marker . 1) . -424) ((marker . 1) . -424) ((marker . 1) . -424) ((marker . 1) . -424) ((marker . 1) . -424) ((marker . 1) . -424) ((marker . 1) . -424) ((marker . 1) . -424) ((marker . 1) . -424) ((marker . 1) . -424) ((marker . 1) . -423) ((marker . 1) . -424) ((marker . 1) . -424) ((marker . 1) . -424) ((marker . 1) . -456) ((marker . 1) . -483) ((marker . 1) . -424) ((marker . 1) . -456) ((marker . 1) . -456) ((marker . 1) . -456) ((marker . 1) . -456) ((marker . 1) . -456) ((marker . 1) . -456) ((marker . 1) . -456) ((marker . 1) . -456) ((marker . 1) . -456) ((marker . 1) . -456) ((marker . 1) . -476) ((marker . 1) . -456) ((marker . 1) . -456) ((marker . 1) . -456) ((marker . 1) . -456) ((marker . 1) . -456) ((marker . 1) . -456) ((marker . 1) . -456) ((marker . 1) . -456) ((marker . 1) . -456) ((marker . 1) . -456) ((marker . 1) . -456) ((marker . 1) . -456) ((marker . 1) . -456) ((marker . 1) . -456) ((marker . 1) . -456) ((marker . 1) . -456) ((marker . 1) . -456) ((marker . 1) . -456) ((marker . 1) . -456) ((marker . 1) . -421) ((marker) . -361) ((marker) . -362) ((marker) . -365) ((marker) . -366) ((marker) . -335) ((marker) . -336) ((marker) . -293) ((marker) . -294) ((marker) . -297) ((marker) . -298) ((marker) . -259) ((marker) . -260) ((marker) . -263) ((marker) . -264) ((marker) . -210) ((marker) . -211) ((marker) . -214) ((marker) . -215) ((marker) . -175) ((marker) . -176) ((marker) . -179) ((marker) . -180) ((marker) . -146) ((marker) . -147) ((marker) . -122) ((marker) . -123) ((marker) . -126) ((marker) . -127) ((marker) . -89) ((marker) . -90) ((marker) . -93) ((marker) . -94) ((marker) . -54) ((marker) . -55) ((marker) . -58) ((marker) . -59) ((marker) . -12) ((marker) . -13) ((marker . 1) . -421) ((marker . 1) . -183) ((marker . 1) . -183) ((marker . 1) . -218) ((marker . 1) . -218) ((marker . 1) . -267) ((marker . 1) . -267) ((marker . 1) . -301) ((marker . 1) . -301) ((marker . 1) . -369) ((marker . 1) . -369) ((marker . 1) . -425) ((marker . 1) . -425) ((marker . 1) . -430) ((marker . 1) . -425) ((marker . 1) . -425) ((marker . 1) . -430) ((marker . 1) . -456) ((marker . 1) . -456) ((marker . 1) . -461) ((marker . 1) . -456) ((marker . 1) . -456) ((marker . 1) . -461) ((marker . 1) . -483) ((marker . 1) . -483) ((marker . 1) . -488) ((marker . 1) . -483) ((marker . 1) . -483) ((marker . 1) . -488) (t 24237 1445 380969 840000) nil (26 . 649) ("md = {\"aaaa\": \"bbbb\", \"aaaa\": \"bbbb\", \"aaaa\": \"bbbb\", \"aaaa\": \"bbbb\", \"aaaa\": \"bbbb\"}" . 26) (nil rear-nonsticky t 110 . 111) (1 . 111) ("#!/usr/bin/env python3


md = {
    \"aaaa\": \"bbbb\",
    \"aaaa\": \"bbbb\",
    \"aaaa\": \"bbbb\",
    \"aaaa\": \"bbbb\",
    \"aaaa\": \"bbbb\",
}
" . 1) ((marker) . -112) ((marker) . -113) ((marker) . -92) ((marker) . -93) ((marker) . -72) ((marker) . -73) ((marker) . -52) ((marker) . -53) ((marker) . -32) ((marker) . -33) (1 . 135) ("#!/usr/bin/env python3


md = {\"aaaa\": \"bbbb\", \"aaaa\": \"bbbb\", \"aaaa\": \"bbbb\", \"aaaa\": \"bbbb\", \"aaaa\": \"bbbb\"}" . 1) ((marker . 649) . -23) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -30) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -30) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -30) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -30) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -30) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -30) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -30) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -30) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -30) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -30) ((marker . 1) . -25) ((marker . 1) . -110) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker) . -25) ((marker) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -30) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -30) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -30) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -30) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -30) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -30) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -30) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -30) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -30) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -30) (t 24237 1445 240865 238000) nil (26 . 111) ("md = {\"aaaa\": \"bbbb\", \"aaaa\": \"bbbb\", \"aaaa\": \"bbbb\", \"aaaa\": \"bbbb\", \"aaaa\": \"bbbb\"}
" . 26) ((marker . 649) . -86) ((marker . 1) . -5) ((marker . 1) . -5) ((marker . 1) . -5) ((marker . 1) . -5) ((marker . 1) . -5) ((marker . 1) . -5) ((marker . 1) . -5) ((marker . 1) . -5) ((marker . 1) . -5) ((marker . 1) . -5) ((marker . 1) . -5) ((marker . 1) . -5) ((marker . 1) . -5) ((marker . 1) . -5) ((marker . 1) . -5) ((marker . 1) . -5) ((marker . 1) . -5) ((marker . 1) . -5) ((marker . 1) . -5) ((marker . 1) . -5) ((marker) . -79) ((marker) . -83) ((marker) . -79) ((marker) . -83) (t 24237 1445 51059 414000) nil (26 . 112) ("md = {\"aaaa\": \"bbbb\", \"aaaa\": \"bbbb\", \"aaaa\": \"bbbb\", \"aaaa\": \"bbbb\", \"aaaa\": \"bbbb\"}" . 26) ((marker . 1) . -5) ((marker . 1) . -5) ((marker . 1) . -5) ((marker . 1) . -5) ((marker . 1) . -5) ((marker . 1) . -5) ((marker . 1) . -5) ((marker . 1) . -5) ((marker . 1) . -5) ((marker . 1) . -5) ((marker . 1) . -85) ((marker . 1) . -5) ((marker . 1) . -5) ((marker . 1) . -5) ((marker . 1) . -5) ((marker . 1) . -5) ((marker . 1) . -5) ((marker . 1) . -5) ((marker . 1) . -5) ((marker . 1) . -5) ((marker . 1) . -5) ((marker . 1) . -5) ((marker . 1) . -5) ((marker . 1) . -5) ((marker . 1) . -5) ((marker . 1) . -5) ((marker . 1) . -5) ((marker . 1) . -5) ((marker . 1) . -5) ((marker . 1) . -5) ((marker . 1) . -5) (t 24237 1443 132728 261000) nil (1 . 111) ("#!/usr/bin/env python3


md = {
    \"aaaa\": \"bbbb\",
    \"aaaa\": \"bbbb\",
    \"aaaa\": \"bbbb\",
    \"aaaa\": \"bbbb\",
    \"aaaa\": \"bbbb\",
}
" . 1) ((marker . 649) . -23) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -30) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -30) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -30) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -30) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -30) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -30) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -30) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -30) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -30) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -30) ((marker) . -112) ((marker) . -113) ((marker) . -92) ((marker) . -93) ((marker) . -72) ((marker) . -73) ((marker) . -52) ((marker) . -53) ((marker) . -32) ((marker) . -33) (t 24237 1442 181113 996000) nil (1 . 135) ("#!/usr/bin/env python3


md = {\"aaaa\": \"bbbb\", \"aaaa\": \"bbbb\", \"aaaa\": \"bbbb\", \"aaaa\": \"bbbb\", \"aaaa\": \"bbbb\"}" . 1) ((marker . 649) . -23) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -30) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -30) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -30) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -30) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -30) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -30) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -30) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -30) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -30) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -30) ((marker . 1) . -25) ((marker . 1) . -110) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker) . -25) ((marker) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -30) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -30) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -30) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -30) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -30) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -30) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -30) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -30) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -30) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -30) (t 24237 1440 781102 165000) nil (26 . 111) ("md = {\"aaaa\": \"bbbb\", \"aaaa\": \"bbbb\", \"aaaa\": \"bbbb\", \"aaaa\": \"bbbb\", \"aaaa\": \"bbbb\"}
" . 26) ((marker . 1) . -5) ((marker . 1) . -5) ((marker . 1) . -5) ((marker . 1) . -5) ((marker . 1) . -5) ((marker . 1) . -5) ((marker . 1) . -5) ((marker . 1) . -5) ((marker . 1) . -5) ((marker . 1) . -5) ((marker) . -79) ((marker) . -83) ((marker) . -79) ((marker) . -83) (t 24237 1439 178178 53000) nil (26 . 112) ("md = {\"aaaa\": \"bbbb\", \"aaaa\": \"bbbb\", \"aaaa\": \"bbbb\", \"aaaa\": \"bbbb\", \"aaaa\": \"bbbb\"}" . -26) ((marker . 1) . -5) ((marker . 1) . -5) ((marker . 1) . -5) ((marker . 1) . -5) ((marker . 1) . -5) ((marker . 1) . -5) ((marker . 1) . -5) ((marker . 1) . -5) ((marker . 1) . -5) ((marker . 1) . -5) ((marker) . -84) ((marker) . -85) ((marker) . -85) ((marker . 1) . -85) 1 (t 24237 1438 728306 475000) nil (1 . 111) ("#!/usr/bin/env python3


md = {
    \"aaaa\": \"bbbb\",
    \"aaaa\": \"bbbb\",
    \"aaaa\": \"bbbb\",
    \"aaaa\": \"bbbb\",
    \"aaaa\": \"bbbb\",
}
" . 1) ((marker*) . 134) ((marker*) . 134) ((marker) . -112) ((marker) . -113) ((marker) . -92) ((marker) . -93) ((marker) . -72) ((marker) . -73) ((marker) . -52) ((marker) . -53) ((marker) . -32) ((marker) . -33) (1 . 135) ("#!/usr/bin/env python3


md = {\"aaaa\": \"bbbb\", \"aaaa\": \"bbbb\", \"aaaa\": \"bbbb\", \"aaaa\": \"bbbb\", \"aaaa\": \"bbbb\"}" . 1) ((marker . 649) . -25) ((marker . 649) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -23) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -24) ((marker . 1) . -24) ((marker . 649) . -25) ((marker . 649) . -25) ((marker . 1) . -25) ((marker . 1) . -24) ((marker*) . 85) ((marker) . -25) ((marker*) . 85) ((marker) . -25) (nil rear-nonsticky nil 110 . 111) (26 . 111) ("class User:
    def __init__(self, first, last, age):
        self.first = first.title()
        self.last = last.title()
        self.age = age

    def describe_user(self):
        print(\"## User Info ##\\n\")
        print(f\"Name: {self.first} {self.last}\")
        print(f\"Age: {self.age}\")
        print(f\"Birth Year: {self.age}\")

    def greet_user(self):
        print(f\"\\n>> Welcome, {self.first} {self.last}!<<\\n\")


u1 = User(\"dave\", \"jones\", 37)
u2 = User(\"mr\", \"big\", 27)
u3 = User(\"laura\", \"black\", 15)

u1.describe_user()
u1.greet_user()

u2.describe_user()
u2.greet_user()

u3.describe_user()
u3.greet_user()
" . 26) ((marker . 649) . -361) ((marker . 649) . -423) ((marker . 1) . -456) ((marker . 1) . -623) ((marker . 1) . -456) ((marker . 1) . -623) ((marker . 1) . -210) ((marker . 1) . -259) ((marker . 1) . -145) ((marker . 1) . -210) ((marker . 1) . -210) ((marker . 1) . -145) ((marker . 1) . -210) ((marker . 1) . -210) ((marker . 1) . -145) ((marker . 1) . -210) ((marker . 1) . -210) ((marker . 1) . -145) ((marker . 1) . -210) ((marker . 1) . -210) ((marker . 1) . -145) ((marker . 1) . -210) ((marker . 1) . -210) ((marker . 1) . -145) ((marker . 1) . -210) ((marker . 1) . -145) ((marker . 1) . -210) ((marker . 1) . -210) ((marker . 1) . -210) ((marker . 1) . -145) ((marker . 1) . -210) ((marker . 1) . -210) ((marker . 1) . -145) ((marker . 1) . -145) ((marker . 1) . -210) ((marker . 1) . -210) ((marker . 1) . -210) ((marker . 1) . -145) ((marker* . 649) . 413) ((marker . 1) . -210) ((marker . 1) . -175) ((marker . 1) . -145) ((marker . 1) . -145) ((marker . 1) . -210) ((marker . 1) . -210) ((marker . 1) . -210) ((marker . 1) . -145) ((marker . 1) . -210) ((marker . 1) . -210) ((marker . 1) . -145) ((marker . 1) . -145) ((marker . 1) . -210) ((marker . 1) . -210) ((marker . 1) . -210) ((marker . 1) . -145) ((marker . 1) . -210) ((marker . 1) . -210) ((marker . 1) . -145) ((marker . 1) . -145) ((marker . 1) . -210) ((marker . 1) . -210) ((marker . 1) . -210) ((marker . 1) . -145) ((marker . 1) . -210) ((marker . 1) . -210) ((marker . 1) . -145) ((marker . 1) . -145) ((marker . 1) . -210) ((marker . 1) . -210) ((marker . 1) . -210) ((marker . 1) . -145) ((marker . 1) . -210) ((marker . 1) . -210) ((marker . 1) . -145) ((marker . 1) . -210) ((marker . 1) . -259) ((marker . 1) . -145) ((marker . 1) . -210) ((marker . 1) . -210) ((marker . 1) . -210) ((marker . 1) . -210) ((marker . 1) . -145) ((marker . 1) . -210) ((marker . 1) . -210) ((marker . 1) . -145) ((marker . 1) . -210) ((marker . 1) . -259) ((marker . 1) . -145) ((marker . 1) . -145) ((marker . 1) . -210) ((marker . 1) . -210) ((marker . 1) . -210) ((marker . 1) . -145) ((marker . 1) . -210) ((marker . 1) . -210) ((marker . 1) . -145) ((marker . 1) . -145) ((marker . 1) . -210) ((marker . 1) . -210) ((marker . 1) . -210) ((marker . 1) . -145) ((marker . 1) . -424) ((marker . 1) . -339) ((marker . 1) . -210) ((marker . 1) . -424) ((marker . 1) . -145) ((marker . 1) . -424) ((marker . 1) . -424) ((marker . 1) . -424) ((marker . 1) . -175) ((marker . 1) . -424) ((marker . 1) . -424) ((marker . 1) . -175) ((marker . 1) . -145) ((marker . 1) . -424) ((marker . 1) . -424) ((marker . 1) . -424) ((marker . 1) . -175) ((marker . 1) . -516) ((marker . 1) . -483) ((marker . 1) . -456) ((marker . 1) . -210) ((marker . 1) . -483) ((marker . 1) . -210) ((marker . 1) . -483) ((marker . 1) . -483) ((marker . 1) . -483) ((marker . 1) . -210) ((marker . 1) . -516) ((marker . 1) . -516) ((marker . 1) . -516) ((marker . 1) . -516) ((marker . 1) . -483) ((marker . 1) . -516) ((marker . 1) . -516) ((marker . 1) . -516) ((marker . 1) . -516) ((marker . 1) . -424) ((marker . 1) . -339) ((marker . 1) . -516) ((marker . 1) . -424) ((marker . 1) . -424) ((marker . 1) . -424) ((marker . 1) . -424) ((marker . 1) . -424) ((marker . 1) . -424) ((marker . 1) . -424) ((marker . 1) . -424) ((marker . 1) . -424) ((marker . 1) . -424) ((marker . 1) . -424) ((marker . 1) . -424) ((marker . 1) . -424) ((marker . 1) . -424) ((marker . 1) . -424) ((marker . 1) . -424) ((marker . 1) . -424) ((marker . 1) . -424) ((marker . 1) . -424) ((marker . 1) . -424) ((marker . 1) . -424) ((marker . 1) . -424) ((marker . 1) . -424) ((marker . 1) . -424) ((marker . 1) . -424) ((marker . 1) . -423) ((marker . 1) . -424) ((marker . 1) . -424) ((marker . 1) . -424) ((marker . 1) . -456) ((marker . 1) . -483) ((marker . 1) . -424) ((marker . 1) . -456) ((marker . 1) . -456) ((marker . 1) . -456) ((marker . 1) . -456) ((marker . 1) . -456) ((marker . 1) . -456) ((marker . 1) . -456) ((marker . 1) . -456) ((marker . 1) . -456) ((marker . 1) . -456) ((marker . 1) . -476) ((marker . 1) . -456) ((marker . 1) . -456) ((marker . 1) . -456) ((marker . 1) . -456) ((marker . 1) . -456) ((marker . 1) . -456) ((marker . 1) . -456) ((marker . 1) . -456) ((marker . 1) . -456) ((marker . 1) . -456) ((marker . 1) . -456) ((marker . 1) . -456) ((marker) . -361) ((marker) . -362) ((marker) . -365) ((marker) . -366) ((marker) . -335) ((marker) . -336) ((marker) . -293) ((marker) . -294) ((marker) . -297) ((marker) . -298) ((marker) . -259) ((marker) . -260) ((marker) . -263) ((marker) . -264) ((marker) . -210) ((marker) . -211) ((marker) . -214) ((marker) . -215) ((marker) . -175) ((marker) . -176) ((marker) . -179) ((marker) . -180) ((marker) . -146) ((marker) . -147) ((marker) . -122) ((marker) . -123) ((marker) . -126) ((marker) . -127) ((marker) . -89) ((marker) . -90) ((marker) . -93) ((marker) . -94) ((marker) . -54) ((marker) . -55) ((marker) . -58) ((marker) . -59) ((marker) . -12) ((marker) . -13) ((marker . 1) . -456) ((marker . 1) . -456) ((marker . 1) . -456) ((marker . 1) . -456) ((marker . 1) . -456) ((marker . 1) . -456) ((marker . 1) . -456) ((marker . 649) . -421) ((marker . 649) . -421) ((marker . 1) . -421) ((marker*) . 202) ((marker) . -422) ((marker*) . 249) ((marker) . -375) (t 24237 713 954152 878000) nil (26 . 649) ("md = {\"aaaa\": \"bbbb\", \"aaaa\": \"bbbb\", \"aaaa\": \"bbbb\", \"aaaa\": \"bbbb\", \"aaaa\": \"bbbb\"}" . 26) (nil rear-nonsticky t 110 . 111) (1 . 111) ("#!/usr/bin/env python3


md = {
    \"aaaa\": \"bbbb\",
    \"aaaa\": \"bbbb\",
    \"aaaa\": \"bbbb\",
    \"aaaa\": \"bbbb\",
    \"aaaa\": \"bbbb\",
}
" . 1) (t 24237 712 644127 210000) (1 . 135) ("#!/usr/bin/env python3


md = {\"aaaa\": \"bbbb\", \"aaaa\": \"bbbb\", \"aaaa\": \"bbbb\", \"aaaa\": \"bbbb\", \"aaaa\": \"bbbb\"}" . 1) nil (1 . 111) ("#!/usr/bin/env python3


md = {
    \"aaaa\": \"bbbb\",
    \"aaaa\": \"bbbb\",
    \"aaaa\": \"bbbb\",
    \"aaaa\": \"bbbb\",
    \"aaaa\": \"bbbb\",
}
" . 1) (t 24237 711 692288 686000) nil (1 . 135) ("#!/usr/bin/env python3


md = {\"aaaa\": \"bbbb\", \"aaaa\": \"bbbb\", \"aaaa\": \"bbbb\", \"aaaa\": \"bbbb\", \"aaaa\": \"bbbb\"}" . 1) 110 nil (1 . 111) ("#!/usr/bin/env python3


md = {
    \"aaaa\": \"bbbb\",
    \"aaaa\": \"bbbb\",
    \"aaaa\": \"bbbb\",
    \"aaaa\": \"bbbb\",
    \"aaaa\": \"bbbb\",
}
" . 1) (t 24237 708 692340 950000) nil (1 . 135) ("#!/usr/bin/env python3


md = {\"aaaa\": \"bbbb\", \"aaaa\": \"bbbb\", \"aaaa\": \"bbbb\", \"aaaa\": \"bbbb\", \"aaaa\": \"bbbb\"}" . 1) 110 nil (nil rear-nonsticky nil 110 . 111) (nil fontified nil 26 . 111) (26 . 111) 649 ("class User:
    def __init__(self, first, last, age):
        self.first = first.title()
        self.last = last.title()
        self.age = age

    def describe_user(self):
        print(\"## User Info ##\\n\")
        print(f\"Name: {self.first} {self.last}\")
        print(f\"Age: {self.age}\")
        print(f\"Birth Year: {self.age}\")

    def greet_user(self):
        print(f\"\\n>> Welcome, {self.first} {self.last}!<<\\n\")


u1 = User(\"dave\", \"jones\", 37)
u2 = User(\"mr\", \"big\", 27)
u3 = User(\"laura\", \"black\", 15)

u1.describe_user()
u1.greet_user()

u2.describe_user()
u2.greet_user()

u3.describe_user()
u3.greet_user()
" . 26) 649 (t 24235 32959 37234 729000) nil (26 . 649) ("import items
import world


class Player:
    def __init__(self):
        self.inventory = [items.Rock(),
                          items.Dagger(),
                          items.CrustyBread()]
        self.x = world.start_tile_location[0]
        self.y = world.start_tile_location[1]
        self.hp = 100
        self.gold = 5
        self.victory = False

    def is_alive(self):
        return self.hp > 0

    def print_inventory(self):
        print(\"Inventory:\")
        for item in self.inventory:
            print('* ' + str(item))
        print(\"Gold: {}\".format(self.gold))

    def heal(self):
        consumables = [item for item in self.inventory
                       if isinstance(item, items.Consumable)]
        if not consumables:
            print(\"You don't have any items to heal you!\")
            return

        for i, item in enumerate(consumables, 1):
            print(\"Choose an item to use to heal: \")
            print(\"{}. {}\".format(i, item))

        valid = False
        while not valid:
            choice = input(\"\")
            try:
                to_eat = consumables[int(choice) - 1]
                self.hp = min(100, self.hp + to_eat.healing_value)
                self.inventory.remove(to_eat)
                print(\"Current HP: {}\".format(self.hp))
                valid = True
            except (ValueError, IndexError):
                print(\"Invalid choice, try again.\")

    def most_powerful_weapon(self):
        max_damage = 0
        best_weapon = None
        for item in self.inventory:
            try:
                if item.damage > max_damage:
                    best_weapon = item
                    max_damage = item.damage
            except AttributeError:
                pass

        return best_weapon

    def move(self, dx, dy):
        self.x += dx
        self.y += dy

    def move_north(self):
        self.move(dx=0, dy=-1)

    def move_south(self):
        self.move(dx=0, dy=1)

    def move_east(self):
        self.move(dx=1, dy=0)

    def move_west(self):
        self.move(dx=-1, dy=0)

    def attack(self):
        best_weapon = self.most_powerful_weapon()
        room = world.tile_at(self.x, self.y)
        enemy = room.enemy
        print(\"You use {} against {}!\".format(best_weapon.name, enemy.name))
        enemy.hp -= best_weapon.damage
        if not enemy.is_alive():
            print(\"You killed {}!\".format(enemy.name))
        else:
            print(\"{} HP is {}.\".format(enemy.name, enemy.hp))

    def trade(self):
        room = world.tile_at(self.x, self.y)
        room.check_if_trade(self)" . 26) (nil fontified nil 2595 . 2596) (nil fontified nil 2594 . 2595) (nil fontified nil 2593 . 2594) (nil fontified nil 2592 . 2593) (nil fontified nil 2588 . 2592) (nil fontified nil 2587 . 2588) (nil fontified nil 2586 . 2587) (nil fontified nil 2585 . 2586) (nil fontified nil 2584 . 2585) (nil fontified nil 2580 . 2584) (nil fontified nil 2579 . 2580) (nil fontified nil 2572 . 2579) (nil fontified nil 2571 . 2572) (nil fontified nil 2565 . 2571) (nil fontified nil 2564 . 2565) (nil fontified nil 2563 . 2564) (nil fontified nil 2559 . 2563) (nil fontified nil 2551 . 2559) (nil fontified nil 2550 . 2551) (nil fontified nil 2549 . 2550) (nil fontified nil 2548 . 2549) (nil fontified nil 2546 . 2548) (nil fontified nil 2544 . 2546) (nil fontified nil 2543 . 2544) (nil fontified nil 2538 . 2543) (nil fontified nil 2537 . 2538) (nil fontified nil 2534 . 2537) (nil fontified nil 2529 . 2534) (nil fontified nil 2528 . 2529) (nil fontified nil 2527 . 2528) (nil fontified nil 2526 . 2527) (nil fontified nil 2524 . 2526) (nil fontified nil 2523 . 2524) (nil fontified nil 2517 . 2523) (nil fontified nil 2516 . 2517) (nil fontified nil 2512 . 2516) (nil fontified nil 2511 . 2512) (nil fontified nil 2506 . 2511) (nil fontified nil 2505 . 2506) (nil fontified nil 2499 . 2505) (nil fontified nil 2498 . 2499) (nil fontified nil 2497 . 2498) (nil fontified nil 2485 . 2497) (nil fontified nil 2484 . 2485) (nil fontified nil 2483 . 2484) (nil fontified nil 2478 . 2483) (nil fontified nil 2465 . 2478) (nil fontified nil 2464 . 2465) (nil fontified nil 2460 . 2464) (nil fontified nil 2451 . 2460) (nil fontified nil 2450 . 2451) (nil fontified nil 2449 . 2450) (nil fontified nil 2445 . 2449) (nil fontified nil 2444 . 2445) (nil fontified nil 2439 . 2444) (nil fontified nil 2438 . 2439) (nil fontified nil 2432 . 2438) (nil fontified nil 2431 . 2432) (nil fontified nil 2430 . 2431) (nil fontified nil 2416 . 2430) (nil fontified nil 2415 . 2416) (nil fontified nil 2414 . 2415) (nil fontified nil 2409 . 2414) (nil fontified nil 2396 . 2409) (nil fontified nil 2395 . 2396) (nil fontified nil 2394 . 2395) (nil fontified nil 2393 . 2394) (nil fontified nil 2385 . 2393) (nil fontified nil 2384 . 2385) (nil fontified nil 2378 . 2384) (nil fontified nil 2375 . 2378) (nil fontified nil 2374 . 2375) (nil fontified nil 2372 . 2374) (nil fontified nil 2357 . 2372) (nil fontified nil 2356 . 2357) (nil fontified nil 2344 . 2356) (nil fontified nil 2343 . 2344) (nil fontified nil 2342 . 2343) (nil fontified nil 2339 . 2342) (nil fontified nil 2338 . 2339) (nil fontified nil 2324 . 2338) (nil fontified nil 2323 . 2324) (nil fontified nil 2322 . 2323) (nil fontified nil 2318 . 2322) (nil fontified nil 2317 . 2318) (nil fontified nil 2311 . 2317) (nil fontified nil 2310 . 2311) (nil fontified nil 2306 . 2310) (nil fontified nil 2305 . 2306) (nil fontified nil 2294 . 2305) (nil fontified nil 2293 . 2294) (nil fontified nil 2287 . 2293) (nil fontified nil 2286 . 2287) (nil fontified nil 2285 . 2286) (nil fontified nil 2263 . 2285) (nil fontified nil 2262 . 2263) (nil fontified nil 2261 . 2262) (nil fontified nil 2256 . 2261) (nil fontified nil 2242 . 2256) (nil fontified nil 2241 . 2242) (nil fontified nil 2236 . 2241) (nil fontified nil 2235 . 2236) (nil fontified nil 2234 . 2235) (nil fontified nil 2229 . 2234) (nil fontified nil 2220 . 2229) (nil fontified nil 2219 . 2220) (nil fontified nil 2218 . 2219) (nil fontified nil 2217 . 2218) (nil fontified nil 2213 . 2217) (nil fontified nil 2212 . 2213) (nil fontified nil 2211 . 2212) (nil fontified nil 2210 . 2211) (nil fontified nil 2209 . 2210) (nil fontified nil 2205 . 2209) (nil fontified nil 2204 . 2205) (nil fontified nil 2197 . 2204) (nil fontified nil 2196 . 2197) (nil fontified nil 2190 . 2196) (nil fontified nil 2189 . 2190) (nil fontified nil 2188 . 2189) (nil fontified nil 2184 . 2188) (nil fontified nil 2175 . 2184) (nil fontified nil 2174 . 2175) (nil fontified nil 2173 . 2174) (nil fontified nil 2153 . 2173) (nil fontified nil 2152 . 2153) (nil fontified nil 2148 . 2152) (nil fontified nil 2147 . 2148) (nil fontified nil 2146 . 2147) (nil fontified nil 2145 . 2146) (nil fontified nil 2134 . 2145) (nil fontified nil 2125 . 2134) (nil fontified nil 2124 . 2125) (nil fontified nil 2123 . 2124) (nil fontified nil 2119 . 2123) (nil fontified nil 2118 . 2119) (nil fontified nil 2112 . 2118) (nil fontified nil 2111 . 2112) (nil fontified nil 2108 . 2111) (nil fontified nil 2102 . 2108) (nil fontified nil 2101 . 2102) (nil fontified nil 2100 . 2101) (nil fontified nil 2099 . 2100) (nil fontified nil 2096 . 2099) (nil fontified nil 2095 . 2096) (nil fontified nil 2094 . 2095) (nil fontified nil 2093 . 2094) (nil fontified nil 2092 . 2093) (nil fontified nil 2090 . 2092) (nil fontified nil 2089 . 2090) (nil fontified nil 2085 . 2089) (nil fontified nil 2084 . 2085) (nil fontified nil 2080 . 2084) (nil fontified nil 2071 . 2080) (nil fontified nil 2070 . 2071) (nil fontified nil 2069 . 2070) (nil fontified nil 2065 . 2069) (nil fontified nil 2064 . 2065) (nil fontified nil 2055 . 2064) (nil fontified nil 2054 . 2055) (nil fontified nil 2051 . 2054) (nil fontified nil 2046 . 2051) (nil fontified nil 2045 . 2046) (nil fontified nil 2044 . 2045) (nil fontified nil 2043 . 2044) (nil fontified nil 2042 . 2043) (nil fontified nil 2039 . 2042) (nil fontified nil 2038 . 2039) (nil fontified nil 2037 . 2038) (nil fontified nil 2036 . 2037) (nil fontified nil 2034 . 2036) (nil fontified nil 2033 . 2034) (nil fontified nil 2029 . 2033) (nil fontified nil 2028 . 2029) (nil fontified nil 2024 . 2028) (nil fontified nil 2016 . 2024) (nil fontified nil 1449 . 2016) (nil fontified nil 1448 . 1449) (nil fontified nil 1422 . 1448) (nil fontified nil 1421 . 1422) (nil fontified nil 1307 . 1421) (nil fontified nil 1306 . 1307) (nil fontified nil 1292 . 1306) (nil fontified nil 1291 . 1292) (nil fontified nil 1083 . 1291) (nil fontified nil 1082 . 1083) (nil fontified nil 1081 . 1082) (nil fontified nil 1054 . 1081) (nil fontified t 1053 . 1054) (nil fontified t 1052 . 1053) (nil fontified t 1046 . 1052) (nil fontified t 1043 . 1046) (nil fontified t 1042 . 1043) (nil fontified t 1037 . 1042) (nil fontified t 1034 . 1037) (nil fontified t 1028 . 1034) (nil fontified t 1023 . 1028) (nil fontified t 1022 . 1023) (nil fontified t 1021 . 1022) (nil fontified t 1020 . 1021) (nil fontified t 1015 . 1020) (nil fontified t 1005 . 1015) (nil fontified t 1004 . 1005) (nil fontified t 1003 . 1004) (nil fontified t 998 . 1003) (nil fontified t 997 . 998) (nil fontified t 996 . 997) (nil fontified t 995 . 996) (nil fontified t 989 . 995) (nil fontified t 988 . 989) (nil fontified t 987 . 988) (nil fontified t 981 . 987) (nil fontified t 980 . 981) (nil fontified t 979 . 980) (nil fontified t 974 . 979) (nil fontified t 961 . 974) (nil fontified t 960 . 961) (nil fontified t 959 . 960) (nil fontified t 928 . 959) (nil fontified t 927 . 928) (nil fontified t 926 . 927) (nil fontified t 921 . 926) (nil fontified t 908 . 921) (nil fontified t 907 . 908) (nil fontified t 906 . 907) (nil fontified t 905 . 906) (nil fontified t 904 . 905) (nil fontified t 903 . 904) (nil fontified t 892 . 903) (nil fontified t 891 . 892) (nil fontified t 882 . 891) (nil fontified t 881 . 882) (nil fontified t 879 . 881) (nil fontified t 873 . 879) (nil fontified t 872 . 873) (nil fontified t 870 . 872) (nil fontified t 867 . 870) (nil fontified t 857 . 867) (nil fontified t 851 . 857) (nil fontified t 838 . 851) (nil fontified t 837 . 838) (nil fontified t 836 . 837) (nil fontified t 799 . 836) (nil fontified t 798 . 799) (nil fontified t 797 . 798) (nil fontified t 792 . 797) (nil fontified t 779 . 792) (nil fontified t 778 . 779) (nil fontified t 766 . 778) (nil fontified t 763 . 766) (nil fontified t 762 . 763) (nil fontified t 760 . 762) (nil fontified t 751 . 760) (nil fontified t 750 . 751) (nil fontified t 749 . 750) (nil fontified t 739 . 749) (nil fontified t 738 . 739) (nil fontified t 732 . 738) (nil fontified t 731 . 732) (nil fontified t 727 . 731) (nil fontified t 726 . 727) (nil fontified t 716 . 726) (nil fontified t 715 . 716) (nil fontified t 713 . 715) (nil fontified t 680 . 713) (nil fontified t 679 . 680) (nil fontified t 675 . 679) (nil fontified t 674 . 675) (nil fontified t 672 . 674) (nil fontified t 666 . 672) (nil fontified t 663 . 666) (nil fontified t 658 . 663) (nil fontified t 657 . 658) (nil fontified t 656 . 657) (nil fontified t 655 . 656) (nil fontified t 654 . 655) (nil fontified t 643 . 654) (nil fontified t 634 . 643) (nil fontified t 633 . 634) (nil fontified t 632 . 633) (nil fontified t 628 . 632) (nil fontified t 627 . 628) (nil fontified t 623 . 627) (nil fontified t 622 . 623) (nil fontified t 619 . 622) (nil fontified t 613 . 619) (nil fontified t 612 . 613) (nil fontified t 611 . 612) (nil fontified t 607 . 611) (nil fontified t 606 . 607) (nil fontified t 602 . 606) (nil fontified t 601 . 602) (nil fontified t 595 . 601) (nil fontified t 594 . 595) (nil fontified t 593 . 594) (nil fontified t 585 . 593) (nil fontified t 584 . 585) (nil fontified t 583 . 584) (nil fontified t 578 . 583) (nil fontified t 569 . 578) (nil fontified t 568 . 569) (nil fontified t 567 . 568) (nil fontified t 563 . 567) (nil fontified t 562 . 563) (nil fontified t 559 . 562) (nil fontified t 558 . 559) (nil fontified t 557 . 558) (nil fontified t 556 . 557) (nil fontified t 555 . 556) (nil fontified t 553 . 555) (nil fontified t 552 . 553) (nil fontified t 551 . 552) (nil fontified t 546 . 551) (nil fontified t 534 . 546) (nil fontified t 533 . 534) (nil fontified t 532 . 533) (nil fontified t 526 . 532) (nil fontified t 523 . 526) (nil fontified t 522 . 523) (nil fontified t 518 . 522) (nil fontified t 517 . 518) (nil fontified t 515 . 517) (nil fontified t 509 . 515) (nil fontified t 506 . 509) (nil fontified t 501 . 506) (nil fontified t 497 . 501) (nil fontified t 496 . 497) (nil fontified t 495 . 496) (nil fontified t 485 . 495) (nil fontified t 484 . 485) (nil fontified t 483 . 484) (nil fontified t 478 . 483) (nil fontified t 469 . 478) (nil fontified t 468 . 469) (nil fontified t 467 . 468) (nil fontified t 463 . 467) (nil fontified t 462 . 463) (nil fontified t 447 . 462) (nil fontified t 446 . 447) (nil fontified t 443 . 446) (nil fontified t 437 . 443) (nil fontified t 436 . 437) (nil fontified t 435 . 436) (nil fontified t 434 . 435) (nil fontified t 431 . 434) (nil fontified t 430 . 431) (nil fontified t 426 . 430) (nil fontified t 425 . 426) (nil fontified t 419 . 425) (nil fontified t 410 . 419) (nil fontified t 409 . 410) (nil fontified t 408 . 409) (nil fontified t 404 . 408) (nil fontified t 403 . 404) (nil fontified t 395 . 403) (nil fontified t 394 . 395) (nil fontified t 391 . 394) (nil fontified t 385 . 391) (nil fontified t 380 . 385) (nil fontified t 379 . 380) (nil fontified t 378 . 379) (nil fontified t 370 . 378) (nil fontified t 369 . 370) (nil fontified t 365 . 369) (nil fontified t 356 . 365) (nil fontified t 355 . 356) (nil fontified t 354 . 355) (nil fontified t 353 . 354) (nil fontified t 348 . 353) (nil fontified t 347 . 348) (nil fontified t 343 . 347) (nil fontified t 334 . 343) (nil fontified t 331 . 334) (nil fontified t 330 . 331) (nil fontified t 329 . 330) (nil fontified t 326 . 329) (nil fontified t 325 . 326) (nil fontified t 321 . 325) (nil fontified t 312 . 321) (nil fontified t 311 . 312) (nil fontified t 310 . 311) (nil fontified t 309 . 310) (nil fontified t 290 . 309) (nil fontified t 289 . 290) (nil fontified t 283 . 289) (nil fontified t 282 . 283) (nil fontified t 280 . 282) (nil fontified t 279 . 280) (nil fontified t 275 . 279) (nil fontified t 266 . 275) (nil fontified t 265 . 266) (nil fontified t 264 . 265) (nil fontified t 263 . 264) (nil fontified t 244 . 263) (nil fontified t 243 . 244) (nil fontified t 237 . 243) (nil fontified t 236 . 237) (nil fontified t 234 . 236) (nil fontified t 233 . 234) (nil fontified t 229 . 233) (nil fontified t 220 . 229) (nil fontified t 219 . 220) (nil fontified t 218 . 219) (nil fontified t 217 . 218) (nil fontified t 206 . 217) (nil fontified t 205 . 206) (nil fontified t 173 . 205) (nil fontified t 172 . 173) (nil fontified t 171 . 172) (nil fontified t 170 . 171) (nil fontified t 164 . 170) (nil fontified t 163 . 164) (nil fontified t 131 . 163) (nil fontified t 130 . 131) (nil fontified t 129 . 130) (nil fontified t 128 . 129) (nil fontified t 124 . 128) (nil fontified t 123 . 124) (nil fontified t 118 . 123) (nil fontified t 117 . 118) (nil fontified t 116 . 117) (nil fontified t 115 . 116) (nil fontified t 105 . 115) (nil fontified t 104 . 105) (nil fontified t 100 . 104) (nil fontified t 91 . 100) (nil fontified t 90 . 91) (nil fontified t 89 . 90) (nil fontified t 85 . 89) (nil fontified t 84 . 85) (nil fontified t 76 . 84) (nil fontified t 75 . 76) (nil fontified t 72 . 75) (nil fontified t 67 . 72) (nil fontified t 66 . 67) (nil fontified t 60 . 66) (nil fontified t 59 . 60) (nil fontified t 54 . 59) (nil fontified t 45 . 54) (nil fontified t 39 . 45) (nil fontified t 32 . 39) (nil fontified t 26 . 32) (nil rear-nonsticky t 2628 . 2629) nil (1 . 2629) ("#!/usr/bin/env python3


import items
import world


class Player:
    def __init__(self):
        self.inventory = [items.Rock(), items.Dagger(), items.CrustyBread()]
        self.x = world.start_tile_location[0]
        self.y = world.start_tile_location[1]
        self.hp = 100
        self.gold = 5
        self.victory = False

    def is_alive(self):
        return self.hp > 0

    def print_inventory(self):
        print(\"Inventory:\")
        for item in self.inventory:
            print(\"* \" + str(item))
        print(\"Gold: {}\".format(self.gold))

    def heal(self):
        consumables = [
            item
            for item in self.inventory
            if isinstance(item, items.Consumable)
        ]
        if not consumables:
            print(\"You don't have any items to heal you!\")
            return

        for i, item in enumerate(consumables, 1):
            print(\"Choose an item to use to heal: \")
            print(\"{}. {}\".format(i, item))

        valid = False
        while not valid:
            choice = input(\"\")
            try:
                to_eat = consumables[int(choice) - 1]
                self.hp = min(100, self.hp + to_eat.healing_value)
                self.inventory.remove(to_eat)
                print(\"Current HP: {}\".format(self.hp))
                valid = True
            except (ValueError, IndexError):
                print(\"Invalid choice, try again.\")

    def most_powerful_weapon(self):
        max_damage = 0
        best_weapon = None
        for item in self.inventory:
            try:
                if item.damage > max_damage:
                    best_weapon = item
                    max_damage = item.damage
            except AttributeError:
                pass

        return best_weapon

    def move(self, dx, dy):
        self.x += dx
        self.y += dy

    def move_north(self):
        self.move(dx=0, dy=-1)

    def move_south(self):
        self.move(dx=0, dy=1)

    def move_east(self):
        self.move(dx=1, dy=0)

    def move_west(self):
        self.move(dx=-1, dy=0)

    def attack(self):
        best_weapon = self.most_powerful_weapon()
        room = world.tile_at(self.x, self.y)
        enemy = room.enemy
        print(\"You use {} against {}!\".format(best_weapon.name, enemy.name))
        enemy.hp -= best_weapon.damage
        if not enemy.is_alive():
            print(\"You killed {}!\".format(enemy.name))
        else:
            print(\"{} HP is {}.\".format(enemy.name, enemy.hp))

    def trade(self):
        room = world.tile_at(self.x, self.y)
        room.check_if_trade(self)
" . 1) (t 24235 32732 40461 660000) nil (1 . 2601) ("#!/usr/bin/env python3


import items
import world


class Player:
    def __init__(self):
        self.inventory = [items.Rock(),
                          items.Dagger(),
                          items.CrustyBread()]
        self.x = world.start_tile_location[0]
        self.y = world.start_tile_location[1]
        self.hp = 100
        self.gold = 5
        self.victory = False

    def is_alive(self):
        return self.hp > 0

    def print_inventory(self):
        print(\"Inventory:\")
        for item in self.inventory:
            print('* ' + str(item))
        print(\"Gold: {}\".format(self.gold))

    def heal(self):
        consumables = [item for item in self.inventory
                       if isinstance(item, items.Consumable)]
        if not consumables:
            print(\"You don't have any items to heal you!\")
            return

        for i, item in enumerate(consumables, 1):
            print(\"Choose an item to use to heal: \")
            print(\"{}. {}\".format(i, item))

        valid = False
        while not valid:
            choice = input(\"\")
            try:
                to_eat = consumables[int(choice) - 1]
                self.hp = min(100, self.hp + to_eat.healing_value)
                self.inventory.remove(to_eat)
                print(\"Current HP: {}\".format(self.hp))
                valid = True
            except (ValueError, IndexError):
                print(\"Invalid choice, try again.\")

    def most_powerful_weapon(self):
        max_damage = 0
        best_weapon = None
        for item in self.inventory:
            try:
                if item.damage > max_damage:
                    best_weapon = item
                    max_damage = item.damage
            except AttributeError:
                pass

        return best_weapon

    def move(self, dx, dy):
        self.x += dx
        self.y += dy

    def move_north(self):
        self.move(dx=0, dy=-1)

    def move_south(self):
        self.move(dx=0, dy=1)

    def move_east(self):
        self.move(dx=1, dy=0)

    def move_west(self):
        self.move(dx=-1, dy=0)

    def attack(self):
        best_weapon = self.most_powerful_weapon()
        room = world.tile_at(self.x, self.y)
        enemy = room.enemy
        print(\"You use {} against {}!\".format(best_weapon.name, enemy.name))
        enemy.hp -= best_weapon.damage
        if not enemy.is_alive():
            print(\"You killed {}!\".format(enemy.name))
        else:
            print(\"{} HP is {}.\".format(enemy.name, enemy.hp))

    def trade(self):
        room = world.tile_at(self.x, self.y)
        room.check_if_trade(self)" . 1) nil (1 . 2629) ("#!/usr/bin/env python3


import items
import world


class Player:
    def __init__(self):
        self.inventory = [items.Rock(), items.Dagger(), items.CrustyBread()]
        self.x = world.start_tile_location[0]
        self.y = world.start_tile_location[1]
        self.hp = 100
        self.gold = 5
        self.victory = False

    def is_alive(self):
        return self.hp > 0

    def print_inventory(self):
        print(\"Inventory:\")
        for item in self.inventory:
            print(\"* \" + str(item))
        print(\"Gold: {}\".format(self.gold))

    def heal(self):
        consumables = [
            item
            for item in self.inventory
            if isinstance(item, items.Consumable)
        ]
        if not consumables:
            print(\"You don't have any items to heal you!\")
            return

        for i, item in enumerate(consumables, 1):
            print(\"Choose an item to use to heal: \")
            print(\"{}. {}\".format(i, item))

        valid = False
        while not valid:
            choice = input(\"\")
            try:
                to_eat = consumables[int(choice) - 1]
                self.hp = min(100, self.hp + to_eat.healing_value)
                self.inventory.remove(to_eat)
                print(\"Current HP: {}\".format(self.hp))
                valid = True
            except (ValueError, IndexError):
                print(\"Invalid choice, try again.\")

    def most_powerful_weapon(self):
        max_damage = 0
        best_weapon = None
        for item in self.inventory:
            try:
                if item.damage > max_damage:
                    best_weapon = item
                    max_damage = item.damage
            except AttributeError:
                pass

        return best_weapon

    def move(self, dx, dy):
        self.x += dx
        self.y += dy

    def move_north(self):
        self.move(dx=0, dy=-1)

    def move_south(self):
        self.move(dx=0, dy=1)

    def move_east(self):
        self.move(dx=1, dy=0)

    def move_west(self):
        self.move(dx=-1, dy=0)

    def attack(self):
        best_weapon = self.most_powerful_weapon()
        room = world.tile_at(self.x, self.y)
        enemy = room.enemy
        print(\"You use {} against {}!\".format(best_weapon.name, enemy.name))
        enemy.hp -= best_weapon.damage
        if not enemy.is_alive():
            print(\"You killed {}!\".format(enemy.name))
        else:
            print(\"{} HP is {}.\".format(enemy.name, enemy.hp))

    def trade(self):
        room = world.tile_at(self.x, self.y)
        room.check_if_trade(self)
" . 1) (t 24235 32729 427077 62000) nil (1 . 2601) ("#!/usr/bin/env python3


import items
import world


class Player:
    def __init__(self):
        self.inventory = [items.Rock(),
                          items.Dagger(),
                          items.CrustyBread()]
        self.x = world.start_tile_location[0]
        self.y = world.start_tile_location[1]
        self.hp = 100
        self.gold = 5
        self.victory = False

    def is_alive(self):
        return self.hp > 0

    def print_inventory(self):
        print(\"Inventory:\")
        for item in self.inventory:
            print('* ' + str(item))
        print(\"Gold: {}\".format(self.gold))

    def heal(self):
        consumables = [item for item in self.inventory
                       if isinstance(item, items.Consumable)]
        if not consumables:
            print(\"You don't have any items to heal you!\")
            return

        for i, item in enumerate(consumables, 1):
            print(\"Choose an item to use to heal: \")
            print(\"{}. {}\".format(i, item))

        valid = False
        while not valid:
            choice = input(\"\")
            try:
                to_eat = consumables[int(choice) - 1]
                self.hp = min(100, self.hp + to_eat.healing_value)
                self.inventory.remove(to_eat)
                print(\"Current HP: {}\".format(self.hp))
                valid = True
            except (ValueError, IndexError):
                print(\"Invalid choice, try again.\")

    def most_powerful_weapon(self):
        max_damage = 0
        best_weapon = None
        for item in self.inventory:
            try:
                if item.damage > max_damage:
                    best_weapon = item
                    max_damage = item.damage
            except AttributeError:
                pass

        return best_weapon

    def move(self, dx, dy):
        self.x += dx
        self.y += dy

    def move_north(self):
        self.move(dx=0, dy=-1)

    def move_south(self):
        self.move(dx=0, dy=1)

    def move_east(self):
        self.move(dx=1, dy=0)

    def move_west(self):
        self.move(dx=-1, dy=0)

    def attack(self):
        best_weapon = self.most_powerful_weapon()
        room = world.tile_at(self.x, self.y)
        enemy = room.enemy
        print(\"You use {} against {}!\".format(best_weapon.name, enemy.name))
        enemy.hp -= best_weapon.damage
        if not enemy.is_alive():
            print(\"You killed {}!\".format(enemy.name))
        else:
            print(\"{} HP is {}.\".format(enemy.name, enemy.hp))

    def trade(self):
        room = world.tile_at(self.x, self.y)
        room.check_if_trade(self)" . 1) nil (1 . 2629) ("#!/usr/bin/env python3


import items
import world


class Player:
    def __init__(self):
        self.inventory = [items.Rock(), items.Dagger(), items.CrustyBread()]
        self.x = world.start_tile_location[0]
        self.y = world.start_tile_location[1]
        self.hp = 100
        self.gold = 5
        self.victory = False

    def is_alive(self):
        return self.hp > 0

    def print_inventory(self):
        print(\"Inventory:\")
        for item in self.inventory:
            print(\"* \" + str(item))
        print(\"Gold: {}\".format(self.gold))

    def heal(self):
        consumables = [
            item
            for item in self.inventory
            if isinstance(item, items.Consumable)
        ]
        if not consumables:
            print(\"You don't have any items to heal you!\")
            return

        for i, item in enumerate(consumables, 1):
            print(\"Choose an item to use to heal: \")
            print(\"{}. {}\".format(i, item))

        valid = False
        while not valid:
            choice = input(\"\")
            try:
                to_eat = consumables[int(choice) - 1]
                self.hp = min(100, self.hp + to_eat.healing_value)
                self.inventory.remove(to_eat)
                print(\"Current HP: {}\".format(self.hp))
                valid = True
            except (ValueError, IndexError):
                print(\"Invalid choice, try again.\")

    def most_powerful_weapon(self):
        max_damage = 0
        best_weapon = None
        for item in self.inventory:
            try:
                if item.damage > max_damage:
                    best_weapon = item
                    max_damage = item.damage
            except AttributeError:
                pass

        return best_weapon

    def move(self, dx, dy):
        self.x += dx
        self.y += dy

    def move_north(self):
        self.move(dx=0, dy=-1)

    def move_south(self):
        self.move(dx=0, dy=1)

    def move_east(self):
        self.move(dx=1, dy=0)

    def move_west(self):
        self.move(dx=-1, dy=0)

    def attack(self):
        best_weapon = self.most_powerful_weapon()
        room = world.tile_at(self.x, self.y)
        enemy = room.enemy
        print(\"You use {} against {}!\".format(best_weapon.name, enemy.name))
        enemy.hp -= best_weapon.damage
        if not enemy.is_alive():
            print(\"You killed {}!\".format(enemy.name))
        else:
            print(\"{} HP is {}.\".format(enemy.name, enemy.hp))

    def trade(self):
        room = world.tile_at(self.x, self.y)
        room.check_if_trade(self)
" . 1) (t 24235 32727 719070 50000) nil (1 . 2601) ("#!/usr/bin/env python3


import items
import world


class Player:
    def __init__(self):
        self.inventory = [items.Rock(),
                          items.Dagger(),
                          items.CrustyBread()]
        self.x = world.start_tile_location[0]
        self.y = world.start_tile_location[1]
        self.hp = 100
        self.gold = 5
        self.victory = False

    def is_alive(self):
        return self.hp > 0

    def print_inventory(self):
        print(\"Inventory:\")
        for item in self.inventory:
            print('* ' + str(item))
        print(\"Gold: {}\".format(self.gold))

    def heal(self):
        consumables = [item for item in self.inventory
                       if isinstance(item, items.Consumable)]
        if not consumables:
            print(\"You don't have any items to heal you!\")
            return

        for i, item in enumerate(consumables, 1):
            print(\"Choose an item to use to heal: \")
            print(\"{}. {}\".format(i, item))

        valid = False
        while not valid:
            choice = input(\"\")
            try:
                to_eat = consumables[int(choice) - 1]
                self.hp = min(100, self.hp + to_eat.healing_value)
                self.inventory.remove(to_eat)
                print(\"Current HP: {}\".format(self.hp))
                valid = True
            except (ValueError, IndexError):
                print(\"Invalid choice, try again.\")

    def most_powerful_weapon(self):
        max_damage = 0
        best_weapon = None
        for item in self.inventory:
            try:
                if item.damage > max_damage:
                    best_weapon = item
                    max_damage = item.damage
            except AttributeError:
                pass

        return best_weapon

    def move(self, dx, dy):
        self.x += dx
        self.y += dy

    def move_north(self):
        self.move(dx=0, dy=-1)

    def move_south(self):
        self.move(dx=0, dy=1)

    def move_east(self):
        self.move(dx=1, dy=0)

    def move_west(self):
        self.move(dx=-1, dy=0)

    def attack(self):
        best_weapon = self.most_powerful_weapon()
        room = world.tile_at(self.x, self.y)
        enemy = room.enemy
        print(\"You use {} against {}!\".format(best_weapon.name, enemy.name))
        enemy.hp -= best_weapon.damage
        if not enemy.is_alive():
            print(\"You killed {}!\".format(enemy.name))
        else:
            print(\"{} HP is {}.\".format(enemy.name, enemy.hp))

    def trade(self):
        room = world.tile_at(self.x, self.y)
        room.check_if_trade(self)" . 1) 2628 nil (nil rear-nonsticky nil 2628 . 2629) (nil fontified nil 26 . 2629) (26 . 2629) 649 ("class User:
    def __init__(self, first, last, age):
        self.first = first.title()
        self.last = last.title()
        self.age = age

    def describe_user(self):
        print(\"## User Info ##\\n\")
        print(f\"Name: {self.first} {self.last}\")
        print(f\"Age: {self.age}\")
        print(f\"Birth Year: {self.age}\")

    def greet_user(self):
        print(f\"\\n>> Welcome, {self.first} {self.last}!<<\\n\")


u1 = User(\"dave\", \"jones\", 37)
u2 = User(\"mr\", \"big\", 27)
u3 = User(\"laura\", \"black\", 15)

u1.describe_user()
u1.greet_user()

u2.describe_user()
u2.greet_user()

u3.describe_user()
u3.greet_user()
" . 26) 649 (t 24235 32551 724855 611000) nil (26 . 649) ("/Users/davi/.pyenv/versions/3.8.2/bin" . 26) (nil rear-nonsticky t 62 . 63) nil (nil rear-nonsticky nil 62 . 63) (nil fontified nil 26 . 63) (26 . 63) 649 ("class User:
    def __init__(self, first, last, age):
        self.first = first.title()
        self.last = last.title()
        self.age = age

    def describe_user(self):
        print(\"## User Info ##\\n\")
        print(f\"Name: {self.first} {self.last}\")
        print(f\"Age: {self.age}\")
        print(f\"Birth Year: {self.age}\")

    def greet_user(self):
        print(f\"\\n>> Welcome, {self.first} {self.last}!<<\\n\")


u1 = User(\"dave\", \"jones\", 37)
u2 = User(\"mr\", \"big\", 27)
u3 = User(\"laura\", \"black\", 15)

u1.describe_user()
u1.greet_user()

u2.describe_user()
u2.greet_user()

u3.describe_user()
u3.greet_user()
" . 26) 649 (t 24235 32551 724855 611000)) (emacs-undo-equiv-table (1 . -1) (2 . 26) (3 . 25) (4 . 24) (5 . 23) (6 . 14) (7 . 13) (8 . 12) (9 . 11) (10 . 24) (11 . 23) (12 . 22) (13 . 21) (14 . 20) (15 . 19) (16 . 18) (20 . 22) (18 . 20) (17 . 23)))