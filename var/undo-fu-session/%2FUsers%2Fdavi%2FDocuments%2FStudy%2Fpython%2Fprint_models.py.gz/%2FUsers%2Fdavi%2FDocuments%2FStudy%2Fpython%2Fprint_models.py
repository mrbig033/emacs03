((buffer-size . 828) (buffer-checksum . "120e656782018f6d357458d9d710e527d6f07245"))
((emacs-pending-undo-list (783 . 787) (783 . 784) nil (":" . 726) (726 . 728) (": list " . 726) ((marker . 1) . -6) ((marker . 1) . -6) ((marker . 1) . -6) ...) (emacs-buffer-undo-list (1 . 829) ("#!/usr/bin/env python3


def print_models(unprinted_designs: list, completed_models: list):
    \"\"\"
    Simulate printing each design, untile none are left.
    Move each design to completed_models after printing.
    \"\"\"
    while unprinted_designs:
        current_design: list = unprinted_designs.pop()
        print(f\"Printing model: {current_design}\")
        completed_models.append(current_design)


def show_completed_models(completed_models):
    \"\"\" Show all the models that have been printed \"\"\"
    print(\"\\nThe following models have been printed: \")
    for completed_model in completed_models:
        print(completed_model)


unprinted_designs = [\"phone case\", \"robot pendant\", \"dodecahedron\"]
completed_models: list = []

print_models(unprinted_designs, completed_models)
show_completed_models(completed_models)" . 1) ((marker . 1) . -25) ((marker . 1) . -92) ((marker . 1) . -24) ((marker . 1) . -24) ((marker . 1) . -24) ((marker . 1) . -24) ((marker . 1) . -24) ...) (emacs-undo-equiv-table (-1 . -11) (-2 . -10) (-3 . -9) (-4 . -8) (-5 . -7) (-6 . -10) (-7 . -9) (-11 . -15) (-12 . -14) ...))