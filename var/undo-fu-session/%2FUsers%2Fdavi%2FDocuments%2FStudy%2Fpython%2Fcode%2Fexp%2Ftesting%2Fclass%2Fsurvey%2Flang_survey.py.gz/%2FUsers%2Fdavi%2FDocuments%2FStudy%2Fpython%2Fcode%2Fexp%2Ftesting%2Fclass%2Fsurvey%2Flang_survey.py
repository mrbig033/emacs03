((buffer-size . 387) (buffer-checksum . "22bef9fc2beb839b8ca2aedf408904f847c53715"))
((emacs-pending-undo-list (78123 . 78688) ("(defhydra hydra-text-main (:color blue :hint nil :exit nil :foreign-keys nil)
  \"
^
  _e_: clean spaces  _l_: lorem par _v_: visible mode
  _i_: dup. par      _s_: lorem sen
  _t_: truncate      _y_: copy line
  _d_: com & dup     _Y_: move line
\"

  (\"<escape>\" nil)

  (\"e\" xah-clean-whitespace)
  (\"SPC\" hydra-text-commands/body)
  (\"i\" duplicate-inner-paragraph)

  (\"t\" toggle-truncate-lines)

  (\"l\" lorem-ipsum-insert-paragraphs)
  (\"s\" lorem-ipsum-insert-sentences)
  (\"y\" avy-move-line)
  (\"Y\" avy-copy-line)
  (\"d\" my-comm-dup-line)
  (\"v\" visible-mode))
" . 78123) ((marker . 44) . -565) ((marker . 143) . -565) 78688 (t 24242 39686 487744 743000) nil (78123 . 78688) ("(defhydra hydra-text-main (:color blue :hint nil :exit nil :foreign-keys nil)
  \"
^
  _e_: clean spaces  _l_: lorem par _v_: visible mode
  _i_: dup. par      _s_: lorem sen
  _t_: truncate      _Y_: copy line
  _d_: com & dup     _y_: move line
\"

  (\"<escape>\" nil)

  (\"e\" xah-clean-whitespace)
  (\"SPC\" hydra-text-commands/body)
  (\"i\" duplicate-inner-paragraph)

  (\"t\" toggle-truncate-lines)

  (\"l\" lorem-ipsum-insert-paragraphs)
  (\"s\" lorem-ipsum-insert-sentences)
  (\"y\" avy-move-line)
  (\"Y\" avy-copy-line)
  (\"d\" my-comm-dup-line)
  (\"v\" visible-mode))
" . 78123) ((marker . 78113) . -20) ((marker . 78113) . -20) 78143 (t 24242 39353 583432 456000) nil (65680 . 66480) ("(defhydra hydra-python-mode (:color blue :hint nil :foreign-keys run)
  \"
    ^
    ^Python^
    ^^^^^-------------------------------------------
    _r_: run term    _c_: copy eror  _B_: pdb
    _s_: quickshell  _d_: goto def   _a_: scratch
    _P_: prev error  _a_: goto assig _RET_: flycheck
    _n_: next error  _b_: go back

\"

  (\"<escape>\" nil)
  (\"q\" nil)

  (\"r\" my-run-on-terminal)
  (\"s\" quickrun-shell)
  (\"P\" flymake-goto-prev-error)
  (\"n\" flymake-goto-next-error)

  (\"c\" flycheck-copy-errors-as-kill)

  (\"d\" elpy-goto-definition)
  (\"b\" pop-tag-mark)
  (\"<C-return>\" dumb-jump-back)

  (\"g\" engine/search-python-3)
  (\"D\" engine/search-python-3-docs)
  (\"B\" my-pdb)
  (\"a\" my-goto-python-scratch)
  (\"o\" elpy-doc)
  (\"RET\" hydra-flycheck-mode/body)

  )
" . 65680) 66451 (t 24242 39341 409425 602000) nil (65680 . 66451) ("(defhydra hydra-python-mode (:color blue :hint nil :foreign-keys run)
  \"
    ^
    ^Python^
    ^^^^^-------------------------------------------
    _r_: run term    _c_: copy eror  _B_: pdb
    _s_: quickshell  _d_: goto def   _a_: scratch
    _P_: prev error  _a_: goto assig
    _n_: next error  _b_: go back        _RET_: flycheck

\"

  (\"<escape>\" nil)
  (\"q\" nil)

  (\"r\" my-run-on-terminal)
  (\"s\" quickrun-shell)
  (\"P\" flymake-goto-prev-error)
  (\"n\" flymake-goto-next-error)

  (\"c\" flycheck-copy-errors-as-kill)

  (\"d\" elpy-goto-definition)
  (\"b\" pop-tag-mark)
  (\"<C-return>\" dumb-jump-back)

  (\"g\" engine/search-python-3)
  (\"D\" engine/search-python-3-docs)
  (\"B\" my-pdb)
  (\"a\" my-goto-python-scratch)
  (\"o\" elpy-doc)
  (\"RET\" hydra-flycheck-mode/body)

  )
" . 65680) 66458 (t 24242 39335 941942 460000) nil (65680 . 66458) ("(defhydra hydra-python-mode (:color blue :hint nil :foreign-keys run)
  \"
    ^
    ^Python^
    ^^^^^-------------------------------------------
    _r_: run term    _c_: copy eror  _B_: pdb
    _s_: quickshell  _d_: goto def   _a_: scratch
    _P_: prev error  _b_: go back    _o_: doc
    _n_: next error  _a_: goto assig       _RET_: flycheck

\"

  (\"<escape>\" nil)
  (\"q\" nil)

  (\"r\" my-run-on-terminal)
  (\"s\" quickrun-shell)
  (\"P\" flymake-goto-prev-error)
  (\"n\" flymake-goto-next-error)

  (\"c\" flycheck-copy-errors-as-kill)

  (\"d\" elpy-goto-definition)
  (\"b\" pop-tag-mark)
  (\"<C-return>\" dumb-jump-back)

  (\"g\" engine/search-python-3)
  (\"D\" engine/search-python-3-docs)
  (\"B\" my-pdb)
  (\"a\" my-goto-python-scratch)
  (\"o\" elpy-doc)
  (\"RET\" hydra-flycheck-mode/body)

  )
" . 65680) 66469 (t 24242 39326 243099 326000) nil (65680 . 66469) ("(defhydra hydra-python-mode (:color blue :hint nil :foreign-keys run)
  \"
    ^
    ^Python^
    ^^^^^-------------------------------------------
    _r_: run term    _c_: copy eror  _B_: pdb
    _s_: quickshell  _d_: goto def   _a_: scratch
    _P_: prev error  _b_: go back    _o_: doc
    _n_: next error  _a_: goto assi       _RET_: flycheck

\"

  (\"<escape>\" nil)
  (\"q\" nil)

  (\"r\" my-run-on-terminal)
  (\"s\" quickrun-shell)
  (\"P\" flymake-goto-prev-error)
  (\"n\" flymake-goto-next-error)

  (\"c\" flycheck-copy-errors-as-kill)

  (\"d\" elpy-goto-definition)
  (\"b\" pop-tag-mark)
  (\"<C-return>\" dumb-jump-back)

  (\"g\" engine/search-python-3)
  (\"D\" engine/search-python-3-docs)
  (\"B\" my-pdb)
  (\"a\" my-goto-python-scratch)
  (\"o\" elpy-doc)
  (\"RET\" hydra-flycheck-mode/body)

  )
" . 65680) 66468 (t 24242 39324 947713 520000) nil (65680 . 66468) ("(defhydra hydra-python-mode (:color blue :hint nil :foreign-keys run)
  \"
    ^
    ^Python^
    ^^^^^-------------------------------------------
    _r_: run term    _c_: copy eror  _B_: pdb
    _s_: quickshell  _d_: goto def   _a_: scratch
    _P_: prev error  _b_: go back    _o_: doc
    _n_: next error  _D_: docs       _RET_: flycheck

\"

  (\"<escape>\" nil)
  (\"q\" nil)

  (\"r\" my-run-on-terminal)
  (\"s\" quickrun-shell)
  (\"P\" flymake-goto-prev-error)
  (\"n\" flymake-goto-next-error)

  (\"c\" flycheck-copy-errors-as-kill)

  (\"d\" elpy-goto-definition)
  (\"b\" pop-tag-mark)
  (\"<C-return>\" dumb-jump-back)

  (\"g\" engine/search-python-3)
  (\"D\" engine/search-python-3-docs)
  (\"B\" my-pdb)
  (\"a\" my-goto-python-scratch)
  (\"o\" elpy-doc)
  (\"RET\" hydra-flycheck-mode/body)

  )
" . 65680) ((marker . 65680) . -19) ((marker . 65680) . -565) ((marker . 65680) . -19) 66245 (t 24242 38956 271672 81000) nil (108951 . 109720) ("(use-package super-save
  :config
  (setq super-save-exclude '(\".pdf\" \"+new-snippet+\"))

  (setq auto-save-default nil
        super-save-idle-duration 5
        super-save-auto-save-when-idle t
        auto-save-file-name-transforms `((\".*\" \"~/emacs-profiles/my-emacs/var/temp\" t)))

  (setq super-save-hook-triggers '(mouse-leave-buffer-hook focus-out-hook))

  (setq super-save-triggers
        '(quickrun
          quit-window
          last-buffer
          windmove-up
          windmove-down
          windmove-left
          windmove-right
          switch-to-buffer
          delete-window
          eyebrowse-close-window-config
          eyebrowse-create-window-config
          eyebrowse-prev-window-config))

  (auto-save-mode -1)
  (super-save-mode nil))
" . 108951) ((marker . 108958) . -52) ((marker . 108958) . -769) ((marker . 108958) . -52) ((marker . 108958) . -721) ((marker . 108958) . -721) ((marker . 108958) . -52) ((marker . 108958) . -172) ((marker . 108958) . -137) 109123 (t 24242 38239 245529 938000) nil (161783 . 169651) ("(use-package python
  :ensure nil
  :init
  (add-hook 'python-mode-hook 'my-python-hooks)
  (add-hook 'inferior-python-mode-hook 'my-inferior-python-mode-hooks)

  ;; https://stackoverflow.com/a/6141681
  (add-hook 'python-mode-hook
            (lambda ()
              (add-hook 'evil-insert-state-exit-hook (lambda() (save-buffer)) nil t)))

  ;; https://stackoverflow.com/a/6141681
  ;; (add-hook 'python-mode-hook
  ;;           (lambda ()
  ;;             (add-hook 'write-contents-functions (lambda() (elpy-black-fix-code)) nil t)))

  :config
  (font-lock-add-keywords 'python-mode
                          '((\"cls\" . font-lock-keyword-face)))
  (setq python-shell-interpreter \"python3\")
  (setq python-shell-interpreter-args \"-i -q\")

  (setq python-shell-completion-native-enable nil)

  (defun my-python-hooks ()
    (interactive)
    (flymake-mode -1)
    (toggle-truncate-lines +1)
    (electric-operator-mode +1)
    (flycheck-mode +1)
    (rainbow-delimiters-mode +1)
    (highlight-operators-mode +1)
    (evil-swap-keys-swap-double-single-quotes)
    (evil-swap-keys-swap-underscore-dash)
    (evil-swap-keys-swap-colon-semicolon)
    (smartparens-strict-mode +1)
    (my-company-idle-one-prefix-one-quiet)
    (highlight-numbers-mode +1)
    (yafolding-mode +1)
    ;; (apheleia-mode +1)
    (importmagic-mode +1)
    (elpy-enable +1))

  (defun my-inferior-python-mode-hooks ()
    (interactive)
    (electric-operator-mode +1)
    (flycheck-mode +1)
    (rainbow-delimiters-mode +1)
    (highlight-operators-mode +1)
    (evil-swap-keys-swap-double-single-quotes)
    (evil-swap-keys-swap-underscore-dash)
    (evil-swap-keys-swap-colon-semicolon)
    (smartparens-strict-mode +1)
    (my-company-idle-one-prefix-one-quiet)
    (company-mode +1)
    (highlight-numbers-mode +1))

  ;; (add-to-list 'company-backends 'company-jedi)

  ;; (setq-local company-backends '(company-jedi
  ;;                                company-dabbrev-code
  ;;                                company-files
  ;;                                (company-semantic
  ;;                                 company-capf
  ;;                                 company-keywords
  ;;                                 company-dabbrev
  ;;                                 company-shell)))

  (defun my/olivetti-narrow ()
    (interactive)
    (olivetti-mode +1)
    (setq-local olivetti-body-width 60))

  (defun my-python-hooks ()
    (interactive)
    (subword-mode 1)
    (electric-operator-mode +1)
    (company-mode +1)
    (flycheck-mode +1)
    (rainbow-delimiters-mode +1)
    (highlight-operators-mode +1)
    (evil-swap-keys-swap-double-single-quotes)
    (evil-swap-keys-swap-underscore-dash)
    (evil-swap-keys-swap-colon-semicolon)
    (smartparens-strict-mode +1)
    (my-company-idle-one-prefix-one-quiet)
    (highlight-numbers-mode +1)
    (elpy-enable +1)
    )

  ;; PYTHON KEYS ;;
  (general-define-key
   :keymaps 'inferior-python-mode-map
   \"C-j\" 'elpy-shell-switch-to-buffer
   \"M-e\" 'counsel-shell-history
   \"C-c j\" 'my/evil-shell-bottom
   \"C-c u\" 'universal-argument
   \"C-u\" 'comint-kill-input
   \"C-l\" 'comint-clear-buffer
   \"C-;\" 'my-elpy-switch-to-buffer
   \"C-n\" 'comint-next-input
   \"C-p\" 'comint-previous-input)

  (general-unbind 'inferior-python-mode-map
    :with 'elpy-shell-switch-to-buffer
    [remap save-buffer]
    [remap my-save-buffer]
    [remap comint-next-prompt])

  (general-unbind 'python-mode-map
    :with 'elpy-folding-toggle-at-point
    [remap hs-toggle-hiding])

  (general-unbind 'python-mode-map
    :with 'my-python-shebang
    [remap my-bash-shebang])

  (general-define-key
   :keymaps 'python-mode-map
   \"<M-return>\" 'blacken-buffer
   \"M-a\" 'python-nav-backward-statement
   \"M-e\" 'python-nav-forward-statement
   \"C-S-p\" 'python-nav-backward-sexp
   \"C-S-n\" 'python-nav-forward-sexp
   \"C-x o\" 'my/olivetti-narrow
   \"C-x m\" 'elpy-multiedit-python-symbol-at-point
   \"C-x M\" 'elpy-multiedit-stop
   \"C-c g\" 'my/counsel-ag-python
   \"M-m\" 'flycheck-first-error
   \"C-c p\" 'my/python-make-print
   \"C-c f\" 'my/python-make-fstring
   \"C-c DEL\" 'my/erase-python-file
   \"C-c =\" 'my/erase-python-file-and-yank
   )

  (general-unbind 'python-mode-map
    :with 'yafolding-hide-all
    [remap evil-close-folds])

  (general-nmap
    :keymaps 'python-mode-map
    \"<escape>\" 'my-python-save-buffer)

  (defun my-python-save-buffer ()
    (interactive)
    (delete-trailing-whitespace)
    (blacken-buffer)
    (save-buffer))

  (general-nvmap
    :keymaps 'python-mode-map
    \"zi\" 'yafolding-show-all
    \"M-a\" 'python-nav-backward-statement
    \"M-e\" 'python-nav-forward-statement
    \"C-S-p\" 'python-nav-backward-sexp
    \"C-S-n\" 'python-nav-forward-sexp
    \"C-ç\" 'my/python-newline-beg
    \"<backspace>\" 'org-edit-src-exit
    \"<C-return>\" 'my-quickrun
    \"<tab>\" 'elpy-folding-toggle-at-point
    \"<tab>\" 'elpy-folding-toggle-at-point
    \"RET\" 'hydra-python-mode/body
    \"zm\" 'evil-close-folds
    \"gh\" 'outline-up-heading
    \"gl\" 'outline-next-heading
    \"zl\" 'outline-show-subtree
    \"<\" 'python-indent-shift-left
    \">\" 'python-indent-shift-right
    \"gj\" 'outline-forward-same-level
    \"gk\" 'outline-backward-same-level)

  (defun my-python-newline-beg ()
    (interactive)
    (evil-insert-state)
    (newline)
    (beginning-of-line))

  (defun my-python-colon-newline ()
    (interactive)
    (end-of-line)
    (insert \":\")
    (newline-and-indent))

  (general-imap
    :keymaps 'python-mode-map
    \"C-=\"   'my-python-colon-newline
    \"C-ç\" 'my-python-newline-beg
    \"<C-return>\" 'my-quickrun
    \"C-h\" 'python-indent-dedent-line-backspace
    \"M-a\" 'python-nav-backward-statement
    \"M-e\" 'python-nav-forward-statement
    \"C-S-p\" 'python-nav-backward-sexp
    \"C-S-n\" 'python-nav-forward-sexp
    )

  ;; PYTHON FUNCTIONS;;

  (defun execute-python-program ()
    (interactive)
    (my/window-to-register-91)
    (my/quiet-save-buffer)
    (defvar foo-execute-python)
    (setq foo-execute-python (concat \"python3 \" (buffer-file-name)))
    (other-window 1)
    (switch-to-buffer-other-window \"*Async Shell Command*\")
    (shell-command foo))

  (defun my/execute-python-program-shell-simple  ()
    (interactive)
    (my/window-to-register-91)
    (my/quiet-save-buffer)
    (defvar foo-execute-python-simple)
    (setq foo-execute-python-simple (concat \"python3 \" (prelude-copy-file-name-to-clipboard)))
    (shell-command foo))

  (defun my/ex-python-run ()
    (interactive)
    (evil-ex \"w !python3\"))

  (defun my/execute-python-program-shell ()
    (interactive)
    (progn
      (my/quiet-save-buffer)
      (prelude-copy-file-name-to-clipboard)
      (shell)
      (sit-for 0.3)
      (insert \"source ~/scripts/cline_scripts/smallprompt.sh\")
      (comint-send-input)
      (insert \"python3 \")
      (yank)
      (comint-send-input)
      (evil-insert-state)
      (sit-for 0.3)
      (comint-clear-buffer)
      (company-mode -1)))

  (general-unbind 'python-mode-map
    :with 'elpy-doc
    [remap helpful-at-point])

  (defun my/run-python-external ()
    (interactive)
    (progn
      (prelude-copy-file-name-to-clipboard)
      (start-process-shell-command
       \"call term\" nil
       \"~/scripts/i3_scripts/show_term_right\")))

  (defun my/erase-python-file ()
    (interactive)
    (erase-buffer)
    (insert \"#!/usr/bin/env python3\\n\\n\")
    (evil-insert-state)
    (flycheck-clear))

  (defun my/erase-python-file-and-yank ()
    (interactive)
    (erase-buffer)
    (insert \"#!/usr/bin/env python3\\n\\n\")
    (yank))

  (defun my/kill-python-file ()
    (interactive)
    (kill-region (point-min) (point-max))
    (insert \"#!/usr/bin/env python3\\n\\n\")
    (evil-insert-state)
    (flycheck-clear))

  ;; PYTHON SETTINGS

  (setq comment-auto-fill-only-comments t
        python-indent-offset 4
        python-indent-guess-indent-offset nil)

  (auto-fill-mode 1))
" . 161783) ((marker . 161790) . -4347) ((marker* . 169658) . 3387) ((marker . 161790) . -4364) ((marker . 161790) . -4470) ((marker . 161790) . -4349) ((marker . 161790) . -4364) ((marker . 161790) . -4470) ((marker . 161790) . -4470) ((marker . 161790) . -16) 161799 (t 24242 38172 419550 307000) nil (108951 . 109720) ("(use-package super-save
  :config
  (setq super-save-exclude '(\"py\" \".pdf\" \"+new-snippet+\"))

  (setq auto-save-default nil
        super-save-idle-duration 5
        super-save-auto-save-when-idle t
        auto-save-file-name-transforms `((\".*\" \"~/emacs-profiles/my-emacs/var/temp\" t)))

  (setq super-save-hook-triggers '(mouse-leave-buffer-hook focus-out-hook))

  (setq super-save-triggers
        '(quickrun
          quit-window
          last-buffer
          windmove-up
          windmove-down
          windmove-left
          windmove-right
          switch-to-buffer
          delete-window
          eyebrowse-close-window-config
          eyebrowse-create-window-config
          eyebrowse-prev-window-config))

  (auto-save-mode -1)
  (super-save-mode nil))
" . 108951) ((marker* . 109727) . 681) ((marker . 108958) . -93) ((marker . 108958) . -18) 108969 (t 24242 37618 767844 428000) nil (161788 . 169647) ("(use-package python
  :ensure nil
  :init
  (add-hook 'python-mode-hook 'my-python-hooks)
  (add-hook 'inferior-python-mode-hook 'my-inferior-python-mode-hooks)

  ;; https://stackoverflow.com/a/6141681
  (add-hook 'python-mode-hook
            (lambda ()
              (add-hook 'evil-insert-state-exit-hook (lambda() (save-buffer)) nil t)))

  ;; https://stackoverflow.com/a/6141681
  ;; (add-hook 'python-mode-hook
  ;;           (lambda ()
  ;;             (add-hook 'write-contents-functions (lambda() (elpy-black-fix-code)) nil t)))

  :config
  (font-lock-add-keywords 'python-mode
                          '((\"cls\" . font-lock-keyword-face)))
  (setq python-shell-interpreter \"python3\")
  (setq python-shell-interpreter-args \"-i -q\")

  (setq python-shell-completion-native-enable nil)

  (defun my-python-hooks ()
    (interactive)
    (flymake-mode -1)
    (toggle-truncate-lines +1)
    (electric-operator-mode +1)
    (flycheck-mode +1)
    (rainbow-delimiters-mode +1)
    (highlight-operators-mode +1)
    (evil-swap-keys-swap-double-single-quotes)
    (evil-swap-keys-swap-underscore-dash)
    (evil-swap-keys-swap-colon-semicolon)
    (smartparens-strict-mode +1)
    (my-company-idle-one-prefix-one-quiet)
    (highlight-numbers-mode +1)
    (yafolding-mode +1)
    ;; (apheleia-mode +1)
    (importmagic-mode +1)
    (elpy-enable +1))

  (defun my-inferior-python-mode-hooks ()
    (interactive)
    (electric-operator-mode +1)
    (flycheck-mode +1)
    (rainbow-delimiters-mode +1)
    (highlight-operators-mode +1)
    (evil-swap-keys-swap-double-single-quotes)
    (evil-swap-keys-swap-underscore-dash)
    (evil-swap-keys-swap-colon-semicolon)
    (smartparens-strict-mode +1)
    (my-company-idle-one-prefix-one-quiet)
    (company-mode +1)
    (highlight-numbers-mode +1))

  ;; (add-to-list 'company-backends 'company-jedi)

  ;; (setq-local company-backends '(company-jedi
  ;;                                company-dabbrev-code
  ;;                                company-files
  ;;                                (company-semantic
  ;;                                 company-capf
  ;;                                 company-keywords
  ;;                                 company-dabbrev
  ;;                                 company-shell)))

  (defun my/olivetti-narrow ()
    (interactive)
    (olivetti-mode +1)
    (setq-local olivetti-body-width 60))

  (defun my-python-hooks ()
    (interactive)
    (subword-mode 1)
    (electric-operator-mode +1)
    (company-mode +1)
    (flycheck-mode +1)
    (rainbow-delimiters-mode +1)
    (highlight-operators-mode +1)
    (evil-swap-keys-swap-double-single-quotes)
    (evil-swap-keys-swap-underscore-dash)
    (evil-swap-keys-swap-colon-semicolon)
    (smartparens-strict-mode +1)
    (my-company-idle-one-prefix-one-quiet)
    (highlight-numbers-mode +1)
    (elpy-enable +1)
    )

  ;; PYTHON KEYS ;;
  (general-define-key
   :keymaps 'inferior-python-mode-map
   \"C-j\" 'elpy-shell-switch-to-buffer
   \"M-e\" 'counsel-shell-history
   \"C-c j\" 'my/evil-shell-bottom
   \"C-c u\" 'universal-argument
   \"C-u\" 'comint-kill-input
   \"C-l\" 'comint-clear-buffer
   \"C-;\" 'my-elpy-switch-to-buffer
   \"C-n\" 'comint-next-input
   \"C-p\" 'comint-previous-input)

  (general-unbind 'inferior-python-mode-map
    :with 'elpy-shell-switch-to-buffer
    [remap save-buffer]
    [remap my-save-buffer]
    [remap comint-next-prompt])

  (general-unbind 'python-mode-map
    :with 'elpy-folding-toggle-at-point
    [remap hs-toggle-hiding])

  (general-unbind 'python-mode-map
    :with 'my-python-shebang
    [remap my-bash-shebang])

  (general-define-key
   :keymaps 'python-mode-map
   \"<M-return>\" 'blacken-buffer
   \"M-a\" 'python-nav-backward-statement
   \"M-e\" 'python-nav-forward-statement
   \"C-S-p\" 'python-nav-backward-sexp
   \"C-S-n\" 'python-nav-forward-sexp
   \"C-x o\" 'my/olivetti-narrow
   \"C-x m\" 'elpy-multiedit-python-symbol-at-point
   \"C-x M\" 'elpy-multiedit-stop
   \"C-c g\" 'my/counsel-ag-python
   \"M-m\" 'flycheck-first-error
   \"C-c p\" 'my/python-make-print
   \"C-c f\" 'my/python-make-fstring
   \"C-c DEL\" 'my/erase-python-file
   \"C-c =\" 'my/erase-python-file-and-yank
   )

  (general-unbind 'python-mode-map
    :with 'yafolding-hide-all
    [remap evil-close-folds])

  (general-nmap
    :keymaps 'python-mode-map
    \"<escape>\" 'my-python-save-buffer)

  (defun my-python-save-buffer ()
    (interactive)
    (blacken-buffer)
    (save-buffer))

  (general-nvmap
    :keymaps 'python-mode-map
    \"zi\" 'yafolding-show-all
    \"M-a\" 'python-nav-backward-statement
    \"M-e\" 'python-nav-forward-statement
    \"C-S-p\" 'python-nav-backward-sexp
    \"C-S-n\" 'python-nav-forward-sexp
    \"C-ç\" 'my/python-newline-beg
    \"<backspace>\" 'org-edit-src-exit
    \"<C-return>\" 'my-quickrun
    \"<tab>\" 'elpy-folding-toggle-at-point
    \"<tab>\" 'elpy-folding-toggle-at-point
    \"RET\" 'hydra-python-mode/body
    \"zm\" 'evil-close-folds
    \"gh\" 'outline-up-heading
    \"gl\" 'outline-next-heading
    \"zl\" 'outline-show-subtree
    \"<\" 'python-indent-shift-left
    \">\" 'python-indent-shift-right
    \"gj\" 'outline-forward-same-level
    \"gk\" 'outline-backward-same-level)

  (defun my-python-newline-beg ()
    (interactive)
    (evil-insert-state)
    (newline)
    (beginning-of-line))

  (defun my-python-colon-newline ()
    (interactive)
    (end-of-line)
    (insert \":\")
    (newline-and-indent))

  (general-imap
    :keymaps 'python-mode-map
    \"C-=\"   'my-python-colon-newline
    \"C-ç\" 'my-python-newline-beg
    \"<C-return>\" 'my-quickrun
    \"C-h\" 'python-indent-dedent-line-backspace
    \"M-a\" 'python-nav-backward-statement
    \"M-e\" 'python-nav-forward-statement
    \"C-S-p\" 'python-nav-backward-sexp
    \"C-S-n\" 'python-nav-forward-sexp
    )

  ;; PYTHON FUNCTIONS;;

  (defun execute-python-program ()
    (interactive)
    (my/window-to-register-91)
    (my/quiet-save-buffer)
    (defvar foo-execute-python)
    (setq foo-execute-python (concat \"python3 \" (buffer-file-name)))
    (other-window 1)
    (switch-to-buffer-other-window \"*Async Shell Command*\")
    (shell-command foo))

  (defun my/execute-python-program-shell-simple  ()
    (interactive)
    (my/window-to-register-91)
    (my/quiet-save-buffer)
    (defvar foo-execute-python-simple)
    (setq foo-execute-python-simple (concat \"python3 \" (prelude-copy-file-name-to-clipboard)))
    (shell-command foo))

  (defun my/ex-python-run ()
    (interactive)
    (evil-ex \"w !python3\"))

  (defun my/execute-python-program-shell ()
    (interactive)
    (progn
      (my/quiet-save-buffer)
      (prelude-copy-file-name-to-clipboard)
      (shell)
      (sit-for 0.3)
      (insert \"source ~/scripts/cline_scripts/smallprompt.sh\")
      (comint-send-input)
      (insert \"python3 \")
      (yank)
      (comint-send-input)
      (evil-insert-state)
      (sit-for 0.3)
      (comint-clear-buffer)
      (company-mode -1)))

  (general-unbind 'python-mode-map
    :with 'elpy-doc
    [remap helpful-at-point])

  (defun my/run-python-external ()
    (interactive)
    (progn
      (prelude-copy-file-name-to-clipboard)
      (start-process-shell-command
       \"call term\" nil
       \"~/scripts/i3_scripts/show_term_right\")))

  (defun my/erase-python-file ()
    (interactive)
    (erase-buffer)
    (insert \"#!/usr/bin/env python3\\n\\n\")
    (evil-insert-state)
    (flycheck-clear))

  (defun my/erase-python-file-and-yank ()
    (interactive)
    (erase-buffer)
    (insert \"#!/usr/bin/env python3\\n\\n\")
    (yank))

  (defun my/kill-python-file ()
    (interactive)
    (kill-region (point-min) (point-max))
    (insert \"#!/usr/bin/env python3\\n\\n\")
    (evil-insert-state)
    (flycheck-clear))

  ;; PYTHON SETTINGS

  (setq comment-auto-fill-only-comments t
        python-indent-offset 4
        python-indent-guess-indent-offset nil)

  (auto-fill-mode 1))
" . 161788) ((marker . 44) . -7826) ((marker . 143) . -7826) ((marker . 1) . -4047) 169614 (t 24242 37590 821823 616000) nil (161788 . 169614) ("(use-package python
  :ensure nil
  :init
  (add-hook 'python-mode-hook 'my-python-hooks)
  (add-hook 'inferior-python-mode-hook 'my-inferior-python-mode-hooks)

  ;; https://stackoverflow.com/a/6141681
  (add-hook 'python-mode-hook
            (lambda ()
              (add-hook 'evil-insert-state-exit-hook (lambda() (save-buffer)) nil t)))

  ;; https://stackoverflow.com/a/6141681
  ;; (add-hook 'python-mode-hook
  ;;           (lambda ()
  ;;             (add-hook 'write-contents-functions (lambda() (elpy-black-fix-code)) nil t)))

  :config
  (font-lock-add-keywords 'python-mode
                          '((\"cls\" . font-lock-keyword-face)))
  (setq python-shell-interpreter \"python3\")
  (setq python-shell-interpreter-args \"-i -q\")

  (setq python-shell-completion-native-enable nil)

  (defun my-python-hooks ()
    (interactive)
    (flymake-mode -1)
    (toggle-truncate-lines +1)
    (electric-operator-mode +1)
    (flycheck-mode +1)
    (rainbow-delimiters-mode +1)
    (highlight-operators-mode +1)
    (evil-swap-keys-swap-double-single-quotes)
    (evil-swap-keys-swap-underscore-dash)
    (evil-swap-keys-swap-colon-semicolon)
    (smartparens-strict-mode +1)
    (my-company-idle-one-prefix-one-quiet)
    (highlight-numbers-mode +1)
    (yafolding-mode +1)
    ;; (apheleia-mode +1)
    (importmagic-mode +1)
    (elpy-enable +1))

  (defun my-inferior-python-mode-hooks ()
    (interactive)
    (electric-operator-mode +1)
    (flycheck-mode +1)
    (rainbow-delimiters-mode +1)
    (highlight-operators-mode +1)
    (evil-swap-keys-swap-double-single-quotes)
    (evil-swap-keys-swap-underscore-dash)
    (evil-swap-keys-swap-colon-semicolon)
    (smartparens-strict-mode +1)
    (my-company-idle-one-prefix-one-quiet)
    (company-mode +1)
    (highlight-numbers-mode +1))

  ;; (add-to-list 'company-backends 'company-jedi)

  ;; (setq-local company-backends '(company-jedi
  ;;                                company-dabbrev-code
  ;;                                company-files
  ;;                                (company-semantic
  ;;                                 company-capf
  ;;                                 company-keywords
  ;;                                 company-dabbrev
  ;;                                 company-shell)))

  (defun my/olivetti-narrow ()
    (interactive)
    (olivetti-mode +1)
    (setq-local olivetti-body-width 60))

  (defun my-python-hooks ()
    (interactive)
    (subword-mode 1)
    (electric-operator-mode +1)
    (company-mode +1)
    (flycheck-mode +1)
    (rainbow-delimiters-mode +1)
    (highlight-operators-mode +1)
    (evil-swap-keys-swap-double-single-quotes)
    (evil-swap-keys-swap-underscore-dash)
    (evil-swap-keys-swap-colon-semicolon)
    (smartparens-strict-mode +1)
    (my-company-idle-one-prefix-one-quiet)
    (highlight-numbers-mode +1)
    (elpy-enable +1)
    )

  ;; PYTHON KEYS ;;
  (general-define-key
   :keymaps 'inferior-python-mode-map
   \"C-j\" 'elpy-shell-switch-to-buffer
   \"M-e\" 'counsel-shell-history
   \"C-c j\" 'my/evil-shell-bottom
   \"C-c u\" 'universal-argument
   \"C-u\" 'comint-kill-input
   \"C-l\" 'comint-clear-buffer
   \"C-;\" 'my-elpy-switch-to-buffer
   \"C-n\" 'comint-next-input
   \"C-p\" 'comint-previous-input)

  (general-unbind 'inferior-python-mode-map
    :with 'elpy-shell-switch-to-buffer
    [remap save-buffer]
    [remap my-save-buffer]
    [remap comint-next-prompt])

  (general-unbind 'python-mode-map
    :with 'elpy-folding-toggle-at-point
    [remap hs-toggle-hiding])

  (general-unbind 'python-mode-map
    :with 'my-python-shebang
    [remap my-bash-shebang])

  (general-define-key
   :keymaps 'python-mode-map
   \"<M-return>\" 'blacken-buffer
   \"M-a\" 'python-nav-backward-statement
   \"M-e\" 'python-nav-forward-statement
   \"C-S-p\" 'python-nav-backward-sexp
   \"C-S-n\" 'python-nav-forward-sexp
   \"C-x o\" 'my/olivetti-narrow
   \"C-x m\" 'elpy-multiedit-python-symbol-at-point
   \"C-x M\" 'elpy-multiedit-stop
   \"C-c g\" 'my/counsel-ag-python
   \"M-m\" 'flycheck-first-error
   \"C-c p\" 'my/python-make-print
   \"C-c f\" 'my/python-make-fstring
   \"C-c DEL\" 'my/erase-python-file
   \"C-c =\" 'my/erase-python-file-and-yank
   )

  (general-unbind 'python-mode-map
    :with 'yafolding-hide-all
    [remap evil-close-folds])

  (general-nmap
    :keymaps 'python-mode-map
    \"<escape>\" 'my-python-save-buffer)

  (defun my-python-save-buffer ()
    (interactive)
    (delete-trailing-whitespace)
    (blacken-buffer)
    (save-buffer))

  (general-nvmap
    :keymaps 'python-mode-map
    \"zi\" 'yafolding-show-all
    \"M-a\" 'python-nav-backward-statement
    \"M-e\" 'python-nav-forward-statement
    \"C-S-p\" 'python-nav-backward-sexp
    \"C-S-n\" 'python-nav-forward-sexp
    \"C-ç\" 'my/python-newline-beg
    \"<backspace>\" 'org-edit-src-exit
    \"<C-return>\" 'my-quickrun
    \"<tab>\" 'elpy-folding-toggle-at-point
    \"<tab>\" 'elpy-folding-toggle-at-point
    \"RET\" 'hydra-python-mode/body
    \"zm\" 'evil-close-folds
    \"gh\" 'outline-up-heading
    \"gl\" 'outline-next-heading
    \"zl\" 'outline-show-subtree
    \"<\" 'python-indent-shift-left
    \">\" 'python-indent-shift-right
    \"gj\" 'outline-forward-same-level
    \"gk\" 'outline-backward-same-level)

  (defun my-python-newline-beg ()
    (interactive)
    (evil-insert-state)
    (newline)
    (beginning-of-line))

  (defun my-python-colon-newline ()
    (interactive)
    (end-of-line)
    (insert \":\")
    (newline-and-indent))

  (general-imap
    :keymaps 'python-mode-map
    \"C-=\"   'my-python-colon-newline
    \"C-ç\" 'my-python-newline-beg
    \"<C-return>\" 'my-quickrun
    \"C-h\" 'python-indent-dedent-line-backspace
    \"M-a\" 'python-nav-backward-statement
    \"M-e\" 'python-nav-forward-statement
    \"C-S-p\" 'python-nav-backward-sexp
    \"C-S-n\" 'python-nav-forward-sexp
    )

  ;; PYTHON FUNCTIONS;;

  (defun execute-python-program ()
    (interactive)
    (my/window-to-register-91)
    (my/quiet-save-buffer)
    (defvar foo-execute-python)
    (setq foo-execute-python (concat \"python3 \" (buffer-file-name)))
    (other-window 1)
    (switch-to-buffer-other-window \"*Async Shell Command*\")
    (shell-command foo))

  (defun my/execute-python-program-shell-simple  ()
    (interactive)
    (my/window-to-register-91)
    (my/quiet-save-buffer)
    (defvar foo-execute-python-simple)
    (setq foo-execute-python-simple (concat \"python3 \" (prelude-copy-file-name-to-clipboard)))
    (shell-command foo))

  (defun my/ex-python-run ()
    (interactive)
    (evil-ex \"w !python3\"))

  (defun my/execute-python-program-shell ()
    (interactive)
    (progn
      (my/quiet-save-buffer)
      (prelude-copy-file-name-to-clipboard)
      (shell)
      (sit-for 0.3)
      (insert \"source ~/scripts/cline_scripts/smallprompt.sh\")
      (comint-send-input)
      (insert \"python3 \")
      (yank)
      (comint-send-input)
      (evil-insert-state)
      (sit-for 0.3)
      (comint-clear-buffer)
      (company-mode -1)))

  (general-unbind 'python-mode-map
    :with 'elpy-doc
    [remap helpful-at-point])

  (defun my/run-python-external ()
    (interactive)
    (progn
      (prelude-copy-file-name-to-clipboard)
      (start-process-shell-command
       \"call term\" nil
       \"~/scripts/i3_scripts/show_term_right\")))

  (defun my/erase-python-file ()
    (interactive)
    (erase-buffer)
    (insert \"#!/usr/bin/env python3\\n\\n\")
    (evil-insert-state)
    (flycheck-clear))

  (defun my/erase-python-file-and-yank ()
    (interactive)
    (erase-buffer)
    (insert \"#!/usr/bin/env python3\\n\\n\")
    (yank))

  (defun my/kill-python-file ()
    (interactive)
    (kill-region (point-min) (point-max))
    (insert \"#!/usr/bin/env python3\\n\\n\")
    (evil-insert-state)
    (flycheck-clear))

  ;; PYTHON SETTINGS

  (setq comment-auto-fill-only-comments t
        python-indent-offset 4
        python-indent-guess-indent-offset nil)

  (auto-fill-mode 1))
" . 161788) ((marker . 78613) . -4470) 166258 (t 24242 37576 953777 597000) nil (161788 . 169647) ("(use-package python
  :ensure nil
  :init
  (add-hook 'python-mode-hook 'my-python-hooks)
  (add-hook 'inferior-python-mode-hook 'my-inferior-python-mode-hooks)

  ;; https://stackoverflow.com/a/6141681
  (add-hook 'python-mode-hook
            (lambda ()
              (add-hook 'evil-insert-state-exit-hook (lambda() (save-buffer)) nil t)))

  ;; https://stackoverflow.com/a/6141681
  ;; (add-hook 'python-mode-hook
  ;;           (lambda ()
  ;;             (add-hook 'write-contents-functions (lambda() (elpy-black-fix-code)) nil t)))

  :config
  (font-lock-add-keywords 'python-mode
                          '((\"cls\" . font-lock-keyword-face)))
  (setq python-shell-interpreter \"python3\")
  (setq python-shell-interpreter-args \"-i -q\")

  (setq python-shell-completion-native-enable nil)

  (defun my-python-hooks ()
    (interactive)
    (flymake-mode -1)
    (toggle-truncate-lines +1)
    (electric-operator-mode +1)
    (flycheck-mode +1)
    (rainbow-delimiters-mode +1)
    (highlight-operators-mode +1)
    (evil-swap-keys-swap-double-single-quotes)
    (evil-swap-keys-swap-underscore-dash)
    (evil-swap-keys-swap-colon-semicolon)
    (smartparens-strict-mode +1)
    (my-company-idle-one-prefix-one-quiet)
    (highlight-numbers-mode +1)
    (yafolding-mode +1)
    ;; (apheleia-mode +1)
    (importmagic-mode +1)
    (elpy-enable +1))

  (defun my-inferior-python-mode-hooks ()
    (interactive)
    (electric-operator-mode +1)
    (flycheck-mode +1)
    (rainbow-delimiters-mode +1)
    (highlight-operators-mode +1)
    (evil-swap-keys-swap-double-single-quotes)
    (evil-swap-keys-swap-underscore-dash)
    (evil-swap-keys-swap-colon-semicolon)
    (smartparens-strict-mode +1)
    (my-company-idle-one-prefix-one-quiet)
    (company-mode +1)
    (highlight-numbers-mode +1))

  ;; (add-to-list 'company-backends 'company-jedi)

  ;; (setq-local company-backends '(company-jedi
  ;;                                company-dabbrev-code
  ;;                                company-files
  ;;                                (company-semantic
  ;;                                 company-capf
  ;;                                 company-keywords
  ;;                                 company-dabbrev
  ;;                                 company-shell)))

  (defun my/olivetti-narrow ()
    (interactive)
    (olivetti-mode +1)
    (setq-local olivetti-body-width 60))

  (defun my-python-hooks ()
    (interactive)
    (subword-mode 1)
    (electric-operator-mode +1)
    (company-mode +1)
    (flycheck-mode +1)
    (rainbow-delimiters-mode +1)
    (highlight-operators-mode +1)
    (evil-swap-keys-swap-double-single-quotes)
    (evil-swap-keys-swap-underscore-dash)
    (evil-swap-keys-swap-colon-semicolon)
    (smartparens-strict-mode +1)
    (my-company-idle-one-prefix-one-quiet)
    (highlight-numbers-mode +1)
    (elpy-enable +1)
    )

  ;; PYTHON KEYS ;;
  (general-define-key
   :keymaps 'inferior-python-mode-map
   \"C-j\" 'elpy-shell-switch-to-buffer
   \"M-e\" 'counsel-shell-history
   \"C-c j\" 'my/evil-shell-bottom
   \"C-c u\" 'universal-argument
   \"C-u\" 'comint-kill-input
   \"C-l\" 'comint-clear-buffer
   \"C-;\" 'my-elpy-switch-to-buffer
   \"C-n\" 'comint-next-input
   \"C-p\" 'comint-previous-input)

  (general-unbind 'inferior-python-mode-map
    :with 'elpy-shell-switch-to-buffer
    [remap save-buffer]
    [remap my-save-buffer]
    [remap comint-next-prompt])

  (general-unbind 'python-mode-map
    :with 'elpy-folding-toggle-at-point
    [remap hs-toggle-hiding])

  (general-unbind 'python-mode-map
    :with 'my-python-shebang
    [remap my-bash-shebang])

  (general-define-key
   :keymaps 'python-mode-map
   \"<M-return>\" 'blacken-buffer
   \"M-a\" 'python-nav-backward-statement
   \"M-e\" 'python-nav-forward-statement
   \"C-S-p\" 'python-nav-backward-sexp
   \"C-S-n\" 'python-nav-forward-sexp
   \"C-x o\" 'my/olivetti-narrow
   \"C-x m\" 'elpy-multiedit-python-symbol-at-point
   \"C-x M\" 'elpy-multiedit-stop
   \"C-c g\" 'my/counsel-ag-python
   \"M-m\" 'flycheck-first-error
   \"C-c p\" 'my/python-make-print
   \"C-c f\" 'my/python-make-fstring
   \"C-c DEL\" 'my/erase-python-file
   \"C-c =\" 'my/erase-python-file-and-yank
   )

  (general-unbind 'python-mode-map
    :with 'yafolding-hide-all
    [remap evil-close-folds])

  (general-nmap
    :keymaps 'python-mode-map
    \"<escape>\" 'my-python-save-buffer)

  (defun my-python-save-buffer ()
    (interactive)
    (delete-trailing-whitespace)
    (blacken-buffer)
    (save-buffer)
    )

  (general-nvmap
    :keymaps 'python-mode-map
    \"zi\" 'yafolding-show-all
    \"M-a\" 'python-nav-backward-statement
    \"M-e\" 'python-nav-forward-statement
    \"C-S-p\" 'python-nav-backward-sexp
    \"C-S-n\" 'python-nav-forward-sexp
    \"C-ç\" 'my/python-newline-beg
    \"<backspace>\" 'org-edit-src-exit
    \"<C-return>\" 'my-quickrun
    \"<tab>\" 'elpy-folding-toggle-at-point
    \"<tab>\" 'elpy-folding-toggle-at-point
    \"RET\" 'hydra-python-mode/body
    \"zm\" 'evil-close-folds
    \"gh\" 'outline-up-heading
    \"gl\" 'outline-next-heading
    \"zl\" 'outline-show-subtree
    \"<\" 'python-indent-shift-left
    \">\" 'python-indent-shift-right
    \"gj\" 'outline-forward-same-level
    \"gk\" 'outline-backward-same-level)

  (defun my-python-newline-beg ()
    (interactive)
    (evil-insert-state)
    (newline)
    (beginning-of-line))

  (defun my-python-colon-newline ()
    (interactive)
    (end-of-line)
    (insert \":\")
    (newline-and-indent))

  (general-imap
    :keymaps 'python-mode-map
    \"C-=\"   'my-python-colon-newline
    \"C-ç\" 'my-python-newline-beg
    \"<C-return>\" 'my-quickrun
    \"C-h\" 'python-indent-dedent-line-backspace
    \"M-a\" 'python-nav-backward-statement
    \"M-e\" 'python-nav-forward-statement
    \"C-S-p\" 'python-nav-backward-sexp
    \"C-S-n\" 'python-nav-forward-sexp
    )

  ;; PYTHON FUNCTIONS;;

  (defun execute-python-program ()
    (interactive)
    (my/window-to-register-91)
    (my/quiet-save-buffer)
    (defvar foo-execute-python)
    (setq foo-execute-python (concat \"python3 \" (buffer-file-name)))
    (other-window 1)
    (switch-to-buffer-other-window \"*Async Shell Command*\")
    (shell-command foo))

  (defun my/execute-python-program-shell-simple  ()
    (interactive)
    (my/window-to-register-91)
    (my/quiet-save-buffer)
    (defvar foo-execute-python-simple)
    (setq foo-execute-python-simple (concat \"python3 \" (prelude-copy-file-name-to-clipboard)))
    (shell-command foo))

  (defun my/ex-python-run ()
    (interactive)
    (evil-ex \"w !python3\"))

  (defun my/execute-python-program-shell ()
    (interactive)
    (progn
      (my/quiet-save-buffer)
      (prelude-copy-file-name-to-clipboard)
      (shell)
      (sit-for 0.3)
      (insert \"source ~/scripts/cline_scripts/smallprompt.sh\")
      (comint-send-input)
      (insert \"python3 \")
      (yank)
      (comint-send-input)
      (evil-insert-state)
      (sit-for 0.3)
      (comint-clear-buffer)
      (company-mode -1)))

  (general-unbind 'python-mode-map
    :with 'elpy-doc
    [remap helpful-at-point])

  (defun my/run-python-external ()
    (interactive)
    (progn
      (prelude-copy-file-name-to-clipboard)
      (start-process-shell-command
       \"call term\" nil
       \"~/scripts/i3_scripts/show_term_right\")))

  (defun my/erase-python-file ()
    (interactive)
    (erase-buffer)
    (insert \"#!/usr/bin/env python3\\n\\n\")
    (evil-insert-state)
    (flycheck-clear))

  (defun my/erase-python-file-and-yank ()
    (interactive)
    (erase-buffer)
    (insert \"#!/usr/bin/env python3\\n\\n\")
    (yank))

  (defun my/kill-python-file ()
    (interactive)
    (kill-region (point-min) (point-max))
    (insert \"#!/usr/bin/env python3\\n\\n\")
    (evil-insert-state)
    (flycheck-clear))

  ;; PYTHON SETTINGS

  (setq comment-auto-fill-only-comments t
        python-indent-offset 4
        python-indent-guess-indent-offset nil)

  (auto-fill-mode 1))
" . 161788) 169652 (t 24242 37576 206204 194000) nil (161788 . 169652) ("(use-package python
  :ensure nil
  :init
  (add-hook 'python-mode-hook 'my-python-hooks)
  (add-hook 'inferior-python-mode-hook 'my-inferior-python-mode-hooks)

  ;; https://stackoverflow.com/a/6141681
  (add-hook 'python-mode-hook
            (lambda ()
              (add-hook 'evil-insert-state-exit-hook (lambda() (save-buffer)) nil t)))

  ;; https://stackoverflow.com/a/6141681
  ;; (add-hook 'python-mode-hook
  ;;           (lambda ()
  ;;             (add-hook 'write-contents-functions (lambda() (elpy-black-fix-code)) nil t)))

  :config
  (font-lock-add-keywords 'python-mode
                          '((\"cls\" . font-lock-keyword-face)))
  (setq python-shell-interpreter \"python3\")
  (setq python-shell-interpreter-args \"-i -q\")

  (setq python-shell-completion-native-enable nil)

  (defun my-python-hooks ()
    (interactive)
    (flymake-mode -1)
    (toggle-truncate-lines +1)
    (electric-operator-mode +1)
    (flycheck-mode +1)
    (rainbow-delimiters-mode +1)
    (highlight-operators-mode +1)
    (evil-swap-keys-swap-double-single-quotes)
    (evil-swap-keys-swap-underscore-dash)
    (evil-swap-keys-swap-colon-semicolon)
    (smartparens-strict-mode +1)
    (my-company-idle-one-prefix-one-quiet)
    (highlight-numbers-mode +1)
    (yafolding-mode +1)
    ;; (apheleia-mode +1)
    (importmagic-mode +1)
    (elpy-enable +1))

  (defun my-inferior-python-mode-hooks ()
    (interactive)
    (electric-operator-mode +1)
    (flycheck-mode +1)
    (rainbow-delimiters-mode +1)
    (highlight-operators-mode +1)
    (evil-swap-keys-swap-double-single-quotes)
    (evil-swap-keys-swap-underscore-dash)
    (evil-swap-keys-swap-colon-semicolon)
    (smartparens-strict-mode +1)
    (my-company-idle-one-prefix-one-quiet)
    (company-mode +1)
    (highlight-numbers-mode +1))

  ;; (add-to-list 'company-backends 'company-jedi)

  ;; (setq-local company-backends '(company-jedi
  ;;                                company-dabbrev-code
  ;;                                company-files
  ;;                                (company-semantic
  ;;                                 company-capf
  ;;                                 company-keywords
  ;;                                 company-dabbrev
  ;;                                 company-shell)))

  (defun my/olivetti-narrow ()
    (interactive)
    (olivetti-mode +1)
    (setq-local olivetti-body-width 60))

  (defun my-python-hooks ()
    (interactive)
    (subword-mode 1)
    (electric-operator-mode +1)
    (company-mode +1)
    (flycheck-mode +1)
    (rainbow-delimiters-mode +1)
    (highlight-operators-mode +1)
    (evil-swap-keys-swap-double-single-quotes)
    (evil-swap-keys-swap-underscore-dash)
    (evil-swap-keys-swap-colon-semicolon)
    (smartparens-strict-mode +1)
    (my-company-idle-one-prefix-one-quiet)
    (highlight-numbers-mode +1)
    (elpy-enable +1)
    )

  ;; PYTHON KEYS ;;
  (general-define-key
   :keymaps 'inferior-python-mode-map
   \"C-j\" 'elpy-shell-switch-to-buffer
   \"M-e\" 'counsel-shell-history
   \"C-c j\" 'my/evil-shell-bottom
   \"C-c u\" 'universal-argument
   \"C-u\" 'comint-kill-input
   \"C-l\" 'comint-clear-buffer
   \"C-;\" 'my-elpy-switch-to-buffer
   \"C-n\" 'comint-next-input
   \"C-p\" 'comint-previous-input)

  (general-unbind 'inferior-python-mode-map
    :with 'elpy-shell-switch-to-buffer
    [remap save-buffer]
    [remap my-save-buffer]
    [remap comint-next-prompt])

  (general-unbind 'python-mode-map
    :with 'elpy-folding-toggle-at-point
    [remap hs-toggle-hiding])

  (general-unbind 'python-mode-map
    :with 'my-python-shebang
    [remap my-bash-shebang])

  (general-define-key
   :keymaps 'python-mode-map
   \"<M-return>\" 'blacken-buffer
   \"M-a\" 'python-nav-backward-statement
   \"M-e\" 'python-nav-forward-statement
   \"C-S-p\" 'python-nav-backward-sexp
   \"C-S-n\" 'python-nav-forward-sexp
   \"C-x o\" 'my/olivetti-narrow
   \"C-x m\" 'elpy-multiedit-python-symbol-at-point
   \"C-x M\" 'elpy-multiedit-stop
   \"C-c g\" 'my/counsel-ag-python
   \"M-m\" 'flycheck-first-error
   \"C-c p\" 'my/python-make-print
   \"C-c f\" 'my/python-make-fstring
   \"C-c DEL\" 'my/erase-python-file
   \"C-c =\" 'my/erase-python-file-and-yank
   )

  (general-unbind 'python-mode-map
    :with 'yafolding-hide-all
    [remap evil-close-folds])

  (general-nmap
    :keymaps 'python-mode-map
    \"<escape>\" 'my-python-save-buffer)

  (defun my-python-save-buffer ()
    (interactive)
    (delete-trailing-whitespace)
    (save-buffer)
    (blacken-buffer))

  (general-nvmap
    :keymaps 'python-mode-map
    \"zi\" 'yafolding-show-all
    \"M-a\" 'python-nav-backward-statement
    \"M-e\" 'python-nav-forward-statement
    \"C-S-p\" 'python-nav-backward-sexp
    \"C-S-n\" 'python-nav-forward-sexp
    \"C-ç\" 'my/python-newline-beg
    \"<backspace>\" 'org-edit-src-exit
    \"<C-return>\" 'my-quickrun
    \"<tab>\" 'elpy-folding-toggle-at-point
    \"<tab>\" 'elpy-folding-toggle-at-point
    \"RET\" 'hydra-python-mode/body
    \"zm\" 'evil-close-folds
    \"gh\" 'outline-up-heading
    \"gl\" 'outline-next-heading
    \"zl\" 'outline-show-subtree
    \"<\" 'python-indent-shift-left
    \">\" 'python-indent-shift-right
    \"gj\" 'outline-forward-same-level
    \"gk\" 'outline-backward-same-level)

  (defun my-python-newline-beg ()
    (interactive)
    (evil-insert-state)
    (newline)
    (beginning-of-line))

  (defun my-python-colon-newline ()
    (interactive)
    (end-of-line)
    (insert \":\")
    (newline-and-indent))

  (general-imap
    :keymaps 'python-mode-map
    \"C-=\"   'my-python-colon-newline
    \"C-ç\" 'my-python-newline-beg
    \"<C-return>\" 'my-quickrun
    \"C-h\" 'python-indent-dedent-line-backspace
    \"M-a\" 'python-nav-backward-statement
    \"M-e\" 'python-nav-forward-statement
    \"C-S-p\" 'python-nav-backward-sexp
    \"C-S-n\" 'python-nav-forward-sexp
    )

  ;; PYTHON FUNCTIONS;;

  (defun execute-python-program ()
    (interactive)
    (my/window-to-register-91)
    (my/quiet-save-buffer)
    (defvar foo-execute-python)
    (setq foo-execute-python (concat \"python3 \" (buffer-file-name)))
    (other-window 1)
    (switch-to-buffer-other-window \"*Async Shell Command*\")
    (shell-command foo))

  (defun my/execute-python-program-shell-simple  ()
    (interactive)
    (my/window-to-register-91)
    (my/quiet-save-buffer)
    (defvar foo-execute-python-simple)
    (setq foo-execute-python-simple (concat \"python3 \" (prelude-copy-file-name-to-clipboard)))
    (shell-command foo))

  (defun my/ex-python-run ()
    (interactive)
    (evil-ex \"w !python3\"))

  (defun my/execute-python-program-shell ()
    (interactive)
    (progn
      (my/quiet-save-buffer)
      (prelude-copy-file-name-to-clipboard)
      (shell)
      (sit-for 0.3)
      (insert \"source ~/scripts/cline_scripts/smallprompt.sh\")
      (comint-send-input)
      (insert \"python3 \")
      (yank)
      (comint-send-input)
      (evil-insert-state)
      (sit-for 0.3)
      (comint-clear-buffer)
      (company-mode -1)))

  (general-unbind 'python-mode-map
    :with 'elpy-doc
    [remap helpful-at-point])

  (defun my/run-python-external ()
    (interactive)
    (progn
      (prelude-copy-file-name-to-clipboard)
      (start-process-shell-command
       \"call term\" nil
       \"~/scripts/i3_scripts/show_term_right\")))

  (defun my/erase-python-file ()
    (interactive)
    (erase-buffer)
    (insert \"#!/usr/bin/env python3\\n\\n\")
    (evil-insert-state)
    (flycheck-clear))

  (defun my/erase-python-file-and-yank ()
    (interactive)
    (erase-buffer)
    (insert \"#!/usr/bin/env python3\\n\\n\")
    (yank))

  (defun my/kill-python-file ()
    (interactive)
    (kill-region (point-min) (point-max))
    (insert \"#!/usr/bin/env python3\\n\\n\")
    (evil-insert-state)
    (flycheck-clear))

  ;; PYTHON SETTINGS

  (setq comment-auto-fill-only-comments t
        python-indent-offset 4
        python-indent-guess-indent-offset nil)

  (auto-fill-mode 1))
" . 161788) 166198 (t 24242 37033 262541 200000) nil (161788 . 169647) ("(use-package python
  :ensure nil
  :init
  (add-hook 'python-mode-hook 'my-python-hooks)
  (add-hook 'inferior-python-mode-hook 'my-inferior-python-mode-hooks)

  ;; https://stackoverflow.com/a/6141681
  (add-hook 'python-mode-hook
            (lambda ()
              (add-hook 'evil-insert-state-exit-hook (lambda() (save-buffer)) nil t)))

  ;; https://stackoverflow.com/a/6141681
  ;; (add-hook 'python-mode-hook
  ;;           (lambda ()
  ;;             (add-hook 'write-contents-functions (lambda() (elpy-black-fix-code)) nil t)))

  :config
  (font-lock-add-keywords 'python-mode
                          '((\"cls\" . font-lock-keyword-face)))
  (setq python-shell-interpreter \"python3\")
  (setq python-shell-interpreter-args \"-i -q\")

  (setq python-shell-completion-native-enable nil)

  (defun my-python-hooks ()
    (interactive)
    (flymake-mode -1)
    (toggle-truncate-lines +1)
    (electric-operator-mode +1)
    (flycheck-mode +1)
    (rainbow-delimiters-mode +1)
    (highlight-operators-mode +1)
    (evil-swap-keys-swap-double-single-quotes)
    (evil-swap-keys-swap-underscore-dash)
    (evil-swap-keys-swap-colon-semicolon)
    (smartparens-strict-mode +1)
    (my-company-idle-one-prefix-one-quiet)
    (highlight-numbers-mode +1)
    (yafolding-mode +1)
    ;; (apheleia-mode +1)
    (importmagic-mode +1)
    (elpy-enable +1))

  (defun my-inferior-python-mode-hooks ()
    (interactive)
    (electric-operator-mode +1)
    (flycheck-mode +1)
    (rainbow-delimiters-mode +1)
    (highlight-operators-mode +1)
    (evil-swap-keys-swap-double-single-quotes)
    (evil-swap-keys-swap-underscore-dash)
    (evil-swap-keys-swap-colon-semicolon)
    (smartparens-strict-mode +1)
    (my-company-idle-one-prefix-one-quiet)
    (company-mode +1)
    (highlight-numbers-mode +1))

  ;; (add-to-list 'company-backends 'company-jedi)

  ;; (setq-local company-backends '(company-jedi
  ;;                                company-dabbrev-code
  ;;                                company-files
  ;;                                (company-semantic
  ;;                                 company-capf
  ;;                                 company-keywords
  ;;                                 company-dabbrev
  ;;                                 company-shell)))

  (defun my/olivetti-narrow ()
    (interactive)
    (olivetti-mode +1)
    (setq-local olivetti-body-width 60))

  (defun my-python-hooks ()
    (interactive)
    (subword-mode 1)
    (electric-operator-mode +1)
    (company-mode +1)
    (flycheck-mode +1)
    (rainbow-delimiters-mode +1)
    (highlight-operators-mode +1)
    (evil-swap-keys-swap-double-single-quotes)
    (evil-swap-keys-swap-underscore-dash)
    (evil-swap-keys-swap-colon-semicolon)
    (smartparens-strict-mode +1)
    (my-company-idle-one-prefix-one-quiet)
    (highlight-numbers-mode +1)
    (elpy-enable +1)
    )

  ;; PYTHON KEYS ;;
  (general-define-key
   :keymaps 'inferior-python-mode-map
   \"C-j\" 'elpy-shell-switch-to-buffer
   \"M-e\" 'counsel-shell-history
   \"C-c j\" 'my/evil-shell-bottom
   \"C-c u\" 'universal-argument
   \"C-u\" 'comint-kill-input
   \"C-l\" 'comint-clear-buffer
   \"C-;\" 'my-elpy-switch-to-buffer
   \"C-n\" 'comint-next-input
   \"C-p\" 'comint-previous-input)

  (general-unbind 'inferior-python-mode-map
    :with 'elpy-shell-switch-to-buffer
    [remap save-buffer]
    [remap my-save-buffer]
    [remap comint-next-prompt])

  (general-unbind 'python-mode-map
    :with 'elpy-folding-toggle-at-point
    [remap hs-toggle-hiding])

  (general-unbind 'python-mode-map
    :with 'my-python-shebang
    [remap my-bash-shebang])

  (general-define-key
   :keymaps 'python-mode-map
   \"<M-return>\" 'apheleia-format-buffer
   \"M-a\" 'python-nav-backward-statement
   \"M-e\" 'python-nav-forward-statement
   \"C-S-p\" 'python-nav-backward-sexp
   \"C-S-n\" 'python-nav-forward-sexp
   \"C-x o\" 'my/olivetti-narrow
   \"C-x m\" 'elpy-multiedit-python-symbol-at-point
   \"C-x M\" 'elpy-multiedit-stop
   \"C-c g\" 'my/counsel-ag-python
   \"M-m\" 'flycheck-first-error
   \"C-c p\" 'my/python-make-print
   \"C-c f\" 'my/python-make-fstring
   \"C-c DEL\" 'my/erase-python-file
   \"C-c =\" 'my/erase-python-file-and-yank
   )

  (general-unbind 'python-mode-map
    :with 'yafolding-hide-all
    [remap evil-close-folds])

  (general-nmap
    :keymaps 'python-mode-map
    \"<escape>\" 'my-python-save-buffer)

  (defun my-python-save-buffer ()
    (interactive)
    (delete-trailing-whitespace)
    (save-buffer)
    (blacken-buffer))

  (general-nvmap
    :keymaps 'python-mode-map
    \"zi\" 'yafolding-show-all
    \"M-a\" 'python-nav-backward-statement
    \"M-e\" 'python-nav-forward-statement
    \"C-S-p\" 'python-nav-backward-sexp
    \"C-S-n\" 'python-nav-forward-sexp
    \"C-ç\" 'my/python-newline-beg
    \"<backspace>\" 'org-edit-src-exit
    \"<C-return>\" 'my-quickrun
    \"<tab>\" 'elpy-folding-toggle-at-point
    \"<tab>\" 'elpy-folding-toggle-at-point
    \"RET\" 'hydra-python-mode/body
    \"zm\" 'evil-close-folds
    \"gh\" 'outline-up-heading
    \"gl\" 'outline-next-heading
    \"zl\" 'outline-show-subtree
    \"<\" 'python-indent-shift-left
    \">\" 'python-indent-shift-right
    \"gj\" 'outline-forward-same-level
    \"gk\" 'outline-backward-same-level)

  (defun my-python-newline-beg ()
    (interactive)
    (evil-insert-state)
    (newline)
    (beginning-of-line))

  (defun my-python-colon-newline ()
    (interactive)
    (end-of-line)
    (insert \":\")
    (newline-and-indent))

  (general-imap
    :keymaps 'python-mode-map
    \"C-=\"   'my-python-colon-newline
    \"C-ç\" 'my-python-newline-beg
    \"<C-return>\" 'my-quickrun
    \"C-h\" 'python-indent-dedent-line-backspace
    \"M-a\" 'python-nav-backward-statement
    \"M-e\" 'python-nav-forward-statement
    \"C-S-p\" 'python-nav-backward-sexp
    \"C-S-n\" 'python-nav-forward-sexp
    )

  ;; PYTHON FUNCTIONS;;

  (defun execute-python-program ()
    (interactive)
    (my/window-to-register-91)
    (my/quiet-save-buffer)
    (defvar foo-execute-python)
    (setq foo-execute-python (concat \"python3 \" (buffer-file-name)))
    (other-window 1)
    (switch-to-buffer-other-window \"*Async Shell Command*\")
    (shell-command foo))

  (defun my/execute-python-program-shell-simple  ()
    (interactive)
    (my/window-to-register-91)
    (my/quiet-save-buffer)
    (defvar foo-execute-python-simple)
    (setq foo-execute-python-simple (concat \"python3 \" (prelude-copy-file-name-to-clipboard)))
    (shell-command foo))

  (defun my/ex-python-run ()
    (interactive)
    (evil-ex \"w !python3\"))

  (defun my/execute-python-program-shell ()
    (interactive)
    (progn
      (my/quiet-save-buffer)
      (prelude-copy-file-name-to-clipboard)
      (shell)
      (sit-for 0.3)
      (insert \"source ~/scripts/cline_scripts/smallprompt.sh\")
      (comint-send-input)
      (insert \"python3 \")
      (yank)
      (comint-send-input)
      (evil-insert-state)
      (sit-for 0.3)
      (comint-clear-buffer)
      (company-mode -1)))

  (general-unbind 'python-mode-map
    :with 'elpy-doc
    [remap helpful-at-point])

  (defun my/run-python-external ()
    (interactive)
    (progn
      (prelude-copy-file-name-to-clipboard)
      (start-process-shell-command
       \"call term\" nil
       \"~/scripts/i3_scripts/show_term_right\")))

  (defun my/erase-python-file ()
    (interactive)
    (erase-buffer)
    (insert \"#!/usr/bin/env python3\\n\\n\")
    (evil-insert-state)
    (flycheck-clear))

  (defun my/erase-python-file-and-yank ()
    (interactive)
    (erase-buffer)
    (insert \"#!/usr/bin/env python3\\n\\n\")
    (yank))

  (defun my/kill-python-file ()
    (interactive)
    (kill-region (point-min) (point-max))
    (insert \"#!/usr/bin/env python3\\n\\n\")
    (evil-insert-state)
    (flycheck-clear))

  ;; PYTHON SETTINGS

  (setq comment-auto-fill-only-comments t
        python-indent-offset 4
        python-indent-guess-indent-offset nil)

  (auto-fill-mode 1))
" . 161788) ((marker . 78613) . -4480) 166250 (t 24242 37015 451521 75000) nil (161788 . 169655) ("(use-package python
  :ensure nil
  :init
  (add-hook 'python-mode-hook 'my-python-hooks)
  (add-hook 'inferior-python-mode-hook 'my-inferior-python-mode-hooks)

  ;; https://stackoverflow.com/a/6141681
  (add-hook 'python-mode-hook
            (lambda ()
              (add-hook 'evil-insert-state-exit-hook (lambda() (save-buffer)) nil t)))

  ;; https://stackoverflow.com/a/6141681
  ;; (add-hook 'python-mode-hook
  ;;           (lambda ()
  ;;             (add-hook 'write-contents-functions (lambda() (elpy-black-fix-code)) nil t)))

  :config
  (font-lock-add-keywords 'python-mode
                          '((\"cls\" . font-lock-keyword-face)))
  (setq python-shell-interpreter \"python3\")
  (setq python-shell-interpreter-args \"-i -q\")

  (setq python-shell-completion-native-enable nil)

  (defun my-python-hooks ()
    (interactive)
    (flymake-mode -1)
    (toggle-truncate-lines +1)
    (electric-operator-mode +1)
    (flycheck-mode +1)
    (rainbow-delimiters-mode +1)
    (highlight-operators-mode +1)
    (evil-swap-keys-swap-double-single-quotes)
    (evil-swap-keys-swap-underscore-dash)
    (evil-swap-keys-swap-colon-semicolon)
    (smartparens-strict-mode +1)
    (my-company-idle-one-prefix-one-quiet)
    (highlight-numbers-mode +1)
    (yafolding-mode +1)
    ;; (apheleia-mode +1)
    (importmagic-mode +1)
    (elpy-enable +1))

  (defun my-inferior-python-mode-hooks ()
    (interactive)
    (electric-operator-mode +1)
    (flycheck-mode +1)
    (rainbow-delimiters-mode +1)
    (highlight-operators-mode +1)
    (evil-swap-keys-swap-double-single-quotes)
    (evil-swap-keys-swap-underscore-dash)
    (evil-swap-keys-swap-colon-semicolon)
    (smartparens-strict-mode +1)
    (my-company-idle-one-prefix-one-quiet)
    (company-mode +1)
    (highlight-numbers-mode +1))

  ;; (add-to-list 'company-backends 'company-jedi)

  ;; (setq-local company-backends '(company-jedi
  ;;                                company-dabbrev-code
  ;;                                company-files
  ;;                                (company-semantic
  ;;                                 company-capf
  ;;                                 company-keywords
  ;;                                 company-dabbrev
  ;;                                 company-shell)))

  (defun my/olivetti-narrow ()
    (interactive)
    (olivetti-mode +1)
    (setq-local olivetti-body-width 60))

  (defun my-python-hooks ()
    (interactive)
    (subword-mode 1)
    (electric-operator-mode +1)
    (company-mode +1)
    (flycheck-mode +1)
    (rainbow-delimiters-mode +1)
    (highlight-operators-mode +1)
    (evil-swap-keys-swap-double-single-quotes)
    (evil-swap-keys-swap-underscore-dash)
    (evil-swap-keys-swap-colon-semicolon)
    (smartparens-strict-mode +1)
    (my-company-idle-one-prefix-one-quiet)
    (highlight-numbers-mode +1)
    (elpy-enable +1)
    )

  ;; PYTHON KEYS ;;
  (general-define-key
   :keymaps 'inferior-python-mode-map
   \"C-j\" 'elpy-shell-switch-to-buffer
   \"M-e\" 'counsel-shell-history
   \"C-c j\" 'my/evil-shell-bottom
   \"C-c u\" 'universal-argument
   \"C-u\" 'comint-kill-input
   \"C-l\" 'comint-clear-buffer
   \"C-;\" 'my-elpy-switch-to-buffer
   \"C-n\" 'comint-next-input
   \"C-p\" 'comint-previous-input)

  (general-unbind 'inferior-python-mode-map
    :with 'elpy-shell-switch-to-buffer
    [remap save-buffer]
    [remap my-save-buffer]
    [remap comint-next-prompt])

  (general-unbind 'python-mode-map
    :with 'elpy-folding-toggle-at-point
    [remap hs-toggle-hiding])

  (general-unbind 'python-mode-map
    :with 'my-python-shebang
    [remap my-bash-shebang])

  (general-define-key
   :keymaps 'python-mode-map
   \"<M-return>\" 'apheleia-format-buffer
   \"M-a\" 'python-nav-backward-statement
   \"M-e\" 'python-nav-forward-statement
   \"C-S-p\" 'python-nav-backward-sexp
   \"C-S-n\" 'python-nav-forward-sexp
   \"C-x o\" 'my/olivetti-narrow
   \"C-x m\" 'elpy-multiedit-python-symbol-at-point
   \"C-x M\" 'elpy-multiedit-stop
   \"C-c g\" 'my/counsel-ag-python
   \"M-m\" 'flycheck-first-error
   \"C-c p\" 'my/python-make-print
   \"C-c f\" 'my/python-make-fstring
   \"C-c DEL\" 'my/erase-python-file
   \"C-c =\" 'my/erase-python-file-and-yank
   )

  (general-unbind 'python-mode-map
    :with 'yafolding-hide-all
    [remap evil-close-folds])

  (general-nmap
    :keymaps 'python-mode-map
    \"<escape>\" 'my-python-save-buffer)

  (defun my-python-save-buffer ()
    (interactive)
    (delete-trailing-whitespace)
    (save-buffer)
    (blacken-buffer))


  (general-nvmap
    :keymaps 'python-mode-map
    \"zi\" 'yafolding-show-all
    \"M-a\" 'python-nav-backward-statement
    \"M-e\" 'python-nav-forward-statement
    \"C-S-p\" 'python-nav-backward-sexp
    \"C-S-n\" 'python-nav-forward-sexp
    \"C-ç\" 'my/python-newline-beg
    \"<backspace>\" 'org-edit-src-exit
    \"<C-return>\" 'my-quickrun
    \"<tab>\" 'elpy-folding-toggle-at-point
    \"<tab>\" 'elpy-folding-toggle-at-point
    \"RET\" 'hydra-python-mode/body
    \"zm\" 'evil-close-folds
    \"gh\" 'outline-up-heading
    \"gl\" 'outline-next-heading
    \"zl\" 'outline-show-subtree
    \"<\" 'python-indent-shift-left
    \">\" 'python-indent-shift-right
    \"gj\" 'outline-forward-same-level
    \"gk\" 'outline-backward-same-level)

  (defun my-python-newline-beg ()
    (interactive)
    (evil-insert-state)
    (newline)
    (beginning-of-line))

  (defun my-python-colon-newline ()
    (interactive)
    (end-of-line)
    (insert \":\")
    (newline-and-indent))

  (general-imap
    :keymaps 'python-mode-map
    \"C-=\"   'my-python-colon-newline
    \"C-ç\" 'my-python-newline-beg
    \"<C-return>\" 'my-quickrun
    \"C-h\" 'python-indent-dedent-line-backspace
    \"M-a\" 'python-nav-backward-statement
    \"M-e\" 'python-nav-forward-statement
    \"C-S-p\" 'python-nav-backward-sexp
    \"C-S-n\" 'python-nav-forward-sexp
    )

  ;; PYTHON FUNCTIONS;;

  (defun execute-python-program ()
    (interactive)
    (my/window-to-register-91)
    (my/quiet-save-buffer)
    (defvar foo-execute-python)
    (setq foo-execute-python (concat \"python3 \" (buffer-file-name)))
    (other-window 1)
    (switch-to-buffer-other-window \"*Async Shell Command*\")
    (shell-command foo))

  (defun my/execute-python-program-shell-simple  ()
    (interactive)
    (my/window-to-register-91)
    (my/quiet-save-buffer)
    (defvar foo-execute-python-simple)
    (setq foo-execute-python-simple (concat \"python3 \" (prelude-copy-file-name-to-clipboard)))
    (shell-command foo))

  (defun my/ex-python-run ()
    (interactive)
    (evil-ex \"w !python3\"))

  (defun my/execute-python-program-shell ()
    (interactive)
    (progn
      (my/quiet-save-buffer)
      (prelude-copy-file-name-to-clipboard)
      (shell)
      (sit-for 0.3)
      (insert \"source ~/scripts/cline_scripts/smallprompt.sh\")
      (comint-send-input)
      (insert \"python3 \")
      (yank)
      (comint-send-input)
      (evil-insert-state)
      (sit-for 0.3)
      (comint-clear-buffer)
      (company-mode -1)))

  (general-unbind 'python-mode-map
    :with 'elpy-doc
    [remap helpful-at-point])

  (defun my/run-python-external ()
    (interactive)
    (progn
      (prelude-copy-file-name-to-clipboard)
      (start-process-shell-command
       \"call term\" nil
       \"~/scripts/i3_scripts/show_term_right\")))

  (defun my/erase-python-file ()
    (interactive)
    (erase-buffer)
    (insert \"#!/usr/bin/env python3\\n\\n\")
    (evil-insert-state)
    (flycheck-clear))

  (defun my/erase-python-file-and-yank ()
    (interactive)
    (erase-buffer)
    (insert \"#!/usr/bin/env python3\\n\\n\")
    (yank))

  (defun my/kill-python-file ()
    (interactive)
    (kill-region (point-min) (point-max))
    (insert \"#!/usr/bin/env python3\\n\\n\")
    (evil-insert-state)
    (flycheck-clear))

  ;; PYTHON SETTINGS

  (setq comment-auto-fill-only-comments t
        python-indent-offset 4
        python-indent-guess-indent-offset nil)

  (auto-fill-mode 1))
" . 161788) 169656 (t 24242 37012 563514 223000) nil (161788 . 169656) ("(use-package python
  :ensure nil
  :init
  (add-hook 'python-mode-hook 'my-python-hooks)
  (add-hook 'inferior-python-mode-hook 'my-inferior-python-mode-hooks)

  ;; https://stackoverflow.com/a/6141681
  (add-hook 'python-mode-hook
            (lambda ()
              (add-hook 'evil-insert-state-exit-hook (lambda() (save-buffer)) nil t)))

  ;; https://stackoverflow.com/a/6141681
  ;; (add-hook 'python-mode-hook
  ;;           (lambda ()
  ;;             (add-hook 'write-contents-functions (lambda() (elpy-black-fix-code)) nil t)))

  :config
  (font-lock-add-keywords 'python-mode
                          '((\"cls\" . font-lock-keyword-face)))
  (setq python-shell-interpreter \"python3\")
  (setq python-shell-interpreter-args \"-i -q\")

  (setq python-shell-completion-native-enable nil)

  (defun my-python-hooks ()
    (interactive)
    (flymake-mode -1)
    (toggle-truncate-lines +1)
    (electric-operator-mode +1)
    (flycheck-mode +1)
    (rainbow-delimiters-mode +1)
    (highlight-operators-mode +1)
    (evil-swap-keys-swap-double-single-quotes)
    (evil-swap-keys-swap-underscore-dash)
    (evil-swap-keys-swap-colon-semicolon)
    (smartparens-strict-mode +1)
    (my-company-idle-one-prefix-one-quiet)
    (highlight-numbers-mode +1)
    (yafolding-mode +1)
    ;; (apheleia-mode +1)
    (importmagic-mode +1)
    (elpy-enable +1))

  (defun my-inferior-python-mode-hooks ()
    (interactive)
    (electric-operator-mode +1)
    (flycheck-mode +1)
    (rainbow-delimiters-mode +1)
    (highlight-operators-mode +1)
    (evil-swap-keys-swap-double-single-quotes)
    (evil-swap-keys-swap-underscore-dash)
    (evil-swap-keys-swap-colon-semicolon)
    (smartparens-strict-mode +1)
    (my-company-idle-one-prefix-one-quiet)
    (company-mode +1)
    (highlight-numbers-mode +1))

  ;; (add-to-list 'company-backends 'company-jedi)

  ;; (setq-local company-backends '(company-jedi
  ;;                                company-dabbrev-code
  ;;                                company-files
  ;;                                (company-semantic
  ;;                                 company-capf
  ;;                                 company-keywords
  ;;                                 company-dabbrev
  ;;                                 company-shell)))

  (defun my/olivetti-narrow ()
    (interactive)
    (olivetti-mode +1)
    (setq-local olivetti-body-width 60))

  (defun my-python-hooks ()
    (interactive)
    (subword-mode 1)
    (electric-operator-mode +1)
    (company-mode +1)
    (flycheck-mode +1)
    (rainbow-delimiters-mode +1)
    (highlight-operators-mode +1)
    (evil-swap-keys-swap-double-single-quotes)
    (evil-swap-keys-swap-underscore-dash)
    (evil-swap-keys-swap-colon-semicolon)
    (smartparens-strict-mode +1)
    (my-company-idle-one-prefix-one-quiet)
    (highlight-numbers-mode +1)
    (elpy-enable +1)
    )

  ;; PYTHON KEYS ;;
  (general-define-key
   :keymaps 'inferior-python-mode-map
   \"C-j\" 'elpy-shell-switch-to-buffer
   \"M-e\" 'counsel-shell-history
   \"C-c j\" 'my/evil-shell-bottom
   \"C-c u\" 'universal-argument
   \"C-u\" 'comint-kill-input
   \"C-l\" 'comint-clear-buffer
   \"C-;\" 'my-elpy-switch-to-buffer
   \"C-n\" 'comint-next-input
   \"C-p\" 'comint-previous-input)

  (general-unbind 'inferior-python-mode-map
    :with 'elpy-shell-switch-to-buffer
    [remap save-buffer]
    [remap my-save-buffer]
    [remap comint-next-prompt])

  (general-unbind 'python-mode-map
    :with 'elpy-folding-toggle-at-point
    [remap hs-toggle-hiding])

  (general-unbind 'python-mode-map
    :with 'my-python-shebang
    [remap my-bash-shebang])

  (general-define-key
   :keymaps 'python-mode-map
   \"<M-return>\" 'apheleia-format-buffer
   \"M-a\" 'python-nav-backward-statement
   \"M-e\" 'python-nav-forward-statement
   \"C-S-p\" 'python-nav-backward-sexp
   \"C-S-n\" 'python-nav-forward-sexp
   \"C-x o\" 'my/olivetti-narrow
   \"C-x m\" 'elpy-multiedit-python-symbol-at-point
   \"C-x M\" 'elpy-multiedit-stop
   \"C-c g\" 'my/counsel-ag-python
   \"M-m\" 'flycheck-first-error
   \"C-c p\" 'my/python-make-print
   \"C-c f\" 'my/python-make-fstring
   \"C-c DEL\" 'my/erase-python-file
   \"C-c =\" 'my/erase-python-file-and-yank
   )

  (general-unbind 'python-mode-map
    :with 'yafolding-hide-all
    [remap evil-close-folds])

  (general-nmap
    :keymaps 'python-mode-map
    \"<escape>\" 'my-python-save-buffer)

  (defun my-python-save-buffer ()
    (interactive)
    (delete-trailing-whitespace)
    (save-buffer)
    (blacken-))


  (general-nvmap
    :keymaps 'python-mode-map
    \"zi\" 'yafolding-show-all
    \"M-a\" 'python-nav-backward-statement
    \"M-e\" 'python-nav-forward-statement
    \"C-S-p\" 'python-nav-backward-sexp
    \"C-S-n\" 'python-nav-forward-sexp
    \"C-ç\" 'my/python-newline-beg
    \"<backspace>\" 'org-edit-src-exit
    \"<C-return>\" 'my-quickrun
    \"<tab>\" 'elpy-folding-toggle-at-point
    \"<tab>\" 'elpy-folding-toggle-at-point
    \"RET\" 'hydra-python-mode/body
    \"zm\" 'evil-close-folds
    \"gh\" 'outline-up-heading
    \"gl\" 'outline-next-heading
    \"zl\" 'outline-show-subtree
    \"<\" 'python-indent-shift-left
    \">\" 'python-indent-shift-right
    \"gj\" 'outline-forward-same-level
    \"gk\" 'outline-backward-same-level)

  (defun my-python-newline-beg ()
    (interactive)
    (evil-insert-state)
    (newline)
    (beginning-of-line))

  (defun my-python-colon-newline ()
    (interactive)
    (end-of-line)
    (insert \":\")
    (newline-and-indent))

  (general-imap
    :keymaps 'python-mode-map
    \"C-=\"   'my-python-colon-newline
    \"C-ç\" 'my-python-newline-beg
    \"<C-return>\" 'my-quickrun
    \"C-h\" 'python-indent-dedent-line-backspace
    \"M-a\" 'python-nav-backward-statement
    \"M-e\" 'python-nav-forward-statement
    \"C-S-p\" 'python-nav-backward-sexp
    \"C-S-n\" 'python-nav-forward-sexp
    )

  ;; PYTHON FUNCTIONS;;

  (defun execute-python-program ()
    (interactive)
    (my/window-to-register-91)
    (my/quiet-save-buffer)
    (defvar foo-execute-python)
    (setq foo-execute-python (concat \"python3 \" (buffer-file-name)))
    (other-window 1)
    (switch-to-buffer-other-window \"*Async Shell Command*\")
    (shell-command foo))

  (defun my/execute-python-program-shell-simple  ()
    (interactive)
    (my/window-to-register-91)
    (my/quiet-save-buffer)
    (defvar foo-execute-python-simple)
    (setq foo-execute-python-simple (concat \"python3 \" (prelude-copy-file-name-to-clipboard)))
    (shell-command foo))

  (defun my/ex-python-run ()
    (interactive)
    (evil-ex \"w !python3\"))

  (defun my/execute-python-program-shell ()
    (interactive)
    (progn
      (my/quiet-save-buffer)
      (prelude-copy-file-name-to-clipboard)
      (shell)
      (sit-for 0.3)
      (insert \"source ~/scripts/cline_scripts/smallprompt.sh\")
      (comint-send-input)
      (insert \"python3 \")
      (yank)
      (comint-send-input)
      (evil-insert-state)
      (sit-for 0.3)
      (comint-clear-buffer)
      (company-mode -1)))

  (general-unbind 'python-mode-map
    :with 'elpy-doc
    [remap helpful-at-point])

  (defun my/run-python-external ()
    (interactive)
    (progn
      (prelude-copy-file-name-to-clipboard)
      (start-process-shell-command
       \"call term\" nil
       \"~/scripts/i3_scripts/show_term_right\")))

  (defun my/erase-python-file ()
    (interactive)
    (erase-buffer)
    (insert \"#!/usr/bin/env python3\\n\\n\")
    (evil-insert-state)
    (flycheck-clear))

  (defun my/erase-python-file-and-yank ()
    (interactive)
    (erase-buffer)
    (insert \"#!/usr/bin/env python3\\n\\n\")
    (yank))

  (defun my/kill-python-file ()
    (interactive)
    (kill-region (point-min) (point-max))
    (insert \"#!/usr/bin/env python3\\n\\n\")
    (evil-insert-state)
    (flycheck-clear))

  ;; PYTHON SETTINGS

  (setq comment-auto-fill-only-comments t
        python-indent-offset 4
        python-indent-guess-indent-offset nil)

  (auto-fill-mode 1))
" . 161788) 169650 (t 24242 37008 585278 150000) nil (161788 . 169650) ("(use-package python
  :ensure nil
  :init
  (add-hook 'python-mode-hook 'my-python-hooks)
  (add-hook 'inferior-python-mode-hook 'my-inferior-python-mode-hooks)

  ;; https://stackoverflow.com/a/6141681
  (add-hook 'python-mode-hook
            (lambda ()
              (add-hook 'evil-insert-state-exit-hook (lambda() (save-buffer)) nil t)))

  ;; https://stackoverflow.com/a/6141681
  ;; (add-hook 'python-mode-hook
  ;;           (lambda ()
  ;;             (add-hook 'write-contents-functions (lambda() (elpy-black-fix-code)) nil t)))

  :config
  (font-lock-add-keywords 'python-mode
                          '((\"cls\" . font-lock-keyword-face)))
  (setq python-shell-interpreter \"python3\")
  (setq python-shell-interpreter-args \"-i -q\")

  (setq python-shell-completion-native-enable nil)

  (defun my-python-hooks ()
    (interactive)
    (flymake-mode -1)
    (toggle-truncate-lines +1)
    (electric-operator-mode +1)
    (flycheck-mode +1)
    (rainbow-delimiters-mode +1)
    (highlight-operators-mode +1)
    (evil-swap-keys-swap-double-single-quotes)
    (evil-swap-keys-swap-underscore-dash)
    (evil-swap-keys-swap-colon-semicolon)
    (smartparens-strict-mode +1)
    (my-company-idle-one-prefix-one-quiet)
    (highlight-numbers-mode +1)
    (yafolding-mode +1)
    ;; (apheleia-mode +1)
    (importmagic-mode +1)
    (elpy-enable +1))

  (defun my-inferior-python-mode-hooks ()
    (interactive)
    (electric-operator-mode +1)
    (flycheck-mode +1)
    (rainbow-delimiters-mode +1)
    (highlight-operators-mode +1)
    (evil-swap-keys-swap-double-single-quotes)
    (evil-swap-keys-swap-underscore-dash)
    (evil-swap-keys-swap-colon-semicolon)
    (smartparens-strict-mode +1)
    (my-company-idle-one-prefix-one-quiet)
    (company-mode +1)
    (highlight-numbers-mode +1))

  ;; (add-to-list 'company-backends 'company-jedi)

  ;; (setq-local company-backends '(company-jedi
  ;;                                company-dabbrev-code
  ;;                                company-files
  ;;                                (company-semantic
  ;;                                 company-capf
  ;;                                 company-keywords
  ;;                                 company-dabbrev
  ;;                                 company-shell)))

  (defun my/olivetti-narrow ()
    (interactive)
    (olivetti-mode +1)
    (setq-local olivetti-body-width 60))

  (defun my-python-hooks ()
    (interactive)
    (subword-mode 1)
    (electric-operator-mode +1)
    (company-mode +1)
    (flycheck-mode +1)
    (rainbow-delimiters-mode +1)
    (highlight-operators-mode +1)
    (evil-swap-keys-swap-double-single-quotes)
    (evil-swap-keys-swap-underscore-dash)
    (evil-swap-keys-swap-colon-semicolon)
    (smartparens-strict-mode +1)
    (my-company-idle-one-prefix-one-quiet)
    (highlight-numbers-mode +1)
    (elpy-enable +1)
    )

  ;; PYTHON KEYS ;;
  (general-define-key
   :keymaps 'inferior-python-mode-map
   \"C-j\" 'elpy-shell-switch-to-buffer
   \"M-e\" 'counsel-shell-history
   \"C-c j\" 'my/evil-shell-bottom
   \"C-c u\" 'universal-argument
   \"C-u\" 'comint-kill-input
   \"C-l\" 'comint-clear-buffer
   \"C-;\" 'my-elpy-switch-to-buffer
   \"C-n\" 'comint-next-input
   \"C-p\" 'comint-previous-input)

  (general-unbind 'inferior-python-mode-map
    :with 'elpy-shell-switch-to-buffer
    [remap save-buffer]
    [remap my-save-buffer]
    [remap comint-next-prompt])

  (general-unbind 'python-mode-map
    :with 'elpy-folding-toggle-at-point
    [remap hs-toggle-hiding])

  (general-unbind 'python-mode-map
    :with 'my-python-shebang
    [remap my-bash-shebang])

  (general-define-key
   :keymaps 'python-mode-map
   \"<M-return>\" 'apheleia-format-buffer
   \"M-a\" 'python-nav-backward-statement
   \"M-e\" 'python-nav-forward-statement
   \"C-S-p\" 'python-nav-backward-sexp
   \"C-S-n\" 'python-nav-forward-sexp
   \"C-x o\" 'my/olivetti-narrow
   \"C-x m\" 'elpy-multiedit-python-symbol-at-point
   \"C-x M\" 'elpy-multiedit-stop
   \"C-c g\" 'my/counsel-ag-python
   \"M-m\" 'flycheck-first-error
   \"C-c p\" 'my/python-make-print
   \"C-c f\" 'my/python-make-fstring
   \"C-c DEL\" 'my/erase-python-file
   \"C-c =\" 'my/erase-python-file-and-yank
   )

  (general-unbind 'python-mode-map
    :with 'yafolding-hide-all
    [remap evil-close-folds])

  (general-nmap
    :keymaps 'python-mode-map
    \"<escape>\" 'my-python-save-buffer)

  (defun my-python-save-buffer ()
    (interactive)
    (delete-trailing-whitespace)
    (save-buffer)
    (apheleia-format-buffer))


  (general-nvmap
    :keymaps 'python-mode-map
    \"zi\" 'yafolding-show-all
    \"M-a\" 'python-nav-backward-statement
    \"M-e\" 'python-nav-forward-statement
    \"C-S-p\" 'python-nav-backward-sexp
    \"C-S-n\" 'python-nav-forward-sexp
    \"C-ç\" 'my/python-newline-beg
    \"<backspace>\" 'org-edit-src-exit
    \"<C-return>\" 'my-quickrun
    \"<tab>\" 'elpy-folding-toggle-at-point
    \"<tab>\" 'elpy-folding-toggle-at-point
    \"RET\" 'hydra-python-mode/body
    \"zm\" 'evil-close-folds
    \"gh\" 'outline-up-heading
    \"gl\" 'outline-next-heading
    \"zl\" 'outline-show-subtree
    \"<\" 'python-indent-shift-left
    \">\" 'python-indent-shift-right
    \"gj\" 'outline-forward-same-level
    \"gk\" 'outline-backward-same-level)

  (defun my-python-newline-beg ()
    (interactive)
    (evil-insert-state)
    (newline)
    (beginning-of-line))

  (defun my-python-colon-newline ()
    (interactive)
    (end-of-line)
    (insert \":\")
    (newline-and-indent))

  (general-imap
    :keymaps 'python-mode-map
    \"C-=\"   'my-python-colon-newline
    \"C-ç\" 'my-python-newline-beg
    \"<C-return>\" 'my-quickrun
    \"C-h\" 'python-indent-dedent-line-backspace
    \"M-a\" 'python-nav-backward-statement
    \"M-e\" 'python-nav-forward-statement
    \"C-S-p\" 'python-nav-backward-sexp
    \"C-S-n\" 'python-nav-forward-sexp
    )

  ;; PYTHON FUNCTIONS;;

  (defun execute-python-program ()
    (interactive)
    (my/window-to-register-91)
    (my/quiet-save-buffer)
    (defvar foo-execute-python)
    (setq foo-execute-python (concat \"python3 \" (buffer-file-name)))
    (other-window 1)
    (switch-to-buffer-other-window \"*Async Shell Command*\")
    (shell-command foo))

  (defun my/execute-python-program-shell-simple  ()
    (interactive)
    (my/window-to-register-91)
    (my/quiet-save-buffer)
    (defvar foo-execute-python-simple)
    (setq foo-execute-python-simple (concat \"python3 \" (prelude-copy-file-name-to-clipboard)))
    (shell-command foo))

  (defun my/ex-python-run ()
    (interactive)
    (evil-ex \"w !python3\"))

  (defun my/execute-python-program-shell ()
    (interactive)
    (progn
      (my/quiet-save-buffer)
      (prelude-copy-file-name-to-clipboard)
      (shell)
      (sit-for 0.3)
      (insert \"source ~/scripts/cline_scripts/smallprompt.sh\")
      (comint-send-input)
      (insert \"python3 \")
      (yank)
      (comint-send-input)
      (evil-insert-state)
      (sit-for 0.3)
      (comint-clear-buffer)
      (company-mode -1)))

  (general-unbind 'python-mode-map
    :with 'elpy-doc
    [remap helpful-at-point])

  (defun my/run-python-external ()
    (interactive)
    (progn
      (prelude-copy-file-name-to-clipboard)
      (start-process-shell-command
       \"call term\" nil
       \"~/scripts/i3_scripts/show_term_right\")))

  (defun my/erase-python-file ()
    (interactive)
    (erase-buffer)
    (insert \"#!/usr/bin/env python3\\n\\n\")
    (evil-insert-state)
    (flycheck-clear))

  (defun my/erase-python-file-and-yank ()
    (interactive)
    (erase-buffer)
    (insert \"#!/usr/bin/env python3\\n\\n\")
    (yank))

  (defun my/kill-python-file ()
    (interactive)
    (kill-region (point-min) (point-max))
    (insert \"#!/usr/bin/env python3\\n\\n\")
    (evil-insert-state)
    (flycheck-clear))

  ;; PYTHON SETTINGS

  (setq comment-auto-fill-only-comments t
        python-indent-offset 4
        python-indent-guess-indent-offset nil)

  (auto-fill-mode 1))
" . 161788) ((marker . 78613) . -4489) ((marker . 161790) . -4489) ((marker* . 169658) . 3387) ((marker . 161790) . -4489) ((marker . 161790) . -4489) 166277 (t 24242 37000 341290 702000) nil ("  (defun my-apheleia-black ()
    (interactive)
    (apheleia-format-buffer 'black))
" . 166277) ((marker . 78613) . -82) ((marker . 161790) . -82) ((marker . 161790) . -29) ((marker . 44) . -28) ((marker . 143) . -29) ((marker) . -29) ((marker) . -82) 166306 (t 24242 36988 518781 298000) nil (161788 . 169749) ("(use-package python
  :ensure nil
  :init
  (add-hook 'python-mode-hook 'my-python-hooks)
  (add-hook 'inferior-python-mode-hook 'my-inferior-python-mode-hooks)

  ;; https://stackoverflow.com/a/6141681
  (add-hook 'python-mode-hook
            (lambda ()
              (add-hook 'evil-insert-state-exit-hook (lambda() (save-buffer)) nil t)))

  ;; https://stackoverflow.com/a/6141681
  ;; (add-hook 'python-mode-hook
  ;;           (lambda ()
  ;;             (add-hook 'write-contents-functions (lambda() (elpy-black-fix-code)) nil t)))

  :config
  (font-lock-add-keywords 'python-mode
                          '((\"cls\" . font-lock-keyword-face)))
  (setq python-shell-interpreter \"python3\")
  (setq python-shell-interpreter-args \"-i -q\")

  (setq python-shell-completion-native-enable nil)

  (defun my-python-hooks ()
    (interactive)
    (flymake-mode -1)
    (toggle-truncate-lines +1)
    (electric-operator-mode +1)
    (flycheck-mode +1)
    (rainbow-delimiters-mode +1)
    (highlight-operators-mode +1)
    (evil-swap-keys-swap-double-single-quotes)
    (evil-swap-keys-swap-underscore-dash)
    (evil-swap-keys-swap-colon-semicolon)
    (smartparens-strict-mode +1)
    (my-company-idle-one-prefix-one-quiet)
    (highlight-numbers-mode +1)
    (yafolding-mode +1)
    ;; (apheleia-mode +1)
    (importmagic-mode +1)
    (elpy-enable +1))

  (defun my-inferior-python-mode-hooks ()
    (interactive)
    (electric-operator-mode +1)
    (flycheck-mode +1)
    (rainbow-delimiters-mode +1)
    (highlight-operators-mode +1)
    (evil-swap-keys-swap-double-single-quotes)
    (evil-swap-keys-swap-underscore-dash)
    (evil-swap-keys-swap-colon-semicolon)
    (smartparens-strict-mode +1)
    (my-company-idle-one-prefix-one-quiet)
    (company-mode +1)
    (highlight-numbers-mode +1))

  ;; (add-to-list 'company-backends 'company-jedi)

  ;; (setq-local company-backends '(company-jedi
  ;;                                company-dabbrev-code
  ;;                                company-files
  ;;                                (company-semantic
  ;;                                 company-capf
  ;;                                 company-keywords
  ;;                                 company-dabbrev
  ;;                                 company-shell)))

  (defun my/olivetti-narrow ()
    (interactive)
    (olivetti-mode +1)
    (setq-local olivetti-body-width 60))

  (defun my-python-hooks ()
    (interactive)
    (subword-mode 1)
    (electric-operator-mode +1)
    (company-mode +1)
    (flycheck-mode +1)
    (rainbow-delimiters-mode +1)
    (highlight-operators-mode +1)
    (evil-swap-keys-swap-double-single-quotes)
    (evil-swap-keys-swap-underscore-dash)
    (evil-swap-keys-swap-colon-semicolon)
    (smartparens-strict-mode +1)
    (my-company-idle-one-prefix-one-quiet)
    (highlight-numbers-mode +1)
    (elpy-enable +1)
    )

  ;; PYTHON KEYS ;;
  (general-define-key
   :keymaps 'inferior-python-mode-map
   \"C-j\" 'elpy-shell-switch-to-buffer
   \"M-e\" 'counsel-shell-history
   \"C-c j\" 'my/evil-shell-bottom
   \"C-c u\" 'universal-argument
   \"C-u\" 'comint-kill-input
   \"C-l\" 'comint-clear-buffer
   \"C-;\" 'my-elpy-switch-to-buffer
   \"C-n\" 'comint-next-input
   \"C-p\" 'comint-previous-input)

  (general-unbind 'inferior-python-mode-map
    :with 'elpy-shell-switch-to-buffer
    [remap save-buffer]
    [remap my-save-buffer]
    [remap comint-next-prompt])

  (general-unbind 'python-mode-map
    :with 'elpy-folding-toggle-at-point
    [remap hs-toggle-hiding])

  (general-unbind 'python-mode-map
    :with 'my-python-shebang
    [remap my-bash-shebang])

  (general-define-key
   :keymaps 'python-mode-map
   \"<M-return>\" 'apheleia-format-buffer
   \"M-a\" 'python-nav-backward-statement
   \"M-e\" 'python-nav-forward-statement
   \"C-S-p\" 'python-nav-backward-sexp
   \"C-S-n\" 'python-nav-forward-sexp
   \"C-x o\" 'my/olivetti-narrow
   \"C-x m\" 'elpy-multiedit-python-symbol-at-point
   \"C-x M\" 'elpy-multiedit-stop
   \"C-c g\" 'my/counsel-ag-python
   \"M-m\" 'flycheck-first-error
   \"C-c p\" 'my/python-make-print
   \"C-c f\" 'my/python-make-fstring
   \"C-c DEL\" 'my/erase-python-file
   \"C-c =\" 'my/erase-python-file-and-yank
   )

  (general-unbind 'python-mode-map
    :with 'yafolding-hide-all
    [remap evil-close-folds])

  (general-nmap
    :keymaps 'python-mode-map
    \"<escape>\" 'my-python-save-buffer)

  (defun my-python-save-buffer ()
    (interactive)
    (delete-trailing-whitespace)
    (save-buffer)
    (apheleia-format-buffer))

  (defun my-apheleia-black ()
    (interactive)
    (apheleia-format-buffer black))

  (general-nvmap
    :keymaps 'python-mode-map
    \"zi\" 'yafolding-show-all
    \"M-a\" 'python-nav-backward-statement
    \"M-e\" 'python-nav-forward-statement
    \"C-S-p\" 'python-nav-backward-sexp
    \"C-S-n\" 'python-nav-forward-sexp
    \"C-ç\" 'my/python-newline-beg
    \"<backspace>\" 'org-edit-src-exit
    \"<C-return>\" 'my-quickrun
    \"<tab>\" 'elpy-folding-toggle-at-point
    \"<tab>\" 'elpy-folding-toggle-at-point
    \"RET\" 'hydra-python-mode/body
    \"zm\" 'evil-close-folds
    \"gh\" 'outline-up-heading
    \"gl\" 'outline-next-heading
    \"zl\" 'outline-show-subtree
    \"<\" 'python-indent-shift-left
    \">\" 'python-indent-shift-right
    \"gj\" 'outline-forward-same-level
    \"gk\" 'outline-backward-same-level)

  (defun my-python-newline-beg ()
    (interactive)
    (evil-insert-state)
    (newline)
    (beginning-of-line))

  (defun my-python-colon-newline ()
    (interactive)
    (end-of-line)
    (insert \":\")
    (newline-and-indent))

  (general-imap
    :keymaps 'python-mode-map
    \"C-=\"   'my-python-colon-newline
    \"C-ç\" 'my-python-newline-beg
    \"<C-return>\" 'my-quickrun
    \"C-h\" 'python-indent-dedent-line-backspace
    \"M-a\" 'python-nav-backward-statement
    \"M-e\" 'python-nav-forward-statement
    \"C-S-p\" 'python-nav-backward-sexp
    \"C-S-n\" 'python-nav-forward-sexp
    )

  ;; PYTHON FUNCTIONS;;

  (defun execute-python-program ()
    (interactive)
    (my/window-to-register-91)
    (my/quiet-save-buffer)
    (defvar foo-execute-python)
    (setq foo-execute-python (concat \"python3 \" (buffer-file-name)))
    (other-window 1)
    (switch-to-buffer-other-window \"*Async Shell Command*\")
    (shell-command foo))

  (defun my/execute-python-program-shell-simple  ()
    (interactive)
    (my/window-to-register-91)
    (my/quiet-save-buffer)
    (defvar foo-execute-python-simple)
    (setq foo-execute-python-simple (concat \"python3 \" (prelude-copy-file-name-to-clipboard)))
    (shell-command foo))

  (defun my/ex-python-run ()
    (interactive)
    (evil-ex \"w !python3\"))

  (defun my/execute-python-program-shell ()
    (interactive)
    (progn
      (my/quiet-save-buffer)
      (prelude-copy-file-name-to-clipboard)
      (shell)
      (sit-for 0.3)
      (insert \"source ~/scripts/cline_scripts/smallprompt.sh\")
      (comint-send-input)
      (insert \"python3 \")
      (yank)
      (comint-send-input)
      (evil-insert-state)
      (sit-for 0.3)
      (comint-clear-buffer)
      (company-mode -1)))

  (general-unbind 'python-mode-map
    :with 'elpy-doc
    [remap helpful-at-point])

  (defun my/run-python-external ()
    (interactive)
    (progn
      (prelude-copy-file-name-to-clipboard)
      (start-process-shell-command
       \"call term\" nil
       \"~/scripts/i3_scripts/show_term_right\")))

  (defun my/erase-python-file ()
    (interactive)
    (erase-buffer)
    (insert \"#!/usr/bin/env python3\\n\\n\")
    (evil-insert-state)
    (flycheck-clear))

  (defun my/erase-python-file-and-yank ()
    (interactive)
    (erase-buffer)
    (insert \"#!/usr/bin/env python3\\n\\n\")
    (yank))

  (defun my/kill-python-file ()
    (interactive)
    (kill-region (point-min) (point-max))
    (insert \"#!/usr/bin/env python3\\n\\n\")
    (evil-insert-state)
    (flycheck-clear))

  ;; PYTHON SETTINGS

  (setq comment-auto-fill-only-comments t
        python-indent-offset 4
        python-indent-guess-indent-offset nil)

  (auto-fill-mode 1))
" . 161788) ((marker . 44) . -7960) ((marker . 143) . -7960) ((marker . 1) . -3845) 169748 (t 24242 36983 586780 933000) nil (161788 . 169748) ("(use-package python
  :ensure nil
  :init
  (add-hook 'python-mode-hook 'my-python-hooks)
  (add-hook 'inferior-python-mode-hook 'my-inferior-python-mode-hooks)

  ;; https://stackoverflow.com/a/6141681
  (add-hook 'python-mode-hook
            (lambda ()
              (add-hook 'evil-insert-state-exit-hook (lambda() (save-buffer)) nil t)))

  ;; https://stackoverflow.com/a/6141681
  ;; (add-hook 'python-mode-hook
  ;;           (lambda ()
  ;;             (add-hook 'write-contents-functions (lambda() (elpy-black-fix-code)) nil t)))

  :config
  (font-lock-add-keywords 'python-mode
                          '((\"cls\" . font-lock-keyword-face)))
  (setq python-shell-interpreter \"python3\")
  (setq python-shell-interpreter-args \"-i -q\")

  (setq python-shell-completion-native-enable nil)

  (defun my-python-hooks ()
    (interactive)
    (flymake-mode -1)
    (toggle-truncate-lines +1)
    (electric-operator-mode +1)
    (flycheck-mode +1)
    (rainbow-delimiters-mode +1)
    (highlight-operators-mode +1)
    (evil-swap-keys-swap-double-single-quotes)
    (evil-swap-keys-swap-underscore-dash)
    (evil-swap-keys-swap-colon-semicolon)
    (smartparens-strict-mode +1)
    (my-company-idle-one-prefix-one-quiet)
    (highlight-numbers-mode +1)
    (yafolding-mode +1)
    ;; (apheleia-mode +1)
    (importmagic-mode +1)
    (elpy-enable +1))

  (defun my-inferior-python-mode-hooks ()
    (interactive)
    (electric-operator-mode +1)
    (flycheck-mode +1)
    (rainbow-delimiters-mode +1)
    (highlight-operators-mode +1)
    (evil-swap-keys-swap-double-single-quotes)
    (evil-swap-keys-swap-underscore-dash)
    (evil-swap-keys-swap-colon-semicolon)
    (smartparens-strict-mode +1)
    (my-company-idle-one-prefix-one-quiet)
    (company-mode +1)
    (highlight-numbers-mode +1))

  ;; (add-to-list 'company-backends 'company-jedi)

  ;; (setq-local company-backends '(company-jedi
  ;;                                company-dabbrev-code
  ;;                                company-files
  ;;                                (company-semantic
  ;;                                 company-capf
  ;;                                 company-keywords
  ;;                                 company-dabbrev
  ;;                                 company-shell)))

  (defun my/olivetti-narrow ()
    (interactive)
    (olivetti-mode +1)
    (setq-local olivetti-body-width 60))

  (defun my-python-hooks ()
    (interactive)
    (subword-mode 1)
    (electric-operator-mode +1)
    (company-mode +1)
    (flycheck-mode +1)
    (rainbow-delimiters-mode +1)
    (highlight-operators-mode +1)
    (evil-swap-keys-swap-double-single-quotes)
    (evil-swap-keys-swap-underscore-dash)
    (evil-swap-keys-swap-colon-semicolon)
    (smartparens-strict-mode +1)
    (my-company-idle-one-prefix-one-quiet)
    (highlight-numbers-mode +1)
    (elpy-enable +1)
    )

  ;; PYTHON KEYS ;;
  (general-define-key
   :keymaps 'inferior-python-mode-map
   \"C-j\" 'elpy-shell-switch-to-buffer
   \"M-e\" 'counsel-shell-history
   \"C-c j\" 'my/evil-shell-bottom
   \"C-c u\" 'universal-argument
   \"C-u\" 'comint-kill-input
   \"C-l\" 'comint-clear-buffer
   \"C-;\" 'my-elpy-switch-to-buffer
   \"C-n\" 'comint-next-input
   \"C-p\" 'comint-previous-input)

  (general-unbind 'inferior-python-mode-map
    :with 'elpy-shell-switch-to-buffer
    [remap save-buffer]
    [remap my-save-buffer]
    [remap comint-next-prompt])

  (general-unbind 'python-mode-map
    :with 'elpy-folding-toggle-at-point
    [remap hs-toggle-hiding])

  (general-unbind 'python-mode-map
    :with 'my-python-shebang
    [remap my-bash-shebang])

  (general-define-key
   :keymaps 'python-mode-map
   \"<M-return>\" 'apheleia-format-buffer
   \"M-a\" 'python-nav-backward-statement
   \"M-e\" 'python-nav-forward-statement
   \"C-S-p\" 'python-nav-backward-sexp
   \"C-S-n\" 'python-nav-forward-sexp
   \"C-x o\" 'my/olivetti-narrow
   \"C-x m\" 'elpy-multiedit-python-symbol-at-point
   \"C-x M\" 'elpy-multiedit-stop
   \"C-c g\" 'my/counsel-ag-python
   \"M-m\" 'flycheck-first-error
   \"C-c p\" 'my/python-make-print
   \"C-c f\" 'my/python-make-fstring
   \"C-c DEL\" 'my/erase-python-file
   \"C-c =\" 'my/erase-python-file-and-yank
   )

  (general-unbind 'python-mode-map
    :with 'yafolding-hide-all
    [remap evil-close-folds])

  (general-nmap
    :keymaps 'python-mode-map
    \"<escape>\" 'my-python-save-buffer)

  (defun my-python-save-buffer ()
    (interactive)
    (delete-trailing-whitespace)
    (save-buffer)
    (apheleia-format-buffer))

  (defun my-apheleia-black ()
    (interactive)
    (apheleia-format-buffer \"black\"))

  (general-nvmap
    :keymaps 'python-mode-map
    \"zi\" 'yafolding-show-all
    \"M-a\" 'python-nav-backward-statement
    \"M-e\" 'python-nav-forward-statement
    \"C-S-p\" 'python-nav-backward-sexp
    \"C-S-n\" 'python-nav-forward-sexp
    \"C-ç\" 'my/python-newline-beg
    \"<backspace>\" 'org-edit-src-exit
    \"<C-return>\" 'my-quickrun
    \"<tab>\" 'elpy-folding-toggle-at-point
    \"<tab>\" 'elpy-folding-toggle-at-point
    \"RET\" 'hydra-python-mode/body
    \"zm\" 'evil-close-folds
    \"gh\" 'outline-up-heading
    \"gl\" 'outline-next-heading
    \"zl\" 'outline-show-subtree
    \"<\" 'python-indent-shift-left
    \">\" 'python-indent-shift-right
    \"gj\" 'outline-forward-same-level
    \"gk\" 'outline-backward-same-level)

  (defun my-python-newline-beg ()
    (interactive)
    (evil-insert-state)
    (newline)
    (beginning-of-line))

  (defun my-python-colon-newline ()
    (interactive)
    (end-of-line)
    (insert \":\")
    (newline-and-indent))

  (general-imap
    :keymaps 'python-mode-map
    \"C-=\"   'my-python-colon-newline
    \"C-ç\" 'my-python-newline-beg
    \"<C-return>\" 'my-quickrun
    \"C-h\" 'python-indent-dedent-line-backspace
    \"M-a\" 'python-nav-backward-statement
    \"M-e\" 'python-nav-forward-statement
    \"C-S-p\" 'python-nav-backward-sexp
    \"C-S-n\" 'python-nav-forward-sexp
    )

  ;; PYTHON FUNCTIONS;;

  (defun execute-python-program ()
    (interactive)
    (my/window-to-register-91)
    (my/quiet-save-buffer)
    (defvar foo-execute-python)
    (setq foo-execute-python (concat \"python3 \" (buffer-file-name)))
    (other-window 1)
    (switch-to-buffer-other-window \"*Async Shell Command*\")
    (shell-command foo))

  (defun my/execute-python-program-shell-simple  ()
    (interactive)
    (my/window-to-register-91)
    (my/quiet-save-buffer)
    (defvar foo-execute-python-simple)
    (setq foo-execute-python-simple (concat \"python3 \" (prelude-copy-file-name-to-clipboard)))
    (shell-command foo))

  (defun my/ex-python-run ()
    (interactive)
    (evil-ex \"w !python3\"))

  (defun my/execute-python-program-shell ()
    (interactive)
    (progn
      (my/quiet-save-buffer)
      (prelude-copy-file-name-to-clipboard)
      (shell)
      (sit-for 0.3)
      (insert \"source ~/scripts/cline_scripts/smallprompt.sh\")
      (comint-send-input)
      (insert \"python3 \")
      (yank)
      (comint-send-input)
      (evil-insert-state)
      (sit-for 0.3)
      (comint-clear-buffer)
      (company-mode -1)))

  (general-unbind 'python-mode-map
    :with 'elpy-doc
    [remap helpful-at-point])

  (defun my/run-python-external ()
    (interactive)
    (progn
      (prelude-copy-file-name-to-clipboard)
      (start-process-shell-command
       \"call term\" nil
       \"~/scripts/i3_scripts/show_term_right\")))

  (defun my/erase-python-file ()
    (interactive)
    (erase-buffer)
    (insert \"#!/usr/bin/env python3\\n\\n\")
    (evil-insert-state)
    (flycheck-clear))

  (defun my/erase-python-file-and-yank ()
    (interactive)
    (erase-buffer)
    (insert \"#!/usr/bin/env python3\\n\\n\")
    (yank))

  (defun my/kill-python-file ()
    (interactive)
    (kill-region (point-min) (point-max))
    (insert \"#!/usr/bin/env python3\\n\\n\")
    (evil-insert-state)
    (flycheck-clear))

  ;; PYTHON SETTINGS

  (setq comment-auto-fill-only-comments t
        python-indent-offset 4
        python-indent-guess-indent-offset nil)

  (auto-fill-mode 1))
" . 161788) ((marker . 78613) . -4517) 166353 (t 24242 36966 307269 380000) nil (161788 . 169750) ("(use-package python
  :ensure nil
  :init
  (add-hook 'python-mode-hook 'my-python-hooks)
  (add-hook 'inferior-python-mode-hook 'my-inferior-python-mode-hooks)

  ;; https://stackoverflow.com/a/6141681
  (add-hook 'python-mode-hook
            (lambda ()
              (add-hook 'evil-insert-state-exit-hook (lambda() (save-buffer)) nil t)))

  ;; https://stackoverflow.com/a/6141681
  ;; (add-hook 'python-mode-hook
  ;;           (lambda ()
  ;;             (add-hook 'write-contents-functions (lambda() (elpy-black-fix-code)) nil t)))

  :config
  (font-lock-add-keywords 'python-mode
                          '((\"cls\" . font-lock-keyword-face)))
  (setq python-shell-interpreter \"python3\")
  (setq python-shell-interpreter-args \"-i -q\")

  (setq python-shell-completion-native-enable nil)

  (defun my-python-hooks ()
    (interactive)
    (flymake-mode -1)
    (toggle-truncate-lines +1)
    (electric-operator-mode +1)
    (flycheck-mode +1)
    (rainbow-delimiters-mode +1)
    (highlight-operators-mode +1)
    (evil-swap-keys-swap-double-single-quotes)
    (evil-swap-keys-swap-underscore-dash)
    (evil-swap-keys-swap-colon-semicolon)
    (smartparens-strict-mode +1)
    (my-company-idle-one-prefix-one-quiet)
    (highlight-numbers-mode +1)
    (yafolding-mode +1)
    ;; (apheleia-mode +1)
    (importmagic-mode +1)
    (elpy-enable +1))

  (defun my-inferior-python-mode-hooks ()
    (interactive)
    (electric-operator-mode +1)
    (flycheck-mode +1)
    (rainbow-delimiters-mode +1)
    (highlight-operators-mode +1)
    (evil-swap-keys-swap-double-single-quotes)
    (evil-swap-keys-swap-underscore-dash)
    (evil-swap-keys-swap-colon-semicolon)
    (smartparens-strict-mode +1)
    (my-company-idle-one-prefix-one-quiet)
    (company-mode +1)
    (highlight-numbers-mode +1))

  ;; (add-to-list 'company-backends 'company-jedi)

  ;; (setq-local company-backends '(company-jedi
  ;;                                company-dabbrev-code
  ;;                                company-files
  ;;                                (company-semantic
  ;;                                 company-capf
  ;;                                 company-keywords
  ;;                                 company-dabbrev
  ;;                                 company-shell)))

  (defun my/olivetti-narrow ()
    (interactive)
    (olivetti-mode +1)
    (setq-local olivetti-body-width 60))

  (defun my-python-hooks ()
    (interactive)
    (subword-mode 1)
    (electric-operator-mode +1)
    (company-mode +1)
    (flycheck-mode +1)
    (rainbow-delimiters-mode +1)
    (highlight-operators-mode +1)
    (evil-swap-keys-swap-double-single-quotes)
    (evil-swap-keys-swap-underscore-dash)
    (evil-swap-keys-swap-colon-semicolon)
    (smartparens-strict-mode +1)
    (my-company-idle-one-prefix-one-quiet)
    (highlight-numbers-mode +1)
    (elpy-enable +1)
    )

  ;; PYTHON KEYS ;;
  (general-define-key
   :keymaps 'inferior-python-mode-map
   \"C-j\" 'elpy-shell-switch-to-buffer
   \"M-e\" 'counsel-shell-history
   \"C-c j\" 'my/evil-shell-bottom
   \"C-c u\" 'universal-argument
   \"C-u\" 'comint-kill-input
   \"C-l\" 'comint-clear-buffer
   \"C-;\" 'my-elpy-switch-to-buffer
   \"C-n\" 'comint-next-input
   \"C-p\" 'comint-previous-input)

  (general-unbind 'inferior-python-mode-map
    :with 'elpy-shell-switch-to-buffer
    [remap save-buffer]
    [remap my-save-buffer]
    [remap comint-next-prompt])

  (general-unbind 'python-mode-map
    :with 'elpy-folding-toggle-at-point
    [remap hs-toggle-hiding])

  (general-unbind 'python-mode-map
    :with 'my-python-shebang
    [remap my-bash-shebang])

  (general-define-key
   :keymaps 'python-mode-map
   \"<M-return>\" 'apheleia-format-buffer
   \"M-a\" 'python-nav-backward-statement
   \"M-e\" 'python-nav-forward-statement
   \"C-S-p\" 'python-nav-backward-sexp
   \"C-S-n\" 'python-nav-forward-sexp
   \"C-x o\" 'my/olivetti-narrow
   \"C-x m\" 'elpy-multiedit-python-symbol-at-point
   \"C-x M\" 'elpy-multiedit-stop
   \"C-c g\" 'my/counsel-ag-python
   \"M-m\" 'flycheck-first-error
   \"C-c p\" 'my/python-make-print
   \"C-c f\" 'my/python-make-fstring
   \"C-c DEL\" 'my/erase-python-file
   \"C-c =\" 'my/erase-python-file-and-yank
   )

  (general-unbind 'python-mode-map
    :with 'yafolding-hide-all
    [remap evil-close-folds])

  (general-nmap
    :keymaps 'python-mode-map
    \"<escape>\" 'my-python-save-buffer)

  (defun my-python-save-buffer ()
    (interactive)
    (delete-trailing-whitespace)
    (save-buffer)
    (apheleia-format-buffer))

  (defun my-apheleia-black ()
    (interactive)
    (apheleia-format-buffer)
(apheleia-format-buffer COMMAND &optional CALLBACK)
    )

  (general-nvmap
    :keymaps 'python-mode-map
    \"zi\" 'yafolding-show-all
    \"M-a\" 'python-nav-backward-statement
    \"M-e\" 'python-nav-forward-statement
    \"C-S-p\" 'python-nav-backward-sexp
    \"C-S-n\" 'python-nav-forward-sexp
    \"C-ç\" 'my/python-newline-beg
    \"<backspace>\" 'org-edit-src-exit
    \"<C-return>\" 'my-quickrun
    \"<tab>\" 'elpy-folding-toggle-at-point
    \"<tab>\" 'elpy-folding-toggle-at-point
    \"RET\" 'hydra-python-mode/body
    \"zm\" 'evil-close-folds
    \"gh\" 'outline-up-heading
    \"gl\" 'outline-next-heading
    \"zl\" 'outline-show-subtree
    \"<\" 'python-indent-shift-left
    \">\" 'python-indent-shift-right
    \"gj\" 'outline-forward-same-level
    \"gk\" 'outline-backward-same-level)

  (defun my-python-newline-beg ()
    (interactive)
    (evil-insert-state)
    (newline)
    (beginning-of-line))

  (defun my-python-colon-newline ()
    (interactive)
    (end-of-line)
    (insert \":\")
    (newline-and-indent))

  (general-imap
    :keymaps 'python-mode-map
    \"C-=\"   'my-python-colon-newline
    \"C-ç\" 'my-python-newline-beg
    \"<C-return>\" 'my-quickrun
    \"C-h\" 'python-indent-dedent-line-backspace
    \"M-a\" 'python-nav-backward-statement
    \"M-e\" 'python-nav-forward-statement
    \"C-S-p\" 'python-nav-backward-sexp
    \"C-S-n\" 'python-nav-forward-sexp
    )

  ;; PYTHON FUNCTIONS;;

  (defun execute-python-program ()
    (interactive)
    (my/window-to-register-91)
    (my/quiet-save-buffer)
    (defvar foo-execute-python)
    (setq foo-execute-python (concat \"python3 \" (buffer-file-name)))
    (other-window 1)
    (switch-to-buffer-other-window \"*Async Shell Command*\")
    (shell-command foo))

  (defun my/execute-python-program-shell-simple  ()
    (interactive)
    (my/window-to-register-91)
    (my/quiet-save-buffer)
    (defvar foo-execute-python-simple)
    (setq foo-execute-python-simple (concat \"python3 \" (prelude-copy-file-name-to-clipboard)))
    (shell-command foo))

  (defun my/ex-python-run ()
    (interactive)
    (evil-ex \"w !python3\"))

  (defun my/execute-python-program-shell ()
    (interactive)
    (progn
      (my/quiet-save-buffer)
      (prelude-copy-file-name-to-clipboard)
      (shell)
      (sit-for 0.3)
      (insert \"source ~/scripts/cline_scripts/smallprompt.sh\")
      (comint-send-input)
      (insert \"python3 \")
      (yank)
      (comint-send-input)
      (evil-insert-state)
      (sit-for 0.3)
      (comint-clear-buffer)
      (company-mode -1)))

  (general-unbind 'python-mode-map
    :with 'elpy-doc
    [remap helpful-at-point])

  (defun my/run-python-external ()
    (interactive)
    (progn
      (prelude-copy-file-name-to-clipboard)
      (start-process-shell-command
       \"call term\" nil
       \"~/scripts/i3_scripts/show_term_right\")))

  (defun my/erase-python-file ()
    (interactive)
    (erase-buffer)
    (insert \"#!/usr/bin/env python3\\n\\n\")
    (evil-insert-state)
    (flycheck-clear))

  (defun my/erase-python-file-and-yank ()
    (interactive)
    (erase-buffer)
    (insert \"#!/usr/bin/env python3\\n\\n\")
    (yank))

  (defun my/kill-python-file ()
    (interactive)
    (kill-region (point-min) (point-max))
    (insert \"#!/usr/bin/env python3\\n\\n\")
    (evil-insert-state)
    (flycheck-clear))

  ;; PYTHON SETTINGS

  (setq comment-auto-fill-only-comments t
        python-indent-offset 4
        python-indent-guess-indent-offset nil)

  (auto-fill-mode 1))
" . 161788) 169799 (t 24242 36963 387173 235000) nil (161788 . 169799) ("(use-package python
  :ensure nil
  :init
  (add-hook 'python-mode-hook 'my-python-hooks)
  (add-hook 'inferior-python-mode-hook 'my-inferior-python-mode-hooks)

  ;; https://stackoverflow.com/a/6141681
  (add-hook 'python-mode-hook
            (lambda ()
              (add-hook 'evil-insert-state-exit-hook (lambda() (save-buffer)) nil t)))

  ;; https://stackoverflow.com/a/6141681
  ;; (add-hook 'python-mode-hook
  ;;           (lambda ()
  ;;             (add-hook 'write-contents-functions (lambda() (elpy-black-fix-code)) nil t)))

  :config
  (font-lock-add-keywords 'python-mode
                          '((\"cls\" . font-lock-keyword-face)))
  (setq python-shell-interpreter \"python3\")
  (setq python-shell-interpreter-args \"-i -q\")

  (setq python-shell-completion-native-enable nil)

  (defun my-python-hooks ()
    (interactive)
    (flymake-mode -1)
    (toggle-truncate-lines +1)
    (electric-operator-mode +1)
    (flycheck-mode +1)
    (rainbow-delimiters-mode +1)
    (highlight-operators-mode +1)
    (evil-swap-keys-swap-double-single-quotes)
    (evil-swap-keys-swap-underscore-dash)
    (evil-swap-keys-swap-colon-semicolon)
    (smartparens-strict-mode +1)
    (my-company-idle-one-prefix-one-quiet)
    (highlight-numbers-mode +1)
    (yafolding-mode +1)
    ;; (apheleia-mode +1)
    (importmagic-mode +1)
    (elpy-enable +1))

  (defun my-inferior-python-mode-hooks ()
    (interactive)
    (electric-operator-mode +1)
    (flycheck-mode +1)
    (rainbow-delimiters-mode +1)
    (highlight-operators-mode +1)
    (evil-swap-keys-swap-double-single-quotes)
    (evil-swap-keys-swap-underscore-dash)
    (evil-swap-keys-swap-colon-semicolon)
    (smartparens-strict-mode +1)
    (my-company-idle-one-prefix-one-quiet)
    (company-mode +1)
    (highlight-numbers-mode +1))

  ;; (add-to-list 'company-backends 'company-jedi)

  ;; (setq-local company-backends '(company-jedi
  ;;                                company-dabbrev-code
  ;;                                company-files
  ;;                                (company-semantic
  ;;                                 company-capf
  ;;                                 company-keywords
  ;;                                 company-dabbrev
  ;;                                 company-shell)))

  (defun my/olivetti-narrow ()
    (interactive)
    (olivetti-mode +1)
    (setq-local olivetti-body-width 60))

  (defun my-python-hooks ()
    (interactive)
    (subword-mode 1)
    (electric-operator-mode +1)
    (company-mode +1)
    (flycheck-mode +1)
    (rainbow-delimiters-mode +1)
    (highlight-operators-mode +1)
    (evil-swap-keys-swap-double-single-quotes)
    (evil-swap-keys-swap-underscore-dash)
    (evil-swap-keys-swap-colon-semicolon)
    (smartparens-strict-mode +1)
    (my-company-idle-one-prefix-one-quiet)
    (highlight-numbers-mode +1)
    (elpy-enable +1)
    )

  ;; PYTHON KEYS ;;
  (general-define-key
   :keymaps 'inferior-python-mode-map
   \"C-j\" 'elpy-shell-switch-to-buffer
   \"M-e\" 'counsel-shell-history
   \"C-c j\" 'my/evil-shell-bottom
   \"C-c u\" 'universal-argument
   \"C-u\" 'comint-kill-input
   \"C-l\" 'comint-clear-buffer
   \"C-;\" 'my-elpy-switch-to-buffer
   \"C-n\" 'comint-next-input
   \"C-p\" 'comint-previous-input)

  (general-unbind 'inferior-python-mode-map
    :with 'elpy-shell-switch-to-buffer
    [remap save-buffer]
    [remap my-save-buffer]
    [remap comint-next-prompt])

  (general-unbind 'python-mode-map
    :with 'elpy-folding-toggle-at-point
    [remap hs-toggle-hiding])

  (general-unbind 'python-mode-map
    :with 'my-python-shebang
    [remap my-bash-shebang])

  (general-define-key
   :keymaps 'python-mode-map
   \"<M-return>\" 'apheleia-format-buffer
   \"M-a\" 'python-nav-backward-statement
   \"M-e\" 'python-nav-forward-statement
   \"C-S-p\" 'python-nav-backward-sexp
   \"C-S-n\" 'python-nav-forward-sexp
   \"C-x o\" 'my/olivetti-narrow
   \"C-x m\" 'elpy-multiedit-python-symbol-at-point
   \"C-x M\" 'elpy-multiedit-stop
   \"C-c g\" 'my/counsel-ag-python
   \"M-m\" 'flycheck-first-error
   \"C-c p\" 'my/python-make-print
   \"C-c f\" 'my/python-make-fstring
   \"C-c DEL\" 'my/erase-python-file
   \"C-c =\" 'my/erase-python-file-and-yank
   )

  (general-unbind 'python-mode-map
    :with 'yafolding-hide-all
    [remap evil-close-folds])

  (general-nmap
    :keymaps 'python-mode-map
    \"<escape>\" 'my-python-save-buffer)

  (defun my-python-save-buffer ()
    (interactive)
    (delete-trailing-whitespace)
    (save-buffer)
    (apheleia-format-buffer))

  (defun my-apheleia-black ()
    (interactive)
    (apheleia-format-buffer)

    )

  (general-nvmap
    :keymaps 'python-mode-map
    \"zi\" 'yafolding-show-all
    \"M-a\" 'python-nav-backward-statement
    \"M-e\" 'python-nav-forward-statement
    \"C-S-p\" 'python-nav-backward-sexp
    \"C-S-n\" 'python-nav-forward-sexp
    \"C-ç\" 'my/python-newline-beg
    \"<backspace>\" 'org-edit-src-exit
    \"<C-return>\" 'my-quickrun
    \"<tab>\" 'elpy-folding-toggle-at-point
    \"<tab>\" 'elpy-folding-toggle-at-point
    \"RET\" 'hydra-python-mode/body
    \"zm\" 'evil-close-folds
    \"gh\" 'outline-up-heading
    \"gl\" 'outline-next-heading
    \"zl\" 'outline-show-subtree
    \"<\" 'python-indent-shift-left
    \">\" 'python-indent-shift-right
    \"gj\" 'outline-forward-same-level
    \"gk\" 'outline-backward-same-level)

  (defun my-python-newline-beg ()
    (interactive)
    (evil-insert-state)
    (newline)
    (beginning-of-line))

  (defun my-python-colon-newline ()
    (interactive)
    (end-of-line)
    (insert \":\")
    (newline-and-indent))

  (general-imap
    :keymaps 'python-mode-map
    \"C-=\"   'my-python-colon-newline
    \"C-ç\" 'my-python-newline-beg
    \"<C-return>\" 'my-quickrun
    \"C-h\" 'python-indent-dedent-line-backspace
    \"M-a\" 'python-nav-backward-statement
    \"M-e\" 'python-nav-forward-statement
    \"C-S-p\" 'python-nav-backward-sexp
    \"C-S-n\" 'python-nav-forward-sexp
    )

  ;; PYTHON FUNCTIONS;;

  (defun execute-python-program ()
    (interactive)
    (my/window-to-register-91)
    (my/quiet-save-buffer)
    (defvar foo-execute-python)
    (setq foo-execute-python (concat \"python3 \" (buffer-file-name)))
    (other-window 1)
    (switch-to-buffer-other-window \"*Async Shell Command*\")
    (shell-command foo))

  (defun my/execute-python-program-shell-simple  ()
    (interactive)
    (my/window-to-register-91)
    (my/quiet-save-buffer)
    (defvar foo-execute-python-simple)
    (setq foo-execute-python-simple (concat \"python3 \" (prelude-copy-file-name-to-clipboard)))
    (shell-command foo))

  (defun my/ex-python-run ()
    (interactive)
    (evil-ex \"w !python3\"))

  (defun my/execute-python-program-shell ()
    (interactive)
    (progn
      (my/quiet-save-buffer)
      (prelude-copy-file-name-to-clipboard)
      (shell)
      (sit-for 0.3)
      (insert \"source ~/scripts/cline_scripts/smallprompt.sh\")
      (comint-send-input)
      (insert \"python3 \")
      (yank)
      (comint-send-input)
      (evil-insert-state)
      (sit-for 0.3)
      (comint-clear-buffer)
      (company-mode -1)))

  (general-unbind 'python-mode-map
    :with 'elpy-doc
    [remap helpful-at-point])

  (defun my/run-python-external ()
    (interactive)
    (progn
      (prelude-copy-file-name-to-clipboard)
      (start-process-shell-command
       \"call term\" nil
       \"~/scripts/i3_scripts/show_term_right\")))

  (defun my/erase-python-file ()
    (interactive)
    (erase-buffer)
    (insert \"#!/usr/bin/env python3\\n\\n\")
    (evil-insert-state)
    (flycheck-clear))

  (defun my/erase-python-file-and-yank ()
    (interactive)
    (erase-buffer)
    (insert \"#!/usr/bin/env python3\\n\\n\")
    (yank))

  (defun my/kill-python-file ()
    (interactive)
    (kill-region (point-min) (point-max))
    (insert \"#!/usr/bin/env python3\\n\\n\")
    (evil-insert-state)
    (flycheck-clear))

  ;; PYTHON SETTINGS

  (setq comment-auto-fill-only-comments t
        python-indent-offset 4
        python-indent-guess-indent-offset nil)

  (auto-fill-mode 1))
" . 161788) 169748 (t 24242 36952 175826 987000) nil (161788 . 169748) ("(use-package python
  :ensure nil
  :init
  (add-hook 'python-mode-hook 'my-python-hooks)
  (add-hook 'inferior-python-mode-hook 'my-inferior-python-mode-hooks)

  ;; https://stackoverflow.com/a/6141681
  (add-hook 'python-mode-hook
            (lambda ()
              (add-hook 'evil-insert-state-exit-hook (lambda() (save-buffer)) nil t)))

  ;; https://stackoverflow.com/a/6141681
  ;; (add-hook 'python-mode-hook
  ;;           (lambda ()
  ;;             (add-hook 'write-contents-functions (lambda() (elpy-black-fix-code)) nil t)))

  :config
  (font-lock-add-keywords 'python-mode
                          '((\"cls\" . font-lock-keyword-face)))
  (setq python-shell-interpreter \"python3\")
  (setq python-shell-interpreter-args \"-i -q\")

  (setq python-shell-completion-native-enable nil)

  (defun my-python-hooks ()
    (interactive)
    (flymake-mode -1)
    (toggle-truncate-lines +1)
    (electric-operator-mode +1)
    (flycheck-mode +1)
    (rainbow-delimiters-mode +1)
    (highlight-operators-mode +1)
    (evil-swap-keys-swap-double-single-quotes)
    (evil-swap-keys-swap-underscore-dash)
    (evil-swap-keys-swap-colon-semicolon)
    (smartparens-strict-mode +1)
    (my-company-idle-one-prefix-one-quiet)
    (highlight-numbers-mode +1)
    (yafolding-mode +1)
    ;; (apheleia-mode +1)
    (importmagic-mode +1)
    (elpy-enable +1))

  (defun my-inferior-python-mode-hooks ()
    (interactive)
    (electric-operator-mode +1)
    (flycheck-mode +1)
    (rainbow-delimiters-mode +1)
    (highlight-operators-mode +1)
    (evil-swap-keys-swap-double-single-quotes)
    (evil-swap-keys-swap-underscore-dash)
    (evil-swap-keys-swap-colon-semicolon)
    (smartparens-strict-mode +1)
    (my-company-idle-one-prefix-one-quiet)
    (company-mode +1)
    (highlight-numbers-mode +1))

  ;; (add-to-list 'company-backends 'company-jedi)

  ;; (setq-local company-backends '(company-jedi
  ;;                                company-dabbrev-code
  ;;                                company-files
  ;;                                (company-semantic
  ;;                                 company-capf
  ;;                                 company-keywords
  ;;                                 company-dabbrev
  ;;                                 company-shell)))

  (defun my/olivetti-narrow ()
    (interactive)
    (olivetti-mode +1)
    (setq-local olivetti-body-width 60))

  (defun my-python-hooks ()
    (interactive)
    (subword-mode 1)
    (electric-operator-mode +1)
    (company-mode +1)
    (flycheck-mode +1)
    (rainbow-delimiters-mode +1)
    (highlight-operators-mode +1)
    (evil-swap-keys-swap-double-single-quotes)
    (evil-swap-keys-swap-underscore-dash)
    (evil-swap-keys-swap-colon-semicolon)
    (smartparens-strict-mode +1)
    (my-company-idle-one-prefix-one-quiet)
    (highlight-numbers-mode +1)
    (elpy-enable +1)
    )

  ;; PYTHON KEYS ;;
  (general-define-key
   :keymaps 'inferior-python-mode-map
   \"C-j\" 'elpy-shell-switch-to-buffer
   \"M-e\" 'counsel-shell-history
   \"C-c j\" 'my/evil-shell-bottom
   \"C-c u\" 'universal-argument
   \"C-u\" 'comint-kill-input
   \"C-l\" 'comint-clear-buffer
   \"C-;\" 'my-elpy-switch-to-buffer
   \"C-n\" 'comint-next-input
   \"C-p\" 'comint-previous-input)

  (general-unbind 'inferior-python-mode-map
    :with 'elpy-shell-switch-to-buffer
    [remap save-buffer]
    [remap my-save-buffer]
    [remap comint-next-prompt])

  (general-unbind 'python-mode-map
    :with 'elpy-folding-toggle-at-point
    [remap hs-toggle-hiding])

  (general-unbind 'python-mode-map
    :with 'my-python-shebang
    [remap my-bash-shebang])

  (general-define-key
   :keymaps 'python-mode-map
   \"<M-return>\" 'apheleia-format-buffer
   \"M-a\" 'python-nav-backward-statement
   \"M-e\" 'python-nav-forward-statement
   \"C-S-p\" 'python-nav-backward-sexp
   \"C-S-n\" 'python-nav-forward-sexp
   \"C-x o\" 'my/olivetti-narrow
   \"C-x m\" 'elpy-multiedit-python-symbol-at-point
   \"C-x M\" 'elpy-multiedit-stop
   \"C-c g\" 'my/counsel-ag-python
   \"M-m\" 'flycheck-first-error
   \"C-c p\" 'my/python-make-print
   \"C-c f\" 'my/python-make-fstring
   \"C-c DEL\" 'my/erase-python-file
   \"C-c =\" 'my/erase-python-file-and-yank
   )

  (general-unbind 'python-mode-map
    :with 'yafolding-hide-all
    [remap evil-close-folds])

  (general-nmap
    :keymaps 'python-mode-map
    \"<escape>\" 'my-python-save-buffer)

  (defun my-python-save-buffer ()
    (interactive)
    (delete-trailing-whitespace)
    (save-buffer)
    (apheleia-format-buffer))

  (defun my-apheleia-black ()
    (interactive)
    (apheleia-format-buffer))

  (general-nvmap
    :keymaps 'python-mode-map
    \"zi\" 'yafolding-show-all
    \"M-a\" 'python-nav-backward-statement
    \"M-e\" 'python-nav-forward-statement
    \"C-S-p\" 'python-nav-backward-sexp
    \"C-S-n\" 'python-nav-forward-sexp
    \"C-ç\" 'my/python-newline-beg
    \"<backspace>\" 'org-edit-src-exit
    \"<C-return>\" 'my-quickrun
    \"<tab>\" 'elpy-folding-toggle-at-point
    \"<tab>\" 'elpy-folding-toggle-at-point
    \"RET\" 'hydra-python-mode/body
    \"zm\" 'evil-close-folds
    \"gh\" 'outline-up-heading
    \"gl\" 'outline-next-heading
    \"zl\" 'outline-show-subtree
    \"<\" 'python-indent-shift-left
    \">\" 'python-indent-shift-right
    \"gj\" 'outline-forward-same-level
    \"gk\" 'outline-backward-same-level)

  (defun my-python-newline-beg ()
    (interactive)
    (evil-insert-state)
    (newline)
    (beginning-of-line))

  (defun my-python-colon-newline ()
    (interactive)
    (end-of-line)
    (insert \":\")
    (newline-and-indent))

  (general-imap
    :keymaps 'python-mode-map
    \"C-=\"   'my-python-colon-newline
    \"C-ç\" 'my-python-newline-beg
    \"<C-return>\" 'my-quickrun
    \"C-h\" 'python-indent-dedent-line-backspace
    \"M-a\" 'python-nav-backward-statement
    \"M-e\" 'python-nav-forward-statement
    \"C-S-p\" 'python-nav-backward-sexp
    \"C-S-n\" 'python-nav-forward-sexp
    )

  ;; PYTHON FUNCTIONS;;

  (defun execute-python-program ()
    (interactive)
    (my/window-to-register-91)
    (my/quiet-save-buffer)
    (defvar foo-execute-python)
    (setq foo-execute-python (concat \"python3 \" (buffer-file-name)))
    (other-window 1)
    (switch-to-buffer-other-window \"*Async Shell Command*\")
    (shell-command foo))

  (defun my/execute-python-program-shell-simple  ()
    (interactive)
    (my/window-to-register-91)
    (my/quiet-save-buffer)
    (defvar foo-execute-python-simple)
    (setq foo-execute-python-simple (concat \"python3 \" (prelude-copy-file-name-to-clipboard)))
    (shell-command foo))

  (defun my/ex-python-run ()
    (interactive)
    (evil-ex \"w !python3\"))

  (defun my/execute-python-program-shell ()
    (interactive)
    (progn
      (my/quiet-save-buffer)
      (prelude-copy-file-name-to-clipboard)
      (shell)
      (sit-for 0.3)
      (insert \"source ~/scripts/cline_scripts/smallprompt.sh\")
      (comint-send-input)
      (insert \"python3 \")
      (yank)
      (comint-send-input)
      (evil-insert-state)
      (sit-for 0.3)
      (comint-clear-buffer)
      (company-mode -1)))

  (general-unbind 'python-mode-map
    :with 'elpy-doc
    [remap helpful-at-point])

  (defun my/run-python-external ()
    (interactive)
    (progn
      (prelude-copy-file-name-to-clipboard)
      (start-process-shell-command
       \"call term\" nil
       \"~/scripts/i3_scripts/show_term_right\")))

  (defun my/erase-python-file ()
    (interactive)
    (erase-buffer)
    (insert \"#!/usr/bin/env python3\\n\\n\")
    (evil-insert-state)
    (flycheck-clear))

  (defun my/erase-python-file-and-yank ()
    (interactive)
    (erase-buffer)
    (insert \"#!/usr/bin/env python3\\n\\n\")
    (yank))

  (defun my/kill-python-file ()
    (interactive)
    (kill-region (point-min) (point-max))
    (insert \"#!/usr/bin/env python3\\n\\n\")
    (evil-insert-state)
    (flycheck-clear))

  ;; PYTHON SETTINGS

  (setq comment-auto-fill-only-comments t
        python-indent-offset 4
        python-indent-guess-indent-offset nil)

  (auto-fill-mode 1))
" . 161788) 169742 (t 24242 36948 925860 558000)) (emacs-buffer-undo-list nil ("n" . 143) nil ("o" . 143) ((marker . 143) . -1) ((marker . 143) . -1) ((marker . 143) . -1) ((marker . 143) . -1) ((marker . 143) . -1) ((marker . 143) . -1) ((marker . 143) . -1) ((marker . 143) . -1) ((marker . 143) . -1) ((marker . 143) . -1) ((marker . 143) . -1) ((marker . 143) . -1) nil ("n" . 143) nil ("A" . 143) (t 24242 40185 904222 482000) nil ("n" . 44) ((marker . 44) . -1) ((marker . 44) . -1) ((marker . 44) . -1) ((marker . 44) . -1) ((marker . 44) . -1) ((marker . 44) . -1) ((marker . 44) . -1) ((marker . 44) . -1) ((marker . 44) . -1) nil ("o" . 44) nil ("n" . 44) nil ("A" . 44) (t 24242 38442 187021 100000) nil (149 . 151) ("i" . -149) ((marker . 143) . -1) ("n" . -150) ((marker . 143) . -1) 151 (147 . 151) ("Anonymous" . 147) (t 24242 38435 154828 152000) nil (nil rear-nonsticky nil 53 . 54) (nil fontified nil 44 . 54) (44 . 54) 59 ("AnonymousSurvey" . 44) ((marker . 44) . -15) ((marker . 44) . -9) ((marker . 143) . -14) ((marker . 131) . -14) ((marker) . -14) 59 (t 24242 38260 202686 479000) nil ("sdasd" . 359) (t 24242 38258 662173 247000) nil (359 . 364) (t 24242 38251 537823 736000) nil ("asd" . 380) (t 24242 38248 429197 368000) nil (380 . 383) (t 24242 38187 972462 80000) nil ("sda" . 359) (t 24242 38183 652515 338000) nil (359 . 362) (t 24242 38182 463480 886000) nil ("sd" . 359) (t 24242 38179 255143 592000) nil (359 . 361) (t 24242 38125 396028 398000) nil (395 . 396) (391 . 395) (t 24242 38097 480232 175000) nil (apply yas--snippet-revive 60 98 #s(yas--snippet nil nil nil 98 nil nil nil nil)) (apply yas--take-care-of-redo #s(yas--snippet nil nil nil 98 nil nil nil nil)) (60 . 98) ("clear" . 60) 65 (t 24242 38097 259367 655000) nil (60 . 65) (59 . 60) (t 24242 38084 986771 190000) 25 nil (352 . 361) ("resu" . -352) 356 (352 . 356) (342 . 352) ("my" . -342) 344 (342 . 344) (341 . 342) (337 . 339) (">" . -337) 338 (327 . 338) ("\"" . -327) (327 . 328) ("\"" . -327) (327 . 329) ("\"" . -327) (327 . 328) (apply yas--snippet-revive 321 328 #s(yas--snippet nil nil #s(yas--exit 327 nil) 97 nil nil nil nil)) (apply yas--take-care-of-redo #s(yas--snippet nil nil #s(yas--exit 327 nil) 97 nil nil nil nil)) (321 . 328) ("p" . 321) 322 (t 24242 38069 726635 375000) nil (321 . 322) ("    " . -321) 325 (321 . 325) ("    " . 320) (324 . 325) (319 . 324) (t 24242 38058 718912 750000) 317 nil (1 . 320) ("#!/usr/bin/env python3

from survey import AnonymousSurvey

question = \"What's your mother tongue?\"
my_survey = AnonymousSurvey(question)

my_survey.show_question()
print(\"Enter 'q' to quit\\n\")

while True:
    response = input(\"Language: \")
    if response == \"q\":
        break
    my_survey.store_response(response)" . 1) 317 (t 24242 38058 90685 958000) nil (310 . 318) ("respo" . -310) 315 (312 . 315) ("p" . -312) ("o" . -313) 314 (310 . 314) (295 . 311) ("sto" . -295) 298 (296 . 298) ("o" . -296) ("t" . -297) 298 (297 . 298) (295 . 297) (285 . 295) ("my" . -285) 287 (285 . 287) (280 . 285) ("
" . -280) 281 ("    " . -281) 285 ("
" . -285) 286 (280 . 285) (275 . 280) ("bre" . -275) 278 (275 . 278) (266 . 275) (nil face font-lock-string-face 265 . 266) (nil fontified t 265 . 266) (265 . 266) (262 . 264) ("\"" . -262) (262 . 263) ("\"" . -262) (262 . 264) ("\"" . -262) (258 . 263) (" = =" . -258) 262 (258 . 262) (" =" . -258) 260 (259 . 260) (250 . 259) ("re" . -250) 252 (247 . 252) (242 . 247) (t 24242 38027 605801 485000) nil (apply yas--snippet-revive 196 243 #s(yas--snippet nil (#s(yas--field 1 212 242 nil nil nil t #s(yas--exit 242 nil))) #s(yas--exit 242 nil) 96 nil #s(yas--field 1 212 242 nil nil nil t #s(yas--exit 242 nil)) nil nil)) (229 . 240) ("\"" . -229) (229 . 230) ("\"" . -229) (229 . 231) ("\"" . -229) (228 . 230) ("(" . -228) (228 . 230) ("(" . -228) (228 . 229) (220 . 228) ("=" . -220) 221 (220 . 221) (212 . 220) ("respon" . -212) 218 (213 . 218) ("pass" . 213) (212 . 213) (apply yas--take-care-of-redo #s(yas--snippet nil (#s(yas--field 1 212 242 nil nil nil t #s(yas--exit 242 nil))) #s(yas--exit 242 nil) 96 nil #s(yas--field 1 212 242 nil nil nil t #s(yas--exit 242 nil)) nil nil)) (196 . 217) ("wt" . 196) 198 (t 24242 38010 364505 709000) nil (196 . 198) ("tru" . -196) 199 ("e" . -199) 200 (196 . 200) (195 . 196) (t 24242 38004 56667 52000) 195 nil ("
" . 166) (t 24242 38002 786144 932000) nil (165 . 166) 164 (t 24242 37999 735689 789000) nil (181 . 192) (" " . -181) (181 . 182) ("'" . -181) (179 . 182) (" " . -179) (179 . 180) ("'" . -179) (172 . 180) ("\"" . -172) (172 . 173) ("\"" . -172) (172 . 174) ("\"" . -172) (172 . 173) (apply yas--snippet-revive 166 173 #s(yas--snippet nil nil #s(yas--exit 172 nil) 95 nil nil nil nil)) (apply yas--take-care-of-redo #s(yas--snippet nil nil #s(yas--exit 172 nil) 95 nil nil nil nil)) (166 . 173) ("p" . 166) 167 (t 24242 37990 224097 722000) nil (166 . 167) (165 . 166) (t 24242 37980 586081 841000) 162 nil (150 . 163) ("show_ques" . -150) 159 (155 . 159) ("results" . 155) (t 24242 37973 47914 989000) nil (150 . 164) ("sho" . -150) 153 (150 . 153) (140 . 150) ("my" . -140) 142 (140 . 142) (139 . 140) (138 . 139) (t 24242 37964 726803 776000) 101 nil ("

" . 139) 140 (t 24242 37963 905185 307000) nil (139 . 140) (138 . 139) (t 24242 37917 744537 998000) 136 nil (129 . 137) ("questoin" . 129) (t 24242 37915 147819 330000) nil (129 . 137) (113 . 130) ("An" . -113) 115 (113 . 115) (110 . 113) ("=" . -110) 111 (106 . 111) ("e" . -106) ("r" . -107) 108 (104 . 108) ("q" . -104) ("u" . -105) 106 (101 . 106) (nil face font-lock-string-face 100 . 101) (nil fontified t 100 . 101) (100 . 101) (t 24242 37901 78852 650000) 61 nil (1 . 101) ("#!/usr/bin/env python3

from survey import AnonymousSurvey

question = \"What's your mother tongue?\"" . 1) (t 24242 37900 413906 939000) nil (94 . 99) (77 . 94) (" " . -77) (77 . 78) ("'" . -77) (73 . 78) ("What " . -73) 78 ("language " . -78) 87 ("did " . -87) 91 ("you " . -91) 95 ("fi" . -95) 97 (95 . 97) (93 . 95) (72 . 93) ("\"" . -72) (72 . 73) ("\"" . -72) (72 . 74) ("\"" . -72) (72 . 73) (apply yas--snippet-revive 61 72 #s(yas--snippet nil (#s(yas--field 1 61 69 nil nil nil t #s(yas--exit 72 nil))) #s(yas--exit 72 nil) 94 nil #s(yas--field 1 61 69 nil nil nil t #s(yas--exit 72 nil)) nil nil)) (62 . 69) ("variable" . 62) (61 . 62) (apply yas--take-care-of-redo #s(yas--snippet nil (#s(yas--field 1 61 69 nil nil nil t #s(yas--exit 72 nil))) #s(yas--exit 72 nil) 94 nil #s(yas--field 1 61 69 nil nil nil t #s(yas--exit 72 nil)) nil nil)) (61 . 72) ("v" . 61) 62 (t 24242 37867 891167 402000) nil (61 . 62) ("variable =" . 61) (t 24242 37865 300276 462000) nil (apply yas--snippet-revive 61 71 #s(yas--snippet nil (#s(yas--field 1 61 69 nil nil nil nil #s(yas--exit 71 nil))) #s(yas--exit 71 nil) 93 nil #s(yas--field 1 61 69 nil nil nil nil #s(yas--exit 71 nil)) nil nil)) nil (" " . 71) 61 (t 24242 37864 549461 731000) nil (apply yas--take-care-of-redo #s(yas--snippet nil (#s(yas--field 1 61 69 nil nil nil nil #s(yas--exit 71 nil))) #s(yas--exit 71 nil) 93 nil #s(yas--field 1 61 69 nil nil nil nil #s(yas--exit 71 nil)) nil nil)) (61 . 72) ("v" . 61) 62 (t 24242 37856 369372 519000) nil (61 . 62) (59 . 61) (44 . 59) ("Ano" . -44) 47 (36 . 47) (30 . 36) ("su" . -30) 32 (25 . 32) (24 . 25) (t 24242 36552 754712 125000) 24 nil ("
" . -24) 25 (t 24242 36552 44270 808000) nil (1 . 25) (t 24242 36530 3080 954000)) (emacs-undo-equiv-table))