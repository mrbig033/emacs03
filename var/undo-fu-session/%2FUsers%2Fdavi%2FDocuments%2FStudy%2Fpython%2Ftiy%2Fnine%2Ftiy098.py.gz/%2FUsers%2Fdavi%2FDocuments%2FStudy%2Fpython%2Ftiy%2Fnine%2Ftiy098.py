((buffer-size . 1093) (buffer-checksum . "bad16225fd332008010fec9bc686a5cf4b650e45"))
((emacs-pending-undo-list ("
" . -26) 24 (t 24237 11985 264175 489000) nil (23 . 24) (t 24237 11720 831334 616000) 1 nil (nil rear-nonsticky nil 658 . 659) (nil fontified nil 1 . 659) (1 . 659) ("#!/usr/bin/env python3
sd
" . 1) (t 24237 11698 20913 863000) nil (24 . 27) ("sd" . -24) 25 (t 24237 11697 635274 651000) nil (24 . 26) (t 24237 11694 589699 432000) nil ("
" . -24) 25 (t 24237 11694 137914 347000) nil (1 . 25) (t 24234 22106 276943 273000)) (emacs-buffer-undo-list nil (nil rear-nonsticky nil 1093 . 1094) (nil fontified nil 1 . 1094) (1 . 1094) (t 24234 22106 277217 377000)) (emacs-undo-equiv-table))