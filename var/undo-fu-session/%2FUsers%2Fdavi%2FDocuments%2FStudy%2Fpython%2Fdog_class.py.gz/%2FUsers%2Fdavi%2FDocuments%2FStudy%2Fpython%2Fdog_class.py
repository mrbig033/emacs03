((buffer-size . 532) (buffer-checksum . "c3cddfbe99a19b013f6ac2e2bde181e0fb7d6021"))
((emacs-pending-undo-list (420 . 449) (t 24234 23366 222650 692000) nil ("restaurant.describe_resturant" . 420) ((marker . 453) . -29) ((marker . 453) . -29) ((marker . 453) . -29) ((marker . 453) . -29) ((marker . 232) . -29) ((marker . 457) . -29) ((marker . 453) . -29) ((marker . 453) . -29) ((marker . 453) . -29) ((marker . 453) . -29) ((marker . 453) . -29) ((marker) . -29) 449 (t 24234 23352 285195 601000) nil (431 . 451) ("de" . -431) ((marker . 457) . -2) 433 (431 . 433) (420 . 431) ("res" . -420) ((marker . 457) . -3) 423 (420 . 423) ("restaurant" . 420) (t 24234 23335 299437 131000) nil (1 . 432) ("#!/usr/bin/env python3


class Restaurant:
    \"\"\"Model of a restaurant.\"\"\"

    def __init__(self, name, cuisine):
        self.name = name.title()
        self.cuisine = cuisine

    def describe_resturant(self):
        print(f\"Name: {self.name}. Cuizine: {self.cuisine}\")

    def open_restaurant(self):
        print(f\"{self.name} is open to business!\")


restaurant = Restaurant(\"bar do careca\", \"baiana\")

print(restaurant)" . 1) ((marker . 278) . -413) ((marker . 311) . -430) ((marker . 309) . -408) ((marker . 1) . -23) ((marker . 232) . -429) ((marker . 457) . -428) ((marker* . 454) . 1) ((marker . 1) . -146) ((marker . 1) . -398) ((marker . 1) . -398) ((marker . 1) . -398) ((marker . 1) . -398) ((marker . 1) . -408) ((marker . 1) . -258) ((marker . 1) . -258) ((marker . 1) . -258) ((marker . 1) . -258) ((marker . 1) . -429) ((marker . 1) . -419) ((marker . 1) . -429) ((marker . 1) . -429) 429 nil (420 . 430) ("res" . -420) ((marker . 457) . -3) 423 (422 . 423) (420 . 422) (apply yas--snippet-revive 414 421 #s(yas--snippet nil nil #s(yas--exit 420 nil) 13 nil nil nil nil)) (apply yas--take-care-of-redo #s(yas--snippet nil nil #s(yas--exit 420 nil) 13 nil nil nil nil)) (414 . 421) ("p" . 414) ((marker . 311) . -1) ((marker . 457) . -1) 415 nil (414 . 415) ("
" . -414) ((marker . 278) . -1) ((marker . 311) . -1) ((marker . 457) . -1) 415 (414 . 415) (413 . 414) 413 nil (259 . 260) (t 24234 23323 761969 735000) nil ("i" . 254) nil ("s" . 254) (t 24234 23319 901064 871000) nil (405 . 411) (404 . 405) ("\"" . -404) (404 . 405) ("\"" . -404) (404 . 406) ("\"" . -404) (404 . 405) (nil fontified nil 402 . 404) (nil face font-lock-string-face 402 . 404) (402 . 404) ("," . -402) 403 (402 . 403) (t 24234 23309 564218 929000) nil (398 . 401) ("a" . -398) ((marker . 457) . -1) 399 (388 . 399) (t 24234 23302 311123 155000) nil (147 . 148) ("(" . -147) (147 . 149) ("(" . -147) (141 . 148) (t 24234 23298 910818 370000) nil (379 . 380) ("\"" . -379) (379 . 380) ("\"" . -379) (379 . 381) ("\"" . -379) (378 . 380) ("(" . -378) (378 . 380) ("(" . -378) (378 . 379) (368 . 378) ("Re" . -368) ((marker . 457) . -2) 370 (365 . 370) ("=" . -365) 366 (358 . 366) ("w" . -358) ((marker . 457) . -1) 359 (355 . 359) ("        " . -355) ((marker . 457) . -8) 363 (355 . 363) ("        " . 354) ((marker . 457) . -8) (354 . 363) ("        " . 353) ((marker . 457) . -8) (361 . 362) (352 . 361) (t 24234 23277 722105 116000) 351 nil (1 . 353) ("#!/usr/bin/env python3


class Restaurant:
    \"\"\"Model of a restaurant.\"\"\"

    def __init__(self, name, cuisine):
        self.name = name
        self.cuisine = cuisine

    def describe_resturant(self):
        print(f\"Name: {self.name}. Cuisizine:{self.cuisine}\")


    def open_restaurant(self):
        print(f\"{self.name} is open to business!\")
" . 1) ((marker . 278) . -302) ((marker . 311) . -353) ((marker . 1) . -353) ((marker . 1) . -353) ((marker . 1) . -353) ((marker . 1) . -353) ((marker . 1) . -353) ((marker . 1) . -353) ((marker . 232) . -353) ((marker . 457) . -351) ((marker* . 454) . 1) ((marker*) . 2) ((marker) . -352) ((marker*) . 38) ((marker) . -316) ("
" . 354) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 232) . -1) 352 nil (" pass" . 353) ((marker* . 454) . 5) ("       " . 353) ((marker* . 454) . 7) ("
" . 353) ((marker . 311) . -1) ((marker* . 454) . 1) (345 . 351) ("s" . -345) ((marker . 457) . -1) ("i" . -346) ((marker . 457) . -1) 347 (334 . 347) ("opern " . -334) ((marker . 457) . -6) 340 ("to " . -340) ((marker . 457) . -3) 343 (330 . 343) (320 . 329) (nil face font-lock-string-face 319 . 320) (nil fontified nil 319 . 320) (319 . 320) ("{" . -319) (320 . 321) (nil fontified nil 319 . 320) (nil face font-lock-string-face 319 . 320) (319 . 320) ("{" . -319) (318 . 320) ("\"" . -318) (318 . 319) ("\"" . -318) (318 . 320) ("\"" . -318) (317 . 319) (apply yas--snippet-revive 311 318 #s(yas--snippet nil nil #s(yas--exit 317 nil) 12 nil nil nil nil)) (apply yas--take-care-of-redo #s(yas--snippet nil nil #s(yas--exit 317 nil) 12 nil nil nil nil)) (311 . 318) ("p" . 311) ((marker . 457) . -1) 312 nil (311 . 312) (apply yas--snippet-revive 276 325 #s(yas--snippet nil (#s(yas--field 1 280 295 nil nil nil t #s(yas--field 2 296 300 nil nil nil t #s(yas--field 3 301 301 nil nil nil nil #s(yas--exit 311 nil)))) #s(yas--field 2 296 300 nil nil nil t #s(yas--field 3 301 301 nil nil nil nil #s(yas--exit 311 nil))) #s(yas--field 3 301 301 nil nil nil nil #s(yas--exit 311 nil))) #s(yas--exit 311 nil) 11 nil #s(yas--field 3 301 301 nil nil nil nil #s(yas--exit 311 nil)) nil nil)) (297 . 300) ("arg" . 297) (296 . 297) (290 . 295) ("r" . -290) ((marker . 457) . -1) ("u" . -291) ((marker . 457) . -1) 292 (281 . 292) ("funcname" . 281) (280 . 281) (apply yas--take-care-of-redo #s(yas--snippet nil (#s(yas--field 1 280 295 nil nil nil t #s(yas--field 2 296 300 nil nil nil t #s(yas--field 3 301 301 nil nil nil nil #s(yas--exit 311 nil)))) #s(yas--field 2 296 300 nil nil nil t #s(yas--field 3 301 301 nil nil nil nil #s(yas--exit 311 nil))) #s(yas--field 3 301 301 nil nil nil nil #s(yas--exit 311 nil))) #s(yas--exit 311 nil) 11 nil #s(yas--field 3 301 301 nil nil nil nil #s(yas--exit 311 nil)) nil nil)) (304 . 308) (295 . 299) (276 . 309) ("def" . 276) ((marker . 457) . -3) 279 nil (276 . 279) ("    " . -276) ((marker . 457) . -4) 280 (272 . 280) ("        " . 271) ((marker . 457) . -8) (271 . 280) ("        " . 270) ((marker . 457) . -8) (278 . 279) (269 . 278) (t 24234 23235 405704 856000) 208 nil (1 . 270) ("#!/usr/bin/env python3


class Restaurant:
    \"\"\"Model of a restaurant.\"\"\"

    def __init__(self, name, cuisine):
        self.name = name
        self.cuisine = cuisine

    def describe_resturant(self):
        print(f\"Name: {self.name}. Cuisizine:{self.cuisine}\")


" . -1) ((marker . 278) . -271) ((marker . 311) . -271) ((marker . 1) . -109) ((marker . 1) . -109) ((marker . 309) . -106) ((marker . 1) . -109) ((marker . 1) . -109) ((marker . 1) . -109) ((marker . 1) . -109) ((marker . 1) . -109) ((marker . 1) . -109) ((marker . 1) . -109) ((marker . 1) . -109) ((marker . 1) . -109) ((marker . 1) . -109) ((marker . 1) . -109) ((marker . 309) . -106) ((marker . 1) . -109) ((marker . 1) . -109) ((marker . 1) . -109) ((marker . 1) . -109) ((marker . 1) . -109) ((marker . 1) . -109) ((marker . 1) . -109) ((marker . 1) . -109) ((marker . 1) . -109) ((marker . 1) . -109) ((marker . 1) . -109) ((marker . 1) . -109) ((marker . 1) . -109) ((marker . 1) . -109) ((marker . 1) . -109) ((marker . 1) . -109) ((marker . 1) . -109) ((marker . 1) . -109) ((marker . 1) . -109) ((marker . 1) . -106) ((marker . 1) . -106) ((marker . 1) . -106) ((marker . 1) . -106) ((marker . 1) . -106) ((marker . 1) . -106) ((marker . 1) . -106) ((marker . 1) . -106) ((marker . 1) . -106) ((marker . 1) . -106) ((marker . 1) . -106) ((marker . 1) . -106) ((marker . 1) . -106) ((marker . 1) . -106) ((marker . 1) . -106) ((marker . 1) . -106) ((marker . 1) . -106) ((marker . 1) . -106) ((marker . 1) . -106) ((marker . 1) . -106) ((marker . 1) . -106) ((marker . 1) . -106) ((marker . 1) . -106) ((marker . 1) . -106) ((marker . 1) . -106) ((marker . 1) . -106) ((marker . 1) . -106) ((marker . 1) . -106) ((marker . 1) . -106) ((marker . 1) . -106) ((marker . 1) . -106) ((marker . 1) . -106) ((marker . 1) . -106) ((marker . 1) . -106) ((marker . 1) . -106) ((marker . 1) . -106) ((marker . 1) . -106) ((marker . 1) . -106) ((marker . 1) . -106) ((marker . 1) . -106) ((marker . 1) . -106) ((marker . 1) . -106) ((marker . 1) . -106) ((marker . 1) . -106) ((marker . 1) . -106) ((marker . 1) . -106) ((marker . 1) . -106) ((marker . 232) . -106) ((marker . 457) . -271) ("        " . -272) ((marker . 311) . -8) ((marker . 457) . -8) 280 (272 . 280) ("        " . 271) ((marker . 311) . -8) ((marker . 457) . -8) (279 . 280) (270 . 279) (t 24234 23228 992964 126000) 270 nil ("        pass
" . 270) ((marker . 311) . -13) ((marker . 457) . -8) 278 (t 24234 22999 258836 806000) nil (110 . 111) (t 24234 22996 727084 879000) nil ("s" . -110) 111 (t 24234 22831 499644 326000) nil ("cuisineM" . 162) (155 . 162) ("cuisineM" . 173) (166 . 173) ("cuisineM" . 268) (261 . 268) ("M" . -114) 115 ("cuisine" . 164) (156 . 164) ("cuisine" . 174) (166 . 174) ("cuisine" . 268) (260 . 268) (114 . 115) ("cuisin" . 162) (155 . 162) ("cuisin" . 171) (164 . 171) ("cuisin" . 264) (257 . 264) (113 . 114) ("cuising" . 160) (154 . 160) ("cuising" . 170) (164 . 170) ("cuising" . 264) (258 . 264) ("g" . -113) 114 ("cuisin" . 162) (155 . 162) ("cuisin" . 171) (164 . 171) ("cuisin" . 264) (257 . 264) (113 . 114) ("cuisi" . 160) (154 . 160) ("cuisi" . 168) (162 . 168) ("cuisi" . 260) (254 . 260) (112 . 113) ("cuis" . 158) (153 . 158) ("cuis" . 165) (160 . 165) ("cuis" . 256) (251 . 256) (111 . 112) ("cui" . 156) (152 . 156) ("cui" . 162) (158 . 162) ("cui" . 252) (248 . 252) (110 . 111) ("cu" . 154) (151 . 154) ("cu" . 159) (156 . 159) ("cu" . 248) (245 . 248) (109 . 110) ("c" . 152) (150 . 152) ("c" . 156) (154 . 156) ("c" . 244) (242 . 244) (108 . 109) ("c" . 150) (149 . 150) ("c" . 154) (153 . 154) ("c" . 242) (241 . 242) (149 . 150) (152 . 153) (239 . 240) (107 . 108) ("d" . 148) ("d" . 152) ("d" . 240) ("d" . 107) ("nd" . 150) (149 . 150) ("nd" . 155) (154 . 155) ("nd" . 244) (243 . 244) ("n" . 107) ("ind" . 152) (150 . 152) ("ind" . 158) (156 . 158) ("ind" . 248) (246 . 248) ("i" . 107) ("wind" . 154) (151 . 154) ("wind" . 161) (158 . 161) ("wind" . 252) (249 . 252) ("w" . -107) 108 ("ind" . 156) (152 . 156) ("ind" . 162) (158 . 162) ("ind" . 252) (248 . 252) (107 . 108) ("kind" . 154) (151 . 154) ("kind" . 161) (158 . 161) ("kind" . 252) (249 . 252) ("k" . 107) (t 24234 22746 792773 935000) nil (244 . 254) ("{" . -244) (244 . 246) ("{" . -244) (244 . 245) (238 . 244) ("i" . -238) ("z" . -239) 240 (237 . 240) (232 . 237) ("," . -232) 233 (232 . 233) (221 . 231) ("{" . -221) (221 . 223) ("{" . -221) (215 . 222) ("\\" . -215) ("N" . -216) 217 (215 . 217) ("R" . -215) ("e" . -216) ("s" . -217) 218 (214 . 218) ("\"" . -214) (214 . 215) ("\"" . -214) (214 . 216) ("\"" . -214) (213 . 215) (apply yas--snippet-revive 207 214 #s(yas--snippet nil nil #s(yas--exit 213 nil) 10 nil nil nil nil)) (apply yas--take-care-of-redo #s(yas--snippet nil nil #s(yas--exit 213 nil) 10 nil nil nil nil)) (207 . 214) ("p" . 207) 208 nil (207 . 208) ("\"\"\"\"\"\"" . 207) (t 24234 22717 635802 676000) nil ("
" . 227) 207 nil (210 . 212) (210 . 211) (nil face font-lock-doc-face 209 . 210) (nil fontified nil 209 . 210) (209 . 210) ("\"" . -209) (209 . 210) ("\"" . -209) (209 . 210) (nil face font-lock-doc-face 208 . 209) (nil fontified nil 208 . 209) (208 . 209) ("\"" . -208) (nil face font-lock-doc-face 208 . 209) (nil fontified nil 208 . 209) (208 . 209) ("\"" . -208) ("\"" . 209) (207 . 209) ("\"" . -207) (207 . 208) ("\"" . -207) (207 . 209) ("\"" . -207) (207 . 208) (apply yas--snippet-revive 169 221 #s(yas--snippet nil (#s(yas--field 1 173 191 nil nil nil t #s(yas--field 2 192 196 nil nil nil t #s(yas--field 3 197 197 nil nil nil nil #s(yas--exit 207 nil)))) #s(yas--field 2 192 196 nil nil nil t #s(yas--field 3 197 197 nil nil nil nil #s(yas--exit 207 nil))) #s(yas--field 3 197 197 nil nil nil nil #s(yas--exit 207 nil))) #s(yas--exit 207 nil) 9 nil #s(yas--field 3 197 197 nil nil nil nil #s(yas--exit 207 nil)) nil nil)) ("," . -196) (" " . -197) ("n" . -198) ("a" . -199) ("m" . -200) ("e" . -201) 202 (", " . -202) 204 (202 . 204) ("," . -202) 203 (196 . 203) ("," . -196) 197 (193 . 197) ("arg" . 193) (192 . 193) (174 . 191) ("funcname" . 174) (173 . 174) (apply yas--take-care-of-redo #s(yas--snippet nil (#s(yas--field 1 173 191 nil nil nil t #s(yas--field 2 192 196 nil nil nil t #s(yas--field 3 197 197 nil nil nil nil #s(yas--exit 207 nil)))) #s(yas--field 2 192 196 nil nil nil t #s(yas--field 3 197 197 nil nil nil nil #s(yas--exit 207 nil))) #s(yas--field 3 197 197 nil nil nil nil #s(yas--exit 207 nil))) #s(yas--exit 207 nil) 9 nil #s(yas--field 3 197 197 nil nil nil nil #s(yas--exit 207 nil)) nil nil)) (197 . 201) (188 . 192) (169 . 202) ("def" . 169) 172 nil (169 . 172) ("    " . -169) 173 (165 . 173) (165 . 166) ("    def funcname(arg):

        pass
" . 165) 189 (t 24234 22649 60041 997000) nil (1 . 202) (apply yas--snippet-revive 1 1 #s(yas--snippet nil (#s(yas--field 1 1 1 nil nil nil nil #s(yas--field 2 1 1 nil nil nil nil #s(yas--field 3 1 1 nil nil nil nil #s(yas--exit 1 nil)))) #s(yas--field 2 1 1 nil nil nil nil #s(yas--field 3 1 1 nil nil nil nil #s(yas--exit 1 nil))) #s(yas--field 3 1 1 nil nil nil nil #s(yas--exit 1 nil))) #s(yas--exit 1 nil) 8 nil #s(yas--field 1 1 1 nil nil nil nil #s(yas--field 2 1 1 nil nil nil nil #s(yas--field 3 1 1 nil nil nil nil #s(yas--exit 1 nil)))) nil nil)) ("#!/usr/bin/env python3


class Restaurant:
    \"\"\"Model of a restaurant.\"\"\"

    def __init__(self, name, kind):
        self.name = name
        self.kind = kind


    def funcname(arg):
        
        pass

    
" . 1) (apply yas--take-care-of-redo #s(yas--snippet nil (#s(yas--field 1 1 1 nil nil nil nil #s(yas--field 2 1 1 nil nil nil nil #s(yas--field 3 1 1 nil nil nil nil #s(yas--exit 1 nil)))) #s(yas--field 2 1 1 nil nil nil nil #s(yas--field 3 1 1 nil nil nil nil #s(yas--exit 1 nil))) #s(yas--field 3 1 1 nil nil nil nil #s(yas--exit 1 nil))) #s(yas--exit 1 nil) 8 nil #s(yas--field 1 1 1 nil nil nil nil #s(yas--field 2 1 1 nil nil nil nil #s(yas--field 3 1 1 nil nil nil nil #s(yas--exit 1 nil)))) nil nil)) (198 . 202) (189 . 193) (170 . 203) ("def" . 170) 173 nil (170 . 173) ("    " . -170) 174 (166 . 174) ("        " . 165) (173 . 174) (164 . 173) 164 nil ("        pass
" . 170) 178 nil ("
" . 170) nil ("def funcname(arg):" . 169) (t 24234 22638 220037 941000) nil (1 . 202) (apply yas--snippet-revive 1 1 #s(yas--snippet nil (#s(yas--field 1 1 1 nil nil nil nil #s(yas--field 2 1 1 nil nil nil nil #s(yas--field 3 1 1 nil nil nil nil #s(yas--exit 1 nil)))) #s(yas--field 2 1 1 nil nil nil nil #s(yas--field 3 1 1 nil nil nil nil #s(yas--exit 1 nil))) #s(yas--field 3 1 1 nil nil nil nil #s(yas--exit 1 nil))) #s(yas--exit 1 nil) 7 nil #s(yas--field 1 1 1 nil nil nil nil #s(yas--field 2 1 1 nil nil nil nil #s(yas--field 3 1 1 nil nil nil nil #s(yas--exit 1 nil)))) nil nil)) ("#!/usr/bin/env python3


class Restaurant:
    \"\"\"Model of a restaurant.\"\"\"

    def __init__(self, name, kind):
        self.name = name
        self.kind = kind


    def funcname(arg):
        
        pass

" . 1) (apply yas--take-care-of-redo #s(yas--snippet nil (#s(yas--field 1 1 1 nil nil nil nil #s(yas--field 2 1 1 nil nil nil nil #s(yas--field 3 1 1 nil nil nil nil #s(yas--exit 1 nil)))) #s(yas--field 2 1 1 nil nil nil nil #s(yas--field 3 1 1 nil nil nil nil #s(yas--exit 1 nil))) #s(yas--field 3 1 1 nil nil nil nil #s(yas--exit 1 nil))) #s(yas--exit 1 nil) 7 nil #s(yas--field 1 1 1 nil nil nil nil #s(yas--field 2 1 1 nil nil nil nil #s(yas--field 3 1 1 nil nil nil nil #s(yas--exit 1 nil)))) nil nil)) (198 . 202) (189 . 193) (170 . 203) ("def" . 170) 173 (t 24234 22631 630163 987000) nil (170 . 173) ("    " . -170) 174 (166 . 174) ("        " . 165) (165 . 174) ("        " . 164) (172 . 173) (163 . 172) (t 24234 22618 73086 523000) 162 nil (1 . 164) ("#!/usr/bin/env python3


class Restaurant:
    \"\"\"Model of a restaurant.\"\"\"

    def __init__(self, name, kind):
        self.name = name
        self.kind = kind" . -1) ("
" . -163) 164 (t 24234 22616 567444 279000) (1 . 164) ("#!/usr/bin/env python3


class Restaurant:
    \"\"\"Model of a restaurant.\"\"\"

    def __init__(self, name, kind):
        self.name = name
        self.kind = kind


        
" . 1) (166 . 174) ("        " . 165) (165 . 174) ("        " . 164) (163 . 173) (t 24234 22607 624465 961000) (1 . 164) ("#!/usr/bin/env python3


class Restaurant:
    \"\"\"Model of a restaurant.\"\"\"

    def __init__(self, name, kind):
        self.name = name
        self.kind = kind" . -1) ("
" . -163) 164 (t 24234 22604 755882 496000) nil ("

pass
" . 164) (t 24234 22601 235186 532000) nil ("
" . 44) (t 24234 22589 537165 69000) nil (1 . 172) ("#!/usr/bin/env python3


class Restaurant:



    \"\"\"Model of a restaurant.\"\"\"

    def __init__(self, name, kind):
        self.name = name
        self.kind = kind


pass
" . 1) 46 nil (43 . 46) 42 (t 24234 22575 327822 336000) nil (1 . 171) ("#!/usr/bin/env python3


class Restaurant:
    \"\"\"Model of a restaurant.\"\"\"
    def __init__(self, name, kind):
        self.name = name
        self.kind = kind


pass
" . 1) 72 nil (72 . 73) (51 . 72) (t 24234 22561 193567 938000) (51 . 53) (51 . 52) (nil face font-lock-doc-face 50 . 51) (nil fontified nil 50 . 51) (50 . 51) ("\"" . -50) (50 . 51) ("\"" . -50) (50 . 51) (nil face font-lock-doc-face 49 . 50) (nil fontified nil 49 . 50) (49 . 50) ("\"" . -49) (nil face font-lock-doc-face 49 . 50) (nil fontified nil 49 . 50) (49 . 50) ("\"" . -49) (t 24234 22559 909388 933000) ("\"" . 50) (49 . 50) (t 24234 22559 909388 933000) (48 . 49) ("\"" . -48) (48 . 49) ("\"" . -48) (48 . 50) ("\"" . -48) (48 . 49) (43 . 48) (t 24234 22549 78480 162000) 26 nil (1 . 137) ("#!/usr/bin/env python3


class Restaurant:

    def __init__(self, name, kind):
        self.name = name
        self.kind = kind


pass
" . 1) 44 nil (43 . 44) 26 (t 24234 22532 133724 645000) nil (1 . 137) ("#!/usr/bin/env python3


class Restaurant:
    def __init__(self, name, kind):
        self.name = name
        self.kind = kind

pass" . 1) 131 nil ("        " . 131) nil (139 . 143) (130 . 139) (t 24234 22528 738863 379000) 130 nil (1 . 130) ("#!/usr/bin/env python3


class Restaurant:
    def __init__(self, name, kind):
        self.name = name
        self.kind = kind

    
" . 1) ("    " . -135) 139 (131 . 139) ("        " . 130) (138 . 139) (129 . 138) (t 24234 22477 425941 566000) 112 nil (" " . 129) nil (129 . 130) (t 24234 22464 796432 396000) nil (73 . 77) ("type" . 73) (t 24234 22460 123132 267000) nil (125 . 129) ("ii" . -125) 127 ("n" . -127) 128 (122 . 128) ("=" . -122) 123 (117 . 123) nil (113 . 117) (104 . 113) (101 . 104) ("m" . -101) 102 (97 . 102) ("=" . -97) 98 (89 . 98) ("l" . -89) 90 (88 . 90) (79 . 88) ("
" . -79) 80 ("        slef." . -80) 93 (88 . 93) (79 . 88) (78 . 79) (71 . 77) ("," . -71) 72 (67 . 72) ("r" . -67) ("e" . -68) ("s" . -69) ("t" . -70) 71 (67 . 71) (65 . 67) ("," . -65) 66 (61 . 66) ("9" . -61) 62 (61 . 62) ("s" . -61) ("e" . -62) 63 (60 . 63) ("(" . -60) (60 . 62) ("(" . -60) (51 . 61) (50 . 51) ("t" . -50) (" " . -51) 52 (48 . 52) (43 . 48) (42 . 43) (27 . 42) ("v" . -27) ("l" . -28) 29 (26 . 29) (25 . 26) ("vlsdd" . -25) 30 ("
" . -25) 26 (26 . 31) (26 . 27) ("class Dog:
    \"\"\"A  simple attempt to model a dof.\"\"\"

    def __init__(self, name, age):
        \"\"\"Initialize name and age.\"\"\"
        self.name = name.title()
        self.age = age

    def sit(self):
        \"\"\"Simulate a dog sitting.\"\"\"
        print(f\"{self.name} is now sitting.\")

    def roll_over(self):
        \"\"\"Simulate a dog rolling over.\"\"\"
        print(f\"{self.name} rolled over!\")


my_dog = Dog(\"Willie\", 6)

print(f\"My dog's name is {my_dog.name} and he's {my_dog.age} years old.\")
" . 26) (t 24234 21914 778028 612000) nil ("sdl
" . 531) 533 (t 24234 21913 779365 430000) nil (1 . 535) ("#!/usr/bin/env python3


class Dog:
    \"\"\"A  simple attempt to model a dof.\"\"\"

    def __init__(self, name, age):
        \"\"\"Initialize name and age.\"\"\"
        self.name = name.title()
        self.age = age

    def sit(self):
        \"\"\"Simulate a dog sitting.\"\"\"
        print(f\"{self.name} is now sitting.\")

    def roll_over(self):
        \"\"\"Simulate a dog rolling over.\"\"\"
        print(f\"{self.name} rolled over!\")


my_dog = Dog(\"Willie\", 6)

print(f\"My dog's name is {my_dog.name} and he's {my_dog.age} years old.\")
sdl" . 1) 533 nil (533 . 534) (531 . 533) (t 24234 21645 463102 102000) nil ("


" . 531) 533 nil (531 . 533) (530 . 531) (t 24234 21638 222901 723000) 517 nil (517 . 530) nil (" years old.\")" . 517) (t 24234 21638 222901 723000) nil ("
" . 531) nil (531 . 532) ("
" . 531) nil ("sdad" . 531) (t 24234 21633 437954 508000) nil (1 . 536) ("#!/usr/bin/env python3


class Dog:
    \"\"\"A  simple attempt to model a dof.\"\"\"

    def __init__(self, name, age):
        \"\"\"Initialize name and age.\"\"\"
        self.name = name.title()
        self.age = age

    def sit(self):
        \"\"\"Simulate a dog sitting.\"\"\"
        print(f\"{self.name} is now sitting.\")

    def roll_over(self):
        \"\"\"Simulate a dog rolling over.\"\"\"
        print(f\"{self.name} rolled over!\")


my_dog = Dog(\"Willie\", 6)

print(f\"My dog's name is {my_dog.name} and he's {my_dog.age} years old.\")
sdad" . 1) 534 nil (531 . 535) (t 24234 21630 792280 720000) nil ("  " . 531) 532 nil (531 . 533) (t 24234 21625 71119 921000) nil ("

" . 531) (" " . 531) 534 nil (533 . 534) (532 . 533) 531 nil (531 . 532) (t 24234 21559 254806 89000) nil ("
print(\"First part\"
      \" second part\")
" . 531) nil (558 . 559) nil (1 . 572) ("#!/usr/bin/env python3


class Dog:
    \"\"\"A  simple attempt to model a dof.\"\"\"

    def __init__(self, name, age):
        \"\"\"Initialize name and age.\"\"\"
        self.name = name.title()
        self.age = age

    def sit(self):
        \"\"\"Simulate a dog sitting.\"\"\"
        print(f\"{self.name} is now sitting.\")

    def roll_over(self):
        \"\"\"Simulate a dog rolling over.\"\"\"
        print(f\"{self.name} rolled over!\")


my_dog = Dog(\"Willie\", 6)

print(f\"My dog's name is {my_dog.name} and he's {my_dog.age} years old.\")

print(\"First part\" \"second part\")
" . 1) (t 24234 21552 483437 187000) nil (1 . 566) ("#!/usr/bin/env python3


class Dog:
    \"\"\"A  simple attempt to model a dof.\"\"\"

    def __init__(self, name, age):
        \"\"\"Initialize name and age.\"\"\"
        self.name = name.title()
        self.age = age

    def sit(self):
        \"\"\"Simulate a dog sitting.\"\"\"
        print(f\"{self.name} is now sitting.\")

    def roll_over(self):
        \"\"\"Simulate a dog rolling over.\"\"\"
        print(f\"{self.name} rolled over!\")


my_dog = Dog(\"Willie\", 6)

print(f\"My dog's name is {my_dog.name} and he's {my_dog.age} years old.\")

print(\"First part\"
      \"second part\")
" . 1) 556 nil (551 . 557) (" " . 550) (551 . 552) (t 24234 21547 122333 783000) nil (1 . 566) ("#!/usr/bin/env python3


class Dog:
    \"\"\"A  simple attempt to model a dof.\"\"\"

    def __init__(self, name, age):
        \"\"\"Initialize name and age.\"\"\"
        self.name = name.title()
        self.age = age

    def sit(self):
        \"\"\"Simulate a dog sitting.\"\"\"
        print(f\"{self.name} is now sitting.\")

    def roll_over(self):
        \"\"\"Simulate a dog rolling over.\"\"\"
        print(f\"{self.name} rolled over!\")


my_dog = Dog(\"Willie\", 6)

print(f\"My dog's name is {my_dog.name} and he's {my_dog.age} years old.\")

print(\"First part\"

\"second part\"
)
" . 1) 551 nil (554 . 564) ("c" . -554) ("e" . -555) 556 (555 . 556) (552 . 555) ("\"" . -552) (552 . 553) ("\"" . -552) (552 . 554) ("\"" . -552) (552 . 553) ("'" . -552) ("'" . 553) (552 . 553) ("'" . -552) (552 . 553) ("'" . -552) (552 . 554) ("'" . -552) (552 . 553) nil (550 . 553) (t 24234 21536 973899 923000) nil (538 . 549) ("\"" . -538) (538 . 539) ("\"" . -538) (538 . 540) ("\"" . -538) (538 . 539) (apply yas--snippet-revive 532 539 #s(yas--snippet nil nil #s(yas--exit 538 nil) 6 nil nil nil nil)) (apply yas--take-care-of-redo #s(yas--snippet nil nil #s(yas--exit 538 nil) 6 nil nil nil nil)) (532 . 539) ("p" . 532) 533 nil (532 . 533) (531 . 532) (530 . 531) (t 24234 21530 655528 498000) 527 nil (527 . 528) nil ("." . 527) nil ("abn" . 500) (500 . 503) ("aaaaaaa asd asd asd a" . 500) ("s das d ds " . 521) nil (1 . 563) ("#!/usr/bin/env python3


class Dog:
    \"\"\"A  simple attempt to model a dof.\"\"\"

    def __init__(self, name, age):
        \"\"\"Initialize name and age.\"\"\"
        self.name = name.title()
        self.age = age

    def sit(self):
        \"\"\"Simulate a dog sitting.\"\"\"
        print(f\"{self.name} is now sitting.\")

    def roll_over(self):
        \"\"\"Simulate a dog rolling over.\"\"\"
        print(f\"{self.name} rolled over!\")


my_dog = Dog(\"Willie\", 6)

print(
    f\"My dog's name is {my_dog.name} and aaaaaaa asd asd asd as das d ds he's {my_dog.age} years old.\"
)
" . 1) nil ("as das dsd as " . 532) nil ("\"" . 512) (" \\" . 513) ("
" . 515) ("   " . 517) ("fQ\"" . 520) (522 . 523) ("\"\"" . 522) (522 . 523) ("\"" . 522) (522 . 523) ("\"\"" . 522) (521 . 525) ("\"" . 521) (521 . 522) ("\"\"" . 521) (521 . 522) ("\"" . 521) (521 . 522) ("\"\"" . 521) (521 . 524) ("\"" . 521) nil (1 . 592) ("#!/usr/bin/env python3


class Dog:
    \"\"\"A  simple attempt to model a dof.\"\"\"

    def __init__(self, name, age):
        \"\"\"Initialize name and age.\"\"\"
        self.name = name.title()
        self.age = age

    def sit(self):
        \"\"\"Simulate a dog sitting.\"\"\"
        print(f\"{self.name} is now sitting.\")

    def roll_over(self):
        \"\"\"Simulate a dog rolling over.\"\"\"
        print(f\"{self.name} rolled over!\")


my_dog = Dog(\"Willie\", 6)

print(
    f\"My dog's name is {my_dog.name} and aaaaaaa\"
    f\"asd asd asd as das as das dsd as d ds he's {my_dog.age} years old.\"
)
" . 1) nil (518 . 519) nil ("f" . 518) (t 24234 21522 799053 307000)) (emacs-buffer-undo-list nil (457 . 459) (t 24234 22368 955165 536000) nil (nil rear-nonsticky nil 530 . 531) (nil fontified nil 1 . 531) (1 . 531) (t . -1)) (emacs-undo-equiv-table (-1 . -3)))