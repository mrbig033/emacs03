((buffer-size . 303) (buffer-checksum . "6fab2eeb1d7dce505cf995006c57f8579fc24907"))
((emacs-pending-undo-list (293 . 301) ("        " . 292) ((marker . 1) . -8) (291 . 301) (287 . 289) (274 . 287) ("\"" . -274) (274 . 275) ("\"" . -274) (274 . 276) ("\"" . -274) (273 . 275) ("(" . -273) (273 . 275) ("(" . -273) (266 . 274) (262 . 266) (254 . 262) (252 . 254) (243 . 252) (t 24246 56446 87902 578000) 212 nil (126 . 127) nil (")" . 126) ((marker*) . 1) ((marker) . -1) (t 24246 56446 87902 578000) nil (212 . 213) ("pygame" . 212) (t 24246 56439 369504 175000) nil (180 . 181) ("pygame" . 180) ((marker . 180) . -6) ((marker . 180) . -6) nil (29 . 31) ("p" . -29) ((marker . 1) . -1) 30 (26 . 30) (t 24246 56433 260107 25000) nil (" as p" . 26) (t 24246 56427 736879 508000) nil (26 . 31) (t 24246 56397 972371 75000) nil ("
        " . 248) ((marker . 1) . -1) ((marker . 1) . -9) ((marker . 243) . -9) ((marker . 243) . -9) (249 . 257) nil ("        " . -249) ((marker . 1) . -8) ((marker) . -1) ((marker) . -4) ((marker) . -5) ((marker . 243) . -8) ((marker . 243) . -8) 257 (248 . 257) (t 24246 56397 972371 75000) 235 nil (247 . 248) (235 . 236) 245 (t 24246 56394 303504 776000) nil (240 . 245) ("," . -240) 241 (238 . 241) (235 . 238) ("(" . -235) ((marker . 230) . -1) (235 . 237) ("(" . -235) ((marker . 230) . -1) ((marker . 230) . -1) (230 . 236) (" " . -230) ((marker . 1) . -1) ((marker . 225) . -1) ((marker) . -1) ((marker . 225) . -1) ((marker . 225) . -1) ((marker . 225) . -1) ((marker . 225) . -1) ("-" . -231) ((marker . 1) . -1) ((marker . 225) . -1) ((marker) . -1) ((marker . 225) . -1) ((marker . 225) . -1) (" " . -232) ((marker . 1) . -1) ((marker . 225) . -1) ((marker) . -1) 233 (230 . 233) ("-" . -230) 231 (227 . 231) (219 . 227) ("di" . -219) ((marker . 1) . -2) ((marker) . -2) ((marker . 214) . -1) ((marker . 214) . -2) ((marker . 214) . -1) 221 (219 . 221) (212 . 219) ("py" . -212) ((marker . 1) . -2) ((marker . 212) . -1) ((marker) . -2) ((marker . 212) . -2) ((marker . 212) . -1) 214 (209 . 214) ("=" . -209) 210 (203 . 210) (apply yas--snippet-revive 198 203 #s(yas--snippet nil nil #s(yas--exit 203 nil) 0 nil nil nil nil)) (apply yas--take-care-of-redo #s(yas--snippet nil nil #s(yas--exit 203 nil) 0 nil nil nil nil)) (198 . 203) ("." . 198) ((marker . 1) . -1) 199 nil (198 . 199) (190 . 198) ("        " . 189) ((marker . 1) . -8) ((marker . 189) . -8) ((marker . 189) . -8) ((marker) . -1) ((marker) . -4) ((marker) . -5) (197 . 198) (188 . 197) (t 24246 56359 791723 360000) 187 nil ("game " . 74) nil (70 . 73) ("to manage" . 70) ((marker . 303) . -8) ((marker . 1) . -8) ((marker . 1) . -8) ((marker . 75) . -8) ((marker . 75) . -8) ((marker . 75) . -3) ((marker . 75) . -3) ((marker) . -9) ((marker) . -8) ((marker . 75) . -1) ((marker . 75) . -8) ((marker . 75) . -1) 78 (t 24246 56351 698602 274000) nil ("game " . 164) ((marker . 158) . -3) ((marker . 158) . -3) nil ("the game and " . 157) ((marker . 303) . -12) ((marker . 1) . -12) ((marker . 1) . -12) ((marker) . -13) ((marker) . -12) ((marker . 151) . -2) ((marker . 151) . -7) ((marker . 151) . -2) ((marker . 151) . -11) ((marker . 151) . -7) ((marker . 151) . -11) ((marker . 151) . -13) ((marker . 151) . -12) ((marker . 151) . -13) 169 (t 24246 56345 358451 592000) nil (211 . 217) ("i" . -211) ((marker . 1) . -1) ((marker) . -1) ((marker . 182) . -1) 212 (210 . 212) ("." . -210) ((marker . 1) . -1) ((marker) . -1) ((marker . 180) . -1) ((marker . 180) . -1) 211 (204 . 211) ("pyg" . -204) ((marker . 1) . -3) ((marker . 180) . -1) ((marker) . -3) ((marker . 180) . -2) ((marker . 180) . -1) ((marker . 180) . -3) ((marker . 180) . -2) 207 (204 . 207) (195 . 204) (171 . 192) (170 . 171) ("gre" . -170) ((marker . 1) . -3) 173 (161 . 173) ("came " . -161) ((marker . 1) . -5) 166 (160 . 166) (" " . -160) ((marker . 1) . -1) 161 (158 . 161) ("r" . -158) ((marker . 1) . -1) ("h" . -159) ((marker . 1) . -1) 160 (147 . 160) (146 . 147) (146 . 148) (146 . 147) (nil face font-lock-doc-face 145 . 146) (nil fontified nil 145 . 146) (145 . 146) ("\"" . -145) (145 . 146) ("\"" . -145) (145 . 146) (nil face font-lock-doc-face 144 . 145) (nil fontified nil 144 . 145) (144 . 145) ("\"" . -144) (nil face font-lock-doc-face 144 . 145) (nil fontified nil 144 . 145) (144 . 145) ("\"" . -144) ("\"" . 145) (143 . 145) ("\"" . -143) (143 . 144) ("\"" . -143) (143 . 145) ("\"" . -143) (143 . 144) (133 . 143) (127 . 132) ("(" . -127) (127 . 129) ("(" . -127) (127 . 128) (119 . 127) ("__ini" . -119) ((marker . 1) . -5) 124 (117 . 124) ("d" . -117) ((marker . 1) . -1) 118 (115 . 118) (111 . 115) ("    " . 110) ((marker . 1) . -4) (109 . 115) (89 . 106) ("s" . -89) ((marker . 1) . -1) 90 (77 . 90) (56 . 77) ("Cover" . -56) ((marker . 1) . -5) 61 (56 . 61) (56 . 58) (56 . 57) (nil face font-lock-doc-face 55 . 56) (nil fontified nil 55 . 56) (55 . 56) ("\"" . -55) (55 . 56) ("\"" . -55) (55 . 56) (nil face font-lock-doc-face 54 . 55) (nil fontified nil 54 . 55) (54 . 55) ("\"" . -54) (nil face font-lock-doc-face 54 . 55) (nil fontified nil 54 . 55) (54 . 55) ("\"" . -54) ("\"" . 55) (53 . 55) ("\"" . -53) (53 . 54) ("\"" . -53) (53 . 55) ("\"" . -53) (53 . 54) (47 . 53) (28 . 47) (27 . 28) (26 . 27) 13 nil (11 . 12) (" " . -11) ((marker . 1) . -1) ((marker . 11) . -1) 12 (9 . 12) ("s" . -9) ((marker . 1) . -1) ((marker . 9) . -1) 10 (1 . 10) (1 . 2) (t 24246 56201 94203 257000) nil ("
" . 16) ((marker . 12) . -1) ((marker . 303) . -1) ((marker . 303) . -1) ((marker . 212) . -1) ((marker . 1) . -1) ((marker* . 301) . 1) nil ("
" . 16) ((marker . 12) . -1) ((marker* . 301) . 1) nil (15 . 16) (14 . 15) (t 24246 55766 694396 187000) 1 nil (14 . 16) (13 . 14) (t 24246 55170 830877 816000) nil (1 . 14) ("import pygam" . -1) 12 (t 24246 55170 367900 430000) nil ("e" . 13) nil ("
" . -14) ("
" . -15) ("i" . -16) ("m" . -17) 18 (16 . 18) (15 . 16) (t 24246 55019 488096 736000) 15 nil ("
\"\"\"
 Pygame base template for opening a window
 
 Sample Python/Pygame Programs
 Simpson College Computer Science
 http://programarcadegames.com/
 http://simpson.edu/computer-science/
 
 Explanation video: http://youtu.be/vRB_983kUMc
\"\"\"

# Define some colors
BLACK = (0, 0, 0)
WHITE = (255, 255, 255)
GREEN = (0, 255, 0)
RED = (255, 0, 0)

pygame.init()

# Set the width and height of the screen [width, height]
size = (700, 500)
screen = pygame.display.set_mode(size)

pygame.display.set_caption(\"My Game\")

# Loop until the user clicks the close button.
done = False

# Used to manage how fast the screen updates
clock = pygame.time.Clock()

# -------- Main Program Loop -----------
while not done:
    # --- Main event loop
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            done = True

    # --- Game logic should go here

    # --- Screen-clearing code goes here

    # Here, we clear the screen to white. Don't put other drawing commands
    # above this, or they will be erased with this command.

    # If you want a background image, replace this clear with blit'ing the
    # background image.
    screen.fill(WHITE)

    # --- Drawing code should go here

    # --- Go ahead and update the screen with what we've drawn.
    pygame.display.flip()

    # --- Limit to 60 frames per second
    clock.tick(60)

# Close the window and quit.
pygame.quit()
" . 15) (t 24246 54712 806329 634000)) (emacs-buffer-undo-list nil ("# " . 1) ("# " . 15) ("# " . 37) ("# " . 60) ("# " . 113) ("# " . 139) ("# " . 184) ("# " . 204) ("# " . 260) (t 24246 56733 305349 861000) nil (260 . 262) (204 . 206) (184 . 186) (139 . 141) (113 . 115) (60 . 62) (37 . 39) (15 . 17) (1 . 3) (t 24246 56722 843307 858000) nil (293 . 301) ("        " . 292) ((marker . 1) . -8) (291 . 301) (287 . 289) (274 . 287) ("\"" . -274) (274 . 275) ("\"" . -274) (274 . 276) ("\"" . -274) (273 . 275) ("(" . -273) (273 . 275) ("(" . -273) (266 . 274) (262 . 266) (254 . 262) (252 . 254) (243 . 252) (t 24246 56446 87902 578000) 212 nil (126 . 127) nil (")" . 126) ((marker*) . 1) ((marker) . -1) (t 24246 56446 87902 578000) nil (212 . 213) ("pygame" . 212) (t 24246 56439 369504 175000) nil (180 . 181) ("pygame" . 180) ((marker . 180) . -6) ((marker . 180) . -6) nil (29 . 31) ("p" . -29) ((marker . 1) . -1) 30 (26 . 30) (t 24246 56433 260107 25000) nil (" as p" . 26) (t 24246 56427 736879 508000) nil (26 . 31) (t 24246 56397 972371 75000) nil ("
        " . 248) ((marker . 1) . -1) ((marker . 1) . -9) ((marker . 243) . -9) ((marker . 243) . -9) (249 . 257) nil ("        " . -249) ((marker . 1) . -8) ((marker) . -1) ((marker) . -4) ((marker) . -5) ((marker . 243) . -8) ((marker . 243) . -8) 257 (248 . 257) (t 24246 56397 972371 75000) 235 nil (247 . 248) (235 . 236) 245 (t 24246 56394 303504 776000) nil (240 . 245) ("," . -240) 241 (238 . 241) (235 . 238) ("(" . -235) ((marker . 230) . -1) (235 . 237) ("(" . -235) ((marker . 230) . -1) ((marker . 230) . -1) (230 . 236) (" " . -230) ((marker . 1) . -1) ((marker . 225) . -1) ((marker) . -1) ((marker . 225) . -1) ((marker . 225) . -1) ((marker . 225) . -1) ((marker . 225) . -1) ("-" . -231) ((marker . 1) . -1) ((marker . 225) . -1) ((marker) . -1) ((marker . 225) . -1) ((marker . 225) . -1) (" " . -232) ((marker . 1) . -1) ((marker . 225) . -1) ((marker) . -1) 233 (230 . 233) ("-" . -230) 231 (227 . 231) (219 . 227) ("di" . -219) ((marker . 1) . -2) ((marker) . -2) ((marker . 214) . -1) ((marker . 214) . -2) ((marker . 214) . -1) 221 (219 . 221) (212 . 219) ("py" . -212) ((marker . 1) . -2) ((marker . 212) . -1) ((marker) . -2) ((marker . 212) . -2) ((marker . 212) . -1) 214 (209 . 214) ("=" . -209) 210 (203 . 210) (apply yas--snippet-revive 198 203 #s(yas--snippet nil nil #s(yas--exit 203 nil) 0 nil nil nil nil)) (apply yas--take-care-of-redo #s(yas--snippet nil nil #s(yas--exit 203 nil) 0 nil nil nil nil)) (198 . 203) ("." . 198) ((marker . 1) . -1) 199 nil (198 . 199) (190 . 198) ("        " . 189) ((marker . 1) . -8) ((marker . 189) . -8) ((marker . 189) . -8) ((marker) . -1) ((marker) . -4) ((marker) . -5) (197 . 198) (188 . 197) (t 24246 56359 791723 360000) 187 nil ("game " . 74) nil (70 . 73) ("to manage" . 70) ((marker . 303) . -8) ((marker . 1) . -8) ((marker . 1) . -8) ((marker . 75) . -8) ((marker . 75) . -8) ((marker . 75) . -3) ((marker . 75) . -3) ((marker) . -9) ((marker) . -8) ((marker . 75) . -1) ((marker . 75) . -8) ((marker . 75) . -1) 78 (t 24246 56351 698602 274000) nil ("game " . 164) ((marker . 158) . -3) ((marker . 158) . -3) nil ("the game and " . 157) ((marker . 303) . -12) ((marker . 1) . -12) ((marker . 1) . -12) ((marker) . -13) ((marker) . -12) ((marker . 151) . -2) ((marker . 151) . -7) ((marker . 151) . -2) ((marker . 151) . -11) ((marker . 151) . -7) ((marker . 151) . -11) ((marker . 151) . -13) ((marker . 151) . -12) ((marker . 151) . -13) 169 (t 24246 56345 358451 592000) nil (211 . 217) ("i" . -211) ((marker . 1) . -1) ((marker) . -1) ((marker . 182) . -1) 212 (210 . 212) ("." . -210) ((marker . 1) . -1) ((marker) . -1) ((marker . 180) . -1) ((marker . 180) . -1) 211 (204 . 211) ("pyg" . -204) ((marker . 1) . -3) ((marker . 180) . -1) ((marker) . -3) ((marker . 180) . -2) ((marker . 180) . -1) ((marker . 180) . -3) ((marker . 180) . -2) 207 (204 . 207) (195 . 204) (171 . 192) (170 . 171) ("gre" . -170) ((marker . 1) . -3) 173 (161 . 173) ("came " . -161) ((marker . 1) . -5) 166 (160 . 166) (" " . -160) ((marker . 1) . -1) 161 (158 . 161) ("r" . -158) ((marker . 1) . -1) ("h" . -159) ((marker . 1) . -1) 160 (147 . 160) (146 . 147) (146 . 148) (146 . 147) (nil face font-lock-doc-face 145 . 146) (nil fontified nil 145 . 146) (145 . 146) ("\"" . -145) (145 . 146) ("\"" . -145) (145 . 146) (nil face font-lock-doc-face 144 . 145) (nil fontified nil 144 . 145) (144 . 145) ("\"" . -144) (nil face font-lock-doc-face 144 . 145) (nil fontified nil 144 . 145) (144 . 145) ("\"" . -144) ("\"" . 145) (143 . 145) ("\"" . -143) (143 . 144) ("\"" . -143) (143 . 145) ("\"" . -143) (143 . 144) (133 . 143) (127 . 132) ("(" . -127) (127 . 129) ("(" . -127) (127 . 128) (119 . 127) ("__ini" . -119) ((marker . 1) . -5) 124 (117 . 124) ("d" . -117) ((marker . 1) . -1) 118 (115 . 118) (111 . 115) ("    " . 110) ((marker . 1) . -4) (109 . 115) (89 . 106) ("s" . -89) ((marker . 1) . -1) 90 (77 . 90) (56 . 77) ("Cover" . -56) ((marker . 1) . -5) 61 (56 . 61) (56 . 58) (56 . 57) (nil face font-lock-doc-face 55 . 56) (nil fontified nil 55 . 56) (55 . 56) ("\"" . -55) (55 . 56) ("\"" . -55) (55 . 56) (nil face font-lock-doc-face 54 . 55) (nil fontified nil 54 . 55) (54 . 55) ("\"" . -54) (nil face font-lock-doc-face 54 . 55) (nil fontified nil 54 . 55) (54 . 55) ("\"" . -54) ("\"" . 55) (53 . 55) ("\"" . -53) (53 . 54) ("\"" . -53) (53 . 55) ("\"" . -53) (53 . 54) (47 . 53) (28 . 47) (27 . 28) (26 . 27) 13 nil (11 . 12) (" " . -11) ((marker . 1) . -1) ((marker . 11) . -1) 12 (9 . 12) ("s" . -9) ((marker . 1) . -1) ((marker . 9) . -1) 10 (1 . 10) (1 . 2) (t 24246 56201 94203 257000) nil ("
" . 16) ((marker . 12) . -1) ((marker . 303) . -1) ((marker . 303) . -1) ((marker . 212) . -1) ((marker . 1) . -1) ((marker* . 301) . 1) nil ("
" . 16) ((marker . 12) . -1) ((marker* . 301) . 1) nil (15 . 16) (14 . 15) (t 24246 55766 694396 187000) 1 nil (14 . 16) (13 . 14) (t 24246 55170 830877 816000) nil (1 . 14) ("import pygam" . -1) 12 (t 24246 55170 367900 430000) nil ("e" . 13) nil ("
" . -14) ("
" . -15) ("i" . -16) ("m" . -17) 18 (16 . 18) (15 . 16) (t 24246 55019 488096 736000) 15 nil ("
\"\"\"
 Pygame base template for opening a window
 
 Sample Python/Pygame Programs
 Simpson College Computer Science
 http://programarcadegames.com/
 http://simpson.edu/computer-science/
 
 Explanation video: http://youtu.be/vRB_983kUMc
\"\"\"

# Define some colors
BLACK = (0, 0, 0)
WHITE = (255, 255, 255)
GREEN = (0, 255, 0)
RED = (255, 0, 0)

pygame.init()

# Set the width and height of the screen [width, height]
size = (700, 500)
screen = pygame.display.set_mode(size)

pygame.display.set_caption(\"My Game\")

# Loop until the user clicks the close button.
done = False

# Used to manage how fast the screen updates
clock = pygame.time.Clock()

# -------- Main Program Loop -----------
while not done:
    # --- Main event loop
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            done = True

    # --- Game logic should go here

    # --- Screen-clearing code goes here

    # Here, we clear the screen to white. Don't put other drawing commands
    # above this, or they will be erased with this command.

    # If you want a background image, replace this clear with blit'ing the
    # background image.
    screen.fill(WHITE)

    # --- Drawing code should go here

    # --- Go ahead and update the screen with what we've drawn.
    pygame.display.flip()

    # --- Limit to 60 frames per second
    clock.tick(60)

# Close the window and quit.
pygame.quit()
" . 15) (t 24246 54712 806329 634000)) (emacs-undo-equiv-table (1 . -1) (-2 . -4) (-7 . -9) (-9 . -11)))