((buffer-size . 15) (buffer-checksum . "bd33694f7c1779eebf1b89aacde7be3160cbc20c"))
((emacs-pending-undo-list) (emacs-buffer-undo-list nil (13 . 15) (t 24246 55170 838845 995000) nil (1 . 14) ("import pygam" . -1) ((marker . 16) . -12) ((marker . 1) . -12) ((marker . 1) . -12) ((marker . 1) . -12) ((marker . 1) . -12) ((marker . 1) . -12) ((marker . 1) . -12) ((marker . 1) . -12) ((marker . 1) . -12) ((marker . 1) . -12) ((marker . 1) . -12) ((marker . 1) . -12) ((marker . 1) . -12) ((marker . 1) . -12) ((marker . 1) . -12) ((marker . 1) . -12) ((marker . 1) . -12) ((marker . 1) . -12) ((marker . 1) . -12) ((marker . 1) . -12) ((marker . 15) . -12) ((marker . 15) . -11) ((marker . 1) . -12) ((marker . 1) . -12) ((marker . 1) . -12) ((marker . 1) . -12) ((marker . 1) . -12) ((marker . 1) . -12) ((marker . 1) . -12) ((marker . 1) . -12) ((marker . 1) . -12) ((marker . 1) . -12) ((marker . 1) . -12) ((marker . 1) . -12) ((marker . 1) . -12) ((marker . 1) . -12) ((marker . 1) . -12) ((marker . 1) . -12) ((marker . 1) . -12) ((marker . 1) . -12) ((marker . 1) . -12) ((marker . 1) . -12) ((marker . 1) . -12) ((marker . 1) . -12) ((marker . 1) . -12) ((marker . 1) . -12) ((marker . 1) . -11) ((marker . 1) . -11) ((marker . 1) . -11) ((marker . 1) . -11) ((marker . 1) . -11) ((marker . 1) . -11) ((marker . 1) . -12) ((marker) . -11) 12 (t 24246 55170 367900 430000) nil ("e" . 13) ((marker . 16) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 15) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) nil ("
" . -14) ((marker . 15) . -1) ((marker . 16) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 15) . -1) ((marker . 15) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ("
" . -15) ((marker . 15) . -1) ((marker . 16) . -1) ((marker . 15) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ("i" . -16) ((marker . 16) . -1) ((marker . 15) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ("m" . -17) ((marker . 16) . -1) ((marker . 15) . -1) ((marker . 1) . -1) 18 (16 . 18) (15 . 16) (t 24246 55019 488096 736000) 15 nil ("
\"\"\"
 Pygame base template for opening a window
 
 Sample Python/Pygame Programs
 Simpson College Computer Science
 http://programarcadegames.com/
 http://simpson.edu/computer-science/
 
 Explanation video: http://youtu.be/vRB_983kUMc
\"\"\"

# Define some colors
BLACK = (0, 0, 0)
WHITE = (255, 255, 255)
GREEN = (0, 255, 0)
RED = (255, 0, 0)

pygame.init()

# Set the width and height of the screen [width, height]
size = (700, 500)
screen = pygame.display.set_mode(size)

pygame.display.set_caption(\"My Game\")

# Loop until the user clicks the close button.
done = False

# Used to manage how fast the screen updates
clock = pygame.time.Clock()

# -------- Main Program Loop -----------
while not done:
    # --- Main event loop
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            done = True

    # --- Game logic should go here

    # --- Screen-clearing code goes here

    # Here, we clear the screen to white. Don't put other drawing commands
    # above this, or they will be erased with this command.

    # If you want a background image, replace this clear with blit'ing the
    # background image.
    screen.fill(WHITE)

    # --- Drawing code should go here

    # --- Go ahead and update the screen with what we've drawn.
    pygame.display.flip()

    # --- Limit to 60 frames per second
    clock.tick(60)

# Close the window and quit.
pygame.quit()
" . 15) (t 24246 54712 806329 634000)) (emacs-undo-equiv-table))