((buffer-size . 290) (buffer-checksum . "7ea53625c240110680bcaef31be455e7404e2856"))
((emacs-pending-undo-list (122 . 130) 150 (140 . 150) (131 . 140) ("come " . -131) ((marker . 288) . -5) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -2) ...) (emacs-buffer-undo-list nil (285 . 289) (t 24227 34406 45273 874000) nil (1 . 287) ("#!/usr/bin/env python3


def show_messages(messages: list) -> str:
    for message in messages:
        print(message)


text = [
    \"Eu tenho sete dedos\",
    \"Mas nem todos eles funcionam\",
    \"Uma vez me apaixonei por uma coxa\",
    \"A buceta era uma coisa...\",
]

show_messages()" . 1) ((marker . 271) . -270) ((marker . 291) . -285) ((marker* . 289) . 1) ...) (emacs-undo-equiv-table (-8 . -10) (-12 . -14) (7 . -1) (8 . -2) (-3 . -5) (-2 . -4)))