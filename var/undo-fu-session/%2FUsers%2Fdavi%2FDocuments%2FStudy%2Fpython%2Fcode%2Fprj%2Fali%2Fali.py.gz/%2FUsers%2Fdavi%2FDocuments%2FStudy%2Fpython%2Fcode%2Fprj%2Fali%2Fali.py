((buffer-size . 716) (buffer-checksum . "2e6d7fd90c05a9057499aaf8f901a7c2477ebf19"))
((emacs-pending-undo-list (618 . 622) (" = =" . -618) ((marker . 618) . -3) ((marker . 618) . -3) ((marker . 618) . -3) 622 (618 . 622) (" = " . 618) ((marker . 618) . -1) ((marker . 618) . -1) ((marker . 618) . -1) ((marker . 618) . -1) 620 (619 . 620) ("=" . 619) (t 24246 57041 458 763000) nil (693 . 703) ("ru" . -693) ((marker . 618) . -2) ((marker) . -2) ((marker . 694) . -1) ((marker . 694) . -2) ((marker . 694) . -1) 695 (690 . 695) (685 . 690) (670 . 685) ("Alien" . -670) ((marker . 618) . -5) 675 (671 . 675) ("i" . -671) ((marker . 618) . -1) ("l" . -672) ((marker . 618) . -1) 673 (667 . 673) ("=" . -667) 668 (665 . 668) (660 . 665) (" " . -660) ((marker . 618) . -1) 661 (650 . 661) (643 . 650) (t 24246 57017 930148 319000) nil (637 . 643) (632 . 637) (nil face font-lock-string-face 631 . 632) (nil fontified t 631 . 632) (631 . 632) 630 (nil fontified nil 622 . 630) (nil face font-lock-string-face 622 . 630) (622 . 630) ("__nam" . -622) ((marker . 618) . -5) ((marker . 623) . -1) ((marker) . -5) ((marker . 623) . -2) ((marker . 623) . -1) ((marker . 623) . -3) ((marker . 623) . -2) ((marker . 623) . -4) ((marker . 623) . -3) ((marker . 623) . -5) ((marker . 623) . -4) 627 (621 . 627) ("\"" . -621) (621 . 622) ("\"" . -621) (621 . 623) ("\"" . -621) (618 . 622) ("=" . -618) 619 (607 . 619) ("        " . -607) ((marker . 618) . -8) 615 ("    " . -615) ((marker . 618) . -4) 619 (607 . 619) ("            " . 606) ((marker . 618) . -12) (606 . 619) ("            " . 605) ((marker . 618) . -12) (617 . 618) (604 . 617) (t 24246 56989 163144 703000) 588 nil ("
" . 605) ((marker . 634) . -1) ((marker* . 622) . 1) (t 24246 56987 172894 375000) nil ("
" . 605) ((marker . 634) . -1) ((marker . 1) . -1) ((marker . 705) . -1) ((marker* . 622) . 1) ((marker . 705) . -1) ((marker . 705) . -1) ((marker . 705) . -1) ((marker . 705) . -1) ((marker . 705) . -1) ((marker . 705) . -1) ((marker . 705) . -1) ((marker . 705) . -1) ((marker . 705) . -1) ((marker . 705) . -1) ((marker . 1) . -1) ((marker . 705) . -1) ((marker . 705) . -1) ((marker . 705) . -1) (t 24246 56984 485435 879000) nil ("p." . 605) ((marker . 618) . -1) ((marker . 705) . -2) ((marker) . -2) ((marker . 705) . -1) ((marker . 705) . -1) nil (apply yas--snippet-revive 605 607 #s(yas--snippet ((yas-indent-line (quote fixed)) (yas-wrap-around-region (quote nil))) nil nil 11 nil nil nil nil)) (apply yas--take-care-of-redo #s(yas--snippet ((yas-indent-line (quote fixed)) (yas-wrap-around-region (quote nil))) nil nil 11 nil nil nil nil)) (605 . 607) nil ("            " . -605) ((marker . 618) . -12) ((marker) . -1) ((marker) . -4) ((marker) . -5) ((marker) . -8) ((marker) . -9) ((marker . 705) . -12) ((marker . 705) . -12) 617 (604 . 617) (t 24246 56952 953391 644000) 588 nil ("p." . 605) ((marker . 618) . -1) nil (apply yas--snippet-revive 605 607 #s(yas--snippet nil nil nil 10 nil nil nil nil)) (apply yas--take-care-of-redo #s(yas--snippet nil nil nil 10 nil nil nil nil)) (605 . 607) nil ("            " . -605) ((marker . 618) . -12) ((marker) . -1) ((marker) . -4) ((marker) . -5) ((marker) . -8) ((marker) . -9) ((marker . 705) . -12) ((marker . 705) . -12) 617 (604 . 617) (t 24246 56904 756037 268000) 588 nil (602 . 603) ("(" . -602) (602 . 604) ("(" . -602) (588 . 603) (575 . 588) ("w" . -575) ((marker . 618) . -1) 576 (574 . 576) (568 . 574) ("vivis" . -568) ((marker . 618) . -5) 573 (556 . 573) ("a" . -556) ((marker . 618) . -1) 557 (544 . 557) (" " . -544) ((marker . 618) . -1) 545 (544 . 545) (534 . 544) ("    " . -534) ((marker . 618) . -4) 538 ("    " . -538) ((marker . 618) . -4) 542 (522 . 542) ("                    " . 521) ((marker . 618) . -20) (520 . 542) (518 . 519) ("(" . -518) (518 . 520) ("(" . -518) (518 . 519) (" " . -518) ((marker . 618) . -1) ("*" . -519) ((marker . 618) . -1) (" " . -520) ((marker . 618) . -1) 521 (518 . 521) ("*" . -518) 519 (511 . 519) ("u" . -511) ((marker . 618) . -1) ("s" . -512) ((marker . 618) . -1) 513 (510 . 513) (488 . 510) (478 . 488) (" = =" . -478) ((marker . 618) . -3) 482 (478 . 482) ("=" . -478) 479 (465 . 479) (447 . 465) 446 (445 . 446) ("(" . -445) (445 . 447) ("(" . -445) (429 . 446) (" " . -429) ((marker . 618) . -1) 430 (421 . 430) ("o" . -421) ((marker . 618) . -1) 422 (421 . 422) (408 . 421) (t 24246 56840 444290 672000) 407 nil (404 . 408) ("k" . -404) ((marker . 618) . -1) 405 (401 . 405) ("k" . -401) ((marker . 618) . -1) 402 (392 . 402) ("keyboard shortcut " . 392) ((marker . 1) . -17) ((marker . 705) . -17) ((marker* . 622) . 18) ((marker . 392) . -17) ((marker . 392) . -17) ((marker . 392) . -17) ((marker . 392) . -17) ((marker . 392) . -17) ((marker . 392) . -17) ((marker . 392) . -17) ((marker . 392) . -17) ((marker . 392) . -17) (t 24246 56814 338439 624000) nil (nil rear-nonsticky nil 409 . 410) (nil fontified nil 392 . 410) (392 . 410) ("k" . -392) ((marker . 618) . -1) ("e" . -393) ((marker . 618) . -1) ("y" . -394) ((marker . 618) . -1) ("s" . -395) ((marker . 618) . -1) (" " . -396) ((marker . 618) . -1) 397 (395 . 397) ("b" . -395) ((marker . 618) . -1) 396 (382 . 396) (380 . 382) (366 . 380) (356 . 366) (347 . 356) (342 . 344) ("o" . -342) ((marker . 618) . -1) 343 (333 . 343) (328 . 333) (328 . 330) (328 . 329) (nil face font-lock-doc-face 327 . 328) (nil fontified nil 327 . 328) (327 . 328) ("\"" . -327) (327 . 328) ("\"" . -327) (327 . 328) (nil face font-lock-doc-face 326 . 327) (nil fontified nil 326 . 327) (326 . 327) ("\"" . -326) (nil face font-lock-doc-face 326 . 327) (nil fontified nil 326 . 327) (326 . 327) ("\"" . -326) ("\"" . 327) (325 . 327) ("\"" . -325) (325 . 326) ("\"" . -325) (325 . 327) ("\"" . -325) (325 . 326) (315 . 325) 314 (309 . 314) ("(" . -309) (309 . 311) ("(" . -309) (297 . 310) ("    " . -297) ((marker . 618) . -4) 301 (293 . 301) ("        " . 292) ((marker . 618) . -8) (300 . 301) (291 . 300) (t 24246 56779 781295 87000) 244 nil (" " . 1) nil ("#" . 1) (t 24246 56773 933244 332000) nil ("# " . -246) ("# " . -192) ("# " . -174) ("# " . -131) ("# " . -107) ("# " . -56) ("# " . -35) ("# " . -15) 14 (t 24246 56768 905512 788000) nil (260 . 262) (204 . 206) (184 . 186) (139 . 141) (113 . 115) (60 . 62) (37 . 39) (15 . 17) (1 . 3) (t 24246 56568 405479 159000) nil (293 . 301) ("        " . 292) (291 . 301) (287 . 289) (274 . 287) ("\"" . -274) (274 . 275) ("\"" . -274) (274 . 276) ("\"" . -274) (273 . 275) ("(" . -273) (273 . 275) ("(" . -273) (266 . 274) (262 . 266) (254 . 262) (252 . 254) (243 . 252) (t 24246 56446 87902 578000) 212 nil (126 . 127) nil (")" . 126) (t 24246 56446 87902 578000) nil (212 . 213) ("pygame" . 212) (t 24246 56439 369504 175000) nil (180 . 181) ("pygame" . 180) nil (29 . 31) ("p" . -29) 30 (26 . 30) (t 24246 56433 260107 25000) nil (" as p" . 26) (t 24246 56427 736879 508000) nil (26 . 31) (t 24246 56397 972371 75000) nil ("
        " . 248) (249 . 257) nil ("        " . -249) 257 (248 . 257) (t 24246 56397 972371 75000) 235 nil (247 . 248) (235 . 236) 245 (t 24246 56394 303504 776000) nil (240 . 245) ("," . -240) 241 (238 . 241) (235 . 238) ("(" . -235) (235 . 237) ("(" . -235) (230 . 236) (" " . -230) ("-" . -231) (" " . -232) 233 (230 . 233) ("-" . -230) 231 (227 . 231) (219 . 227) ("di" . -219) 221 (219 . 221) (212 . 219) ("py" . -212) 214 (209 . 214) ("=" . -209) 210 (203 . 210) (apply yas--snippet-revive 198 203 #s(yas--snippet nil nil #s(yas--exit 203 nil) 0 nil nil nil nil)) (apply yas--take-care-of-redo #s(yas--snippet nil nil #s(yas--exit 203 nil) 0 nil nil nil nil)) (198 . 203) ("." . 198) 199 nil (198 . 199) (190 . 198) ("        " . 189) (197 . 198) (188 . 197) (t 24246 56359 791723 360000) 187 nil ("game " . 74) nil (70 . 73) ("to manage" . 70) 78 (t 24246 56351 698602 274000) nil ("game " . 164) nil ("the game and " . 157) 169 (t 24246 56345 358451 592000) nil (211 . 217) ("i" . -211) 212 (210 . 212) ("." . -210) 211 (204 . 211) ("pyg" . -204) 207 (204 . 207) (195 . 204) (171 . 192) (170 . 171) ("gre" . -170) 173 (161 . 173) ("came " . -161) 166 (160 . 166) (" " . -160) 161 (158 . 161) ("r" . -158) ("h" . -159) 160 (147 . 160) (146 . 147) (146 . 148) (146 . 147) (nil face font-lock-doc-face 145 . 146) (nil fontified nil 145 . 146) (145 . 146) ("\"" . -145) (145 . 146) ("\"" . -145) (145 . 146) (nil face font-lock-doc-face 144 . 145) (nil fontified nil 144 . 145) (144 . 145) ("\"" . -144) (nil face font-lock-doc-face 144 . 145) (nil fontified nil 144 . 145) (144 . 145) ("\"" . -144) ("\"" . 145) (143 . 145) ("\"" . -143) (143 . 144) ("\"" . -143) (143 . 145) ("\"" . -143) (143 . 144) (133 . 143) (127 . 132) ("(" . -127) (127 . 129) ("(" . -127) (127 . 128) (119 . 127) ("__ini" . -119) 124 (117 . 124) ("d" . -117) 118 (115 . 118) (111 . 115) ("    " . 110) (109 . 115) (89 . 106) ("s" . -89) 90 (77 . 90) (56 . 77) ("Cover" . -56) 61 (56 . 61) (56 . 58) (56 . 57) (nil face font-lock-doc-face 55 . 56) (nil fontified nil 55 . 56) (55 . 56) ("\"" . -55) (55 . 56) ("\"" . -55) (55 . 56) (nil face font-lock-doc-face 54 . 55) (nil fontified nil 54 . 55) (54 . 55) ("\"" . -54) (nil face font-lock-doc-face 54 . 55) (nil fontified nil 54 . 55) (54 . 55) ("\"" . -54) ("\"" . 55) (53 . 55) ("\"" . -53) (53 . 54) ("\"" . -53) (53 . 55) ("\"" . -53) (53 . 54) (47 . 53) (28 . 47) (27 . 28) (26 . 27) 13 nil (11 . 12) (" " . -11) 12 (9 . 12) ("s" . -9) 10 (1 . 10) (1 . 2) (t 24246 56201 94203 257000) nil ("
" . 16) nil ("
" . 16) nil (15 . 16) (14 . 15) (t 24246 55766 694396 187000) 1 nil (14 . 16) (13 . 14) (t 24246 55170 830877 816000) nil (1 . 14) ("import pygam" . -1) 12 (t 24246 55170 367900 430000) nil ("e" . 13) nil ("
" . -14) ("
" . -15) ("i" . -16) ("m" . -17) 18 (16 . 18) (15 . 16) (t 24246 55019 488096 736000) 15 nil ("
\"\"\"
 Pygame base template for opening a window
 
 Sample Python/Pygame Programs
 Simpson College Computer Science
 http://programarcadegames.com/
 http://simpson.edu/computer-science/
 
 Explanation video: http://youtu.be/vRB_983kUMc
\"\"\"

# Define some colors
BLACK = (0, 0, 0)
WHITE = (255, 255, 255)
GREEN = (0, 255, 0)
RED = (255, 0, 0)

pygame.init()

# Set the width and height of the screen [width, height]
size = (700, 500)
screen = pygame.display.set_mode(size)

pygame.display.set_caption(\"My Game\")

# Loop until the user clicks the close button.
done = False

# Used to manage how fast the screen updates
clock = pygame.time.Clock()

# -------- Main Program Loop -----------
while not done:
    # --- Main event loop
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            done = True

    # --- Game logic should go here

    # --- Screen-clearing code goes here

    # Here, we clear the screen to white. Don't put other drawing commands
    # above this, or they will be erased with this command.

    # If you want a background image, replace this clear with blit'ing the
    # background image.
    screen.fill(WHITE)

    # --- Drawing code should go here

    # --- Go ahead and update the screen with what we've drawn.
    pygame.display.flip()

    # --- Limit to 60 frames per second
    clock.tick(60)

# Close the window and quit.
pygame.quit()
" . 15) (t 24246 54712 806329 634000)) (emacs-buffer-undo-list nil (618 . 622) (" = =" . 618) ((marker . 618) . -3) ((marker . 618) . -3) (618 . 622) (" = " . 618) ((marker . 618) . -1) ((marker . 618) . -1) ((marker . 618) . -1) ((marker . 618) . -1) ((marker . 618) . -3) ((marker . 618) . -1) (619 . 620) ("=" . 619) (t 24246 57059 508646 463000) nil (619 . 620) ("=" . 619) (618 . 621) (" = =" . 618) ((marker . 618) . -3) ((marker . 618) . -3) (618 . 622) (" == " . 618) ((marker . 622) . -4) ((marker . 621) . -3) ((marker . 621) . -3) ((marker . 621) . -3) ((marker . 621) . -3) ((marker . 621) . -3) (t 24246 57052 627582 524000) nil (618 . 622) (" = =" . -618) ((marker . 618) . -3) ((marker . 618) . -3) ((marker . 618) . -3) 622 (618 . 622) (" = " . 618) ((marker . 618) . -1) ((marker . 618) . -1) ((marker . 618) . -1) ((marker . 618) . -1) 620 (619 . 620) ("=" . 619) (t 24246 57041 458 763000) nil (693 . 703) ("ru" . -693) ((marker . 618) . -2) ((marker) . -2) ((marker . 694) . -1) ((marker . 694) . -2) ((marker . 694) . -1) 695 (690 . 695) (685 . 690) (670 . 685) ("Alien" . -670) ((marker . 618) . -5) 675 (671 . 675) ("i" . -671) ((marker . 618) . -1) ("l" . -672) ((marker . 618) . -1) 673 (667 . 673) ("=" . -667) 668 (665 . 668) (660 . 665) (" " . -660) ((marker . 618) . -1) 661 (650 . 661) (643 . 650) (t 24246 57017 930148 319000) nil (637 . 643) (632 . 637) (nil face font-lock-string-face 631 . 632) (nil fontified t 631 . 632) (631 . 632) 630 (nil fontified nil 622 . 630) (nil face font-lock-string-face 622 . 630) (622 . 630) ("__nam" . -622) ((marker . 618) . -5) ((marker . 623) . -1) ((marker) . -5) ((marker . 623) . -2) ((marker . 623) . -1) ((marker . 623) . -3) ((marker . 623) . -2) ((marker . 623) . -4) ((marker . 623) . -3) ((marker . 623) . -5) ((marker . 623) . -4) 627 (621 . 627) ("\"" . -621) (621 . 622) ("\"" . -621) (621 . 623) ("\"" . -621) (618 . 622) ("=" . -618) 619 (607 . 619) ("        " . -607) ((marker . 618) . -8) 615 ("    " . -615) ((marker . 618) . -4) 619 (607 . 619) ("            " . 606) ((marker . 618) . -12) (606 . 619) ("            " . 605) ((marker . 618) . -12) (617 . 618) (604 . 617) (t 24246 56989 163144 703000) 588 nil ("
" . 605) ((marker . 634) . -1) ((marker* . 622) . 1) (t 24246 56987 172894 375000) nil ("
" . 605) ((marker . 634) . -1) ((marker . 1) . -1) ((marker . 705) . -1) ((marker* . 622) . 1) ((marker . 705) . -1) ((marker . 705) . -1) ((marker . 705) . -1) ((marker . 705) . -1) ((marker . 705) . -1) ((marker . 705) . -1) ((marker . 705) . -1) ((marker . 705) . -1) ((marker . 705) . -1) ((marker . 705) . -1) ((marker . 1) . -1) ((marker . 705) . -1) ((marker . 705) . -1) ((marker . 705) . -1) (t 24246 56984 485435 879000) nil ("p." . 605) ((marker . 618) . -1) ((marker . 705) . -2) ((marker) . -2) ((marker . 705) . -1) ((marker . 705) . -1) nil (apply yas--snippet-revive 605 607 #s(yas--snippet ((yas-indent-line (quote fixed)) (yas-wrap-around-region (quote nil))) nil nil 11 nil nil nil nil)) (apply yas--take-care-of-redo #s(yas--snippet ((yas-indent-line (quote fixed)) (yas-wrap-around-region (quote nil))) nil nil 11 nil nil nil nil)) (605 . 607) nil ("            " . -605) ((marker . 618) . -12) ((marker) . -1) ((marker) . -4) ((marker) . -5) ((marker) . -8) ((marker) . -9) ((marker . 705) . -12) ((marker . 705) . -12) 617 (604 . 617) (t 24246 56952 953391 644000) 588 nil ("p." . 605) ((marker . 618) . -1) nil (apply yas--snippet-revive 605 607 #s(yas--snippet nil nil nil 10 nil nil nil nil)) (apply yas--take-care-of-redo #s(yas--snippet nil nil nil 10 nil nil nil nil)) (605 . 607) nil ("            " . -605) ((marker . 618) . -12) ((marker) . -1) ((marker) . -4) ((marker) . -5) ((marker) . -8) ((marker) . -9) ((marker . 705) . -12) ((marker . 705) . -12) 617 (604 . 617) (t 24246 56904 756037 268000) 588 nil (602 . 603) ("(" . -602) (602 . 604) ("(" . -602) (588 . 603) (575 . 588) ("w" . -575) ((marker . 618) . -1) 576 (574 . 576) (568 . 574) ("vivis" . -568) ((marker . 618) . -5) 573 (556 . 573) ("a" . -556) ((marker . 618) . -1) 557 (544 . 557) (" " . -544) ((marker . 618) . -1) 545 (544 . 545) (534 . 544) ("    " . -534) ((marker . 618) . -4) 538 ("    " . -538) ((marker . 618) . -4) 542 (522 . 542) ("                    " . 521) ((marker . 618) . -20) (520 . 542) (518 . 519) ("(" . -518) (518 . 520) ("(" . -518) (518 . 519) (" " . -518) ((marker . 618) . -1) ("*" . -519) ((marker . 618) . -1) (" " . -520) ((marker . 618) . -1) 521 (518 . 521) ("*" . -518) 519 (511 . 519) ("u" . -511) ((marker . 618) . -1) ("s" . -512) ((marker . 618) . -1) 513 (510 . 513) (488 . 510) (478 . 488) (" = =" . -478) ((marker . 618) . -3) 482 (478 . 482) ("=" . -478) 479 (465 . 479) (447 . 465) 446 (445 . 446) ("(" . -445) (445 . 447) ("(" . -445) (429 . 446) (" " . -429) ((marker . 618) . -1) 430 (421 . 430) ("o" . -421) ((marker . 618) . -1) 422 (421 . 422) (408 . 421) (t 24246 56840 444290 672000) 407 nil (404 . 408) ("k" . -404) ((marker . 618) . -1) 405 (401 . 405) ("k" . -401) ((marker . 618) . -1) 402 (392 . 402) ("keyboard shortcut " . 392) ((marker . 1) . -17) ((marker . 705) . -17) ((marker* . 622) . 18) ((marker . 392) . -17) ((marker . 392) . -17) ((marker . 392) . -17) ((marker . 392) . -17) ((marker . 392) . -17) ((marker . 392) . -17) ((marker . 392) . -17) ((marker . 392) . -17) ((marker . 392) . -17) (t 24246 56814 338439 624000) nil (nil rear-nonsticky nil 409 . 410) (nil fontified nil 392 . 410) (392 . 410) ("k" . -392) ((marker . 618) . -1) ("e" . -393) ((marker . 618) . -1) ("y" . -394) ((marker . 618) . -1) ("s" . -395) ((marker . 618) . -1) (" " . -396) ((marker . 618) . -1) 397 (395 . 397) ("b" . -395) ((marker . 618) . -1) 396 (382 . 396) (380 . 382) (366 . 380) (356 . 366) (347 . 356) (342 . 344) ("o" . -342) ((marker . 618) . -1) 343 (333 . 343) (328 . 333) (328 . 330) (328 . 329) (nil face font-lock-doc-face 327 . 328) (nil fontified nil 327 . 328) (327 . 328) ("\"" . -327) (327 . 328) ("\"" . -327) (327 . 328) (nil face font-lock-doc-face 326 . 327) (nil fontified nil 326 . 327) (326 . 327) ("\"" . -326) (nil face font-lock-doc-face 326 . 327) (nil fontified nil 326 . 327) (326 . 327) ("\"" . -326) ("\"" . 327) (325 . 327) ("\"" . -325) (325 . 326) ("\"" . -325) (325 . 327) ("\"" . -325) (325 . 326) (315 . 325) 314 (309 . 314) ("(" . -309) (309 . 311) ("(" . -309) (297 . 310) ("    " . -297) ((marker . 618) . -4) 301 (293 . 301) ("        " . 292) ((marker . 618) . -8) (300 . 301) (291 . 300) (t 24246 56779 781295 87000) 244 nil (" " . 1) nil ("#" . 1) (t 24246 56773 933244 332000) nil ("# " . -246) ("# " . -192) ("# " . -174) ("# " . -131) ("# " . -107) ("# " . -56) ("# " . -35) ("# " . -15) 14 (t 24246 56768 905512 788000) nil (260 . 262) (204 . 206) (184 . 186) (139 . 141) (113 . 115) (60 . 62) (37 . 39) (15 . 17) (1 . 3) (t 24246 56568 405479 159000) nil (293 . 301) ("        " . 292) (291 . 301) (287 . 289) (274 . 287) ("\"" . -274) (274 . 275) ("\"" . -274) (274 . 276) ("\"" . -274) (273 . 275) ("(" . -273) (273 . 275) ("(" . -273) (266 . 274) (262 . 266) (254 . 262) (252 . 254) (243 . 252) (t 24246 56446 87902 578000) 212 nil (126 . 127) nil (")" . 126) (t 24246 56446 87902 578000) nil (212 . 213) ("pygame" . 212) (t 24246 56439 369504 175000) nil (180 . 181) ("pygame" . 180) nil (29 . 31) ("p" . -29) 30 (26 . 30) (t 24246 56433 260107 25000) nil (" as p" . 26) (t 24246 56427 736879 508000) nil (26 . 31) (t 24246 56397 972371 75000) nil ("
        " . 248) (249 . 257) nil ("        " . -249) 257 (248 . 257) (t 24246 56397 972371 75000) 235 nil (247 . 248) (235 . 236) 245 (t 24246 56394 303504 776000) nil (240 . 245) ("," . -240) 241 (238 . 241) (235 . 238) ("(" . -235) (235 . 237) ("(" . -235) (230 . 236) (" " . -230) ("-" . -231) (" " . -232) 233 (230 . 233) ("-" . -230) 231 (227 . 231) (219 . 227) ("di" . -219) 221 (219 . 221) (212 . 219) ("py" . -212) 214 (209 . 214) ("=" . -209) 210 (203 . 210) (apply yas--snippet-revive 198 203 #s(yas--snippet nil nil #s(yas--exit 203 nil) 0 nil nil nil nil)) (apply yas--take-care-of-redo #s(yas--snippet nil nil #s(yas--exit 203 nil) 0 nil nil nil nil)) (198 . 203) ("." . 198) 199 nil (198 . 199) (190 . 198) ("        " . 189) (197 . 198) (188 . 197) (t 24246 56359 791723 360000) 187 nil ("game " . 74) nil (70 . 73) ("to manage" . 70) 78 (t 24246 56351 698602 274000) nil ("game " . 164) nil ("the game and " . 157) 169 (t 24246 56345 358451 592000) nil (211 . 217) ("i" . -211) 212 (210 . 212) ("." . -210) 211 (204 . 211) ("pyg" . -204) 207 (204 . 207) (195 . 204) (171 . 192) (170 . 171) ("gre" . -170) 173 (161 . 173) ("came " . -161) 166 (160 . 166) (" " . -160) 161 (158 . 161) ("r" . -158) ("h" . -159) 160 (147 . 160) (146 . 147) (146 . 148) (146 . 147) (nil face font-lock-doc-face 145 . 146) (nil fontified nil 145 . 146) (145 . 146) ("\"" . -145) (145 . 146) ("\"" . -145) (145 . 146) (nil face font-lock-doc-face 144 . 145) (nil fontified nil 144 . 145) (144 . 145) ("\"" . -144) (nil face font-lock-doc-face 144 . 145) (nil fontified nil 144 . 145) (144 . 145) ("\"" . -144) ("\"" . 145) (143 . 145) ("\"" . -143) (143 . 144) ("\"" . -143) (143 . 145) ("\"" . -143) (143 . 144) (133 . 143) (127 . 132) ("(" . -127) (127 . 129) ("(" . -127) (127 . 128) (119 . 127) ("__ini" . -119) 124 (117 . 124) ("d" . -117) 118 (115 . 118) (111 . 115) ("    " . 110) (109 . 115) (89 . 106) ("s" . -89) 90 (77 . 90) (56 . 77) ("Cover" . -56) 61 (56 . 61) (56 . 58) (56 . 57) (nil face font-lock-doc-face 55 . 56) (nil fontified nil 55 . 56) (55 . 56) ("\"" . -55) (55 . 56) ("\"" . -55) (55 . 56) (nil face font-lock-doc-face 54 . 55) (nil fontified nil 54 . 55) (54 . 55) ("\"" . -54) (nil face font-lock-doc-face 54 . 55) (nil fontified nil 54 . 55) (54 . 55) ("\"" . -54) ("\"" . 55) (53 . 55) ("\"" . -53) (53 . 54) ("\"" . -53) (53 . 55) ("\"" . -53) (53 . 54) (47 . 53) (28 . 47) (27 . 28) (26 . 27) 13 nil (11 . 12) (" " . -11) 12 (9 . 12) ("s" . -9) 10 (1 . 10) (1 . 2) (t 24246 56201 94203 257000) nil ("
" . 16) nil ("
" . 16) nil (15 . 16) (14 . 15) (t 24246 55766 694396 187000) 1 nil (14 . 16) (13 . 14) (t 24246 55170 830877 816000) nil (1 . 14) ("import pygam" . -1) 12 (t 24246 55170 367900 430000) nil ("e" . 13) nil ("
" . -14) ("
" . -15) ("i" . -16) ("m" . -17) 18 (16 . 18) (15 . 16) (t 24246 55019 488096 736000) 15 nil ("
\"\"\"
 Pygame base template for opening a window
 
 Sample Python/Pygame Programs
 Simpson College Computer Science
 http://programarcadegames.com/
 http://simpson.edu/computer-science/
 
 Explanation video: http://youtu.be/vRB_983kUMc
\"\"\"

# Define some colors
BLACK = (0, 0, 0)
WHITE = (255, 255, 255)
GREEN = (0, 255, 0)
RED = (255, 0, 0)

pygame.init()

# Set the width and height of the screen [width, height]
size = (700, 500)
screen = pygame.display.set_mode(size)

pygame.display.set_caption(\"My Game\")

# Loop until the user clicks the close button.
done = False

# Used to manage how fast the screen updates
clock = pygame.time.Clock()

# -------- Main Program Loop -----------
while not done:
    # --- Main event loop
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            done = True

    # --- Game logic should go here

    # --- Screen-clearing code goes here

    # Here, we clear the screen to white. Don't put other drawing commands
    # above this, or they will be erased with this command.

    # If you want a background image, replace this clear with blit'ing the
    # background image.
    screen.fill(WHITE)

    # --- Drawing code should go here

    # --- Go ahead and update the screen with what we've drawn.
    pygame.display.flip()

    # --- Limit to 60 frames per second
    clock.tick(60)

# Close the window and quit.
pygame.quit()
" . 15) (t 24246 54712 806329 634000)) (emacs-undo-equiv-table (-9 . -11) (-6 . -8) (2 . -2) (1 . -1)))