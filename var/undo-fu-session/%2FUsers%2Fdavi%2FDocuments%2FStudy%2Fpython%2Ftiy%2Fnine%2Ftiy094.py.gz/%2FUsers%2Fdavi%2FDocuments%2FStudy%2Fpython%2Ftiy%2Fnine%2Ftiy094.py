((buffer-size . 851) (buffer-checksum . "f2b739c3f0d206222db321a3f29433aec3a594c5"))
((emacs-pending-undo-list (215 . 225) ("\"" . -215) (215 . 216) ("\"" . -215) ((marker) . -1) (215 . 217) ("\"" . -215) ((marker) . -1) ((marker) . -1) (215 . 216) (apply yas--snippet-revive 209 216 #s(yas--snippet nil nil #s(yas--exit 215 nil) 32 nil nil nil nil)) (apply yas--take-care-of-redo #s(yas--snippet nil nil #s(yas--exit 215 nil) 32 nil nil nil nil)) (209 . 216) ("p" . 209) ((marker) . -1) ((marker) . -1) ((marker) . -1) 210 nil (209 . 210) (200 . 209) (t 24234 25170 246273 890000) 180 nil (140 . 147) ("t" . -140) ((marker) . -1) ((marker) . -1) ((marker) . -1) ((marker) . -1) ((marker) . -1) 141 (140 . 141) (";" . -140) ((marker) . -1) 141 (139 . 141) nil (107 . 114) (106 . 107) nil (344 . 345) ("i" . 344) ((marker) . -1) nil (346 . 361) ("des" . -346) ((marker) . -3) ((marker) . -2) ((marker) . -3) ((marker) . -2) ((marker) . -3) ((marker) . -3) ((marker) . -3) ((marker) . -3) ((marker) . -3) 349 (343 . 349) (342 . 343) ("print(u1.first)" . 342) ((marker) . -13) ((marker) . -13) ((marker*) . 1) ((marker) . -7) ((marker) . -7) ((marker) . -7) ((marker) . -7) ((marker) . -7) ((marker) . -7) ((marker) . -7) ((marker) . -7) ((marker) . -10) ((marker) . -10) ((marker) . -10) ((marker) . -10) ((marker) . -10) ((marker) . -10) ((marker) . -10) ((marker) . -10) ((marker) . -10) ((marker) . -10) ((marker) . -10) ((marker) . -10) ((marker) . -10) ((marker) . -10) ((marker) . -10) ((marker) . -10) ((marker) . -11) ((marker) . -10) ((marker) . -11) ((marker) . -11) ((marker) . -11) ((marker) . -11) ((marker) . -12) ((marker) . -11) ((marker) . -12) ((marker) . -13) ((marker) . -12) ((marker) . -13) ((marker) . -14) ((marker) . -13) ((marker) . -14) ((marker) . -7) ((marker) . -14) ((marker) . -14) ((marker) . -14) ((marker) . -14) ((marker) . -14) ((marker) . -14) ((marker) . -14) ((marker) . -14) ((marker) . -14) ((marker) . -13) ((marker) . -13) ((marker) . -13) ((marker) . -13) ((marker) . -13) ((marker) . -13) ((marker) . -14) ((marker) . -13) ((marker) . -13) ((marker) . -13) ((marker) . -13) ((marker) . -13) ((marker) . -13) ((marker) . -13) ((marker) . -13) ((marker) . -13) ((marker) . -13) ((marker) . -13) ((marker) . -13) ((marker) . -13) ((marker) . -13) ((marker) . -13) ((marker) . -13) ((marker) . -13) ((marker) . -13) ((marker) . -13) ((marker) . -13) ((marker) . -13) ((marker) . -13) ((marker) . -13) ((marker) . -13) ((marker) . -13) ((marker) . -13) ((marker) . -13) ((marker) . -13) ((marker) . -13) ((marker) . -13) ((marker) . -13) ((marker) . -13) ((marker) . -13) (t 24234 25140 73811 767000) nil (352 . 356) ("u" . -352) ((marker) . -1) ((marker) . -1) ((marker) . -1) ((marker) . -1) ((marker) . -1) ((marker) . -1) ((marker) . -1) ((marker) . -1) ((marker) . -1) ((marker) . -1) ((marker) . -1) ((marker) . -1) ((marker) . -1) ((marker) . -1) ("r" . -353) ((marker) . -1) ((marker) . -1) ((marker) . -1) ((marker) . -1) ((marker) . -1) ((marker) . -1) ((marker) . -1) ((marker) . -1) ((marker) . -1) ((marker) . -1) ((marker) . -1) ("s" . -354) ((marker) . -1) ((marker) . -1) ((marker) . -1) ((marker) . -1) ((marker) . -1) ((marker) . -1) ((marker) . -1) ((marker) . -1) ("t" . -355) ((marker) . -1) ((marker) . -1) ((marker) . -1) 356 (350 . 356) nil (349 . 350) ("i" . -349) ((marker) . -1) ((marker) . -1) ((marker) . -1) 350 (348 . 350) (apply yas--snippet-revive 342 349 #s(yas--snippet nil nil #s(yas--exit 348 nil) 31 nil nil nil nil)) (apply yas--take-care-of-redo #s(yas--snippet nil nil #s(yas--exit 348 nil) 31 nil nil nil nil)) (342 . 349) ("p" . 342) ((marker) . -1) ((marker) . -1) ((marker) . -1) 343 nil (342 . 343) (341 . 342) 340 nil (", 1" . 340) ((marker) . -2) ((marker) . -2) ((marker) . -1) ((marker) . -2) ((marker) . -1) ((marker) . -1) ((marker) . -3) ((marker) . -3) ((marker) . -3) (t 24234 25110 674798 19000) nil ("ag" . 148) (145 . 148) ("ag" . 153) (150 . 153) ("ag" . 303) (300 . 303) (76 . 77) ("a" . 146) (144 . 146) ("a" . 150) (148 . 150) ("a" . 299) (297 . 299) (75 . 76) ("a" . 144) (143 . 144) ("a" . 148) (147 . 148) ("a" . 297) (296 . 297) (143 . 144) (146 . 147) (294 . 295) (74 . 75) ("_year" . 142) ("_year" . 150) ("_year" . 303) ("_year" . 74) ("birth_year" . 152) (147 . 152) ("birth_year" . 165) (160 . 165) ("birth_year" . 323) (318 . 323) ("birth" . 74) (t 24234 25079 926040 455000) nil (318 . 323) (t 24234 25073 880241 48000) nil ("
" . 25) nil ("from datetime import datetime
" . 25) (t 24234 25070 629271 269000) nil ("        " . 86) ("
" . -86) 85 nil ("    " . 124) ("
" . -124) 123 nil (", current_year=datetime.now().year" . 124) nil ("        self.age = current_year - birth_year
" . 255) 263 nil ("        self.current_year = current_year
" . 255) 287 (t 24234 25061 635144 946000) nil (124 . 158) nil (124 . 125) (124 . 128) nil (86 . 87) (86 . 94) (t 24234 25060 95638 640000) nil ("# " . 215) ("# " . 258) nil ("# " . 25) nil ("# " . 457) nil ("self." . 441) nil (25 . 26) nil (25 . 26) (t 24234 25058 7718 453000) nil (" " . 25) nil ("#" . 25) (t 24234 24990 246384 613000) nil (" c" . 441) (t 24234 24989 215148 913000) nil (441 . 443) (t 24234 24970 212121 292000) nil (441 . 446) (t 24234 24959 203418 582000) nil (457 . 459) (t 24234 24939 756198 279000) nil (25 . 27) 33 (t 24234 24933 933368 205000) nil (258 . 260) (215 . 217) 256 (t 24234 24921 595764 591000) nil ("        " . 86) ("
" . -86) 85 nil ("    " . 124) ("
" . -124) 123 nil (", current_year=datetime.now().year" . 124) 157 (t 24234 24893 285887 450000)) (emacs-buffer-undo-list nil (644 . 648) (" + =" . -644) ((marker . 647) . -3) ((marker . 644) . -3) ((marker . 644) . -3) 648 (644 . 648) (" +" . -644) ((marker . 647) . -1) ((marker . 644) . -1) ((marker . 644) . -1) ((marker . 644) . -1) ((marker . 644) . -1) ((marker . 644) . -1) ((marker . 644) . -1) ((marker . 644) . -1) ((marker . 644) . -1) ((marker . 644) . -1) ((marker . 644) . -1) ((marker . 644) . -1) ((marker . 644) . -1) ((marker . 644) . -1) 646 (645 . 646) ("=" . -645) ((marker . 647) . -1) ((marker . 644) . -1) ((marker . 644) . -1) ((marker . 644) . -1) ((marker . 644) . -1) ((marker . 644) . -1) ((marker . 644) . -1) ((marker . 644) . -1) ((marker . 644) . -1) ((marker . 644) . -1) ((marker . 644) . -1) (" " . -646) ((marker . 647) . -1) ((marker . 644) . -1) ((marker . 644) . -1) ((marker . 644) . -1) ((marker . 644) . -1) ((marker . 644) . -1) ((marker . 644) . -1) ((marker . 644) . -1) ("+" . -647) ((marker . 647) . -1) ((marker . 644) . -1) ((marker . 644) . -1) ((marker . 644) . -1) ((marker . 644) . -1) (" " . -648) ((marker . 647) . -1) ((marker . 644) . -1) 649 (646 . 649) ("+" . -646) 647 (646 . 647) ("=" . -646) ((marker . 647) . -1) (" " . -647) ((marker . 647) . -1) 648 (644 . 648) (" == " . 644) ((marker . 644) . -2) ((marker . 644) . -2) ((marker . 647) . -2) ((marker . 644) . -2) ((marker . 644) . -2) ((marker . 644) . -2) ((marker . 644) . -2) ((marker . 644) . -2) ((marker . 644) . -2) ((marker . 644) . -1) ((marker . 644) . -1) ((marker . 644) . -1) 647 (646 . 647) nil ("+" . 645) ((marker . 644) . -1) ((marker . 644) . -1) ((marker . 644) . -1) (t 24235 37535 913351 659000) nil (644 . 648) (" += " . 644) ((marker . 644) . -4) ((marker . 644) . -4) ((marker . 644) . -4) ((marker . 644) . -4) ((marker . 644) . -4) ((marker . 644) . -4) ((marker . 644) . -4) ((marker . 644) . -4) ((marker . 647) . -2) ((marker . 644) . -1) ((marker . 644) . -1) ((marker . 644) . -2) ((marker . 644) . -1) ((marker . 644) . -2) 647 (646 . 647) nil ("self.number_served = " . 626) ((marker . 644) . -20) ((marker . 626) . -20) ((marker . 647) . -20) ((marker . 626) . -4) ((marker . 626) . -4) ((marker . 626) . -5) ((marker . 626) . -4) ((marker . 626) . -5) ((marker . 626) . -11) ((marker . 626) . -5) ((marker . 626) . -11) ((marker . 626) . -12) ((marker . 626) . -11) ((marker . 626) . -12) ((marker . 626) . -19) ((marker . 626) . -12) ((marker . 626) . -19) ((marker . 626) . -21) ((marker . 626) . -19) ((marker . 626) . -21) ((marker . 626) . -19) ((marker . 626) . -21) ((marker . 626) . -19) ((marker . 626) . -19) ((marker . 626) . -19) ((marker . 626) . -19) ((marker . 626) . -19) ((marker) . -21) ((marker) . -20) ((marker . 626) . -3) ((marker . 626) . -3) ((marker . 626) . -4) ((marker . 626) . -3) ((marker . 626) . -4) ((marker . 626) . -10) ((marker . 626) . -4) ((marker . 626) . -10) ((marker . 626) . -11) ((marker . 626) . -10) ((marker . 626) . -11) ((marker . 626) . -17) ((marker . 626) . -11) ((marker . 626) . -17) ((marker . 626) . -19) ((marker . 626) . -17) ((marker . 626) . -19) ((marker . 626) . -20) ((marker . 626) . -19) ((marker . 626) . -20) 646 (t 24235 37514 233831 945000) nil ("# r1.describe_restaurant()

# r1.number_served = 12000
# r1.describe_restaurant()
" . 723) ((marker . 618) . -55) ((marker . 658) . -82) ((marker . 644) . -75) ((marker . 626) . -20) ((marker . 626) . -75) ((marker . 703) . -28) ((marker . 703) . -28) ((marker . 703) . -28) ((marker . 703) . -28) ((marker . 703) . -28) ((marker . 703) . -28) ((marker . 647) . -75) ((marker . 703) . -82) ((marker . 703) . -82) ((marker . 703) . -75) ((marker . 703) . -82) ((marker . 703) . -75) ((marker . 703) . -48) ((marker . 703) . -75) ((marker . 703) . -48) ((marker . 703) . -27) ((marker . 703) . -48) ((marker . 703) . -27) ((marker . 703) . -20) ((marker . 703) . -27) ((marker . 703) . -20) ((marker . 703) . -20) ((marker . 703) . -20) ((marker . 703) . -20) ((marker) . -82) ((marker . 703) . -20) ((marker . 703) . -20) ((marker) . -20) ((marker) . -75) ((marker . 703) . -20) ((marker . 703) . -27) ((marker . 703) . -20) ((marker . 703) . -27) ((marker . 703) . -48) ((marker . 703) . -27) ((marker . 703) . -48) ((marker . 703) . -75) ((marker . 703) . -48) ((marker . 703) . -75) 798 (t 24235 37506 893793 378000) nil ("-" . 926) ((marker . 824) . -1) ((marker . 824) . -1) ((marker . 824) . -1) ((marker . 824) . -1) ((marker . 824) . -1) ((marker . 824) . -1) nil (877 . 878) ("5" . 877) (t 24235 37277 923322 513000) nil (" " . 927) nil (" " . 926) nil (926 . 929) ("-" . -926) 927 (926 . 927) ("_" . 926) nil (926 . 928) ("5" . 926) nil (nil rear-nonsticky nil 905 . 906) ("
" . -953) (905 . 954) nil (904 . 905) 903 (t 24235 37267 758111 600000) nil ("
" . 857) ((marker . 658) . -1) nil ("print()
" . 857) ((marker . 658) . -8) ((marker . 755) . -8) (t 24235 37265 12160 35000) nil ("
" . 751) ((marker . 658) . -1) nil ("# print()
" . 751) ((marker . 658) . -10) ((marker . 703) . -10) ((marker . 703) . -10) ((marker . 703) . -10) ((marker . 703) . -10) nil ("
" . 817) ((marker . 658) . -1) nil ("# print()
" . 817) ((marker . 658) . -10) (t 24235 37260 2823 67000) nil (383 . 385) (t 24235 37253 180788 812000) nil (nil rear-nonsticky nil 908 . 909) ("
" . -933) (908 . 934) 891 nil (apply yas--snippet-revive 877 884 #s(yas--snippet nil nil #s(yas--exit 883 nil) 6 nil nil nil nil)) (apply yas--take-care-of-redo #s(yas--snippet nil nil #s(yas--exit 883 nil) 6 nil nil nil nil)) (877 . 884) ("p" . 877) ((marker . 647) . -1) 878 nil (877 . 878) (876 . 877) (875 . 876) (t 24235 37244 181412 817000) 871 nil (897 . 898) nil (848 . 849) ("2" . 848) (t 24235 37235 773155 471000) nil ("# " . 877) (t 24235 37233 46279 63000) nil (877 . 879) 897 (t 24235 37229 288956 615000) nil (847 . 849) ("24000" . 847) ((marker . 725) . -4) ((marker . 725) . -4) ((marker . 725) . -4) ((marker . 725) . -1) ((marker . 725) . -1) ((marker . 725) . -2) ((marker . 725) . -1) ((marker . 725) . -2) ((marker . 725) . -1) ((marker . 725) . -2) ((marker . 725) . -1) ((marker . 725) . -1) (t 24235 37215 619182 489000) nil (598 . 604) (t 24235 37213 163232 316000) nil ("self, " . 598) (t 24235 37207 59002 816000) nil ("r" . 641) (t 24235 37196 646639 439000) nil (667 . 676) ("in" . -667) ((marker . 647) . -2) ((marker . 644) . -1) ((marker . 644) . -1) ((marker . 644) . -2) ((marker . 644) . -1) ((marker) . -2) ((marker . 644) . -2) ((marker . 644) . -2) ((marker . 644) . -2) ((marker) . -2) ((marker . 644) . -2) 669 (664 . 669) (" + " . -664) ((marker . 647) . -2) ((marker . 644) . -2) ((marker . 644) . -2) ((marker . 644) . -2) ((marker . 644) . -2) ((marker . 644) . -2) ((marker . 644) . -2) ((marker . 644) . -2) ((marker . 644) . -2) 667 (666 . 667) (" " . -666) ((marker . 647) . -1) ((marker . 644) . -1) ((marker . 644) . -1) ((marker . 644) . -1) ((marker . 644) . -1) ((marker . 644) . -1) ("1" . -667) ((marker . 647) . -1) ((marker . 644) . -1) ((marker . 644) . -1) 668 (t 24235 37190 973781 503000) nil (1 . 895) ("#!/usr/bin/env python3


class Restaurant:
    \"\"\"Model of a restaurant.\"\"\"

    def __init__(self, name, cuisine):
        self.name = name.title()
        self.cuisine = cuisine.title()
        self.number_served = 0

    def describe_restaurant(self):
        print(
            f\"Name: {self.name}.\\nCuizine: {self.cuisine}.\"
            f\"\\nClients served: {self.number_served}\"
        )

    def open_restaurant(self):
        print(f\"{self.name} is open to business!\")

    def set_number_served(self, num_of_clients):
        self.number_served = num_of_clients

    def increment_served(self, increment):
        self.number_serverd = self.number_served + 1


r1 = Restaurant(\"bar do careca\", \"baiana\")
# r1.describe_restaurant()

# print()

# r1.number_served = 12000
# r1.describe_restaurant()

# print()

r1.set_number_served(24000)
r1.describe_restaurant()

r1.increment_served()" . 1) ((marker . 618) . -615) ((marker . 658) . -668) ((marker . 644) . -634) ((marker* . 648) . 250) ((marker . 626) . -634) ((marker* . 626) . 250) ((marker . 626) . -634) ((marker . 626) . -634) ((marker . 644) . -188) ((marker . 647) . -642) ((marker . 1) . -219) ((marker . 1) . -219) ((marker) . -527) ((marker) . -528) ((marker) . -531) ((marker) . -532) ((marker) . -478) ((marker) . -479) ((marker) . -426) ((marker) . -427) ((marker) . -430) ((marker) . -431) ((marker) . -395) ((marker) . -396) ((marker) . -384) ((marker) . -385) ((marker) . -388) ((marker) . -389) ((marker) . -330) ((marker) . -331) ((marker) . -334) ((marker) . -335) ((marker) . -338) ((marker) . -339) ((marker) . -270) ((marker) . -271) ((marker) . -274) ((marker) . -275) ((marker) . -278) ((marker) . -279) ((marker) . -255) ((marker) . -256) ((marker) . -259) ((marker) . -260) ((marker) . -220) ((marker) . -221) ((marker) . -188) ((marker) . -189) ((marker) . -192) ((marker) . -193) ((marker) . -149) ((marker) . -150) ((marker) . -153) ((marker) . -154) ((marker) . -116) ((marker) . -117) ((marker) . -120) ((marker) . -121) ((marker) . -77) ((marker) . -78) ((marker) . -43) ((marker) . -44) ((marker) . -220) ((marker) . -221) ((marker . 1) . -188) ((marker . 1) . -188) ((marker . 1) . -188) ((marker . 1) . -188) ((marker . 1) . -188) ((marker . 1) . -188) ((marker . 1) . -188) ((marker . 1) . -482) ((marker . 1) . -482) ((marker . 1) . -482) ((marker . 1) . -875) ((marker . 1) . -875) ((marker . 1) . -875) ((marker . 1) . -875) ((marker . 1) . -875) ((marker . 1) . -634) ((marker . 1) . -634) ((marker . 1) . -634) ((marker . 1) . -634) ((marker . 1) . -634) ((marker . 1) . -634) ((marker) . -572) ((marker) . -573) ((marker) . -623) ((marker) . -627) ((marker) . -892) ((marker) . -893) ((marker . 1) . -634) ((marker . 1) . -634) ((marker . 1) . -634) ((marker . 1) . -634) ((marker . 1) . -634) ((marker . 1) . -634) ((marker . 1) . -634) ((marker . 1) . -634) ((marker . 1) . -634) ((marker . 1) . -634) ((marker . 1) . -634) ((marker . 1) . -634) ((marker . 1) . -634) ((marker . 1) . -634) ((marker . 1) . -634) ((marker . 1) . -635) ((marker . 1) . -634) ((marker . 1) . -635) ((marker . 1) . -635) ((marker . 1) . -635) ((marker . 1) . -635) ((marker . 1) . -636) ((marker . 1) . -635) ((marker . 1) . -636) ((marker . 1) . -637) ((marker . 1) . -636) ((marker . 1) . -637) ((marker . 1) . -638) ((marker . 1) . -637) ((marker . 1) . -638) ((marker . 1) . -639) ((marker . 1) . -638) ((marker . 1) . -639) ((marker . 1) . -640) ((marker . 1) . -639) ((marker . 1) . -640) ((marker . 1) . -641) ((marker . 1) . -640) ((marker . 1) . -641) ((marker . 1) . -642) ((marker . 1) . -641) ((marker . 1) . -642) ((marker) . -615) ((marker) . -616) ((marker) . -619) ((marker) . -620) ((marker . 1) . -643) ((marker . 1) . -642) ((marker . 1) . -670) ((marker . 1) . -670) ((marker . 1) . -675) ((marker . 1) . -670) ((marker . 1) . -670) ((marker . 1) . -675) ((marker . 1) . -643) ((marker . 1) . -642) ((marker . 1) . -642) ((marker . 1) . -642) 643 nil (635 . 644) (" " . -635) ((marker . 647) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ("-" . -636) ((marker . 647) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) (" " . -637) ((marker . 647) . -1) ((marker . 1) . -1) 638 (635 . 638) ("- " . 635) ((marker* . 626) . 1) 636 (635 . 636) (" - served" . 635) ((marker . 644) . -8) ((marker . 626) . -8) ((marker . 647) . -8) ((marker . 1) . -3) ((marker . 1) . -3) ((marker . 1) . -2) ((marker . 1) . -2) ((marker . 1) . -2) ((marker . 1) . -2) ((marker) . -9) ((marker) . -8) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -8) ((marker . 1) . -1) ((marker . 1) . -8) 643 (t 24235 37183 199585 29000) nil (602 . 613) ("," . -602) 603 (602 . 603) nil (624 . 627) ("-" . -624) 625 (624 . 625) nil (863 . 881) ("in" . -863) ((marker . 658) . -2) ((marker . 647) . -2) ((marker) . -2) ((marker . 1) . -1) ((marker . 1) . -1) ((marker) . -2) ((marker . 1) . -2) ((marker . 1) . -1) ((marker) . -2) ((marker) . -1) ((marker) . -2) ((marker . 1) . -2) 865 (860 . 865) (859 . 860) (t 24235 37154 858504 951000) 859 nil (" " . 220) ((marker . 1) . -1) ((marker . 1) . -1) (1 . 860) ("#!/usr/bin/env python3


class Restaurant:
    \"\"\"Model of a restaurant.\"\"\"

    def __init__(self, name, cuisine):
        self.name = name.title()
        self.cuisine = cuisine.title()
        self.number_served = 0

    def describe_restaurant(self):
        print(
            f\"Name: {self.name}.\\nCuizine: {self.cuisine}.\"
            f\"\\nClients served: {self.number_served}\"
        )

    def open_restaurant(self):
        print(f\"{self.name} is open to business!\")

    def set_number_served(self, num_of_clients):
        self.number_served = num_of_clients

    def increment_served(self):
        self.numberserved = self.number_served + 1


r1 = Restaurant(\"bar do careca\", \"baiana\")
# r1.describe_restaurant()

# print()

# r1.number_served = 12000
# r1.describe_restaurant()

# print()

r1.set_number_served(24000)
r1.describe_restaurant()
" . 1) ((marker . 647) . -219) (t 24235 37154 444803 655000) (1 . 859) ("#!/usr/bin/env python3


class Restaurant:
    \"\"\"Model of a restaurant.\"\"\"

    def __init__(self, name, cuisine):
        self.name = name.title()
        self.cuisine = cuisine.title()
        self.number_served = 0
 
    def describe_restaurant(self):
        print(
            f\"Name: {self.name}.\\nCuizine: {self.cuisine}.\"
            f\"\\nClients served: {self.number_served}\"
        )

    def open_restaurant(self):
        print(f\"{self.name} is open to business!\")

    def set_number_served(self, num_of_clients):
        self.number_served = num_of_clients

    def increment_served(self):
        self.numberserved = self.number_served + 1


r1 = Restaurant(\"bar do careca\", \"baiana\")
# r1.describe_restaurant()

# print()

# r1.number_served = 12000
# r1.describe_restaurant()

# print()

r1.set_number_served(24000)
r1.describe_restaurant()
" . 1) ((marker . 618) . -219) ((marker . 658) . -221) ((marker* . 648) . 639) ((marker . 647) . -219) ((marker . 1) . -220) ((marker . 1) . -220) nil (220 . 221) (t 24235 37146 450340 461000) nil (" " . 220) ((marker) . -1) ((marker . 1) . -1) ((marker . 1) . -1) nil (220 . 221) (t 24235 37139 442831 224000) nil (1 . 859) ("#!/usr/bin/env python3


class Restaurant:
    \"\"\"Model of a restaurant.\"\"\"

    def __init__(self, name, cuisine):
        self.name = name.title()
        self.cuisine = cuisine.title()
        self.number_served = 0

    def describe_restaurant(self):
        print(
            f\"Name: {self.name}.\\nCuizine: {self.cuisine}.\"
            f\"\\nClients served: {self.number_served}\"
        )

    def open_restaurant(self):
        print(f\"{self.name} is open to business!\")

    def set_number_served(self, num_of_clients):
        self.number_served = num_of_clients

    def increment_served(self):
        self.numberserved = self.number_served + 1



r1 = Restaurant(\"bar do careca\", \"baiana\")
# r1.describe_restaurant()

# print()

# r1.number_served = 12000
# r1.describe_restaurant()

# print()

r1.set_number_served(24000)
r1.describe_restaurant()
" . 1) ((marker . 658) . -23) ((marker . 644) . -794) ((marker* . 648) . 203) ((marker . 626) . -729) ((marker* . 626) . 53) ((marker . 626) . -737) ((marker . 626) . -805) ((marker . 804) . -834) ((marker . 851) . -858) ((marker . 1) . -834) ((marker . 1) . -829) ((marker . 1) . -25) ((marker . 1) . -858) ((marker . 1) . -834) ((marker . 1) . -834) ((marker . 1) . -834) ((marker . 1) . -25) ((marker . 1) . -802) ((marker . 1) . -802) ((marker . 1) . -384) ((marker . 1) . -834) ((marker . 1) . -802) ((marker . 1) . -802) ((marker . 1) . -802) ((marker . 1) . -802) ((marker . 1) . -384) ((marker . 1) . -802) ((marker . 1) . -802) ((marker . 1) . -330) ((marker . 1) . -802) ((marker . 1) . -802) ((marker . 1) . -657) ((marker . 1) . -802) ((marker . 1) . -802) ((marker . 1) . -657) ((marker . 1) . -794) ((marker . 1) . -802) ((marker . 1) . -657) ((marker . 1) . -794) ((marker . 1) . -802) ((marker . 1) . -657) ((marker . 1) . -650) ((marker . 1) . -650) ((marker . 1) . -650) ((marker . 1) . -43) ((marker . 1) . -650) ((marker . 1) . -650) ((marker . 1) . -650) ((marker . 1) . -43) ((marker . 1) . -650) ((marker . 1) . -650) ((marker . 1) . -650) ((marker . 1) . -43) ((marker . 1) . -658) ((marker . 1) . -658) ((marker . 1) . -663) ((marker . 1) . -658) ((marker . 1) . -658) ((marker . 1) . -663) ((marker . 1) . -650) ((marker . 1) . -650) ((marker . 1) . -650) ((marker . 1) . -43) ((marker . 1) . -612) ((marker . 1) . -612) ((marker . 1) . -612) ((marker . 1) . -612) ((marker . 1) . -612) ((marker . 1) . -612) ((marker . 1) . -612) ((marker . 1) . -612) ((marker . 1) . -612) ((marker . 1) . -612) ((marker . 1) . -612) ((marker . 1) . -612) ((marker . 1) . -612) ((marker . 1) . -612) ((marker . 1) . -612) ((marker . 1) . -612) ((marker . 1) . -612) ((marker . 1) . -612) ((marker . 1) . -612) ((marker . 1) . -612) ((marker . 1) . -612) ((marker . 1) . -612) ((marker . 1) . -612) ((marker . 1) . -612) ((marker . 1) . -612) ((marker . 1) . -612) ((marker . 1) . -612) ((marker . 1) . -612) ((marker . 1) . -612) ((marker . 1) . -612) ((marker . 1) . -612) ((marker . 1) . -612) ((marker . 1) . -612) ((marker . 1) . -604) ((marker . 1) . -604) ((marker . 1) . -814) ((marker . 1) . -805) ((marker . 1) . -572) ((marker . 1) . -814) ((marker . 1) . -814) ((marker . 1) . -572) ((marker . 1) . -737) ((marker . 1) . -737) ((marker . 1) . -657) ((marker . 1) . -737) ((marker . 1) . -737) ((marker . 1) . -657) ((marker . 1) . -859) ((marker . 1) . -859) ((marker . 1) . -728) ((marker . 1) . -805) ((marker . 1) . -859) ((marker . 1) . -859) ((marker . 1) . -859) ((marker . 1) . -794) ((marker . 1) . -794) ((marker . 1) . -794) ((marker . 1) . -794) ((marker . 1) . -794) ((marker . 1) . -794) ((marker . 1) . -794) ((marker . 1) . -794) ((marker . 1) . -794) ((marker . 1) . -794) ((marker . 1) . -794) ((marker . 644) . -794) ((marker . 1) . -859) ((marker . 1) . -794) ((marker . 1) . -794) ((marker . 1) . -794) ((marker . 1) . -794) ((marker . 1) . -794) ((marker . 1) . -794) ((marker . 1) . -794) ((marker . 1) . -794) ((marker . 1) . -655) ((marker . 1) . -794) ((marker . 1) . -794) ((marker . 1) . -794) ((marker . 1) . -794) ((marker . 1) . -794) ((marker . 1) . -794) ((marker . 1) . -655) ((marker . 1) . -23) ((marker . 1) . -23) ((marker . 1) . -24) ((marker . 1) . -23) ((marker . 1) . -24) ((marker . 1) . -25) ((marker . 1) . -24) ((marker . 1) . -25) ((marker . 1) . -43) ((marker . 1) . -25) ((marker . 1) . -43) ((marker . 1) . -76) ((marker . 1) . -43) ((marker . 1) . -76) ((marker . 1) . -77) ((marker . 1) . -76) ((marker . 1) . -77) ((marker . 1) . -219) ((marker . 1) . -77) ((marker . 1) . -219) ((marker . 1) . -220) ((marker . 1) . -219) ((marker . 1) . -220) ((marker . 1) . -394) ((marker . 1) . -220) ((marker . 1) . -394) ((marker . 1) . -395) ((marker . 1) . -394) ((marker . 1) . -395) ((marker . 1) . -477) ((marker . 1) . -395) ((marker . 1) . -477) ((marker . 1) . -478) ((marker . 1) . -477) ((marker . 1) . -478) ((marker . 1) . -527) ((marker . 1) . -478) ((marker . 1) . -527) ((marker . 1) . -571) ((marker . 1) . -527) ((marker . 1) . -571) ((marker . 1) . -572) ((marker . 1) . -571) ((marker . 1) . -572) ((marker . 1) . -604) ((marker . 1) . -572) ((marker . 1) . -604) ((marker . 1) . -655) ((marker . 1) . -604) ((marker . 1) . -655) ((marker . 1) . -657) ((marker . 1) . -655) ((marker . 1) . -657) ((marker . 1) . -658) ((marker . 1) . -657) ((marker . 1) . -658) ((marker . 1) . -701) ((marker . 1) . -658) ((marker . 1) . -701) ((marker . 1) . -728) ((marker . 1) . -701) ((marker . 1) . -728) ((marker . 1) . -729) ((marker . 1) . -728) ((marker . 1) . -729) ((marker . 1) . -739) ((marker . 1) . -729) ((marker . 1) . -739) ((marker . 1) . -740) ((marker . 1) . -739) ((marker . 1) . -740) ((marker . 1) . -740) ((marker . 1) . -740) ((marker . 1) . -740) ((marker . 1) . -740) ((marker . 1) . -740) ((marker . 1) . -740) ((marker . 1) . -767) ((marker . 1) . -740) ((marker . 1) . -767) ((marker . 1) . -794) ((marker . 1) . -767) ((marker . 1) . -794) ((marker . 1) . -795) ((marker . 1) . -794) ((marker . 1) . -795) ((marker . 1) . -805) ((marker . 1) . -795) ((marker . 1) . -805) ((marker . 1) . -806) ((marker . 1) . -805) ((marker . 1) . -806) ((marker . 1) . -834) ((marker . 1) . -806) ((marker . 1) . -834) ((marker . 1) . -859) ((marker . 1) . -834) ((marker . 1) . -859) ((marker . 1) . -859) ((marker . 1) . -859) ((marker . 1) . -859) ((marker . 1) . -834) ((marker . 1) . -859) ((marker . 1) . -834) ((marker . 1) . -806) ((marker . 1) . -834) ((marker . 1) . -806) ((marker . 1) . -805) ((marker . 1) . -806) ((marker . 1) . -805) ((marker . 1) . -806) ((marker . 1) . -805) ((marker . 1) . -806) ((marker . 1) . -833) ((marker . 1) . -806) ((marker . 1) . -806) ((marker . 1) . -833) ((marker . 1) . -833) ((marker . 1) . -806) ((marker . 1) . -833) ((marker* . 852) . 26) ((marker . 1) . -833) ((marker . 1) . -806) ((marker . 1) . -806) ((marker . 1) . -833) ((marker . 1) . -833) ((marker . 1) . -833) ((marker . 1) . -833) ((marker . 1) . -833) ((marker . 1) . -833) ((marker . 1) . -833) ((marker . 1) . -806) ((marker . 1) . -833) ((marker . 1) . -806) ((marker . 1) . -623) ((marker . 1) . -806) ((marker . 1) . -604) ((marker . 1) . -623) ((marker . 1) . -623) ((marker . 1) . -655) ((marker . 1) . -623) ((marker . 1) . -655) ((marker . 1) . -656) ((marker . 1) . -612) ((marker . 1) . -612) ((marker . 1) . -656) ((marker . 1) . -656) ((marker . 1) . -655) ((marker . 1) . -656) ((marker . 1) . -656) ((marker . 1) . -656) ((marker . 1) . -656) ((marker) . -604) ((marker) . -605) ((marker) . -608) ((marker) . -609) ((marker) . -572) ((marker) . -573) ((marker) . -527) ((marker) . -528) ((marker) . -531) ((marker) . -532) ((marker) . -478) ((marker) . -479) ((marker) . -426) ((marker) . -427) ((marker) . -430) ((marker) . -431) ((marker) . -395) ((marker) . -396) ((marker) . -384) ((marker) . -385) ((marker) . -388) ((marker) . -389) ((marker) . -330) ((marker) . -331) ((marker) . -334) ((marker) . -335) ((marker) . -338) ((marker) . -339) ((marker) . -270) ((marker) . -271) ((marker) . -274) ((marker) . -275) ((marker) . -278) ((marker) . -279) ((marker) . -255) ((marker) . -256) ((marker) . -259) ((marker) . -260) ((marker) . -220) ((marker) . -221) ((marker) . -188) ((marker) . -189) ((marker) . -192) ((marker) . -193) ((marker) . -149) ((marker) . -150) ((marker) . -153) ((marker) . -154) ((marker) . -116) ((marker) . -117) ((marker) . -120) ((marker) . -121) ((marker) . -77) ((marker) . -78) ((marker) . -43) ((marker) . -44) ((marker . 1) . -656) ((marker . 1) . -47) ((marker . 1) . -47) ((marker . 1) . -47) ((marker . 1) . -47) ((marker . 1) . -75) ((marker . 1) . -47) ((marker . 1) . -25) ((marker . 1) . -42) ((marker . 1) . -25) ((marker . 1) . -42) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -263) ((marker . 1) . -263) ((marker . 1) . -263) ((marker . 1) . -263) ((marker . 1) . -263) ((marker . 1) . -263) ((marker . 1) . -434) ((marker . 1) . -434) ((marker . 1) . -658) ((marker . 1) . -658) ((marker . 1) . -663) ((marker . 1) . -658) ((marker . 1) . -658) ((marker . 1) . -663) nil (1 . 860) ("#!/usr/bin/env python3


class Restaurant:
    \"\"\"Model of a restaurant.\"\"\"

    def __init__(self, name, cuisine):
        self.name = name.title()
        self.cuisine = cuisine.title()
        self.number_served = 0

    def describe_restaurant(self):
        print(
            f\"Name: {self.name}.\\nCuizine: {self.cuisine}.\"
            f\"\\nClients served: {self.number_served}\"
        )

    def open_restaurant(self):
        print(f\"{self.name} is open to business!\")

    def set_number_served(self, num_of_clients):
        self.number_served = num_of_clients

    def increment_served(self):
        self.numberserved = self.number_served + 1


r1 = Restaurant(\"bar do careca\", \"baiana\")
# r1.describe_restaurant()

# print()

# r1.number_served = 12000
# r1.describe_restaurant()

# print()

r1.set_number_served(24000)
r1.describe_restaurant()
" . 1) ((marker . 647) . -656) ((marker . 1) . -47) ((marker . 1) . -47) ((marker . 1) . -47) ((marker . 1) . -47) ((marker . 1) . -75) ((marker . 1) . -47) ((marker . 1) . -25) ((marker . 1) . -42) ((marker . 1) . -25) ((marker . 1) . -42) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -263) ((marker . 1) . -263) ((marker . 1) . -263) ((marker . 1) . -263) ((marker . 1) . -263) ((marker . 1) . -263) ((marker . 1) . -434) ((marker . 1) . -434) ((marker . 1) . -657) ((marker . 1) . -657) ((marker . 1) . -662) ((marker . 1) . -657) ((marker . 1) . -657) ((marker . 1) . -662) ((marker) . -604) ((marker) . -605) ((marker) . -608) ((marker) . -609) ((marker) . -572) ((marker) . -573) ((marker) . -527) ((marker) . -528) ((marker) . -531) ((marker) . -532) ((marker) . -478) ((marker) . -479) ((marker) . -426) ((marker) . -427) ((marker) . -430) ((marker) . -431) ((marker) . -395) ((marker) . -396) ((marker) . -384) ((marker) . -385) ((marker) . -388) ((marker) . -389) ((marker) . -330) ((marker) . -331) ((marker) . -334) ((marker) . -335) ((marker) . -338) ((marker) . -339) ((marker) . -270) ((marker) . -271) ((marker) . -274) ((marker) . -275) ((marker) . -278) ((marker) . -279) ((marker) . -255) ((marker) . -256) ((marker) . -259) ((marker) . -260) ((marker) . -220) ((marker) . -221) ((marker) . -188) ((marker) . -189) ((marker) . -192) ((marker) . -193) ((marker) . -149) ((marker) . -150) ((marker) . -153) ((marker) . -154) ((marker) . -116) ((marker) . -117) ((marker) . -120) ((marker) . -121) ((marker) . -77) ((marker) . -78) ((marker) . -43) ((marker) . -44) (1 . 859) ("#!/usr/bin/env python3


class Restaurant:
    \"\"\"Model of a restaurant.\"\"\"

    def __init__(self, name, cuisine):
        self.name = name.title()
        self.cuisine = cuisine.title()
        self.number_served = 0

    def describe_restaurant(self):
        print(
            f\"Name: {self.name}.\\nCuizine: {self.cuisine}.\"
            f\"\\nClients served: {self.number_served}\"
        )

    def open_restaurant(self):
        print(f\"{self.name} is open to business!\")

    def set_number_served(self, num_of_clients):
        self.number_served = num_of_clients

    def increment_served(self):
        self.numberserved = self.number_served + 1



r1 = Restaurant(\"bar do careca\", \"baiana\")
# r1.describe_restaurant()

# print()

# r1.number_served = 12000
# r1.describe_restaurant()

# print()

r1.set_number_served(24000)
r1.describe_restaurant()
" . 1) ((marker . 618) . -795) ((marker . 658) . -805) ((marker . 644) . -794) ((marker* . 648) . 203) ((marker . 626) . -729) ((marker* . 626) . 53) ((marker . 626) . -737) ((marker . 626) . -805) ((marker . 804) . -834) ((marker . 851) . -858) ((marker . 1) . -834) ((marker . 1) . -829) ((marker . 1) . -25) ((marker . 1) . -858) ((marker . 1) . -834) ((marker . 1) . -834) ((marker . 1) . -834) ((marker . 1) . -25) ((marker . 1) . -802) ((marker . 1) . -802) ((marker . 1) . -384) ((marker . 1) . -834) ((marker . 1) . -802) ((marker . 1) . -802) ((marker . 1) . -802) ((marker . 1) . -802) ((marker . 1) . -384) ((marker . 1) . -802) ((marker . 1) . -802) ((marker . 1) . -330) ((marker . 1) . -802) ((marker . 1) . -802) ((marker . 1) . -657) ((marker . 1) . -802) ((marker . 1) . -802) ((marker . 1) . -657) ((marker . 1) . -794) ((marker . 1) . -802) ((marker . 1) . -657) ((marker . 1) . -794) ((marker . 1) . -802) ((marker . 1) . -657) ((marker . 1) . -650) ((marker . 1) . -650) ((marker . 1) . -650) ((marker . 1) . -43) ((marker . 1) . -650) ((marker . 1) . -650) ((marker . 1) . -650) ((marker . 1) . -43) ((marker . 1) . -650) ((marker . 1) . -650) ((marker . 1) . -650) ((marker . 1) . -43) ((marker . 1) . -658) ((marker . 1) . -658) ((marker . 1) . -663) ((marker . 1) . -658) ((marker . 1) . -658) ((marker . 1) . -663) ((marker . 1) . -650) ((marker . 1) . -650) ((marker . 1) . -650) ((marker . 1) . -43) ((marker . 1) . -612) ((marker . 1) . -612) ((marker . 1) . -612) ((marker . 1) . -612) ((marker . 1) . -612) ((marker . 1) . -612) ((marker . 1) . -612) ((marker . 1) . -612) ((marker . 1) . -612) ((marker . 1) . -612) ((marker . 1) . -612) ((marker . 1) . -612) ((marker . 1) . -612) ((marker . 1) . -612) ((marker . 1) . -612) ((marker . 1) . -612) ((marker . 1) . -612) ((marker . 1) . -612) ((marker . 1) . -612) ((marker . 1) . -612) ((marker . 1) . -612) ((marker . 1) . -612) ((marker . 1) . -612) ((marker . 1) . -612) ((marker . 1) . -612) ((marker . 1) . -612) ((marker . 1) . -612) ((marker . 1) . -612) ((marker . 1) . -612) ((marker . 1) . -612) ((marker . 1) . -612) ((marker . 1) . -612) ((marker . 1) . -612) ((marker . 1) . -604) ((marker . 1) . -604) ((marker . 1) . -814) ((marker . 1) . -805) ((marker . 1) . -572) ((marker . 1) . -814) ((marker . 1) . -814) ((marker . 1) . -572) ((marker . 1) . -737) ((marker . 1) . -737) ((marker . 1) . -657) ((marker . 1) . -737) ((marker . 1) . -737) ((marker . 1) . -657) ((marker . 1) . -859) ((marker . 1) . -859) ((marker . 1) . -728) ((marker . 1) . -805) ((marker . 1) . -859) ((marker . 1) . -859) ((marker . 1) . -859) ((marker . 1) . -794) ((marker . 1) . -794) ((marker . 1) . -794) ((marker . 1) . -794) ((marker . 1) . -794) ((marker . 1) . -794) ((marker . 1) . -794) ((marker . 1) . -794) ((marker . 1) . -794) ((marker . 1) . -794) ((marker . 1) . -794) ((marker . 644) . -794) ((marker . 647) . -795) ((marker . 1) . -859) ((marker . 1) . -794) ((marker . 1) . -794) ((marker . 1) . -794) ((marker . 1) . -794) ((marker . 1) . -794) ((marker . 1) . -794) ((marker . 1) . -794) ((marker . 1) . -794) ((marker . 1) . -655) ((marker . 1) . -794) ((marker . 1) . -794) ((marker . 1) . -794) ((marker . 1) . -794) ((marker . 1) . -794) ((marker . 1) . -794) ((marker . 1) . -655) ((marker . 1) . -23) ((marker . 1) . -23) ((marker . 1) . -24) ((marker . 1) . -23) ((marker . 1) . -24) ((marker . 1) . -25) ((marker . 1) . -24) ((marker . 1) . -25) ((marker . 1) . -43) ((marker . 1) . -25) ((marker . 1) . -43) ((marker . 1) . -76) ((marker . 1) . -43) ((marker . 1) . -76) ((marker . 1) . -77) ((marker . 1) . -76) ((marker . 1) . -77) ((marker . 1) . -219) ((marker . 1) . -77) ((marker . 1) . -219) ((marker . 1) . -220) ((marker . 1) . -219) ((marker . 1) . -220) ((marker . 1) . -394) ((marker . 1) . -220) ((marker . 1) . -394) ((marker . 1) . -395) ((marker . 1) . -394) ((marker . 1) . -395) ((marker . 1) . -477) ((marker . 1) . -395) ((marker . 1) . -477) ((marker . 1) . -478) ((marker . 1) . -477) ((marker . 1) . -478) ((marker . 1) . -527) ((marker . 1) . -478) ((marker . 1) . -527) ((marker . 1) . -571) ((marker . 1) . -527) ((marker . 1) . -571) ((marker . 1) . -572) ((marker . 1) . -571) ((marker . 1) . -572) ((marker . 1) . -604) ((marker . 1) . -572) ((marker . 1) . -604) ((marker . 1) . -655) ((marker . 1) . -604) ((marker . 1) . -655) ((marker . 1) . -657) ((marker . 1) . -655) ((marker . 1) . -657) ((marker . 1) . -658) ((marker . 1) . -657) ((marker . 1) . -658) ((marker . 1) . -701) ((marker . 1) . -658) ((marker . 1) . -701) ((marker . 1) . -728) ((marker . 1) . -701) ((marker . 1) . -728) ((marker . 1) . -729) ((marker . 1) . -728) ((marker . 1) . -729) ((marker . 1) . -739) ((marker . 1) . -729) ((marker . 1) . -739) ((marker . 1) . -740) ((marker . 1) . -739) ((marker . 1) . -740) ((marker . 1) . -740) ((marker . 1) . -740) ((marker . 1) . -740) ((marker . 1) . -740) ((marker . 1) . -740) ((marker . 1) . -740) ((marker . 1) . -767) ((marker . 1) . -740) ((marker . 1) . -767) ((marker . 1) . -794) ((marker . 1) . -767) ((marker . 1) . -794) ((marker . 1) . -795) ((marker . 1) . -794) ((marker . 1) . -795) ((marker . 1) . -805) ((marker . 1) . -795) ((marker . 1) . -805) ((marker . 1) . -806) ((marker . 1) . -805) ((marker . 1) . -806) ((marker . 1) . -834) ((marker . 1) . -806) ((marker . 1) . -834) ((marker . 1) . -859) ((marker . 1) . -834) ((marker . 1) . -859) ((marker . 1) . -859) ((marker . 1) . -859) ((marker . 1) . -859) ((marker . 1) . -834) ((marker . 1) . -859) ((marker . 1) . -834) ((marker . 1) . -806) ((marker . 1) . -834) ((marker . 1) . -806) ((marker . 1) . -805) ((marker . 1) . -806) ((marker . 1) . -805) ((marker . 1) . -806) ((marker . 1) . -805) ((marker . 1) . -806) ((marker . 1) . -833) ((marker . 1) . -806) ((marker . 1) . -806) ((marker . 1) . -833) ((marker . 1) . -833) ((marker . 1) . -806) ((marker . 1) . -833) ((marker* . 852) . 26) ((marker . 1) . -833) ((marker . 1) . -806) ((marker . 1) . -806) ((marker . 1) . -833) ((marker . 1) . -833) ((marker . 1) . -833) ((marker . 1) . -833) ((marker . 1) . -833) ((marker . 1) . -833) ((marker . 1) . -833) ((marker . 1) . -806) ((marker . 1) . -833) ((marker . 1) . -806) ((marker . 1) . -623) ((marker . 1) . -806) ((marker . 1) . -604) ((marker . 1) . -623) ((marker . 1) . -623) ((marker . 1) . -655) ((marker . 1) . -623) ((marker . 1) . -655) ((marker . 1) . -656) ((marker . 1) . -612) ((marker . 1) . -612) ((marker . 1) . -656) ((marker . 1) . -656) ((marker . 1) . -655) ((marker . 1) . -656) ((marker . 1) . -656) ((marker . 1) . -656) ((marker . 1) . -656) ((marker) . -604) ((marker) . -605) ((marker) . -608) ((marker) . -609) ((marker) . -572) ((marker) . -573) ((marker) . -527) ((marker) . -528) ((marker) . -531) ((marker) . -532) ((marker) . -478) ((marker) . -479) ((marker) . -426) ((marker) . -427) ((marker) . -430) ((marker) . -431) ((marker) . -395) ((marker) . -396) ((marker) . -384) ((marker) . -385) ((marker) . -388) ((marker) . -389) ((marker) . -330) ((marker) . -331) ((marker) . -334) ((marker) . -335) ((marker) . -338) ((marker) . -339) ((marker) . -270) ((marker) . -271) ((marker) . -274) ((marker) . -275) ((marker) . -278) ((marker) . -279) ((marker) . -255) ((marker) . -256) ((marker) . -259) ((marker) . -260) ((marker) . -220) ((marker) . -221) ((marker) . -188) ((marker) . -189) ((marker) . -192) ((marker) . -193) ((marker) . -149) ((marker) . -150) ((marker) . -153) ((marker) . -154) ((marker) . -116) ((marker) . -117) ((marker) . -120) ((marker) . -121) ((marker) . -77) ((marker) . -78) ((marker) . -43) ((marker) . -44) ((marker . 1) . -795) ((marker . 1) . -657) ((marker . 1) . -795) ("        " . 657) ((marker . 1) . -8) ((marker . 1) . -8) ((marker . 1) . -8) ((marker) . -1) ((marker) . -4) ((marker) . -5) (656 . 665) (t 24235 37138 960387 260000) nil (795 . 797) (767 . 769) (740 . 742) (729 . 731) (t 24235 37137 248977 6000) nil ("# " . 729) ("# " . 740) ("# " . 767) ("# " . 795) (t 24235 37135 476948 722000) nil ("
        " . 656) ((marker . 618) . -1) ((marker . 647) . -9) ((marker . 1) . -1) ((marker . 1) . -9) ((marker . 1) . -9) ((marker . 1) . -9) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker) . -1) ((marker) . -2) ((marker) . -5) ((marker) . -6) (657 . 665) (1 . 860) ("#!/usr/bin/env python3


class Restaurant:
    \"\"\"Model of a restaurant.\"\"\"

    def __init__(self, name, cuisine):
        self.name = name.title()
        self.cuisine = cuisine.title()
        self.number_served = 0

    def describe_restaurant(self):
        print(
            f\"Name: {self.name}.\\nCuizine: {self.cuisine}.\"
            f\"\\nClients served: {self.number_served}\"
        )

    def open_restaurant(self):
        print(f\"{self.name} is open to business!\")

    def set_number_served(self, num_of_clients):
        self.number_served = num_of_clients

    def increment_served(self):
        self.numberserved = self.number_served + 1


r1 = Restaurant(\"bar do careca\", \"baiana\")
# r1.describe_restaurant()

# print()

# r1.number_served = 12000
# r1.describe_restaurant()

# print()

r1.set_number_served(24000)
r1.describe_restaurant()
" . 1) ((marker . 647) . -656) ((marker . 1) . -47) ((marker . 1) . -47) ((marker . 1) . -47) ((marker . 1) . -47) ((marker . 1) . -75) ((marker . 1) . -47) ((marker . 1) . -25) ((marker . 1) . -42) ((marker . 1) . -25) ((marker . 1) . -42) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -263) ((marker . 1) . -263) ((marker . 1) . -263) ((marker . 1) . -263) ((marker . 1) . -263) ((marker . 1) . -263) ((marker . 1) . -434) ((marker . 1) . -434) ((marker . 1) . -657) ((marker . 1) . -657) ((marker . 1) . -662) ((marker . 1) . -657) ((marker . 1) . -657) ((marker . 1) . -662) ((marker) . -604) ((marker) . -605) ((marker) . -608) ((marker) . -609) ((marker) . -572) ((marker) . -573) ((marker) . -527) ((marker) . -528) ((marker) . -531) ((marker) . -532) ((marker) . -478) ((marker) . -479) ((marker) . -426) ((marker) . -427) ((marker) . -430) ((marker) . -431) ((marker) . -395) ((marker) . -396) ((marker) . -384) ((marker) . -385) ((marker) . -388) ((marker) . -389) ((marker) . -330) ((marker) . -331) ((marker) . -334) ((marker) . -335) ((marker) . -338) ((marker) . -339) ((marker) . -270) ((marker) . -271) ((marker) . -274) ((marker) . -275) ((marker) . -278) ((marker) . -279) ((marker) . -255) ((marker) . -256) ((marker) . -259) ((marker) . -260) ((marker) . -220) ((marker) . -221) ((marker) . -188) ((marker) . -189) ((marker) . -192) ((marker) . -193) ((marker) . -149) ((marker) . -150) ((marker) . -153) ((marker) . -154) ((marker) . -116) ((marker) . -117) ((marker) . -120) ((marker) . -121) ((marker) . -77) ((marker) . -78) ((marker) . -43) ((marker) . -44) (t 24235 37135 64638 509000) (1 . 859) ("#!/usr/bin/env python3


class Restaurant:
    \"\"\"Model of a restaurant.\"\"\"

    def __init__(self, name, cuisine):
        self.name = name.title()
        self.cuisine = cuisine.title()
        self.number_served = 0

    def describe_restaurant(self):
        print(
            f\"Name: {self.name}.\\nCuizine: {self.cuisine}.\"
            f\"\\nClients served: {self.number_served}\"
        )

    def open_restaurant(self):
        print(f\"{self.name} is open to business!\")

    def set_number_served(self, num_of_clients):
        self.number_served = num_of_clients

    def increment_served(self):
        self.numberserved = self.number_served + 1



r1 = Restaurant(\"bar do careca\", \"baiana\")
# r1.describe_restaurant()

# print()

# r1.number_served = 12000
# r1.describe_restaurant()

# print()

r1.set_number_served(24000)
r1.describe_restaurant()
" . 1) ((marker . 618) . -656) ((marker . 658) . -657) ((marker . 644) . -794) ((marker* . 648) . 203) ((marker . 626) . -729) ((marker* . 626) . 53) ((marker . 626) . -737) ((marker . 626) . -805) ((marker . 804) . -834) ((marker . 851) . -858) ((marker . 1) . -834) ((marker . 1) . -829) ((marker . 1) . -25) ((marker . 1) . -858) ((marker . 1) . -834) ((marker . 1) . -834) ((marker . 1) . -834) ((marker . 1) . -25) ((marker . 1) . -802) ((marker . 1) . -802) ((marker . 1) . -384) ((marker . 1) . -834) ((marker . 1) . -802) ((marker . 1) . -802) ((marker . 1) . -802) ((marker . 1) . -802) ((marker . 1) . -384) ((marker . 1) . -802) ((marker . 1) . -802) ((marker . 1) . -330) ((marker . 1) . -802) ((marker . 1) . -802) ((marker . 1) . -657) ((marker . 1) . -802) ((marker . 1) . -802) ((marker . 1) . -657) ((marker . 1) . -794) ((marker . 1) . -802) ((marker . 1) . -657) ((marker . 1) . -794) ((marker . 1) . -802) ((marker . 1) . -657) ((marker . 1) . -650) ((marker . 1) . -650) ((marker . 1) . -650) ((marker . 1) . -43) ((marker . 1) . -650) ((marker . 1) . -650) ((marker . 1) . -650) ((marker . 1) . -43) ((marker . 1) . -650) ((marker . 1) . -650) ((marker . 1) . -650) ((marker . 1) . -43) ((marker . 1) . -658) ((marker . 1) . -658) ((marker . 1) . -663) ((marker . 1) . -658) ((marker . 1) . -658) ((marker . 1) . -663) ((marker . 1) . -650) ((marker . 1) . -650) ((marker . 1) . -650) ((marker . 1) . -43) ((marker . 1) . -612) ((marker . 1) . -612) ((marker . 1) . -612) ((marker . 1) . -612) ((marker . 1) . -612) ((marker . 1) . -612) ((marker . 1) . -612) ((marker . 1) . -612) ((marker . 1) . -612) ((marker . 1) . -612) ((marker . 1) . -612) ((marker . 1) . -612) ((marker . 1) . -612) ((marker . 1) . -612) ((marker . 1) . -612) ((marker . 1) . -612) ((marker . 1) . -612) ((marker . 1) . -612) ((marker . 1) . -612) ((marker . 1) . -612) ((marker . 1) . -612) ((marker . 1) . -612) ((marker . 1) . -612) ((marker . 1) . -612) ((marker . 1) . -612) ((marker . 1) . -612) ((marker . 1) . -612) ((marker . 1) . -612) ((marker . 1) . -612) ((marker . 1) . -612) ((marker . 1) . -612) ((marker . 1) . -612) ((marker . 1) . -612) ((marker . 1) . -604) ((marker . 1) . -604) ((marker . 1) . -814) ((marker . 1) . -805) ((marker . 1) . -572) ((marker . 1) . -814) ((marker . 1) . -814) ((marker . 1) . -572) ((marker . 1) . -737) ((marker . 1) . -737) ((marker . 1) . -657) ((marker . 1) . -737) ((marker . 1) . -737) ((marker . 1) . -657) ((marker . 1) . -859) ((marker . 1) . -859) ((marker . 1) . -728) ((marker . 1) . -805) ((marker . 1) . -859) ((marker . 1) . -859) ((marker . 1) . -859) ((marker . 1) . -794) ((marker . 1) . -794) ((marker . 1) . -794) ((marker . 1) . -794) ((marker . 1) . -794) ((marker . 1) . -794) ((marker . 1) . -794) ((marker . 1) . -794) ((marker . 1) . -794) ((marker . 1) . -794) ((marker . 1) . -794) ((marker . 644) . -794) ((marker . 647) . -656) ((marker . 1) . -859) ((marker . 1) . -794) ((marker . 1) . -794) ((marker . 1) . -794) ((marker . 1) . -794) ((marker . 1) . -794) ((marker . 1) . -794) ((marker . 1) . -794) ((marker . 1) . -794) ((marker . 1) . -655) ((marker . 1) . -794) ((marker . 1) . -794) ((marker . 1) . -794) ((marker . 1) . -794) ((marker . 1) . -794) ((marker . 1) . -794) ((marker . 1) . -655) ((marker) . -572) ((marker) . -573) ((marker) . -527) ((marker) . -528) ((marker) . -531) ((marker) . -532) ((marker) . -478) ((marker) . -479) ((marker) . -426) ((marker) . -427) ((marker) . -427) ((marker) . -428) ((marker) . -428) ((marker) . -429) ((marker) . -429) ((marker) . -430) ((marker) . -430) ((marker) . -431) ((marker) . -431) ((marker) . -432) ((marker) . -432) ((marker) . -433) ((marker) . -433) ((marker) . -434) ((marker) . -395) ((marker) . -396) ((marker) . -384) ((marker) . -385) ((marker) . -385) ((marker) . -386) ((marker) . -386) ((marker) . -387) ((marker) . -387) ((marker) . -388) ((marker) . -388) ((marker) . -389) ((marker) . -389) ((marker) . -390) ((marker) . -390) ((marker) . -391) ((marker) . -391) ((marker) . -392) ((marker) . -330) ((marker) . -331) ((marker) . -331) ((marker) . -332) ((marker) . -332) ((marker) . -333) ((marker) . -333) ((marker) . -334) ((marker) . -334) ((marker) . -335) ((marker) . -335) ((marker) . -336) ((marker) . -336) ((marker) . -337) ((marker) . -337) ((marker) . -338) ((marker) . -338) ((marker) . -339) ((marker) . -339) ((marker) . -340) ((marker) . -340) ((marker) . -341) ((marker) . -341) ((marker) . -342) ((marker) . -270) ((marker) . -271) ((marker) . -271) ((marker) . -272) ((marker) . -272) ((marker) . -273) ((marker) . -273) ((marker) . -274) ((marker) . -274) ((marker) . -275) ((marker) . -275) ((marker) . -276) ((marker) . -276) ((marker) . -277) ((marker) . -277) ((marker) . -278) ((marker) . -278) ((marker) . -279) ((marker) . -279) ((marker) . -280) ((marker) . -280) ((marker) . -281) ((marker) . -281) ((marker) . -282) ((marker) . -255) ((marker) . -256) ((marker) . -256) ((marker) . -257) ((marker) . -257) ((marker) . -258) ((marker) . -258) ((marker) . -259) ((marker) . -259) ((marker) . -260) ((marker) . -260) ((marker) . -261) ((marker) . -261) ((marker) . -262) ((marker) . -262) ((marker) . -263) ((marker) . -220) ((marker) . -221) ((marker) . -188) ((marker) . -189) ((marker) . -189) ((marker) . -190) ((marker) . -190) ((marker) . -191) ((marker) . -191) ((marker) . -192) ((marker) . -192) ((marker) . -193) ((marker) . -193) ((marker) . -194) ((marker) . -194) ((marker) . -195) ((marker) . -195) ((marker) . -196) ((marker) . -149) ((marker) . -150) ((marker) . -150) ((marker) . -151) ((marker) . -151) ((marker) . -152) ((marker) . -152) ((marker) . -153) ((marker) . -153) ((marker) . -154) ((marker) . -154) ((marker) . -155) ((marker) . -155) ((marker) . -156) ((marker) . -156) ((marker) . -157) ((marker) . -116) ((marker) . -117) ((marker) . -117) ((marker) . -118) ((marker) . -118) ((marker) . -119) ((marker) . -119) ((marker) . -120) ((marker) . -120) ((marker) . -121) ((marker) . -121) ((marker) . -122) ((marker) . -122) ((marker) . -123) ((marker) . -123) ((marker) . -124) ((marker) . -77) ((marker) . -78) ((marker) . -43) ((marker) . -44) ((marker . 1) . -23) ((marker . 1) . -23) ((marker . 1) . -24) ((marker . 1) . -23) ((marker . 1) . -24) ((marker . 1) . -25) ((marker . 1) . -24) ((marker . 1) . -25) ((marker . 1) . -43) ((marker . 1) . -25) ((marker . 1) . -43) ((marker . 1) . -76) ((marker . 1) . -43) ((marker . 1) . -76) ((marker . 1) . -77) ((marker . 1) . -76) ((marker . 1) . -77) ((marker . 1) . -219) ((marker . 1) . -77) ((marker . 1) . -219) ((marker . 1) . -220) ((marker . 1) . -219) ((marker . 1) . -220) ((marker . 1) . -394) ((marker . 1) . -220) ((marker . 1) . -394) ((marker . 1) . -395) ((marker . 1) . -394) ((marker . 1) . -395) ((marker . 1) . -477) ((marker . 1) . -395) ((marker . 1) . -477) ((marker . 1) . -478) ((marker . 1) . -477) ((marker . 1) . -478) ((marker . 1) . -527) ((marker . 1) . -478) ((marker . 1) . -527) ((marker . 1) . -571) ((marker . 1) . -527) ((marker . 1) . -571) ((marker . 1) . -572) ((marker . 1) . -571) ((marker . 1) . -572) ((marker . 1) . -604) ((marker . 1) . -572) ((marker . 1) . -604) ((marker . 1) . -655) ((marker . 1) . -604) ((marker . 1) . -655) ((marker . 1) . -657) ((marker . 1) . -655) ((marker . 1) . -657) ((marker . 1) . -658) ((marker . 1) . -657) ((marker . 1) . -658) ((marker . 1) . -701) ((marker . 1) . -658) ((marker . 1) . -701) ((marker . 1) . -728) ((marker . 1) . -701) ((marker . 1) . -728) ((marker . 1) . -729) ((marker . 1) . -728) ((marker . 1) . -729) ((marker . 1) . -739) ((marker . 1) . -729) ((marker . 1) . -739) ((marker . 1) . -740) ((marker . 1) . -739) ((marker . 1) . -740) ((marker . 1) . -740) ((marker . 1) . -740) ((marker . 1) . -740) ((marker . 1) . -740) ((marker . 1) . -740) ((marker . 1) . -740) ((marker . 1) . -767) ((marker . 1) . -740) ((marker . 1) . -767) ((marker . 1) . -794) ((marker . 1) . -767) ((marker . 1) . -794) ((marker . 1) . -795) ((marker . 1) . -794) ((marker . 1) . -795) ((marker . 1) . -805) ((marker . 1) . -795) ((marker . 1) . -805) ((marker . 1) . -806) ((marker . 1) . -805) ((marker . 1) . -806) ((marker . 1) . -834) ((marker . 1) . -806) ((marker . 1) . -834) ((marker . 1) . -859) ((marker . 1) . -834) ((marker . 1) . -859) ((marker . 1) . -859) ((marker . 1) . -859) ((marker . 1) . -859) ((marker . 1) . -834) ((marker . 1) . -859) ((marker . 1) . -834) ((marker . 1) . -806) ((marker . 1) . -834) ((marker . 1) . -806) ((marker . 1) . -805) ((marker . 1) . -806) ((marker . 1) . -805) ((marker . 1) . -806) ((marker . 1) . -805) ((marker . 1) . -806) ((marker . 1) . -833) ((marker . 1) . -806) ((marker . 1) . -806) ((marker . 1) . -833) ((marker . 1) . -833) ((marker . 1) . -806) ((marker . 1) . -833) ((marker* . 852) . 26) ((marker . 1) . -833) ((marker . 1) . -806) ((marker . 1) . -806) ((marker . 1) . -833) ((marker . 1) . -833) ((marker . 1) . -833) ((marker . 1) . -833) ((marker . 1) . -833) ((marker . 1) . -833) ((marker . 1) . -833) ((marker . 1) . -806) ((marker . 1) . -833) ((marker . 1) . -806) ((marker) . -604) ((marker) . -605) ((marker) . -608) ((marker) . -609) ((marker . 1) . -623) ((marker . 1) . -806) ((marker . 1) . -604) ((marker . 1) . -623) ((marker . 1) . -623) ((marker . 1) . -655) ((marker . 1) . -623) ((marker . 1) . -655) ((marker . 1) . -656) ((marker . 1) . -612) ((marker . 1) . -612) ((marker . 1) . -656) ((marker . 1) . -656) ((marker . 1) . -655) ((marker . 1) . -656) ((marker . 1) . -656) ((marker . 1) . -656) ((marker . 1) . -656) nil ("        " . -657) ((marker . 647) . -8) ((marker) . -1) ((marker) . -4) ((marker) . -5) ((marker . 1) . -8) ((marker . 1) . -8) ((marker . 1) . -8) 665 (656 . 665) 656 nil ("-" . 624) (624 . 625) (" - " . 624) (625 . 627) ("_" . 625) (624 . 626) ("_" . 624) (t 24235 37133 435879 463000) nil ("
" . 834) ((marker . 618) . -1) ((marker . 647) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ("
" . 835) ((marker . 618) . -1) ((marker . 647) . -1) ((marker* . 852) . 1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) (t 24235 37132 957897 143000) nil (835 . 836) (834 . 835) (t 24235 37112 573956 692000) 807 nil (624 . 625) (" " . -624) ((marker . 647) . -1) ("_" . -625) ((marker . 647) . -1) 626 (625 . 626) ("-" . -625) ((marker . 647) . -1) (" " . -626) ((marker . 647) . -1) 627 (624 . 627) ("-" . -624) 625 (624 . 625) (t 24235 37090 266964 872000) nil (795 . 797) (767 . 769) (740 . 742) (729 . 731) 797 nil (701 . 703) 709 (t 24235 37069 855933 898000) nil (651 . 655) (" +  " . -651) ((marker . 647) . -3) 655 (654 . 655) (651 . 654) (" +" . -651) ((marker . 647) . -1) 653 (651 . 653) (t 24235 37066 924662 536000) nil ("+" . 631) (t 24235 37060 295838 304000) nil (630 . 634) (" + =" . -630) ((marker . 647) . -3) 634 (630 . 634) (" + " . 630) ((marker . 647) . -1) 632 (631 . 632) ("=" . 631) (t 24235 37053 753214 749000) nil (630 . 633) ("=" . -630) 631 (613 . 631) (t 24235 37045 843764 419000) nil ("+" . 613) nil ("+" . 613) (t 24235 37034 601966 365000) nil (614 . 615) (613 . 614) nil ("+" . 613) (605 . 614) ("        + +" . 605) ((marker . 647) . -10) ((marker . 1) . -10) ((marker . 1) . -10) (614 . 616) (" + " . 614) ((marker . 647) . -2) (1 . 829) ("#!/usr/bin/env python3


class Restaurant:
    \"\"\"Model of a restaurant.\"\"\"

    def __init__(self, name, cuisine):
        self.name = name.title()
        self.cuisine = cuisine.title()
        self.number_served = 0

    def describe_restaurant(self):
        print(
            f\"Name: {self.name}.\\nCuizine: {self.cuisine}.\"
            f\"\\nClients served: {self.number_served}\"
        )

    def open_restaurant(self):
        print(f\"{self.name} is open to business!\")

    def set_number_served(self, num_of_clients):
        self.number_served = num_of_clients

    def increment_served(self):
        ++self.number_served


r1 = Restaurant(\"bar do careca\", \"baiana\")
r1.describe_restaurant()

print()

r1.number_served = 12000
r1.describe_restaurant()

print()

r1.set_number_served(24000)
r1.describe_restaurant()
" . 1) ((marker . 78) . -384) ((marker . 647) . -615) (t 24235 37030 740230 555000) (1 . 827) ("#!/usr/bin/env python3


class Restaurant:
    \"\"\"Model of a restaurant.\"\"\"

    def __init__(self, name, cuisine):
        self.name = name.title()
        self.cuisine = cuisine.title()
        self.number_served = 0

    def describe_restaurant(self):
        print(
            f\"Name: {self.name}.\\nCuizine: {self.cuisine}.\"
            f\"\\nClients served: {self.number_served}\"
        )

    def open_restaurant(self):
        print(f\"{self.name} is open to business!\")

    def set_number_served(self, num_of_clients):
        self.number_served = num_of_clients

    def increment_served(self):
        + + self.number_served


r1 = Restaurant(\"bar do careca\", \"baiana\")
r1.describe_restaurant()

print()

r1.number_served = 12000
r1.describe_restaurant()

print()

r1.set_number_served(24000)
r1.describe_restaurant()
" . 1) ((marker . 618) . -604) ((marker . 658) . -635) ((marker . 644) . -634) ((marker* . 648) . 212) ((marker . 626) . -634) ((marker* . 626) . 194) ((marker . 626) . -634) ((marker . 626) . -634) ((marker . 804) . -803) ((marker . 851) . -827) ((marker . 1) . -803) ((marker . 1) . -798) ((marker . 1) . -25) ((marker . 1) . -827) ((marker . 1) . -803) ((marker . 1) . -803) ((marker . 1) . -803) ((marker . 1) . -25) ((marker . 1) . -771) ((marker . 1) . -771) ((marker . 1) . -384) ((marker . 1) . -803) ((marker . 1) . -771) ((marker . 1) . -771) ((marker . 1) . -771) ((marker . 1) . -771) ((marker . 1) . -384) ((marker . 1) . -771) ((marker . 1) . -771) ((marker . 1) . -330) ((marker . 1) . -771) ((marker . 1) . -771) ((marker . 1) . -636) ((marker . 1) . -771) ((marker . 1) . -771) ((marker . 1) . -636) ((marker . 1) . -765) ((marker . 1) . -771) ((marker . 1) . -636) ((marker . 1) . -765) ((marker . 1) . -771) ((marker . 1) . -636) ((marker . 1) . -634) ((marker . 1) . -634) ((marker . 1) . -634) ((marker . 1) . -43) ((marker . 1) . -634) ((marker . 1) . -634) ((marker . 1) . -634) ((marker . 1) . -43) ((marker . 1) . -634) ((marker . 1) . -634) ((marker . 1) . -634) ((marker . 1) . -43) ((marker . 1) . -637) ((marker . 1) . -637) ((marker . 1) . -642) ((marker . 1) . -637) ((marker . 1) . -637) ((marker . 1) . -642) ((marker . 1) . -634) ((marker . 1) . -634) ((marker . 1) . -634) ((marker . 1) . -43) ((marker . 78) . -384) ((marker . 644) . -634) ((marker . 647) . -615) ((marker . 1) . -604) ((marker . 1) . -604) ((marker . 1) . -604) ((marker . 1) . -604) ((marker . 1) . -604) ((marker . 1) . -604) ((marker . 1) . -604) ((marker . 1) . -604) ((marker . 1) . -604) ((marker . 1) . -604) ((marker . 1) . -604) ((marker . 1) . -604) ((marker . 1) . -604) ((marker . 1) . -604) ((marker . 1) . -604) ((marker . 1) . -604) ((marker . 1) . -604) ((marker . 1) . -604) ((marker . 1) . -604) ((marker . 1) . -604) ((marker . 1) . -604) ((marker . 1) . -604) ((marker . 1) . -604) ((marker . 1) . -604) ((marker . 1) . -604) ((marker . 1) . -604) ((marker . 1) . -604) ((marker . 1) . -604) ((marker . 1) . -604) ((marker . 1) . -604) ((marker . 1) . -604) ((marker . 1) . -604) ((marker . 1) . -604) ((marker . 1) . -613) ((marker . 1) . -613) nil (614 . 617) (" +" . -614) ((marker . 647) . -1) ((marker . 1) . -1) ((marker . 1) . -1) 616 (605 . 616) ("        +" . -605) ((marker . 647) . -8) ((marker . 1) . -8) ((marker . 1) . -8) ((marker . 1) . -8) ((marker . 1) . -8) ((marker . 1) . -8) ((marker . 1) . -8) ((marker . 1) . -8) ((marker . 1) . -8) ((marker . 1) . -8) ((marker . 1) . -8) ((marker . 1) . -8) ((marker . 1) . -8) ((marker . 1) . -8) ((marker . 1) . -8) ((marker . 1) . -8) ((marker . 1) . -8) ((marker . 1) . -8) ((marker . 1) . -8) ((marker . 1) . -8) ((marker . 1) . -8) ((marker . 1) . -8) ((marker . 1) . -8) ((marker . 1) . -8) ((marker . 1) . -8) ((marker . 1) . -8) ((marker . 1) . -8) ((marker . 1) . -8) ((marker . 1) . -8) ((marker . 1) . -8) ((marker . 1) . -8) ((marker . 1) . -8) ((marker . 1) . -8) ((marker . 1) . -8) ((marker) . -1) ((marker) . -4) ((marker) . -5) 614 (613 . 614) (t 24235 37028 122136 388000) nil (" " . 613) ((marker) . -1) nil ("=" . 613) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) nil ("+" . 613) ((marker) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) (t 24235 37022 374569 479000) nil (605 . 616) ("        + =" . -605) ((marker . 647) . -10) 616 (605 . 616) ("        +" . -605) ((marker . 647) . -8) 614 (613 . 614) ("=" . -613) ((marker . 647) . -1) (" " . -614) ((marker . 647) . -1) 615 (605 . 615) ("        =" . -605) ((marker . 647) . -8) 614 (613 . 614) (t 24235 37018 607895 46000) nil (" += self.number_served" . 631) ((marker . 644) . -2) ((marker* . 648) . 22) ((marker . 626) . -1) ((marker* . 626) . 19) ((marker . 626) . -1) ((marker . 626) . -2) ((marker . 1) . -2) ((marker . 1) . -1) ((marker . 1) . -2) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -2) ((marker . 1) . -2) ((marker . 644) . -2) nil (618 . 631) ("number" . -618) ((marker . 647) . -6) 624 (621 . 624) (618 . 621) (t 24235 37009 946185 500000) ("increment" . 618) (t 24235 36992 929518 237000) nil (", increment" . 602) (t 24235 36982 719314 422000) nil (" " . 640) (638 . 641) (" +" . 638) ((marker . 647) . -1) (639 . 640) (t 24235 36981 635787 486000) nil ("+" . 639) (638 . 640) (" + " . 638) ((marker . 644) . -2) ((marker . 626) . -1) ((marker . 626) . -1) ((marker . 626) . -2) ((marker . 647) . -1) ((marker . 1) . -2) ((marker . 1) . -1) ((marker . 1) . -2) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) (640 . 641) (t 24235 36981 172311 412000) nil (616 . 624) ("                 " . 616) ((marker) . -17) ((marker) . -17) ((marker) . -1) ((marker) . -4) ((marker) . -5) ((marker) . -8) ((marker) . -9) ((marker) . -12) ((marker) . -13) ((marker) . -16) ((marker) . -17) (1 . 863) ("#!/usr/bin/env python3


class Restaurant:
    \"\"\"Model of a restaurant.\"\"\"

    def __init__(self, name, cuisine):
        self.name = name.title()
        self.cuisine = cuisine.title()
        self.number_served = 0

    def describe_restaurant(self):
        print(
            f\"Name: {self.name}.\\nCuizine: {self.cuisine}.\"
            f\"\\nClients served: {self.number_served}\"
        )

    def open_restaurant(self):
        print(f\"{self.name} is open to business!\")

    def set_number_served(self, num_of_clients):
        self.number_served = num_of_clients

    def increment_served(self, increment):
        self.increment += self.number_served


r1 = Restaurant(\"bar do careca\", \"baiana\")
r1.describe_restaurant()

print()

r1.number_served = 12000
r1.describe_restaurant()

print()

r1.set_number_served(24000)
r1.describe_restaurant()
" . 1) ((marker . 78) . -43) ((marker . 647) . -647) ((marker . 1) . -47) ((marker . 1) . -47) ((marker . 1) . -47) ((marker . 1) . -47) ((marker . 1) . -75) ((marker . 1) . -47) ((marker . 1) . -25) ((marker . 1) . -42) ((marker . 1) . -25) ((marker . 1) . -42) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -263) ((marker . 1) . -263) ((marker . 1) . -263) ((marker . 1) . -263) ((marker . 1) . -263) ((marker . 1) . -263) ((marker . 1) . -434) ((marker . 1) . -434) ((marker . 1) . -662) ((marker . 1) . -662) ((marker . 1) . -667) ((marker . 1) . -662) ((marker . 1) . -662) ((marker . 1) . -667) ((marker) . -615) ((marker) . -616) ((marker) . -619) ((marker) . -620) ((marker) . -572) ((marker) . -573) ((marker) . -527) ((marker) . -528) ((marker) . -531) ((marker) . -532) ((marker) . -478) ((marker) . -479) ((marker) . -426) ((marker) . -427) ((marker) . -430) ((marker) . -431) ((marker) . -395) ((marker) . -396) ((marker) . -384) ((marker) . -385) ((marker) . -388) ((marker) . -389) ((marker) . -330) ((marker) . -331) ((marker) . -334) ((marker) . -335) ((marker) . -338) ((marker) . -339) ((marker) . -270) ((marker) . -271) ((marker) . -274) ((marker) . -275) ((marker) . -278) ((marker) . -279) ((marker) . -255) ((marker) . -256) ((marker) . -259) ((marker) . -260) ((marker) . -220) ((marker) . -221) ((marker) . -188) ((marker) . -189) ((marker) . -192) ((marker) . -193) ((marker) . -149) ((marker) . -150) ((marker) . -153) ((marker) . -154) ((marker) . -116) ((marker) . -117) ((marker) . -120) ((marker) . -121) ((marker) . -77) ((marker) . -78) ((marker) . -43) ((marker) . -44) (t 24235 36980 644118 384000) (1 . 854) ("#!/usr/bin/env python3


class Restaurant:
    \"\"\"Model of a restaurant.\"\"\"

    def __init__(self, name, cuisine):
        self.name = name.title()
        self.cuisine = cuisine.title()
        self.number_served = 0

    def describe_restaurant(self):
        print(
            f\"Name: {self.name}.\\nCuizine: {self.cuisine}.\"
            f\"\\nClients served: {self.number_served}\"
        )

    def open_restaurant(self):
        print(f\"{self.name} is open to business!\")

    def set_number_served(self, num_of_clients):
        self.number_served = num_of_clients

    def increment_served(self, increment):
                 self.increment += self.number_served


r1 = Restaurant(\"bar do careca\", \"baiana\")
r1.describe_restaurant()

print()

r1.number_served = 12000
r1.describe_restaurant()

print()

r1.set_number_served(24000)
r1.describe_restaurant()
" . 1) ((marker . 618) . -615) ((marker . 658) . -669) ((marker . 644) . -648) ((marker* . 648) . 214) ((marker . 626) . -647) ((marker* . 626) . 213) ((marker . 626) . -647) ((marker . 626) . -648) ((marker . 804) . -837) ((marker . 851) . -861) ((marker . 1) . -837) ((marker . 1) . -832) ((marker . 1) . -25) ((marker . 1) . -861) ((marker . 1) . -837) ((marker . 1) . -837) ((marker . 1) . -837) ((marker . 1) . -25) ((marker . 1) . -805) ((marker . 1) . -805) ((marker . 1) . -384) ((marker . 1) . -837) ((marker . 1) . -805) ((marker . 1) . -805) ((marker . 1) . -805) ((marker . 1) . -805) ((marker . 1) . -384) ((marker . 1) . -805) ((marker . 1) . -805) ((marker . 1) . -330) ((marker . 1) . -805) ((marker . 1) . -805) ((marker . 1) . -670) ((marker . 1) . -805) ((marker . 1) . -805) ((marker . 1) . -670) ((marker . 1) . -799) ((marker . 1) . -805) ((marker . 1) . -670) ((marker . 78) . -43) ((marker . 644) . -799) ((marker . 647) . -647) ((marker . 1) . -799) ((marker . 1) . -805) ((marker . 1) . -670) ((marker) . -478) ((marker) . -479) ((marker) . -426) ((marker) . -427) ((marker) . -430) ((marker) . -431) ((marker) . -395) ((marker) . -396) ((marker) . -384) ((marker) . -385) ((marker) . -388) ((marker) . -389) ((marker) . -330) ((marker) . -331) ((marker) . -334) ((marker) . -335) ((marker) . -338) ((marker) . -339) ((marker) . -270) ((marker) . -271) ((marker) . -274) ((marker) . -275) ((marker) . -278) ((marker) . -279) ((marker) . -255) ((marker) . -256) ((marker) . -259) ((marker) . -260) ((marker) . -220) ((marker) . -221) ((marker) . -188) ((marker) . -189) ((marker) . -192) ((marker) . -193) ((marker) . -149) ((marker) . -150) ((marker) . -153) ((marker) . -154) ((marker) . -116) ((marker) . -117) ((marker) . -120) ((marker) . -121) ((marker) . -77) ((marker) . -78) ((marker) . -43) ((marker) . -44) ((marker) . -527) ((marker) . -528) ((marker) . -531) ((marker) . -532) ((marker) . -572) ((marker) . -573) ((marker . 1) . -648) ((marker . 1) . -647) ((marker . 1) . -648) ((marker . 1) . -43) ((marker . 1) . -647) ((marker . 1) . -647) ((marker . 1) . -647) ((marker . 1) . -43) ((marker . 1) . -647) ((marker) . -615) ((marker) . -616) ((marker) . -619) ((marker) . -620) ((marker) . -623) ((marker) . -624) ((marker) . -627) ((marker) . -628) ((marker) . -631) ((marker) . -632) ((marker . 1) . -647) ((marker . 1) . -647) ((marker . 1) . -43) ((marker . 1) . -671) ((marker . 1) . -671) ((marker . 1) . -676) ((marker . 1) . -671) ((marker . 1) . -671) ((marker . 1) . -676) ((marker) . -632) ((marker) . -636) ((marker) . -632) ((marker) . -636) ((marker . 1) . -647) nil (616 . 633) ("        " . 616) ((marker) . -1) ((marker) . -4) ((marker) . -5) 639 (t 24235 36844 563400 191000) nil (" " . -640) ((marker . 647) . -1) 641 (638 . 641) (" +" . -638) ((marker . 647) . -1) 640 (639 . 640) (t 24235 36840 605935 911000) nil (646 . 659) ("num" . -646) ((marker . 647) . -3) 649 (638 . 649) ("=" . -638) 639 (629 . 639) (apply yas--snippet-revive 624 629 #s(yas--snippet nil nil #s(yas--exit 629 nil) 5 nil nil nil nil)) (apply yas--take-care-of-redo #s(yas--snippet nil nil #s(yas--exit 629 nil) 5 nil nil nil nil)) (624 . 629) ("." . 624) ((marker . 647) . -1) 625 nil (624 . 625) (614 . 624) (602 . 613) ("," . -602) 603 (602 . 603) (598 . 602) ("served" . -598) ((marker . 647) . -6) 604 (598 . 604) (597 . 598) ("(" . -597) (597 . 599) ("(" . -597) (577 . 598) ("    " . -577) ((marker . 647) . -4) 581 (573 . 581) ("        " . 572) ((marker . 647) . -8) (580 . 581) (571 . 580) (t 24235 36763 637384 84000) 528 nil (apply yas--snippet-revive 703 710 #s(yas--snippet nil nil #s(yas--exit 709 nil) 4 nil nil nil nil)) (apply yas--take-care-of-redo #s(yas--snippet nil nil #s(yas--exit 709 nil) 4 nil nil nil nil)) (703 . 710) ("p" . 703) ((marker . 647) . -1) 704 nil (703 . 704) (702 . 703) (701 . 702) (t 24235 36758 434356 276000) 677 nil (nil rear-nonsticky nil 730 . 731) ("
" . -755) (730 . 756) 726 (t 24235 36754 238800 417000) nil (1 . 731) ("#!/usr/bin/env python3


class Restaurant:
    \"\"\"Model of a restaurant.\"\"\"

    def __init__(self, name, cuisine):
        self.name = name.title()
        self.cuisine = cuisine.title()
        self.number_served = 0

    def describe_restaurant(self):
        print(
            f\"Name: {self.name}.\\nCuizine: {self.cuisine}.\"
            f\"\\nClients served: {self.number_served}\"
        )

    def open_restaurant(self):
        print(f\"{self.name} is open to business!\")

    def set_number_served(self, num_of_clients):
        self.number_served = num_of_clients


r1 = Restaurant(\"bar do careca\", \"baiana\")
r1.describe_restaurant()

print()

r1.number_served = 12000
r1.describe_restaurant()

r1.set_number_served(24000)" . 1) ((marker . 618) . -702) ((marker . 658) . -729) ((marker . 644) . -535) ((marker* . 648) . 1) ((marker . 1) . -676) ((marker . 1) . -676) ((marker . 1) . -648) ((marker . 1) . -648) ((marker . 1) . -648) ((marker . 1) . -116) ((marker . 1) . -647) ((marker . 1) . -647) ((marker . 1) . -77) ((marker . 1) . -275) ((marker . 1) . -335) ((marker . 1) . -76) ((marker . 1) . -477) ((marker . 1) . -477) ((marker . 1) . -477) ((marker . 1) . -477) ((marker . 1) . -477) ((marker . 1) . -477) ((marker . 1) . -76) ((marker . 1) . -477) ((marker . 1) . -477) ((marker . 1) . -76) ((marker . 78) . -25) ((marker . 644) . -477) ((marker . 647) . -727) ((marker . 1) . -477) ((marker . 1) . -477) ((marker . 1) . -477) ((marker . 1) . -477) ((marker . 1) . -477) ((marker . 1) . -477) ((marker . 1) . -477) ((marker . 1) . -477) ((marker . 1) . -477) ((marker . 1) . -477) ((marker . 1) . -477) ((marker . 1) . -477) ((marker . 1) . -477) ((marker . 1) . -477) ((marker . 1) . -477) ((marker . 1) . -477) ((marker . 1) . -477) ((marker . 1) . -477) ((marker . 1) . -477) ((marker . 1) . -477) ((marker . 1) . -477) ((marker . 1) . -477) ((marker* . 852) . 158) ((marker . 1) . -477) ((marker . 1) . -477) ((marker . 1) . -477) ((marker . 1) . -477) ((marker . 1) . -477) ((marker . 1) . -477) ((marker . 1) . -477) ((marker . 1) . -477) ((marker . 1) . -477) ((marker . 1) . -477) ((marker . 1) . -477) ((marker . 1) . -477) ((marker . 1) . -477) ((marker . 1) . -477) ((marker . 1) . -477) ((marker . 1) . -477) ((marker . 1) . -477) ((marker . 1) . -477) ((marker . 1) . -477) ((marker . 1) . -477) ((marker . 1) . -477) ((marker . 1) . -477) ((marker . 1) . -477) ((marker . 1) . -477) ((marker . 1) . -477) ((marker . 1) . -477) ((marker . 1) . -477) ((marker . 1) . -477) ((marker . 1) . -477) ((marker . 1) . -477) ((marker . 1) . -477) ((marker . 1) . -477) ((marker . 1) . -477) ((marker . 1) . -477) ((marker . 1) . -477) ((marker . 1) . -477) ((marker . 1) . -477) ((marker . 1) . -477) ((marker . 1) . -477) ((marker . 1) . -477) ((marker* . 852) . 158) ((marker . 1) . -477) ((marker . 1) . -477) ((marker . 1) . -477) ((marker . 1) . -477) ((marker . 1) . -477) ((marker . 1) . -477) ((marker . 1) . -477) ((marker . 1) . -477) ((marker . 1) . -477) ((marker . 1) . -477) ((marker . 1) . -477) ((marker . 1) . -477) ((marker . 1) . -477) ((marker . 1) . -477) ((marker . 1) . -477) ((marker . 1) . -477) ((marker . 1) . -477) ((marker . 1) . -477) ((marker . 1) . -477) ((marker . 1) . -648) ((marker . 1) . -535) ((marker . 1) . -535) ((marker*) . 1) ((marker) . -729) ((marker*) . 7) ((marker) . -723) 728 nil (724 . 729) nil (672 . 673) ("8" . 672) nil (706 . 725) ("se" . -706) ((marker . 658) . -2) ((marker . 647) . -2) 708 (703 . 708) (702 . 703) 702 nil ("num_of_client" . 571) (557 . 571) (524 . 525) ("num_of_clien" . 569) (556 . 569) (523 . 524) ("num_of_clie" . 567) (555 . 567) (522 . 523) ("num_of_cli" . 565) (554 . 565) (521 . 522) ("num_of_cl" . 563) (553 . 563) (520 . 521) ("num_of_c" . 561) (552 . 561) (519 . 520) ("num_of_" . 559) (551 . 559) (518 . 519) ("num_of" . 557) (550 . 557) (517 . 518) ("num_o" . 555) (549 . 555) (516 . 517) ("num_" . 553) (548 . 553) (515 . 516) ("num" . 551) (547 . 551) (514 . 515) ("nu" . 549) (546 . 549) (513 . 514) ("n" . 547) (545 . 547) (512 . 513) ("n" . 545) (544 . 545) (544 . 545) (511 . 512) ("clients" . 543) ("clients" . 511) (t 24235 36712 237057 424000) nil (509 . 518) ("," . -509) 510 (509 . 510) (t 24235 36708 907235 425000) nil ("        " . 549) 547 nil (541 . 548) (525 . 541) ("num" . -525) ((marker . 647) . -3) 528 (525 . 528) ("num:" . 525) nil (528 . 538) (525 . 528) (apply yas--snippet-revive 520 525 #s(yas--snippet nil nil #s(yas--exit 525 nil) 3 nil nil nil nil)) (apply yas--take-care-of-redo #s(yas--snippet nil nil #s(yas--exit 525 nil) 3 nil nil nil nil)) (520 . 525) ("." . 520) ((marker . 647) . -1) 521 nil (520 . 521) (511 . 520) (510 . 511) (507 . 509) ("f" . -507) ((marker . 647) . -1) 508 (504 . 508) ("(" . -504) (504 . 506) ("(" . -504) (504 . 505) (483 . 504) ("    " . -483) ((marker . 647) . -4) 487 (478 . 487) 478 nil ("
        " . 478) ((marker . 618) . -1) ((marker . 1) . -9) ((marker . 1) . -9) ((marker . 1) . -9) ((marker . 1) . -9) ((marker . 1) . -5) ((marker . 1) . -5) ((marker . 1) . -5) ((marker . 1) . -5) ((marker . 644) . -5) ((marker . 647) . -9) ((marker . 1) . -5) ((marker . 1) . -5) ((marker . 1) . -5) ((marker . 1) . -5) ((marker . 1) . -5) ((marker . 1) . -5) ((marker . 1) . -5) ((marker . 1) . -5) ((marker . 1) . -5) ((marker . 1) . -5) ((marker . 1) . -5) ((marker . 1) . -5) ((marker . 1) . -5) ((marker . 1) . -5) ((marker . 1) . -5) ((marker . 1) . -5) ((marker . 1) . -5) ((marker . 1) . -5) ((marker . 1) . -5) ((marker . 1) . -5) ((marker . 1) . -5) ((marker . 1) . -5) ((marker . 1) . -5) ((marker . 1) . -5) ((marker . 1) . -5) ((marker . 1) . -5) ((marker . 1) . -5) ((marker . 1) . -5) ((marker . 1) . -5) ((marker . 1) . -5) ((marker . 1) . -5) ((marker . 1) . -5) ((marker . 1) . -5) ((marker . 1) . -5) ((marker . 1) . -5) ((marker . 1) . -5) ((marker . 1) . -5) ((marker . 1) . -5) ((marker . 1) . -5) ((marker . 1) . -5) ((marker . 1) . -5) ((marker . 1) . -5) ((marker . 1) . -5) ((marker . 1) . -5) ((marker . 1) . -5) ((marker . 1) . -5) ((marker . 1) . -5) ((marker . 1) . -5) ((marker . 1) . -5) ((marker . 1) . -5) ((marker . 1) . -5) ((marker . 1) . -5) ((marker . 1) . -5) ((marker . 1) . -5) ((marker . 1) . -5) ((marker . 1) . -5) ((marker . 1) . -5) ((marker . 1) . -5) ((marker . 1) . -5) ((marker . 1) . -5) ((marker . 1) . -5) ((marker . 1) . -5) ((marker . 1) . -5) ((marker . 1) . -5) ((marker . 1) . -5) ((marker . 1) . -5) ((marker . 1) . -5) ((marker . 1) . -5) ((marker . 1) . -5) ((marker . 1) . -5) ((marker . 1) . -5) ((marker . 1) . -5) ((marker . 1) . -5) ((marker . 1) . -5) ((marker . 1) . -5) ((marker . 1) . -5) ((marker . 1) . -5) ((marker . 1) . -5) ((marker . 1) . -5) ((marker . 1) . -5) ((marker . 1) . -5) (483 . 487) ("def set_" . 483) ((marker . 1) . -7) ((marker . 1) . -7) ((marker . 1) . -7) ((marker . 1) . -7) ((marker . 644) . -7) ((marker . 647) . -7) ((marker . 1) . -8) ((marker . 1) . -8) ((marker . 1) . -8) ((marker . 1) . -8) ((marker . 1) . -8) ((marker . 1) . -8) ((marker . 1) . -8) ((marker . 1) . -8) ((marker . 1) . -8) ((marker . 1) . -8) ((marker . 1) . -8) ((marker . 1) . -8) ((marker . 1) . -8) ((marker . 1) . -8) ((marker . 1) . -8) ((marker . 1) . -8) ((marker . 1) . -8) ((marker . 1) . -8) ((marker . 1) . -8) ((marker . 1) . -8) ((marker . 1) . -8) ((marker . 1) . -8) ((marker . 1) . -8) ((marker . 1) . -8) ((marker . 1) . -8) ((marker . 1) . -8) ((marker . 1) . -8) ((marker . 1) . -8) ((marker . 1) . -8) ((marker . 1) . -8) ((marker . 1) . -8) ((marker . 1) . -8) ((marker . 1) . -8) ((marker . 1) . -8) ((marker . 1) . -8) ((marker . 1) . -8) ((marker . 1) . -8) ((marker . 1) . -8) ((marker . 1) . -8) ((marker . 1) . -8) ((marker . 1) . -8) ((marker . 1) . -8) ((marker . 1) . -8) ((marker . 1) . -8) ((marker . 1) . -8) ((marker . 1) . -8) ((marker . 1) . -8) ((marker . 1) . -8) ((marker . 1) . -8) ((marker . 1) . -8) ((marker . 1) . -8) ((marker . 1) . -8) ((marker . 1) . -8) ((marker . 1) . -8) ((marker . 1) . -8) ((marker . 1) . -8) ((marker . 1) . -8) ((marker . 1) . -8) ((marker . 1) . -8) ((marker . 1) . -8) ((marker . 1) . -8) ((marker . 1) . -8) ((marker . 1) . -8) ((marker . 1) . -8) ((marker . 1) . -8) ((marker . 1) . -8) ((marker . 1) . -8) ((marker . 1) . -8) ((marker . 1) . -8) ((marker . 1) . -8) ((marker . 1) . -8) ((marker . 1) . -8) ((marker . 1) . -8) ((marker . 1) . -8) ((marker . 1) . -8) ((marker . 1) . -8) ((marker . 1) . -8) ((marker . 1) . -8) ((marker . 1) . -8) ((marker . 1) . -8) ((marker . 1) . -8) (t 24235 36664 298483 806000) nil (490 . 491) (t 24235 36663 155829 34000) nil ("_" . 490) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1)) (emacs-undo-equiv-table (-24 . -36) (-21 . -39) (-20 . t) (-28 . -30) (-31 . -33) (-25 . -35) (-27 . -31) (-26 . -34) (-22 . -38) (-23 . -37)))