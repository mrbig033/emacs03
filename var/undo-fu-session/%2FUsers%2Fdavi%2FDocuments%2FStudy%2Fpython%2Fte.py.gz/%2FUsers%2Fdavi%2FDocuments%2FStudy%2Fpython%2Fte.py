((buffer-size . 111) (buffer-checksum . "f9a44551463e335459a67c7335116e43e605e10c"))
((emacs-pending-undo-list (32 . 110) (" \"aaaa\": \"bbbb\", \"aaaa\": \"bbbb\", \"aaaa\": \"bbbb\", \"aaaa\": \"bbbb\", \"aaaa\": \"bbbb\", " . 32) (32 . 113) ("
    \"aaaa\": \"bbbb\",
    \"aaaa\": \"bbbb\",
    \"aaaa\": \"bbbb\",
    \"aaaa\": \"bbbb\",
    \"aaaa\": \"bbbb\",
" . 32) ((marker . 112) . -1) (t 24237 832 689200 677000) nil (32 . 133) (" \"aaaa\": \"bbbb\", \"aaaa\": \"bbbb\", \"aaaa\": \"bbbb\", \"aaaa\": \"bbbb\", \"aaaa\": \"bbbb\"" . 32) (t 24237 827 645723 242000) (", " . 111) (t 24237 821 807008 575000) (32 . 113) ("\"aaaa\": \"bbbb\", \"aaaa\": \"bbbb\", \"aaaa\": \"bbbb\", \"aaaa\": \"bbbb\", \"aaaa\": \"bbbb\"" . -32) ((marker . 110) . -78) ((marker . 110) . -78) ((marker . 110) . -78) ((marker . 110) . -78) ((marker . 110) . -78) ((marker . 110) . -78) ((marker . 110) . -78) ((marker . 110) . -78) ((marker . 110) . -78) ((marker . 110) . -78) ((marker . 110) . -78) ((marker . 110) . -78) ((marker . 110) . -78) ((marker . 110) . -78) ((marker . 110) . -78) ((marker . 110) . -78) ((marker . 110) . -78) ((marker . 110) . -78) ((marker . 110) . -78) ((marker . 110) . -78) ((marker . 110) . -78) ((marker . 110) . -78) ((marker . 110) . -78) (t 24237 734 915604 6000) nil (1 . 112) ("#!/usr/bin/env python3


md = {
    \"aaaa\": \"bbbb\",
    \"aaaa\": \"bbbb\",
    \"aaaa\": \"bbbb\",
    \"aaaa\": \"bbbb\",
    \"aaaa\": \"bbbb\",
}
" . 1) (t 24237 731 3900 28000) nil (1 . 135) ("#!/usr/bin/env python3


md = {\"aaaa\": \"bbbb\", \"aaaa\": \"bbbb\", \"aaaa\": \"bbbb\", \"aaaa\": \"bbbb\", \"aaaa\": \"bbbb\"}
" . 1) 110 nil (1 . 112) ("#!/usr/bin/env python3


md = {
    \"aaaa\": \"bbbb\",
    \"aaaa\": \"bbbb\",
    \"aaaa\": \"bbbb\",
    \"aaaa\": \"bbbb\",
    \"aaaa\": \"bbbb\",
}
" . 1) (t 24237 726 864064 340000) nil (1 . 135) ("#!/usr/bin/env python3


md = {\"aaaa\": \"bbbb\", \"aaaa\": \"bbbb\", \"aaaa\": \"bbbb\", \"aaaa\": \"bbbb\", \"aaaa\": \"bbbb\"}
" . 1) 110 nil (1 . 112) ("#!/usr/bin/env python3


md = {
    \"aaaa\": \"bbbb\",
    \"aaaa\": \"bbbb\",
    \"aaaa\": \"bbbb\",
    \"aaaa\": \"bbbb\",
    \"aaaa\": \"bbbb\",
}
" . 1) (t 24237 725 531737 588000) nil (1 . 135) ("#!/usr/bin/env python3


md = {\"aaaa\": \"bbbb\", \"aaaa\": \"bbbb\", \"aaaa\": \"bbbb\", \"aaaa\": \"bbbb\", \"aaaa\": \"bbbb\"}
" . 1) 110 (t 24237 687 815860 291000)) (emacs-buffer-undo-list nil (1 . 112) ("#!/usr/bin/env python3


md = {
    \"aaaa\": \"bbbb\",
    \"aaaa\": \"bbbb\",
    \"aaaa\": \"bbbb\",
    \"aaaa\": \"bbbb\",
    \"aaaa\": \"bbbb\",
}
" . 1) ((marker . 26) . -92) ((marker . 112) . -112) ((marker) . -112) ((marker) . -113) ((marker) . -92) ((marker) . -93) ((marker) . -72) ((marker) . -73) ((marker) . -52) ((marker) . -53) ((marker) . -32) ((marker) . -33) ((marker . 1) . -109) ((marker . 1) . -109) ((marker . 1) . -109) ((marker . 1) . -109) ((marker . 1) . -109) ((marker . 1) . -109) ((marker . 31) . -109) ((marker . 110) . -109) ((marker . 1) . -109) ((marker . 1) . -109) (t 24237 898 496595 533000) nil (1 . 135) ("#!/usr/bin/env python3


md = {\"aaaa\": \"bbbb\", \"aaaa\": \"bbbb\", \"aaaa\": \"bbbb\", \"aaaa\": \"bbbb\", \"aaaa\": \"bbbb\"}
" . 1) ((marker . 26) . -25) ((marker . 112) . -111) ((marker . 110) . -109) ((marker . 110) . -109) ((marker . 110) . -109) ((marker . 110) . -109) ((marker . 110) . -109) ((marker . 110) . -109) ((marker . 110) . -109) ((marker . 110) . -109) ((marker . 110) . -109) ((marker . 110) . -109) ((marker . 110) . -109) ((marker . 110) . -109) ((marker . 110) . -109) ((marker . 110) . -109) ((marker . 110) . -109) ((marker . 110) . -109) ((marker . 110) . -109) ((marker . 110) . -109) ((marker . 110) . -109) ((marker . 110) . -109) ((marker . 110) . -109) ((marker . 110) . -109) ((marker . 110) . -109) ((marker . 31) . -30) ((marker . 110) . -109) ((marker* . 110) . 2) ((marker . 111) . -110) ((marker* . 31) . 81) ((marker . 32) . -31) 110 nil (32 . 110) (" \"aaaa\": \"bbbb\", \"aaaa\": \"bbbb\", \"aaaa\": \"bbbb\", \"aaaa\": \"bbbb\", \"aaaa\": \"bbbb\", " . 32) (32 . 113) ("
    \"aaaa\": \"bbbb\",
    \"aaaa\": \"bbbb\",
    \"aaaa\": \"bbbb\",
    \"aaaa\": \"bbbb\",
    \"aaaa\": \"bbbb\",
" . 32) ((marker . 112) . -1) (t 24237 832 689200 677000) nil (32 . 133) (" \"aaaa\": \"bbbb\", \"aaaa\": \"bbbb\", \"aaaa\": \"bbbb\", \"aaaa\": \"bbbb\", \"aaaa\": \"bbbb\"" . 32) (t 24237 827 645723 242000) (", " . 111) (t 24237 821 807008 575000) (32 . 113) ("\"aaaa\": \"bbbb\", \"aaaa\": \"bbbb\", \"aaaa\": \"bbbb\", \"aaaa\": \"bbbb\", \"aaaa\": \"bbbb\"" . -32) ((marker . 110) . -78) ((marker . 110) . -78) ((marker . 110) . -78) ((marker . 110) . -78) ((marker . 110) . -78) ((marker . 110) . -78) ((marker . 110) . -78) ((marker . 110) . -78) ((marker . 110) . -78) ((marker . 110) . -78) ((marker . 110) . -78) ((marker . 110) . -78) ((marker . 110) . -78) ((marker . 110) . -78) ((marker . 110) . -78) ((marker . 110) . -78) ((marker . 110) . -78) ((marker . 110) . -78) ((marker . 110) . -78) ((marker . 110) . -78) ((marker . 110) . -78) ((marker . 110) . -78) ((marker . 110) . -78) (t 24237 734 915604 6000) nil (1 . 112) ("#!/usr/bin/env python3


md = {
    \"aaaa\": \"bbbb\",
    \"aaaa\": \"bbbb\",
    \"aaaa\": \"bbbb\",
    \"aaaa\": \"bbbb\",
    \"aaaa\": \"bbbb\",
}
" . 1) (t 24237 731 3900 28000) nil (1 . 135) ("#!/usr/bin/env python3


md = {\"aaaa\": \"bbbb\", \"aaaa\": \"bbbb\", \"aaaa\": \"bbbb\", \"aaaa\": \"bbbb\", \"aaaa\": \"bbbb\"}
" . 1) 110 nil (1 . 112) ("#!/usr/bin/env python3


md = {
    \"aaaa\": \"bbbb\",
    \"aaaa\": \"bbbb\",
    \"aaaa\": \"bbbb\",
    \"aaaa\": \"bbbb\",
    \"aaaa\": \"bbbb\",
}
" . 1) (t 24237 726 864064 340000) nil (1 . 135) ("#!/usr/bin/env python3


md = {\"aaaa\": \"bbbb\", \"aaaa\": \"bbbb\", \"aaaa\": \"bbbb\", \"aaaa\": \"bbbb\", \"aaaa\": \"bbbb\"}
" . 1) 110 nil (1 . 112) ("#!/usr/bin/env python3


md = {
    \"aaaa\": \"bbbb\",
    \"aaaa\": \"bbbb\",
    \"aaaa\": \"bbbb\",
    \"aaaa\": \"bbbb\",
    \"aaaa\": \"bbbb\",
}
" . 1) (t 24237 725 531737 588000) nil (1 . 135) ("#!/usr/bin/env python3


md = {\"aaaa\": \"bbbb\", \"aaaa\": \"bbbb\", \"aaaa\": \"bbbb\", \"aaaa\": \"bbbb\", \"aaaa\": \"bbbb\"}
" . 1) 110 (t 24237 687 815860 291000)) (emacs-undo-equiv-table (-1 . -3) (1 . -1)))