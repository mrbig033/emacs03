((buffer-size . 2347) (buffer-checksum . "92a8fecdac55e3ccd2c1641258c33e26afa4b6c7"))
((emacs-pending-undo-list (14356 . 14357) ("0" . 14356) (t 24241 16457 109145 72000) nil (14356 . 14357) ("8" . 14356) (t 24241 8919 239262 585000) nil (82246 . 83151) ("(defhydra hydra-org-clock (:color blue :hint nil :exit nil :foreign-keys nil)
  \"

    _i_: in    _m_: recent   _e_: set effort  ^_r_: timer
    _o_: out   _c_: cancel   _a_: change \\\"    _ps_: pomo strt
    _l_: last  _s_: started  _d_: done        ^_pg_: pomo goto
    _y_: show  _t_: todo     _g_: goto        ^_pp_: pomo only
\"

  (\"q\" nil)
  (\"<escape>\" nil)

  (\"i\" org-clock-in)
  (\"o\" org-clock-out)
  (\"l\" org-clock-in-last)
  (\"c\" org-clock-cancel)
  (\"y\" org-clock-display)
  (\"y\" org-clock-display)
  (\"m\" org-mru-clock-in)
  (\"e\" org-set-effort)
  (\"a\" org-clock-modify-effort-estimate)
  (\"s\" my-org-started-with-clock)
  (\"S\" my-org-started-no-clock)
  (\"d\" my-org-todo-done)
  (\"t\" my-org-todo)
  (\"g\" org-clock-goto)
  (\"r\" hydra-org-timer/body)
  (\"ps\" my-org-started-with-pomodoro)
  (\"pg\" my-org-goto-clock-and-start-pomodoro)
  (\"pd\" my-org-todo-done-pomodoro)
  (\"pp\" org-pomodoro))
" . 82246) ((marker) . -485) ((marker) . -485) 82731 nil (82730 . 82756) 82712 nil ("^" . 94960) nil (94960 . 94961) ("^" . -94960) ((marker) . -1) (94960 . 94961) ("ˆ" . -94960) ((marker) . -1) 94961 (94960 . 94961) ("^" . -94960) ((marker) . -1) (94960 . 94961) (t 24241 8655 699938 186000) nil (94521 . 95039) ("(use-package avy
  :defer nil
  :ensure t
  :config
  (setq avy-case-fold-search 't
        avy-style 'at-full
        avy-timeout-seconds 0.5
        avy-highlight-first t
        avy-single-candidate-jump t
        avy-background t
        avy-styles-alist '((avy-goto-line . at))

        avy-keys (nconc (number-sequence ?a ?z)
                        ;; (number-sequence ?0 ?9)
                        ))

  (setq avy-all-windows nil)

  (custom-set-faces
   '(avy-background-face ((t (:foreground \"SkyBlue\"))))))
" . 94521) 95040 (t 24241 8654 454179 718000) nil (94521 . 95040) ("(use-package avy
  :defer nil
  :ensure t
  :config
  (setq avy-case-fold-search 't
        avy-style 'at-full
        avy-timeout-seconds 0.5
        avy-highlight-first t
        avy-single-candidate-jump t
        avy-background t
        avy-styles-alist '((avy-goto-line . at))

        avy-keys (nconc (number-sequence ?a ?z)
                        (number-sequence ?0 ?9))

        )

  (setq avy-all-windows nil)

  (custom-set-faces
   '(avy-background-face ((t (:foreground \"SkyBlue\"))))))
" . 94521) 95022 (t 24241 8643 514067 419000) nil (94521 . 95022) ("(use-package avy
  :defer nil
  :ensure t
  :config
  (setq avy-case-fold-search 't
        avy-style 'at-full
        avy-timeout-seconds 0.5
        avy-highlight-first t
        avy-single-candidate-jump t
        avy-background t
        avy-styles-alist '((avy-goto-line . at))
        avy-keys (nconc (number-sequence ?a ?z)
                        (number-sequence ?0 ?9))

        )

  (setq avy-all-windows nil)

  (custom-set-faces
   '(avy-background-face ((t (:foreground \"SkyBlue\"))))))
" . 94521) 95021 (t 24241 8641 565695 999000) nil (94521 . 95021) ("(use-package avy
  :defer nil
  :ensure t
  :config
  (setq avy-case-fold-search 't
        avy-style 'at-full
        avy-timeout-seconds 0.5
        avy-highlight-first t
        avy-single-candidate-jump t
        avy-background t
        avy-styles-alist '((avy-goto-line . at))
        avy-keys (nconc (number-sequence ?a ?z)
                        (number-sequence ?0 ?9)))

  (setq avy-all-windows nil)

  (custom-set-faces
   '(avy-background-face ((t (:foreground \"SkyBlue\"))))))
" . 94521) 94536 (t 24241 8401 884210 815000) nil (126193 . 137201) ("(use-package company
  :defer t
  :config
  (general-define-key
   :keymaps   'company-active-map
   \"C-n\"      'company-select-next
   \"S-SPC\" 'company-select-next
   \"C-p\"      'company-select-previous
   \"C-j\"      nil
   \"C-k\"      'company-abort
   \"M--\"      'my-company-comp-first-with-dash
   \"M-=\"      'my-company-comp-first-with-equal
   \"M-q\"      'my-company-comp-first
   \"M-w\"      'my-company-comp-first-with-paren
   \"M-e\"      'my-company-comp-with-paren
   \"M-.\"      'my-company-comp-with-dot
   \"M-f\"      'my-company-comp-first-with-square-bracket
   \"M-j\"      'my-company-comp-first-space
   \"C-j\"      'company-complete
   \"<return>\" 'company-complate
   \"C-l\"      nil
   \"M-r\"      'company-filter-candidates
   \"RET\"      nil
   \"<escape>\" 'company-abort
   ;; \"<escape>\" nil
   \"<tab>\"    'my-company-yasnippet
   \"C-h\"      'delete-backward-char

   \"M-1\"      'company-complete-number
   \"M-2\"      'company-complete-number
   \"M-3\"      'company-complete-number
   \"M-4\"      'company-complete-number
   \"M-5\"      'company-complete-number
   \"M-6\"      'company-complete-number
   \"M-7\"      'company-complete-number
   \"M-8\"      'company-complete-number
   \"M-9\"      'company-complete-number
   \"M-0\"      'company-complete-number

   \"C-1\"      'company-complete-number
   \"C-2\"      'company-complete-number
   \"C-3\"      'company-complete-number
   \"C-4\"      'company-complete-number
   \"C-5\"      'company-complete-number
   \"C-6\"      'company-complete-number
   \"C-7\"      'company-complete-number
   \"C-8\"      'company-complete-number
   \"C-9\"      'company-complete-number
   \"C-0\"      'company-complete-number
   \"C-w\"      'evil-delete-backward-word)

  (general-define-key
   :keymaps   'company-filter-map
   \"C-n\"      nil
   \"C-p\"      nil
   \"M-q\"      'company-complete
   \"M-w\"      'company-complete
   \"M-e\"      'company-complete
   \"M-r\"      'company-complete
   \"M-d\"      'company-complete
   \"<return>\" 'company-complete
   \"RET\"      'company-complete
   \"<tab>\"    'company-complete
   \"<escape>\" 'company-abort
   \"C-h\"      'delete-backward-char

   \"M-1\"      'company-complete-number
   \"M-2\"      'company-complete-number
   \"M-3\"      'company-complete-number
   \"M-4\"      'company-complete-number
   \"M-5\"      'company-complete-number
   \"M-6\"      'company-complete-number
   \"M-7\"      'company-complete-number
   \"M-8\"      'company-complete-number
   \"M-9\"      'company-complete-number
   \"M-0\"      'company-complete-number

   \"C-1\"      'company-complete-number
   \"C-2\"      'company-complete-number
   \"C-3\"      'company-complete-number
   \"C-4\"      'company-complete-number
   \"C-5\"      'company-complete-number
   \"C-6\"      'company-complete-number
   \"C-7\"      'company-complete-number
   \"C-8\"      'company-complete-number
   \"C-9\"      'company-complete-number
   \"C-0\"      'company-complete-number
   \"C-w\"      'evil-delete-backward-word)

  (general-imap
    :keymaps 'company-mode-map
    \"S-SPC\" 'company-complete
    \"M-/\" 'hippie-expand)

  (setq company-show-numbers t
        company-idle-delay 0.3
        company-tooltip-limit 10
        company-auto-complete nil
        company-auto-complete-chars '(46)
        company-dabbrev-other-buffers t
        company-selection-wrap-around t
        company-minimum-prefix-length 2
        company-dabbrev-code-everywhere nil
        company-dabbrev-downcase nil
        company-dabbrev-code-ignore-case t
        company-tooltip-align-annotations 't
        company-dabbrev-ignore-case 'keep-prefix
        company-begin-commands '(self-insert-command)
        company-dabbrev-ignore-buffers \"\\\\`[ *]\")

;;;; BACKENDS ;;;;

  (setq-default company-backends '(company-semantic
                                   company-clang
                                   company-cmake
                                   company-capf
                                   company-files
                                   (company-dabbrev-code company-keywords)
                                   company-dabbrev
                                   company-shell))

;;;; FUNCTIONS ;;;;

  (defun my-company-comp-space ()
    (interactive)
    (company-complete)
    (insert \" \"))

  (defun my-company-comp-first-space
      (interactive)
    (company-select-next)
    (company-complete)
    (insert \" \"))

  (defun my-company-comp-first-with-paren ()
    (interactive)
    (company-select-next)
    (company-complete)
    (insert \"()\")
    (backward-char))

  (defun my-company-comp-first-with-equal ()
    (interactive)
    (company-select-next)
    (company-complete)
    (insert \" = \")
    (company-complete))

  (defun my-company-comp-first-with-dash ()
    (interactive)
    (company-select-next)
    (company-complete)
    (insert \"-\")
    (company-complete))

  (defun my-company-comp-with-dot ()
    (interactive)
    (company-select-next)
    (company-complete)
    (insert \".\")
    (company-complete))

  (defun my-company-comp-with-paren ()
    (interactive)
    (company-complete)
    (insert \"()\")
    (backward-char))

  (defun my-company-comp-first-with-square-bracket ()
    (interactive)
    (company-select-next)
    (company-complete)
    (insert \"[\\\"\\\"]\")
    (backward-char 2))

  (defun my-company-comp-with-square-bracket ()
    (interactive)
    (company-complete)
    (insert \"[]\")
    (backward-char))

  (defun my-company-comp-colon ()
    (interactive)
    (company-select-next)
    (company-complete)
    (insert \": \"))

  (defun my-company-comp-colon-semicolon ()
    (interactive)
    (company-select-next)
    (company-complete)
    (insert \": ;\")
    (backward-char))

  (defun my-company-comp-first ()
    (interactive)
    (company-select-next)
    (company-complete))

  (defun my-company-comp-first-space ()
    (interactive)
    (company-select-next)
    (company-complete)
    (insert \" \"))

  (defun my-company-comp-first-comint ()
    (interactive)
    (company-select-next)
    (company-complete)
    (comint-send-input))

  (defun my-company-comp-comint ()
    (interactive)
    (company-complete)
    (comint-send-input))

  (defun my-company-yasnippet ()
    (interactive)
    (company-abort)
    (yas-expand))

  (defun my-company-abort-tab ()
    (interactive)
    (company-abort)
    (forward-char))

;;;; TOGGLES ;;;;

  (defun my-company-show-options ()
    (interactive)
    (counsel-M-x \"^my-company-idle-\"))

  (defun my-company-show-delay ()
    (interactive)
    (describe-variable 'company-idle-delay))

  (defun my-company-show-prefix-length ()
    (interactive)
    (describe-variable 'company-minimum-prefix-length))

  (defun my-company-idle-zero-prefix-one ()
    (interactive)
    (setq-local company-idle-delay 0.0)
    (setq-local company-minimum-prefix-length 1)
    (message \"idle delay: 0, minimun prefix length: 1\"))

  (defun my-company-idle-zero-prefix-one-quiet ()
    (interactive)
    (setq-local company-idle-delay 0.0)
    (setq-local company-minimum-prefix-length 1))

  (defun my-company-idle-zero-prefix-two ()
    (interactive)
    (setq-local company-idle-delay 0.0)
    (setq-local company-minimum-prefix-length 2)
    (message \"idle delay: 0, minimun prefix length: 2\"))

  (defun my-company-idle-zero-prefix-two-quiet ()
    (interactive)
    (setq-local company-idle-delay 0.0)
    (setq-local company-minimum-prefix-length 2))

  (defun my-company-idle-one-prefix-one ()
    (interactive)
    (setq-local company-idle-delay 0.1)
    (setq-local company-minimum-prefix-length 1)
    (message \"idle delay: 0.1, minimun prefix length: 1\"))

  (defun my-company-idle-one-prefix-one-quiet ()
    (interactive)
    (setq-local company-idle-delay 0.1)
    (setq-local company-minimum-prefix-length 1))

  (defun my-company-idle-one-prefix-two ()
    (interactive)
    (setq-local company-idle-delay 0.1)
    (setq-local company-minimum-prefix-length 2)
    (message \"idle delay: 0.1, minimun prefix length: 2\"))

  (defun my-company-idle-one-prefix-two-quiet ()
    (interactive)
    (setq-local company-idle-delay 0.1)
    (setq-local company-minimum-prefix-length 2))

  (defun my-company-idle-two-prefix-one ()
    (interactive)
    (setq-local company-idle-delay 0.2)
    (setq-local company-minimum-prefix-length 1)
    (message \"idle delay: 0.2, minimun prefix length: 1\"))

  (defun my-company-idle-two-prefix-two ()
    (interactive)
    (setq-local company-idle-delay 0.2)
    (setq-local company-minimum-prefix-length 2)
    (message \"idle delay: 0.2, minimun prefix length: 2\"))

  (defun my-company-idle-two-prefix-two-quiet ()
    (interactive)
    (setq-local company-idle-delay 0.2)
    (setq-local company-minimum-prefix-length 2))

  (defun my-company-idle-two-prefix-one-quiet ()
    (interactive)
    (setq-local company-idle-delay 0.2)
    (setq-local company-minimum-prefix-length 1))

  (defun my-company-idle-three-prefix-one ()
    (interactive)
    (setq-local company-idle-delay 0.3)
    (setq-local company-minimum-prefix-length 1)
    (message \"idle delay: 0.3, minimun prefix length: 1\"))

  (defun my-company-idle-three-prefix-one-quiet ()
    (interactive)
    (setq-local company-idle-delay 0.3)
    (setq-local company-minimum-prefix-length 1))

  (defun my-company-idle-three-prefix-two ()
    (interactive)
    (setq-local company-idle-delay 0.3)
    (setq-local company-minimum-prefix-length 2)
    (message \"idle delay: 0.3, minimun prefix length: 2\"))

  (defun my-company-idle-three-prefix-three-quiet ()
    (interactive)
    (setq-local company-idle-delay 0.3)
    (setq-local company-minimum-prefix-length 3))

  (defun my-company-idle-four-prefix-two ()
    (interactive)
    (setq-local company-idle-delay 0.4)
    (setq-local company-minimum-prefix-length 2)
    (message \"idle delay: 0.4, minimun prefix length: 2\"))

  (defun my-company-idle-four-prefix-two-silent ()
    (interactive)
    (setq-local company-idle-delay 0.4)
    (setq-local company-minimum-prefix-length 2))

  (defun my-company-idle-five-prefix-two ()
    (interactive)
    (setq-local company-idle-delay 0.5)
    (setq-local company-minimum-prefix-length 2)
    (message \"idle delay: 0.5, minimun prefix length: 2\"))

  (defun my-company-idle-five-prefix-two-silent ()
    (interactive)
    (setq-local company-idle-delay 0.5))

  (defun my-company-idle-five-prefix-three-silent ()
    (interactive)
    (setq-local company-idle-delay 0.5)
    (setq-local company-minimum-prefix-length 3))

  (defun my-company-idle-five-prefix-four ()
    (interactive)
    (setq-local company-idle-delay 0.5)
    (setq-local company-minimum-prefix-length 4)
    (message \"idle delay: 0.5, minimun prefix length: 2\"))

  (defun my-company-idle-five-prefix-four-silent ()
    (interactive)
    (setq-local company-idle-delay 0.5)
    (setq-local company-minimum-prefix-length 4))

  (defun my-company-idle-five-prefix-three ()
    (interactive)
    (setq-local company-idle-delay 0.5)
    (setq-local company-minimum-prefix-length 3)
    (message \"idle delay: 0.5, minimun prefix length: 2\")))
" . 126193) 126209 (t 24241 6841 619373 608000) nil (48405 . 48777) ("(straight-use-package '(apheleia :host github :repo \"raxod502/apheleia\"))

(setq apheleia-formatters '((black \"black\" \"-\")
                            (brittany \"brittany\" file)
                            (prettier npx \"prettier\" file)
                            (gofmt \"gofmt\")
                            (terraform \"terraform\" \"fmt\" \"-\")))

;; (apheleia-global-mode +1)
" . 48405) 48761 (t 24241 6363 709988 792000) nil (52378 . 52880) ("(use-package unkillable-scratch
  :config
  (setq unkillable-scratch-behavior 'bury
        unkillable-buffers '(\"^\\\\*scratch\\\\*$\"
                             \"^init.org$\"
                             \"^agenda.org$\"
                             \"^pytasks.org$\"
                             \"^sct.py$\"
                             \"*Racket REPL*\"))

  ;; http://bit.ly/332kLj9
  (defun my-create-scratch-buffer nil
    (interactive)
    (switch-to-buffer (get-buffer-create \"*scratch*\"))
    (lisp-interaction-mode))

  (unkillable-scratch))
" . 52378) 52394 (t 24241 6033 431805 871000) nil (27875 . 31652) ("(use-package general
  :config

  (general-translate-key nil 'override \"<pause>\" \"SPC\")

  (general-evil-setup t)

  (general-define-key
   :keymaps  'global
   \"M-p\" 'backward-paragraph
   \"M-n\" 'forward-paragraph
   \"M-q\" 'eyebrowse-prev-window-config
   \"M-w\" 'eyebrowse-next-window-config
   \"M-7\" 'make-frame
   \"M-8\" 'other-frame
   \"M-9\"     'delete-other-windows
   \"M-0\"     'quit-window
   \"C-c P\" 'counsel-projectile-mode
   \"C-c f\"   'font-lock-mode
   \"C-x d\"   'toggle-debug-on-error
   \"C-_\" 'undo-fu-only-undo
   \"<mouse-8>\" 'nswbuff-switch-to-next-buff
   \"<mouse-2>\" 'my-kill-this-buffer
   \"C-c S\"   'my-emacs-session
   \"C-c -\"   'my-recenter-window
   \"C-;\"     'helpful-at-point
   \"C-:\"     'helpful-variable
   \"C-c C-o\" 'org-open-at-point-global
   \"C-x p\"   'my-goto-package)

  (general-define-key
   :keymaps  'override
   \"C-x n\" 'recursive-narrow-or-widen-dwim
   \"C-c s\" 'my-shell-full
   \"C-c v\"   'yank
   \"C-x r\" 'kill-ring-save
   \"C-x c\" 'quick-calc
   \"C-c i\" 'pbcopy
   \"§\" 'helm-resume
   \"C-S-s\" 'helm-resume
   \"C-s\" 'helm-swoop-without-pre-input
   \"C--\" 'helm-swoop
   \"C-c u\" 'revert-buffer
   \"M-'\"    'delete-window
   \"M-r\" 'ivy-switch-buffer
   \"M-;\" 'counsel-projectile-switch-to-buffer
   \"M-s\" 'last-buffer
   \"C-x s\" 'my-shell-below
   \"M-ç\" 'insert-char
   \"C-0\"     'evil-execute-macro
   \"C-c 0\"     'evil-execute-macro
   \"M-y\" 'my-yank-pop
   \"C-,\"     'evil-window-prev
   \"C-.\"     'evil-window-next
   \"C-/\"     'my-term-below
   \"C-c F s\" 'my-show-server
   \"C-x P\"   'hydra-python-mode/body
   \"C-c ç\"   'my-bash-shebang
   \"C-c k\"   'kill-buffer-and-window
   \"C-9\"     'evil-commentary-line)

  (defun my-insert-checkmark ()
    (interactive)
    (insert \"\"))

  (general-define-key
   :keymaps  'override
   :states   '(normal visual)
   \"C-SPC\" 'fix-word-upcase
   \"X\" 'whack-whitespace)

  (general-define-key
   :states   '(insert)
   :keymaps   'override
   \"C-SPC\" 'fix-word-upcase
   \"C-@\" 'fix-word-upcase
   \"C-S-SPC\" 'fix-word-capitalize
   \"C-c u\" 'universal-argument)

  (general-define-key
   :states   '(insert)
   :keymaps   'override
   \"C-c u\" 'universal-argument)

  (general-define-key
   :states   '(normal visual insert)
   \"<f12>\"   'man
   \"M-9\"     'delete-other-windows
   \"M-0\"     'quit-window
   \"C-c a\"   'align-regexp
   \"C-c e\"   'my-eval-buffer
   ;; \"C-c o\"    'helm-org-in-buffer-headings
   )
    ;;;; LEADER ;;;;
  (general-create-definer leader
    :prefix \"SPC\")

  (leader
    :states  '(normal visual)
    :keymaps 'override
    \";\"      'my-eval-buffer
    \"u\"      'hydra-projectile-mode/body
    \"p\"      'hydra-packages/body
    \"h\"      'my-org-hooks
    \"e\"      'visible-mode
    \",\"      'olivetti-mode
    \"\\\\\"     'org-babel-tangle
    \"/\"     'org-babel-tangle
    \".\"      'my-tangle-py-init.org-only
    \"-\"      'my-tangle-py-init.org-only-and-quit-window
    \"d\"      'my-dup-line
    \"m\"      'hydra-modes/body
    \"s\"      'hydra-search/body
    \"c\"      'hydra-commands/body
    \"SPC\"    'hydra-text-main/body
    \"z\"      'hydra-window/body
    \"i\"      'hydra-find-file/body
    \"0\"      'delete-window
    \"a\"      'counsel-M-x
    \"f\"      'counsel-find-file
    \"j\"      'hydra-org-clock/body
    \"g\"      'counsel-grep
    \"R\"      'eyebrowse-rename-window-config
    \"r\"      'my-ranger-deer
    \"k\"      'hydra-kill/body
    \"q\"      'my-kill-this-buffer
    \"o\"      'hydra-org-mode/body
    \"F\"      'my-reopen-killed-file
    \"t\"      'counsel-buffer-or-recentf
    \"T\"      'my-reopen-killed-file-fancy
    \"l\"      'hydra-tangle/body
    \"w\"      'widenToCenter
    \"W\"      'widenToCenter
    ;; \"n\"      'recursive-narrow-or-widen-dwim
    \"n\"      'org-narrow-to-subtree)

  (general-unbind 'global
    :with 'undo-tree-redo
    [remap redo]))
" . 27875) 31658 (t 24241 6025 704756 5000) nil (27875 . 31658) ("(use-package general
  :config

  (general-translate-key nil 'override \"<pause>\" \"SPC\")

  (general-evil-setup t)

  (general-define-key
   :keymaps  'global
   \"M-p\" 'backward-paragraph
   \"M-n\" 'forward-paragraph
   \"M-q\" 'eyebrowse-prev-window-config
   \"M-w\" 'eyebrowse-next-window-config
   \"M-7\" 'make-frame
   \"M-8\" 'other-frame
   \"M-9\"     'delete-other-windows
   \"M-0\"     'quit-window
   \"C-c P\" 'counsel-projectile-mode
   \"C-c f\"   'font-lock-mode
   \"C-x d\"   'toggle-debug-on-error
   \"C-_\" 'undo-fu-only-undo
   \"<mouse-8>\" 'nswbuff-switch-to-next-buff
   \"<mouse-2>\" 'my-kill-this-buffer
   \"C-c S\"   'my-emacs-session
   \"C-c -\"   'my-recenter-window
   \"C-;\"     'helpful-at-point
   \"C-:\"     'helpful-variable
   \"C-c C-o\" 'org-open-at-point-global
   \"C-x p\"   'my-goto-package)

  (general-define-key
   :keymaps  'override
   \"C-x n\" 'recursive-narrow-or-widen-dwim
   \"C-c s\" 'my-shell-full
   \"C-c v\"   'yank
   \"C-x r\" 'kill-ring-save
   \"C-x c\" 'quick-calc
   \"C-c i\" 'pbcopy
   \"§\" 'helm-resume
   \"C-S-s\" 'helm-resume
   \"C-s\" 'helm-swoop-without-pre-input
   \"C--\" 'helm-swoop
   \"C-c u\" 'revert-buffer
   \"M-'\"    'delete-window
   \"M-r\" 'ivy-switch-buffer
   \"M-;\" 'counsel-projectile-switch-to-buffer
   \"M-s\" 'last-buffer
   \"C-x s\" 'my-shell-below
   \"M-ç\" 'insert-char
   \"C-0\"     'evil-execute-macro
   \"C-c 0\"     'evil-execute-macro
   \"M-y\" 'my-yank-pop
   \"C-,\"     'evil-window-prev
   \"C-.\"     'evil-window-next
   \"C-/\"     'my-term-below
   \"C-c F s\" 'my-show-server
   \"C-x P\"   'hydra-python-mode/body
   \"C-c ç\"   'my-bash-shebang
   \"C-c k\"   'kill-buffer-and-window
   \"C-9\"     'evil-commentary-line)

  (defun my-insert-checkmark ()
    (interactive)
    (insert \"\"))

  (general-define-key
   :keymaps  'override
   :states   '(normal visual)
   \"C-SPC\" 'fix-word-upcase
   \"X\" 'whack-whitespace)

  (general-define-key
   :states   '(insert)
   :keymaps   'override
   \"C-SPC\" 'fix-word-upcase
   \"C-@\" 'fix-word-upcase
   \"C-S-SPC\" 'fix-word-capitalize
   \"C-c u\" 'universal-argument)

  (general-define-key
   :states   '(insert)
   :keymaps   'override
   \"C-c u\" 'universal-argument)

  (general-define-key
   :states   '(normal visual insert)
   \"<f12>\"   'man
   \"M-9\"     'delete-other-windows
   \"M-0\"     'quit-window
   \"C-c a\"   'align-regexp
   \"C-c e\"   'my-eval-buffer
   ;; \"C-c o\"    'helm-org-in-buffer-headings
   )
    ;;;; LEADER ;;;;
  (general-create-definer leader
    :prefix \"SPC\")

  (leader
    :states  '(normal visual)
    :keymaps 'override
    \";\"      'my-eval-buffer
    \"u\"      'hydra-projectile-mode/body
    \"p\"      'hydra-packages/body
    \"h\"      'my-org-hooks
    \"e\"      'visible-mode
    \",\"      'olivetti-mode
    \"\\\\\"     'org-babel-tangle
    \"/\"     'org-babel-tangle
    \".\"      'my-tangle-py-init.org-only
    \"-\"      'my-tangle-py-init.org-only-and-quit-window
    \"d\"      'my-dup-line
    \"m\"      'hydra-modes/body
    \"s\"      'hydra-search/body
    \"c\"      'hydra-commands/body
    \"SPC\"    'hydra-text-main/body
    \"z\"      'hydra-window/body
    \"i\"      'hydra-find-file/body
    \"0\"      'delete-window
    \"a\"      'counsel-M-x
    \"f\"      'counsel-find-file
    \"j\"      'hydra-org-clock/body
    \"g\"      'counsel-grep
    \"R\"      'eyebrowse-rename-window-config
    \"r\"      'my-ranger-deer
    \"k\"      'hydra-kill/body
    \"q\"      'my-kill-this-buffer
    \"o\"      'hydra-org-mode/body
    \"F\"      'my-reopen-killed-file
    \"t\"      'counsel-buffer-or-recentf
    \"T\"      'my-reopen-killed-file-fancy
    \"l\"      'hydra-tangle/body
    \"w\"      'widenToCenter
    \"W\"      'widenToCenter
    ;; \"n\"      'recursive-narrow-or-widen-dwim
    \"n\"      'org-narrow-to-subtree)

  (general-unbind 'global
    :with 'undo-tree-redo
    [remap redo]))
" . 27875) 28928 (t 24241 5981 653860 139000) nil (162228 . 169943) ("(use-package python
  :ensure nil
  :init
  (add-hook 'python-mode-hook 'my-python-hooks)
  (add-hook 'inferior-python-mode-hook 'my-inferior-python-mode-hooks)

  ;; https://stackoverflow.com/a/6141681
  ;; (add-hook 'python-mode-hook
  ;;           (lambda ()
  ;;             (add-hook 'write-contents-functions (lambda() (elpy-black-fix-code)) nil t)))

  :config
  (font-lock-add-keywords 'python-mode
                          '((\"cls\" . font-lock-keyword-face)))
  (setq python-shell-interpreter \"python3\")
  (setq python-shell-interpreter-args \"-i -q\")

  (setq python-shell-completion-native-enable nil)

  (defun my-python-hooks ()
    (interactive)
    (flymake-mode -1)
    (toggle-truncate-lines +1)
    (electric-operator-mode +1)
    (flycheck-mode +1)
    (rainbow-delimiters-mode +1)
    (highlight-operators-mode +1)
    (evil-swap-keys-swap-double-single-quotes)
    (evil-swap-keys-swap-underscore-dash)
    (evil-swap-keys-swap-colon-semicolon)
    (smartparens-strict-mode +1)
    (my-company-idle-one-prefix-one-quiet)
    (highlight-numbers-mode +1)
    (yafolding-mode +1)
    (apheleia-mode +1)
    (importmagic-mode +1)
    (elpy-enable +1))

  (defun my-inferior-python-mode-hooks ()
    (interactive)
    (electric-operator-mode +1)
    (flycheck-mode +1)
    (rainbow-delimiters-mode +1)
    (highlight-operators-mode +1)
    (evil-swap-keys-swap-double-single-quotes)
    (evil-swap-keys-swap-underscore-dash)
    (evil-swap-keys-swap-colon-semicolon)
    (smartparens-strict-mode +1)
    (my-company-idle-one-prefix-one-quiet)
    (company-mode +1)
    (highlight-numbers-mode +1))

  (add-to-list 'company-backends 'company-jedi)

  ;; (setq-local company-backends '(company-jedi
  ;;                                company-dabbrev-code
  ;;                                company-files
  ;;                                (company-semantic
  ;;                                 company-capf
  ;;                                 company-keywords
  ;;                                 company-dabbrev
  ;;                                 company-shell)))

  (defun my/olivetti-narrow ()
    (interactive)
    (olivetti-mode +1)
    (setq-local olivetti-body-width 60))

  (defun my-python-hooks ()
    (interactive)
    (subword-mode 1)
    (electric-operator-mode +1)
    (company-mode)
    (flycheck-mode +1)
    (rainbow-delimiters-mode +1)
    (highlight-operators-mode +1)
    (evil-swap-keys-swap-double-single-quotes)
    (evil-swap-keys-swap-underscore-dash)
    (evil-swap-keys-swap-colon-semicolon)
    (smartparens-strict-mode +1)
    (my-company-idle-one-prefix-one-quiet)
    (highlight-numbers-mode +1)
    (elpy-enable +1)
    )

  ;; PYTHON KEYS ;;
  (general-define-key
   :keymaps 'inferior-python-mode-map
   \"C-j\" 'elpy-shell-switch-to-buffer
   \"M-e\" 'counsel-shell-history
   \"C-c j\" 'my/evil-shell-bottom
   \"C-c u\" 'universal-argument
   \"C-u\" 'comint-kill-input
   \"C-l\" 'comint-clear-buffer
   \"C-;\" 'my-elpy-switch-to-buffer
   \"C-n\" 'comint-next-input
   \"C-p\" 'comint-previous-input)

  (general-unbind 'inferior-python-mode-map
    :with 'elpy-shell-switch-to-buffer
    [remap save-buffer]
    [remap my-save-buffer]
    [remap comint-next-prompt])

  (general-unbind 'python-mode-map
    :with 'elpy-folding-toggle-at-point
    [remap hs-toggle-hiding])

  (general-unbind 'python-mode-map
    :with 'my-python-shebang
    [remap my-bash-shebang])

  (general-define-key
   :keymaps 'python-mode-map
   \"<M-return>\" 'apheleia-format-buffer
   \"M-a\" 'python-nav-backward-statement
   \"M-e\" 'python-nav-forward-statement
   \"C-S-p\" 'python-nav-backward-sexp
   \"C-S-n\" 'python-nav-forward-sexp
   \"C-x o\" 'my/olivetti-narrow
   \"C-x m\" 'elpy-multiedit-python-symbol-at-point
   \"C-x M\" 'elpy-multiedit-stop
   \"C-c g\" 'my/counsel-ag-python
   \"M-m\" 'flycheck-first-error
   \"C-c p\" 'my/python-make-print
   \"C-c f\" 'my/python-make-fstring
   \"C-c DEL\" 'my/erase-python-file
   \"C-c =\" 'my/erase-python-file-and-yank
   )

  (general-unbind 'python-mode-map
    :with 'yafolding-hide-all
    [remap evil-close-folds])

  (general-nmap
    :keymaps 'python-mode-map
    \"<escape>\" 'my-prog-save-buffer)

  (general-nvmap
    :keymaps 'python-mode-map
    \"zi\" 'yafolding-show-all
    \"M-a\" 'python-nav-backward-statement
    \"M-e\" 'python-nav-forward-statement
    \"C-S-p\" 'python-nav-backward-sexp
    \"C-S-n\" 'python-nav-forward-sexp
    \"C-ç\" 'my/python-newline-beg
    \"<backspace>\" 'org-edit-src-exit
    \"<C-return>\" 'my-quickrun
    \"<tab>\" 'elpy-folding-toggle-at-point
    \"<tab>\" 'elpy-folding-toggle-at-point
    \"RET\" 'hydra-python-mode/body
    \"zm\" 'evil-close-folds
    \"gh\" 'outline-up-heading
    \"gl\" 'outline-next-heading
    \"zl\" 'outline-show-subtree
    \"<\" 'python-indent-shift-left
    \">\" 'python-indent-shift-right
    \"gj\" 'outline-forward-same-level
    \"gk\" 'outline-backward-same-level)

  (defun my/python-newline-beg ()
    (interactive)
    (evil-insert-state)
    (newline)
    (beginning-of-line))

  (defun my/python-colon-newline ()
    (interactive)
    (end-of-line)
    (insert \":\")
    (newline-and-indent))

  (general-imap
    :keymaps 'python-mode-map
    \"C-=\"   'my/python-colon-newline
    \"C-ç\" 'my/python-newline-beg
    \"<C-return>\" 'my-python-quickrun
    \"C-h\" 'python-indent-dedent-line-backspace
    \"M-a\" 'python-nav-backward-statement
    \"M-e\" 'python-nav-forward-statement
    \"C-S-p\" 'python-nav-backward-sexp
    \"C-S-n\" 'python-nav-forward-sexp
    )

  ;; PYTHON FUNCTIONS;;

  (defun execute-python-program ()
    (interactive)
    (my/window-to-register-91)
    (my/quiet-save-buffer)
    (defvar foo-execute-python)
    (setq foo-execute-python (concat \"python3 \" (buffer-file-name)))
    (other-window 1)
    (switch-to-buffer-other-window \"*Async Shell Command*\")
    (shell-command foo))

  (defun my/execute-python-program-shell-simple  ()
    (interactive)
    (my/window-to-register-91)
    (my/quiet-save-buffer)
    (defvar foo-execute-python-simple)
    (setq foo-execute-python-simple (concat \"python3 \" (prelude-copy-file-name-to-clipboard)))
    (shell-command foo))

  (defun my/ex-python-run ()
    (interactive)
    (evil-ex \"w !python3\"))

  (defun my/execute-python-program-shell ()
    (interactive)
    (progn
      (my/quiet-save-buffer)
      (prelude-copy-file-name-to-clipboard)
      (shell)
      (sit-for 0.3)
      (insert \"source ~/scripts/cline_scripts/smallprompt.sh\")
      (comint-send-input)
      (insert \"python3 \")
      (yank)
      (comint-send-input)
      (evil-insert-state)
      (sit-for 0.3)
      (comint-clear-buffer)
      (company-mode -1)))

  (general-unbind 'python-mode-map
    :with 'elpy-doc
    [remap helpful-at-point])

  (defun my/run-python-external ()
    (interactive)
    (progn
      (prelude-copy-file-name-to-clipboard)
      (start-process-shell-command
       \"call term\" nil
       \"~/scripts/i3_scripts/show_term_right\")))

  (defun my/erase-python-file ()
    (interactive)
    (erase-buffer)
    (insert \"#!/usr/bin/env python3\\n\\n\")
    (evil-insert-state)
    (flycheck-clear))

  (defun my/erase-python-file-and-yank ()
    (interactive)
    (erase-buffer)
    (insert \"#!/usr/bin/env python3\\n\\n\")
    (yank))

  (defun my/kill-python-file ()
    (interactive)
    (kill-region (point-min) (point-max))
    (insert \"#!/usr/bin/env python3\\n\\n\")
    (evil-insert-state)
    (flycheck-clear))

  (defun my/python-save-buffer ()
    (interactive)
    (evil-ex-nohighlight)
    (let ((inhibit-message t))
      (delete-trailing-whitespace)
      (save-buffer)))

  ;; PYTHON SETTINGS

  (setq comment-auto-fill-only-comments t
        python-indent-offset 4
        python-indent-guess-indent-offset nil)

  (auto-fill-mode 1))
" . 162228) 167458 (t 24241 5974 533176 509000) nil (162228 . 169950) ("(use-package python
  :ensure nil
  :init
  (add-hook 'python-mode-hook 'my-python-hooks)
  (add-hook 'inferior-python-mode-hook 'my-inferior-python-mode-hooks)

  ;; https://stackoverflow.com/a/6141681
  ;; (add-hook 'python-mode-hook
  ;;           (lambda ()
  ;;             (add-hook 'write-contents-functions (lambda() (elpy-black-fix-code)) nil t)))

  :config
  (font-lock-add-keywords 'python-mode
                          '((\"cls\" . font-lock-keyword-face)))
  (setq python-shell-interpreter \"python3\")
  (setq python-shell-interpreter-args \"-i -q\")

  (setq python-shell-completion-native-enable nil)

  (defun my-python-hooks ()
    (interactive)
    (flymake-mode -1)
    (toggle-truncate-lines +1)
    (electric-operator-mode +1)
    (flycheck-mode +1)
    (rainbow-delimiters-mode +1)
    (highlight-operators-mode +1)
    (evil-swap-keys-swap-double-single-quotes)
    (evil-swap-keys-swap-underscore-dash)
    (evil-swap-keys-swap-colon-semicolon)
    (smartparens-strict-mode +1)
    (my-company-idle-one-prefix-one-quiet)
    (highlight-numbers-mode +1)
    (yafolding-mode +1)
    (apheleia-mode +1)
    (importmagic-mode +1)
    (elpy-enable +1))

  (defun my-inferior-python-mode-hooks ()
    (interactive)
    (electric-operator-mode +1)
    (flycheck-mode +1)
    (rainbow-delimiters-mode +1)
    (highlight-operators-mode +1)
    (evil-swap-keys-swap-double-single-quotes)
    (evil-swap-keys-swap-underscore-dash)
    (evil-swap-keys-swap-colon-semicolon)
    (smartparens-strict-mode +1)
    (my-company-idle-one-prefix-one-quiet)
    (company-mode +1)
    (highlight-numbers-mode +1))

  (add-to-list 'company-backends 'company-jedi)

  ;; (setq-local company-backends '(company-jedi
  ;;                                company-dabbrev-code
  ;;                                company-files
  ;;                                (company-semantic
  ;;                                 company-capf
  ;;                                 company-keywords
  ;;                                 company-dabbrev
  ;;                                 company-shell)))

  (defun my/olivetti-narrow ()
    (interactive)
    (olivetti-mode +1)
    (setq-local olivetti-body-width 60))

  (defun my-python-hooks ()
    (interactive)
    (subword-mode 1)
    (electric-operator-mode +1)
    (company-mode)
    (flycheck-mode +1)
    (rainbow-delimiters-mode +1)
    (highlight-operators-mode +1)
    (evil-swap-keys-swap-double-single-quotes)
    (evil-swap-keys-swap-underscore-dash)
    (evil-swap-keys-swap-colon-semicolon)
    (smartparens-strict-mode +1)
    (my-company-idle-one-prefix-one-quiet)
    (highlight-numbers-mode +1)
    (elpy-enable +1)
    )

  ;; PYTHON KEYS ;;
  (general-define-key
   :keymaps 'inferior-python-mode-map
   \"C-j\" 'elpy-shell-switch-to-buffer
   \"M-e\" 'counsel-shell-history
   \"C-c j\" 'my/evil-shell-bottom
   \"C-c u\" 'universal-argument
   \"C-u\" 'comint-kill-input
   \"C-l\" 'comint-clear-buffer
   \"C-;\" 'my-elpy-switch-to-buffer
   \"C-n\" 'comint-next-input
   \"C-p\" 'comint-previous-input)

  (general-unbind 'inferior-python-mode-map
    :with 'elpy-shell-switch-to-buffer
    [remap save-buffer]
    [remap my-save-buffer]
    [remap comint-next-prompt])

  (general-unbind 'python-mode-map
    :with 'elpy-folding-toggle-at-point
    [remap hs-toggle-hiding])

  (general-unbind 'python-mode-map
    :with 'my-python-shebang
    [remap my-bash-shebang])

  (general-define-key
   :keymaps 'python-mode-map
   \"<M-return>\" 'apheleia-format-buffer
   \"M-a\" 'python-nav-backward-statement
   \"M-e\" 'python-nav-forward-statement
   \"C-S-p\" 'python-nav-backward-sexp
   \"C-S-n\" 'python-nav-forward-sexp
   \"C-x o\" 'my/olivetti-narrow
   \"C-x m\" 'elpy-multiedit-python-symbol-at-point
   \"C-x M\" 'elpy-multiedit-stop
   \"C-c g\" 'my/counsel-ag-python
   \"M-m\" 'flycheck-first-error
   \"C-c p\" 'my/python-make-print
   \"C-c f\" 'my/python-make-fstring
   \"C-c DEL\" 'my/erase-python-file
   \"C-c =\" 'my/erase-python-file-and-yank
   )

  (general-unbind 'python-mode-map
    :with 'yafolding-hide-all
    [remap evil-close-folds])

  (general-nmap
    :keymaps 'python-mode-map
    \"<escape>\" 'my-prog-save-buffer)

  (general-nvmap
    :keymaps 'python-mode-map
    \"zi\" 'yafolding-show-all
    \"M-a\" 'python-nav-backward-statement
    \"M-e\" 'python-nav-forward-statement
    \"C-S-p\" 'python-nav-backward-sexp
    \"C-S-n\" 'python-nav-forward-sexp
    \"C-ç\" 'my/python-newline-beg
    \"<backspace>\" 'org-edit-src-exit
    \"<C-return>\" 'my-python-quickrun
    \"<tab>\" 'elpy-folding-toggle-at-point
    \"<tab>\" 'elpy-folding-toggle-at-point
    \"RET\" 'hydra-python-mode/body
    \"zm\" 'evil-close-folds
    \"gh\" 'outline-up-heading
    \"gl\" 'outline-next-heading
    \"zl\" 'outline-show-subtree
    \"<\" 'python-indent-shift-left
    \">\" 'python-indent-shift-right
    \"gj\" 'outline-forward-same-level
    \"gk\" 'outline-backward-same-level)

  (defun my/python-newline-beg ()
    (interactive)
    (evil-insert-state)
    (newline)
    (beginning-of-line))

  (defun my/python-colon-newline ()
    (interactive)
    (end-of-line)
    (insert \":\")
    (newline-and-indent))

  (general-imap
    :keymaps 'python-mode-map
    \"C-=\"   'my/python-colon-newline
    \"C-ç\" 'my/python-newline-beg
    \"<C-return>\" 'my-python-quickrun
    \"C-h\" 'python-indent-dedent-line-backspace
    \"M-a\" 'python-nav-backward-statement
    \"M-e\" 'python-nav-forward-statement
    \"C-S-p\" 'python-nav-backward-sexp
    \"C-S-n\" 'python-nav-forward-sexp
    )

  ;; PYTHON FUNCTIONS;;

  (defun execute-python-program ()
    (interactive)
    (my/window-to-register-91)
    (my/quiet-save-buffer)
    (defvar foo-execute-python)
    (setq foo-execute-python (concat \"python3 \" (buffer-file-name)))
    (other-window 1)
    (switch-to-buffer-other-window \"*Async Shell Command*\")
    (shell-command foo))

  (defun my/execute-python-program-shell-simple  ()
    (interactive)
    (my/window-to-register-91)
    (my/quiet-save-buffer)
    (defvar foo-execute-python-simple)
    (setq foo-execute-python-simple (concat \"python3 \" (prelude-copy-file-name-to-clipboard)))
    (shell-command foo))

  (defun my/ex-python-run ()
    (interactive)
    (evil-ex \"w !python3\"))

  (defun my/execute-python-program-shell ()
    (interactive)
    (progn
      (my/quiet-save-buffer)
      (prelude-copy-file-name-to-clipboard)
      (shell)
      (sit-for 0.3)
      (insert \"source ~/scripts/cline_scripts/smallprompt.sh\")
      (comint-send-input)
      (insert \"python3 \")
      (yank)
      (comint-send-input)
      (evil-insert-state)
      (sit-for 0.3)
      (comint-clear-buffer)
      (company-mode -1)))

  (general-unbind 'python-mode-map
    :with 'elpy-doc
    [remap helpful-at-point])

  (defun my/run-python-external ()
    (interactive)
    (progn
      (prelude-copy-file-name-to-clipboard)
      (start-process-shell-command
       \"call term\" nil
       \"~/scripts/i3_scripts/show_term_right\")))

  (defun my/erase-python-file ()
    (interactive)
    (erase-buffer)
    (insert \"#!/usr/bin/env python3\\n\\n\")
    (evil-insert-state)
    (flycheck-clear))

  (defun my/erase-python-file-and-yank ()
    (interactive)
    (erase-buffer)
    (insert \"#!/usr/bin/env python3\\n\\n\")
    (yank))

  (defun my/kill-python-file ()
    (interactive)
    (kill-region (point-min) (point-max))
    (insert \"#!/usr/bin/env python3\\n\\n\")
    (evil-insert-state)
    (flycheck-clear))

  (defun my/python-save-buffer ()
    (interactive)
    (evil-ex-nohighlight)
    (let ((inhibit-message t))
      (delete-trailing-whitespace)
      (save-buffer)))

  ;; PYTHON SETTINGS

  (setq comment-auto-fill-only-comments t
        python-indent-offset 4
        python-indent-guess-indent-offset nil)

  (auto-fill-mode 1))
" . 162228) 166713 (t 24241 5947 591853 220000) nil (155259 . 156349) ("(use-package quickrun
  :defer nil
  :init
  (add-hook 'quickrun--mode-hook   'my-quickrun-hooks)

  :config
  (defun my-quickrun-hooks ()
    (interactive)
    (hide-mode-line-mode +1)
    (hl-line-mode +1)
    (rainbow-delimiters-mode +1))

  (defun my-quickrun-quit ()
    (interactive)
    (quit-window)
    (my-recenter-window)
    ;; (my-evil-bottom)
    (redraw-display))

  (general-nvmap
    :keymaps 'quickrun--mode-map
    \"M-p\" 'my-paragraph-backwards
    \"M-n\" 'my-paragraph-forward
    \"i\" 'my-quickrun-quit
    \"<C-return>\" 'my-quickrun-quit
    \"RET\" 'my-quickrun-quit
    \";\" 'my-quickrun-quit)

  (general-nmap
    :keymaps 'quickrun--mode-map
    \"<escape>\" 'my-quickrun-quit
    \"RET\" 'my-quickrun-quit)

  (defun my-quickrun ()
    (interactive)
    (save-buffer)
    (quickrun))

  (defun my-python-quickrun ()
    (interactive)
    (save-buffer)
    (apheleia-format-buffer)
    (quickrun))

  (general-unbind 'quickrun--mode-map
    :with 'my-quickrun-quit
    [remap my-quiet-save-buffer])

  (general-unbind 'compilation-mode-map
    :with 'my-quickrun-quit
    [remap my-quiet-save-buffer]))
" . 155259) ((marker . 2348) . -892) 156151 (t 24241 5899 24932 262000) nil (162257 . 169986) ("(use-package python
  :ensure nil
  :init
  (add-hook 'python-mode-hook 'my-python-hooks)
  (add-hook 'inferior-python-mode-hook 'my-inferior-python-mode-hooks)

  ;; https://stackoverflow.com/a/6141681
  ;; (add-hook 'python-mode-hook
  ;;           (lambda ()
  ;;             (add-hook 'write-contents-functions (lambda() (elpy-black-fix-code)) nil t)))

  :config
  (font-lock-add-keywords 'python-mode
                          '((\"cls\" . font-lock-keyword-face)))
  (setq python-shell-interpreter \"python3\")
  (setq python-shell-interpreter-args \"-i -q\")

  (setq python-shell-completion-native-enable nil)

  (defun my-python-hooks ()
    (interactive)
    (flymake-mode -1)
    (toggle-truncate-lines +1)
    (electric-operator-mode +1)
    (flycheck-mode +1)
    (rainbow-delimiters-mode +1)
    (highlight-operators-mode +1)
    (evil-swap-keys-swap-double-single-quotes)
    (evil-swap-keys-swap-underscore-dash)
    (evil-swap-keys-swap-colon-semicolon)
    (smartparens-strict-mode +1)
    (my-company-idle-one-prefix-one-quiet)
    (highlight-numbers-mode +1)
    (yafolding-mode +1)
    (apheleia-mode +1)
    (importmagic-mode +1)
    (elpy-enable +1))

  (defun my-inferior-python-mode-hooks ()
    (interactive)
    (electric-operator-mode +1)
    (flycheck-mode +1)
    (rainbow-delimiters-mode +1)
    (highlight-operators-mode +1)
    (evil-swap-keys-swap-double-single-quotes)
    (evil-swap-keys-swap-underscore-dash)
    (evil-swap-keys-swap-colon-semicolon)
    (smartparens-strict-mode +1)
    (my-company-idle-one-prefix-one-quiet)
    (company-mode +1)
    (highlight-numbers-mode +1))

  (add-to-list 'company-backends 'company-jedi)

  ;; (setq-local company-backends '(company-jedi
  ;;                                company-dabbrev-code
  ;;                                company-files
  ;;                                (company-semantic
  ;;                                 company-capf
  ;;                                 company-keywords
  ;;                                 company-dabbrev
  ;;                                 company-shell)))

  (defun my/olivetti-narrow ()
    (interactive)
    (olivetti-mode +1)
    (setq-local olivetti-body-width 60))

  (defun my-python-hooks ()
    (interactive)
    (subword-mode 1)
    (electric-operator-mode +1)
    (company-mode)
    (flycheck-mode +1)
    (rainbow-delimiters-mode +1)
    (highlight-operators-mode +1)
    (evil-swap-keys-swap-double-single-quotes)
    (evil-swap-keys-swap-underscore-dash)
    (evil-swap-keys-swap-colon-semicolon)
    (smartparens-strict-mode +1)
    (my-company-idle-one-prefix-one-quiet)
    (highlight-numbers-mode +1)
    (elpy-enable +1)
    )

  ;; PYTHON KEYS ;;
  (general-define-key
   :keymaps 'inferior-python-mode-map
   \"C-j\" 'elpy-shell-switch-to-buffer
   \"M-e\" 'counsel-shell-history
   \"C-c j\" 'my/evil-shell-bottom
   \"C-c u\" 'universal-argument
   \"C-u\" 'comint-kill-input
   \"C-l\" 'comint-clear-buffer
   \"C-;\" 'my-elpy-switch-to-buffer
   \"C-n\" 'comint-next-input
   \"C-p\" 'comint-previous-input)

  (general-unbind 'inferior-python-mode-map
    :with 'elpy-shell-switch-to-buffer
    [remap save-buffer]
    [remap my-save-buffer]
    [remap comint-next-prompt])

  (general-unbind 'python-mode-map
    :with 'elpy-folding-toggle-at-point
    [remap hs-toggle-hiding])

  (general-unbind 'python-mode-map
    :with 'my-python-shebang
    [remap my-bash-shebang])

  (general-define-key
   :keymaps 'python-mode-map
   \"<M-return>\" 'apheleia-format-buffer
   \"M-a\" 'python-nav-backward-statement
   \"M-e\" 'python-nav-forward-statement
   \"C-S-p\" 'python-nav-backward-sexp
   \"C-S-n\" 'python-nav-forward-sexp
   \"C-x o\" 'my/olivetti-narrow
   \"C-x m\" 'elpy-multiedit-python-symbol-at-point
   \"C-x M\" 'elpy-multiedit-stop
   \"C-c g\" 'my/counsel-ag-python
   \"M-m\" 'flycheck-first-error
   \"C-c p\" 'my/python-make-print
   \"C-c f\" 'my/python-make-fstring
   \"C-c DEL\" 'my/erase-python-file
   \"C-c =\" 'my/erase-python-file-and-yank
   )

  (general-unbind 'python-mode-map
    :with 'yafolding-hide-all
    [remap evil-close-folds])

  (general-nmap
    :keymaps 'python-mode-map
    \"<escape>\" 'my-prog-save-buffer)

  (general-nvmap
    :keymaps 'python-mode-map
    \"zi\" 'yafolding-show-all
    \"M-a\" 'python-nav-backward-statement
    \"M-e\" 'python-nav-forward-statement
    \"C-S-p\" 'python-nav-backward-sexp
    \"C-S-n\" 'python-nav-forward-sexp
    \"C-ç\" 'my/python-newline-beg
    \"<backspace>\" 'org-edit-src-exit
    \"<C-return>\" 'my-python-quickrun
    \"<tab>\" 'elpy-folding-toggle-at-point
    \"<tab>\" 'elpy-folding-toggle-at-point
    \"RET\" 'hydra-python-mode/body
    \"zm\" 'evil-close-folds
    \"gh\" 'outline-up-heading
    \"gl\" 'outline-next-heading
    \"zl\" 'outline-show-subtree
    \"<\" 'python-indent-shift-left
    \">\" 'python-indent-shift-right
    \"gj\" 'outline-forward-same-level
    \"gk\" 'outline-backward-same-level)

  (defun my/python-newline-beg ()
    (interactive)
    (evil-insert-state)
    (newline)
    (beginning-of-line))

  (defun my/python-colon-newline ()
    (interactive)
    (end-of-line)
    (insert \":\")
    (newline-and-indent))

  (general-imap
    :keymaps 'python-mode-map
    \"C-=\"   'my/python-colon-newline
    \"C-ç\" 'my/python-newline-beg
    \"<C-return>\" 'my-quickrun
    \"C-h\" 'python-indent-dedent-line-backspace
    \"M-a\" 'python-nav-backward-statement
    \"M-e\" 'python-nav-forward-statement
    \"C-S-p\" 'python-nav-backward-sexp
    \"C-S-n\" 'python-nav-forward-sexp
    )

  ;; PYTHON FUNCTIONS;;

  (defun execute-python-program ()
    (interactive)
    (my/window-to-register-91)
    (my/quiet-save-buffer)
    (defvar foo-execute-python)
    (setq foo-execute-python (concat \"python3 \" (buffer-file-name)))
    (other-window 1)
    (switch-to-buffer-other-window \"*Async Shell Command*\")
    (shell-command foo))

  (defun my/execute-python-program-shell-simple  ()
    (interactive)
    (my/window-to-register-91)
    (my/quiet-save-buffer)
    (defvar foo-execute-python-simple)
    (setq foo-execute-python-simple (concat \"python3 \" (prelude-copy-file-name-to-clipboard)))
    (shell-command foo))

  (defun my/ex-python-run ()
    (interactive)
    (evil-ex \"w !python3\"))

  (defun my/execute-python-program-shell ()
    (interactive)
    (progn
      (my/quiet-save-buffer)
      (prelude-copy-file-name-to-clipboard)
      (shell)
      (sit-for 0.3)
      (insert \"source ~/scripts/cline_scripts/smallprompt.sh\")
      (comint-send-input)
      (insert \"python3 \")
      (yank)
      (comint-send-input)
      (evil-insert-state)
      (sit-for 0.3)
      (comint-clear-buffer)
      (company-mode -1)))

  (general-unbind 'python-mode-map
    :with 'elpy-doc
    [remap helpful-at-point])

  (defun my/run-python-external ()
    (interactive)
    (progn
      (prelude-copy-file-name-to-clipboard)
      (start-process-shell-command
       \"call term\" nil
       \"~/scripts/i3_scripts/show_term_right\")))

  (defun my/erase-python-file ()
    (interactive)
    (erase-buffer)
    (insert \"#!/usr/bin/env python3\\n\\n\")
    (evil-insert-state)
    (flycheck-clear))

  (defun my/erase-python-file-and-yank ()
    (interactive)
    (erase-buffer)
    (insert \"#!/usr/bin/env python3\\n\\n\")
    (yank))

  (defun my/kill-python-file ()
    (interactive)
    (kill-region (point-min) (point-max))
    (insert \"#!/usr/bin/env python3\\n\\n\")
    (evil-insert-state)
    (flycheck-clear))

  (defun my/python-save-buffer ()
    (interactive)
    (evil-ex-nohighlight)
    (let ((inhibit-message t))
      (delete-trailing-whitespace)
      (save-buffer)))

  ;; PYTHON SETTINGS

  (setq comment-auto-fill-only-comments t
        python-indent-offset 4
        python-indent-guess-indent-offset nil)

  (auto-fill-mode 1))
" . 162257) 169979 (t 24241 5891 852288 329000) nil (162257 . 169979) ("(use-package python
  :ensure nil
  :init
  (add-hook 'python-mode-hook 'my-python-hooks)
  (add-hook 'inferior-python-mode-hook 'my-inferior-python-mode-hooks)

  ;; https://stackoverflow.com/a/6141681
  ;; (add-hook 'python-mode-hook
  ;;           (lambda ()
  ;;             (add-hook 'write-contents-functions (lambda() (elpy-black-fix-code)) nil t)))

  :config
  (font-lock-add-keywords 'python-mode
                          '((\"cls\" . font-lock-keyword-face)))
  (setq python-shell-interpreter \"python3\")
  (setq python-shell-interpreter-args \"-i -q\")

  (setq python-shell-completion-native-enable nil)

  (defun my-python-hooks ()
    (interactive)
    (flymake-mode -1)
    (toggle-truncate-lines +1)
    (electric-operator-mode +1)
    (flycheck-mode +1)
    (rainbow-delimiters-mode +1)
    (highlight-operators-mode +1)
    (evil-swap-keys-swap-double-single-quotes)
    (evil-swap-keys-swap-underscore-dash)
    (evil-swap-keys-swap-colon-semicolon)
    (smartparens-strict-mode +1)
    (my-company-idle-one-prefix-one-quiet)
    (highlight-numbers-mode +1)
    (yafolding-mode +1)
    (apheleia-mode +1)
    (importmagic-mode +1)
    (elpy-enable +1))

  (defun my-inferior-python-mode-hooks ()
    (interactive)
    (electric-operator-mode +1)
    (flycheck-mode +1)
    (rainbow-delimiters-mode +1)
    (highlight-operators-mode +1)
    (evil-swap-keys-swap-double-single-quotes)
    (evil-swap-keys-swap-underscore-dash)
    (evil-swap-keys-swap-colon-semicolon)
    (smartparens-strict-mode +1)
    (my-company-idle-one-prefix-one-quiet)
    (company-mode +1)
    (highlight-numbers-mode +1))

  (add-to-list 'company-backends 'company-jedi)

  ;; (setq-local company-backends '(company-jedi
  ;;                                company-dabbrev-code
  ;;                                company-files
  ;;                                (company-semantic
  ;;                                 company-capf
  ;;                                 company-keywords
  ;;                                 company-dabbrev
  ;;                                 company-shell)))

  (defun my/olivetti-narrow ()
    (interactive)
    (olivetti-mode +1)
    (setq-local olivetti-body-width 60))

  (defun my-python-hooks ()
    (interactive)
    (subword-mode 1)
    (electric-operator-mode +1)
    (company-mode)
    (flycheck-mode +1)
    (rainbow-delimiters-mode +1)
    (highlight-operators-mode +1)
    (evil-swap-keys-swap-double-single-quotes)
    (evil-swap-keys-swap-underscore-dash)
    (evil-swap-keys-swap-colon-semicolon)
    (smartparens-strict-mode +1)
    (my-company-idle-one-prefix-one-quiet)
    (highlight-numbers-mode +1)
    (elpy-enable +1)
    )

  ;; PYTHON KEYS ;;
  (general-define-key
   :keymaps 'inferior-python-mode-map
   \"C-j\" 'elpy-shell-switch-to-buffer
   \"M-e\" 'counsel-shell-history
   \"C-c j\" 'my/evil-shell-bottom
   \"C-c u\" 'universal-argument
   \"C-u\" 'comint-kill-input
   \"C-l\" 'comint-clear-buffer
   \"C-;\" 'my-elpy-switch-to-buffer
   \"C-n\" 'comint-next-input
   \"C-p\" 'comint-previous-input)

  (general-unbind 'inferior-python-mode-map
    :with 'elpy-shell-switch-to-buffer
    [remap save-buffer]
    [remap my-save-buffer]
    [remap comint-next-prompt])

  (general-unbind 'python-mode-map
    :with 'elpy-folding-toggle-at-point
    [remap hs-toggle-hiding])

  (general-unbind 'python-mode-map
    :with 'my-python-shebang
    [remap my-bash-shebang])

  (general-define-key
   :keymaps 'python-mode-map
   \"<M-return>\" 'apheleia-format-buffer
   \"M-a\" 'python-nav-backward-statement
   \"M-e\" 'python-nav-forward-statement
   \"C-S-p\" 'python-nav-backward-sexp
   \"C-S-n\" 'python-nav-forward-sexp
   \"C-x o\" 'my/olivetti-narrow
   \"C-x m\" 'elpy-multiedit-python-symbol-at-point
   \"C-x M\" 'elpy-multiedit-stop
   \"C-c g\" 'my/counsel-ag-python
   \"M-m\" 'flycheck-first-error
   \"C-c p\" 'my/python-make-print
   \"C-c f\" 'my/python-make-fstring
   \"C-c DEL\" 'my/erase-python-file
   \"C-c =\" 'my/erase-python-file-and-yank
   )

  (general-unbind 'python-mode-map
    :with 'yafolding-hide-all
    [remap evil-close-folds])

  (general-nmap
    :keymaps 'python-mode-map
    \"<escape>\" 'my-prog-save-buffer)

  (general-nvmap
    :keymaps 'python-mode-map
    \"zi\" 'yafolding-show-all
    \"M-a\" 'python-nav-backward-statement
    \"M-e\" 'python-nav-forward-statement
    \"C-S-p\" 'python-nav-backward-sexp
    \"C-S-n\" 'python-nav-forward-sexp
    \"C-ç\" 'my/python-newline-beg
    \"<backspace>\" 'org-edit-src-exit
    \"<C-return>\" 'my-quickrun
    \"<tab>\" 'elpy-folding-toggle-at-point
    \"<tab>\" 'elpy-folding-toggle-at-point
    \"RET\" 'hydra-python-mode/body
    \"zm\" 'evil-close-folds
    \"gh\" 'outline-up-heading
    \"gl\" 'outline-next-heading
    \"zl\" 'outline-show-subtree
    \"<\" 'python-indent-shift-left
    \">\" 'python-indent-shift-right
    \"gj\" 'outline-forward-same-level
    \"gk\" 'outline-backward-same-level)

  (defun my/python-newline-beg ()
    (interactive)
    (evil-insert-state)
    (newline)
    (beginning-of-line))

  (defun my/python-colon-newline ()
    (interactive)
    (end-of-line)
    (insert \":\")
    (newline-and-indent))

  (general-imap
    :keymaps 'python-mode-map
    \"C-=\"   'my/python-colon-newline
    \"C-ç\" 'my/python-newline-beg
    \"<C-return>\" 'my-quickrun
    \"C-h\" 'python-indent-dedent-line-backspace
    \"M-a\" 'python-nav-backward-statement
    \"M-e\" 'python-nav-forward-statement
    \"C-S-p\" 'python-nav-backward-sexp
    \"C-S-n\" 'python-nav-forward-sexp
    )

  ;; PYTHON FUNCTIONS;;

  (defun execute-python-program ()
    (interactive)
    (my/window-to-register-91)
    (my/quiet-save-buffer)
    (defvar foo-execute-python)
    (setq foo-execute-python (concat \"python3 \" (buffer-file-name)))
    (other-window 1)
    (switch-to-buffer-other-window \"*Async Shell Command*\")
    (shell-command foo))

  (defun my/execute-python-program-shell-simple  ()
    (interactive)
    (my/window-to-register-91)
    (my/quiet-save-buffer)
    (defvar foo-execute-python-simple)
    (setq foo-execute-python-simple (concat \"python3 \" (prelude-copy-file-name-to-clipboard)))
    (shell-command foo))

  (defun my/ex-python-run ()
    (interactive)
    (evil-ex \"w !python3\"))

  (defun my/execute-python-program-shell ()
    (interactive)
    (progn
      (my/quiet-save-buffer)
      (prelude-copy-file-name-to-clipboard)
      (shell)
      (sit-for 0.3)
      (insert \"source ~/scripts/cline_scripts/smallprompt.sh\")
      (comint-send-input)
      (insert \"python3 \")
      (yank)
      (comint-send-input)
      (evil-insert-state)
      (sit-for 0.3)
      (comint-clear-buffer)
      (company-mode -1)))

  (general-unbind 'python-mode-map
    :with 'elpy-doc
    [remap helpful-at-point])

  (defun my/run-python-external ()
    (interactive)
    (progn
      (prelude-copy-file-name-to-clipboard)
      (start-process-shell-command
       \"call term\" nil
       \"~/scripts/i3_scripts/show_term_right\")))

  (defun my/erase-python-file ()
    (interactive)
    (erase-buffer)
    (insert \"#!/usr/bin/env python3\\n\\n\")
    (evil-insert-state)
    (flycheck-clear))

  (defun my/erase-python-file-and-yank ()
    (interactive)
    (erase-buffer)
    (insert \"#!/usr/bin/env python3\\n\\n\")
    (yank))

  (defun my/kill-python-file ()
    (interactive)
    (kill-region (point-min) (point-max))
    (insert \"#!/usr/bin/env python3\\n\\n\")
    (evil-insert-state)
    (flycheck-clear))

  (defun my/python-save-buffer ()
    (interactive)
    (evil-ex-nohighlight)
    (let ((inhibit-message t))
      (delete-trailing-whitespace)
      (save-buffer)))

  ;; PYTHON SETTINGS

  (setq comment-auto-fill-only-comments t
        python-indent-offset 4
        python-indent-guess-indent-offset nil)

  (auto-fill-mode 1))
" . 162257) ((marker . 2348) . -16) ((marker . 2348) . -562) ((marker . 2348) . -1137) ((marker . 2348) . -1137) ((marker . 2348) . -16) ((marker . 2348) . -616) 166727 (t 24241 5874 501154 748000) nil (155259 . 156378) ("(use-package quickrun
  :defer nil
  :init
  (add-hook 'quickrun--mode-hook   'my-quickrun-hooks)

  :config
  (defun my-quickrun-hooks ()
    (interactive)
    (hide-mode-line-mode +1)
    (hl-line-mode +1)
    (rainbow-delimiters-mode +1))

  (defun my-quickrun-quit ()
    (interactive)
    (quit-window)
    (my-recenter-window)
    ;; (my-evil-bottom)
    (redraw-display))

  (general-nvmap
    :keymaps 'quickrun--mode-map
    \"M-p\" 'my-paragraph-backwards
    \"M-n\" 'my-paragraph-forward
    \"i\" 'my-quickrun-quit
    \"<C-return>\" 'my-quickrun-quit
    \"RET\" 'my-quickrun-quit
    \";\" 'my-quickrun-quit)

  (general-nmap
    :keymaps 'quickrun--mode-map
    \"<escape>\" 'my-quickrun-quit
    \"RET\" 'my-quickrun-quit)

  (defun my-quickrun ()
    (interactive)
    (save-buffer)
    (quickrun))

  (defun my-python-quickrun ()
    (interactive)
    (save-buffer)

    (quickrun))

  (general-unbind 'quickrun--mode-map
    :with 'my-quickrun-quit
    [remap my-quiet-save-buffer])

  (general-unbind 'compilation-mode-map
    :with 'my-quickrun-quit
    [remap my-quiet-save-buffer]))
" . 155259) 156350 (t 24241 5871 559884 686000) nil (155259 . 156350) ("(use-package quickrun
  :defer nil
  :init
  (add-hook 'quickrun--mode-hook   'my-quickrun-hooks)

  :config
  (defun my-quickrun-hooks ()
    (interactive)
    (hide-mode-line-mode +1)
    (hl-line-mode +1)
    (rainbow-delimiters-mode +1))

  (defun my-quickrun-quit ()
    (interactive)
    (quit-window)
    (my-recenter-window)
    ;; (my-evil-bottom)
    (redraw-display))

  (general-nvmap
    :keymaps 'quickrun--mode-map
    \"M-p\" 'my-paragraph-backwards
    \"M-n\" 'my-paragraph-forward
    \"i\" 'my-quickrun-quit
    \"<C-return>\" 'my-quickrun-quit
    \"RET\" 'my-quickrun-quit
    \";\" 'my-quickrun-quit)

  (general-nmap
    :keymaps 'quickrun--mode-map
    \"<escape>\" 'my-quickrun-quit
    \"RET\" 'my-quickrun-quit)

  (defun my-quickrun ()
    (interactive)
    (save-buffer)
    (quickrun))

  (defun my-python-quickrun ()
    (interactive)
    (save-buffer)
    (quickrun))

  (general-unbind 'quickrun--mode-map
    :with 'my-quickrun-quit
    [remap my-quiet-save-buffer])

  (general-unbind 'compilation-mode-map
    :with 'my-quickrun-quit
    [remap my-quiet-save-buffer]))
" . 155259) 156108 (t 24241 5858 439716 161000) nil (155259 . 156349) ("(use-package quickrun
  :defer nil
  :init
  (add-hook 'quickrun--mode-hook   'my-quickrun-hooks)

  :config
  (defun my-quickrun-hooks ()
    (interactive)
    (hide-mode-line-mode +1)
    (hl-line-mode +1)
    (rainbow-delimiters-mode +1))

  (defun my-quickrun-quit ()
    (interactive)
    (quit-window)
    (my-recenter-window)
    ;; (my-evil-bottom)
    (redraw-display))

  (general-nvmap
    :keymaps 'quickrun--mode-map
    \"M-p\" 'my-paragraph-backwards
    \"M-n\" 'my-paragraph-forward
    \"i\" 'my-quickrun-quit
    \"<C-return>\" 'my-quickrun-quit
    \"RET\" 'my-quickrun-quit
    \";\" 'my-quickrun-quit)

  (general-nmap
    :keymaps 'quickrun--mode-map
    \"<escape>\" 'my-quickrun-quit
    \"RET\" 'my-quickrun-quit)

  (defun my-quickrun ()
    (interactive)
    (save-buffer)
    (quickrun))

  (defun my-quickrun ()
    (interactive)
    (save-buffer)
    (quickrun))

  (general-unbind 'quickrun--mode-map
    :with 'my-quickrun-quit
    [remap my-quiet-save-buffer])

  (general-unbind 'compilation-mode-map
    :with 'my-quickrun-quit
    [remap my-quiet-save-buffer]))
" . 155259) ((marker . 2348) . -877) ((marker . 2348) . -725) ((marker* . 2348) . 205) ((marker . 2348) . -725) ((marker . 2348) . -800) ((marker . 2348) . -802) ((marker . 2348) . -877) 156063 nil (nil rear-nonsticky nil 156062 . 156063) ("
" . -156136) (156060 . 156137) nil (156059 . 156060) 156058 (t 24241 5823 890813 889000) nil (109170 . 110175) ("(use-package super-save
  ;; :disabled
  :config

  ;; (setq super-save-exclude '(\"\\\\.pdf\" \"\\\\.py\" \"+new-snippet+\"))
  ;; (setq-default super-save-exclude '(\"\\\\.pdf\" \"\\\\.py\" \"+new-snippet+\"))

  (setq super-save-exclude '(\"pdf\" \"\\\\.pdf\" \"+new-snippet+\"))
  (setq-default super-save-exclude '(\"pdf\" \"\\\\.pdf\" \"+new-snippet+\"))

  (setq auto-save-default nil
        super-save-idle-duration 2
        super-save-auto-save-when-idle nil
        auto-save-file-name-transforms `((\".*\" \"~/emacs-profiles/my-emacs/var/temp\" t)))

  (setq super-save-hook-triggers '(mouse-leave-buffer-hook focus-out-hook))

  (setq super-save-triggers
        '(quickrun
          quit-window
          last-buffer
          windmove-up
          windmove-down
          windmove-left
          windmove-right
          switch-to-buffer
          delete-window
          eyebrowse-close-window-config
          eyebrowse-create-window-config
          eyebrowse-prev-window-config))

  (auto-save-mode -1)
  (super-save-mode +1))
" . 109170) ((marker . 2348) . -919) ((marker) . -16) ((marker) . -16) 109186 (t 24241 5545 155160 417000) nil (48061 . 48284) ("(use-package exec-path-from-shell
  :init
  (exec-path-from-shell-copy-env \"PYENV_SHELL\")
  :config
  (exec-path-from-shell-copy-env \"STUDY\")
  (when (memq window-system '(mac ns x))
    (exec-path-from-shell-initialize)))
" . 48061) 48284 (t 24241 5536 37029 522000) nil (48061 . 48284) ("(use-package exec-path-from-shell
  :init
  (exec-path-from-shell-copy-env \"PYENV_SHELL\")
  :config
(exec-path-from-shell-copy-env \"STUDY\")
  (when (memq window-system '(mac ns x))
    (exec-path-from-shell-initialize)))
" . 48061) 48282 (t 24241 5529 709736 453000) nil (48061 . 48282) ("(use-package exec-path-from-shell
  :init
  (exec-path-from-shell-copy-env \"PYENV_SHELL\")
  :config
(exec-path-from-shell-copy-env STUDY)
  (when (memq window-system '(mac ns x))
    (exec-path-from-shell-initialize)))
" . 48061) 48280 (t 24241 5527 885890 326000) nil (48061 . 48280) ("(use-package exec-path-from-shell
  :init
  (exec-path-from-shell-copy-env \"PYENV_SHELL\")
  :config
(exec-path-from-shell-copy-env )
  (when (memq window-system '(mac ns x))
    (exec-path-from-shell-initialize)))
" . 48061) 48275 (t 24241 5517 381507 890000) nil (48061 . 48275) ("(use-package exec-path-from-shell
  :init
  (exec-path-from-shell-copy-env \"PYENV_SHELL\")
  :config
exec-path-from-shell-copy-env
  (when (memq window-system '(mac ns x))
    (exec-path-from-shell-initialize)))
" . 48061) 48272 (t 24241 5510 20125 334000) nil (48061 . 48272) ("(use-package exec-path-from-shell
  :init
  (exec-path-from-shell-copy-env \"PYENV_SHELL\")
  :config
  (when (memq window-system '(mac ns x))
    (exec-path-from-shell-initialize)))
" . 48061) ((marker . 2348) . -44) 48105 (t 24240 65130 860538 772000) nil (160580 . 161864) ("(use-package elpy
  :defer t
  :init
  (advice-add 'python-mode :before 'elpy-enable)
  (add-hook 'elpy-mode-hook 'my/elpy-hooks)
  :config
  ;; (setq highlight-indentation-blank-lines 't)
  (setq elpy-rpc-python-command \"/Users/davi/.pyenv/shims/python\")
  (setq elpy-autodoc-delay 3)
  (setq elpy-rpc-virtualenv-path 'current)

  (general-unbind 'normal elpy-mode-map
    :with 'yafolding-toggle-element
    [remap elpy-folding-toggle-at-point])
  (defun my/elpy-hooks ()
    (interactive)
    (my/disable-eldoc)
    (pyenv-mode +1))

  (defun my/disable-eldoc ()
    (interactive)
    (eldoc-mode -1))

  (defun elpy-goto-definition ()
    (interactive)
    (elpy-rpc-warn-if-jedi-not-available)
    (let ((location (elpy-rpc-get-definition)))
      (if location
          (elpy-goto-location (car location) (cadr location))
        (error \"No definition found\")))
    (save-excursion
      (evil-scroll-line-to-center 1)))

  (general-define-key
   :keymaps 'elpy-mode-map
   elpy-shell-send-buffer-and-go
   \"C-j\" 'elpy-shell-switch-to-shell
   \"C-x m\" 'elpy-multiedit
   \"C-x ESC\" 'elpy-multiedit-stop
   \"C-c d\" 'elpy-doc)

  (defun my-elpy-switch-to-buffer ()
    (interactive)
    (elpy-shell-switch-to-buffer)
    (quit-windows-on \"*Python*\"))

  (elpy-enable +1))
" . 160580) ((marker . 2348) . -980) 161560 (t 24240 65100 235131 278000) nil ("   \"C-c j\"   nil
" . 29428) ((marker) . -15) 29443 (t 24240 65099 8277 897000) nil (27875 . 31675) ("(use-package general
  :config

  (general-translate-key nil 'override \"<pause>\" \"SPC\")

  (general-evil-setup t)

  (general-define-key
   :keymaps  'global
   \"M-p\" 'backward-paragraph
   \"M-n\" 'forward-paragraph
   \"M-q\" 'eyebrowse-prev-window-config
   \"M-w\" 'eyebrowse-next-window-config
   \"M-7\" 'make-frame
   \"M-8\" 'other-frame
   \"M-9\"     'delete-other-windows
   \"M-0\"     'quit-window
   \"C-c P\" 'counsel-projectile-mode
   \"C-c f\"   'font-lock-mode
   \"C-x d\"   'toggle-debug-on-error
   \"C-_\" 'undo-fu-only-undo
   \"<mouse-8>\" 'nswbuff-switch-to-next-buff
   \"<mouse-2>\" 'my-kill-this-buffer
   \"C-c S\"   'my-emacs-session
   \"C-c -\"   'my-recenter-window
   \"C-;\"     'helpful-at-point
   \"C-:\"     'helpful-variable
   \"C-c C-o\" 'org-open-at-point-global
   \"C-x p\"   'my-goto-package)

  (general-define-key
   :keymaps  'override
   \"C-x n\" 'recursive-narrow-or-widen-dwim
   \"C-c s\" 'my-shell-full
   \"C-c v\"   'yank
   \"C-x r\" 'kill-ring-save
   \"C-x c\" 'quick-calc
   \"C-c i\" 'pbcopy
   \"§\" 'helm-resume
   \"C-S-s\" 'helm-resume
   \"C-s\" 'helm-swoop-without-pre-input
   \"C--\" 'helm-swoop
   \"C-c u\" 'revert-buffer
   \"M-'\"    'delete-window
   \"M-r\" 'ivy-switch-buffer
   \"M-;\" 'counsel-projectile-switch-to-buffer
   \"M-s\" 'last-buffer
   \"C-x s\" 'my-shell-below
   \"M-ç\" 'insert-char
   \"C-0\"     'evil-execute-macro
   \"C-c 0\"     'evil-execute-macro
   \"M-y\" 'my-yank-pop
   \"C-,\"     'evil-window-prev
   \"C-.\"     'evil-window-next
   \"C-/\"     'my-term-below
   \"C-c F s\" 'my-show-server
   \"C-x P\"   'hydra-python-mode/body
   \"C-c j\"   'org-journal-new-entry
   \"C-c ç\"   'my-bash-shebang
   \"C-c k\"   'kill-buffer-and-window
   \"C-9\"     'evil-commentary-line)

  (defun my-insert-checkmark ()
    (interactive)
    (insert \"\"))

  (general-define-key
   :keymaps  'override
   :states   '(normal visual)
   \"C-SPC\" 'fix-word-upcase
   \"X\" 'whack-whitespace)

  (general-define-key
   :states   '(insert)
   :keymaps   'override
   \"C-SPC\" 'fix-word-upcase
   \"C-@\" 'fix-word-upcase
   \"C-S-SPC\" 'fix-word-capitalize
   \"C-c u\" 'universal-argument)

  (general-define-key
   :states   '(insert)
   :keymaps   'override
   \"C-c u\" 'universal-argument)

  (general-define-key
   :states   '(normal visual insert)
   \"<f12>\"   'man
   \"M-9\"     'delete-other-windows
   \"M-0\"     'quit-window
   \"C-c a\"   'align-regexp
   \"C-c e\"   'my-eval-buffer
   ;; \"C-c o\"    'helm-org-in-buffer-headings
   )
    ;;;; LEADER ;;;;
  (general-create-definer leader
    :prefix \"SPC\")

  (leader
    :states  '(normal visual)
    :keymaps 'override
    \";\"      'my-eval-buffer
    \"u\"      'hydra-projectile-mode/body
    \"p\"      'hydra-packages/body
    \"h\"      'my-org-hooks
    \"e\"      'visible-mode
    \",\"      'olivetti-mode
    \"\\\\\"     'org-babel-tangle
    \"/\"     'org-babel-tangle
    \".\"      'my-tangle-py-init.org-only
    \"-\"      'my-tangle-py-init.org-only-and-quit-window
    \"d\"      'my-dup-line
    \"m\"      'hydra-modes/body
    \"s\"      'hydra-search/body
    \"c\"      'hydra-commands/body
    \"SPC\"    'hydra-text-main/body
    \"z\"      'hydra-window/body
    \"i\"      'hydra-find-file/body
    \"0\"      'delete-window
    \"a\"      'counsel-M-x
    \"f\"      'counsel-find-file
    \"j\"      'hydra-org-clock/body
    \"g\"      'counsel-grep
    \"R\"      'eyebrowse-rename-window-config
    \"r\"      'my-ranger-deer
    \"k\"      'hydra-kill/body
    \"q\"      'my-kill-this-buffer
    \"o\"      'hydra-org-mode/body
    \"F\"      'my-reopen-killed-file
    \"t\"      'counsel-buffer-or-recentf
    \"T\"      'my-reopen-killed-file-fancy
    \"l\"      'hydra-tangle/body
    \"w\"      'widenToCenter
    \"W\"      'widenToCenter
    ;; \"n\"      'recursive-narrow-or-widen-dwim
    \"n\"      'org-narrow-to-subtree)

  (general-unbind 'global
    :with 'undo-tree-redo
    [remap redo]))
" . 27875) 29432 (t 24240 65087 292531 154000) nil (160616 . 161891) ("(use-package elpy
  :defer t
  :init
  (advice-add 'python-mode :before 'elpy-enable)
  (add-hook 'elpy-mode-hook 'my/elpy-hooks)
  :config
  ;; (setq highlight-indentation-blank-lines 't)
  (setq elpy-rpc-python-command \"/Users/davi/.pyenv/shims/python\")
  (setq elpy-autodoc-delay 3)
  (setq elpy-rpc-virtualenv-path 'current)

  (general-unbind 'normal elpy-mode-map
    :with 'yafolding-toggle-element
    [remap elpy-folding-toggle-at-point])
  (defun my/elpy-hooks ()
    (interactive)
    (my/disable-eldoc)
    (pyenv-mode +1))

  (defun my/disable-eldoc ()
    (interactive)
    (eldoc-mode -1))

  (defun elpy-goto-definition ()
    (interactive)
    (elpy-rpc-warn-if-jedi-not-available)
    (let ((location (elpy-rpc-get-definition)))
      (if location
          (elpy-goto-location (car location) (cadr location))
        (error \"No definition found\")))
    (save-excursion
      (evil-scroll-line-to-center 1)))

  (general-define-key
   :keymaps 'elpy-mode-map
elpy-shell-send-buffer-and-go
   \"C-j\" 'elpy-shell-switch-to-shell
   \"C-x m\" 'elpy-multiedit
   \"C-x ESC\" 'elpy-multiedit-stop
   \"C-c d\" 'elpy-doc)

  (defun my-elpy-switch-to-buffer ()
    (interactive)
    (elpy-shell-switch-to-buffer)
    (quit-windows-on \"*Python*\"))

  (elpy-enable +1))
" . 160616) ((marker . 2348) . -1005) 161621 (t 24240 65080 51073 83000) nil (160616 . 161888) ("(use-package elpy
  :defer t
  :init
  (advice-add 'python-mode :before 'elpy-enable)
  (add-hook 'elpy-mode-hook 'my/elpy-hooks)
  :config
  ;; (setq highlight-indentation-blank-lines 't)
  (setq elpy-rpc-python-command \"/Users/davi/.pyenv/shims/python\")
  (setq elpy-autodoc-delay 3)
  (setq elpy-rpc-virtualenv-path 'current)

  (general-unbind 'normal elpy-mode-map
    :with 'yafolding-toggle-element
    [remap elpy-folding-toggle-at-point])
  (defun my/elpy-hooks ()
    (interactive)
    (my/disable-eldoc)
    (pyenv-mode +1))

  (defun my/disable-eldoc ()
    (interactive)
    (eldoc-mode -1))

  (defun elpy-goto-definition ()
    (interactive)
    (elpy-rpc-warn-if-jedi-not-available)
    (let ((location (elpy-rpc-get-definition)))
      (if location
          (elpy-goto-location (car location) (cadr location))
        (error \"No definition found\")))
    (save-excursion
      (evil-scroll-line-to-center 1)))

  (general-define-key
   :keymaps 'elpy-mode-map
   \"C-j\" 'elpy-shell-switch-to-shell
   \"C-x m\" 'elpy-multiedit
   \"C-x ESC\" 'elpy-multiedit-stop
   \"C-c d\" 'elpy-doc)

  (defun my-elpy-switch-to-buffer ()
    (interactive)
    (elpy-shell-switch-to-buffer)
    (quit-windows-on \"*Python*\"))

  (elpy-enable +1))
" . 160616) 160632 (t 24239 55173 384127 354000) nil (109164 . 110171) ("(use-package super-save
  ;; :disabled
  :config

  ;; (setq super-save-exclude '(\"\\\\.pdf\" \"\\\\.py\" \"+new-snippet+\"))
  ;; (setq-default super-save-exclude '(\"\\\\.pdf\" \"\\\\.py\" \"+new-snippet+\"))

  (setq super-save-exclude '(\"pdf\" \"\\\\.pdf\" \"+new-snippet+\"))
  (setq-default super-save-exclude '(\"pdf\" \"\\\\.pdf\" \"+new-snippet+\"))

  (setq auto-save-default nil
        super-save-idle-duration 2
        super-save-auto-save-when-idle nil
        auto-save-file-name-transforms `((\".*\" \"~/emacs-profiles/my-emacs/var/temp\" t)))

  (setq super-save-hook-triggers '(mouse-leave-buffer-hook focus-out-hook))

  (setq super-save-triggers
        '(quickrun
          quit-window
          last-buffer
          windmove-up
          windmove-down
          windmove-left
          windmove-right
          switch-to-buffer
          delete-window
          eyebrowse-close-window-config
          eyebrowse-create-window-config
          eyebrowse-next-window-config
          eyebrowse-prev-window-config))

  (auto-save-mode -1)
  (super-save-mode +1))
" . 109164) 109182 (t 24239 53491 766742 544000) nil (162137 . 169852) ("(use-package python
  :ensure nil
  :init
  (add-hook 'python-mode-hook 'my-python-hooks)
  (add-hook 'inferior-python-mode-hook 'my-inferior-python-mode-hooks)

  ;; https://stackoverflow.com/a/6141681
  ;; (add-hook 'python-mode-hook
  ;;           (lambda ()
  ;;             (add-hook 'write-contents-functions (lambda() (elpy-black-fix-code)) nil t)))

  :config
  (font-lock-add-keywords 'python-mode
                          '((\"cls\" . font-lock-keyword-face)))
  (setq python-shell-interpreter \"python3\")
  (setq python-shell-interpreter-args \"-i -q\")

  (setq python-shell-completion-native-enable nil)

  (defun my-python-hooks ()
    (interactive)
    (flymake-mode -1)
    (electric-operator-mode +1)
    (flycheck-mode +1)
    (rainbow-delimiters-mode +1)
    (highlight-operators-mode +1)
    (evil-swap-keys-swap-double-single-quotes)
    (evil-swap-keys-swap-underscore-dash)
    (evil-swap-keys-swap-colon-semicolon)
    (smartparens-strict-mode +1)
    (my-company-idle-one-prefix-one-quiet)
    (highlight-numbers-mode +1)
    (yafolding-mode +1)
    (apheleia-mode +1)
    (importmagic-mode +1)
    (elpy-enable +1))

  (defun my-inferior-python-mode-hooks ()
    (interactive)
    (electric-operator-mode +1)
    (flycheck-mode +1)
    (rainbow-delimiters-mode +1)
    (highlight-operators-mode +1)
    (evil-swap-keys-swap-double-single-quotes)
    (evil-swap-keys-swap-underscore-dash)
    (evil-swap-keys-swap-colon-semicolon)
    (smartparens-strict-mode +1)
    (my-company-idle-one-prefix-one-quiet)
    (company-mode +1)
    (highlight-numbers-mode +1))

  (add-to-list 'company-backends 'company-jedi)

  ;; (setq-local company-backends '(company-jedi
  ;;                                company-dabbrev-code
  ;;                                company-files
  ;;                                (company-semantic
  ;;                                 company-capf
  ;;                                 company-keywords
  ;;                                 company-dabbrev
  ;;                                 company-shell)))

  (defun my/olivetti-narrow ()
    (interactive)
    (olivetti-mode +1)
    (setq-local olivetti-body-width 60))

  (defun my-python-hooks ()
    (interactive)
    (subword-mode 1)
    (electric-operator-mode +1)
    (company-mode)
    (flycheck-mode +1)
    (rainbow-delimiters-mode +1)
    (highlight-operators-mode +1)
    (evil-swap-keys-swap-double-single-quotes)
    (evil-swap-keys-swap-underscore-dash)
    (evil-swap-keys-swap-colon-semicolon)
    (smartparens-strict-mode +1)
    (my-company-idle-one-prefix-one-quiet)
    (highlight-numbers-mode +1)
    (elpy-enable +1)
    )

  ;; PYTHON KEYS ;;
  (general-define-key
   :keymaps 'inferior-python-mode-map
   \"C-j\" 'elpy-shell-switch-to-buffer
   \"M-e\" 'counsel-shell-history
   \"C-c j\" 'my/evil-shell-bottom
   \"C-c u\" 'universal-argument
   \"C-u\" 'comint-kill-input
   \"C-l\" 'comint-clear-buffer
   \"C-;\" 'my-elpy-switch-to-buffer
   \"C-n\" 'comint-next-input
   \"C-p\" 'comint-previous-input)

  (general-unbind 'inferior-python-mode-map
    :with 'elpy-shell-switch-to-buffer
    [remap save-buffer]
    [remap my-save-buffer]
    [remap comint-next-prompt])

  (general-unbind 'python-mode-map
    :with 'elpy-folding-toggle-at-point
    [remap hs-toggle-hiding])

  (general-unbind 'python-mode-map
    :with 'my-python-shebang
    [remap my-bash-shebang])

  (general-define-key
   :keymaps 'python-mode-map
   \"<M-return>\" 'apheleia-format-buffer
   \"M-a\" 'python-nav-backward-statement
   \"M-e\" 'python-nav-forward-statement
   \"C-S-p\" 'python-nav-backward-sexp
   \"C-S-n\" 'python-nav-forward-sexp
   \"C-x o\" 'my/olivetti-narrow
   \"C-x m\" 'elpy-multiedit-python-symbol-at-point
   \"C-x M\" 'elpy-multiedit-stop
   \"C-c g\" 'my/counsel-ag-python
   \"M-m\" 'flycheck-first-error
   \"C-c p\" 'my/python-make-print
   \"C-c f\" 'my/python-make-fstring
   \"C-c DEL\" 'my/erase-python-file
   \"C-c =\" 'my/erase-python-file-and-yank
   )

  (general-unbind 'python-mode-map
    :with 'yafolding-hide-all
    [remap evil-close-folds])

  (general-nmap
    :keymaps 'python-mode-map
    \"<escape>\" 'my-prog-save-buffer)

  (general-nvmap
    :keymaps 'python-mode-map
    \"zi\" 'yafolding-show-all
    \"M-a\" 'python-nav-backward-statement
    \"M-e\" 'python-nav-forward-statement
    \"C-S-p\" 'python-nav-backward-sexp
    \"C-S-n\" 'python-nav-forward-sexp
    \"C-ç\" 'my/python-newline-beg
    \"<backspace>\" 'org-edit-src-exit
    \"<C-return>\" 'my-quickrun
    \"<tab>\" 'elpy-folding-toggle-at-point
    \"<tab>\" 'elpy-folding-toggle-at-point
    \"RET\" 'hydra-python-mode/body
    \"zm\" 'evil-close-folds
    \"gh\" 'outline-up-heading
    \"gl\" 'outline-next-heading
    \"zl\" 'outline-show-subtree
    \"<\" 'python-indent-shift-left
    \">\" 'python-indent-shift-right
    \"gj\" 'outline-forward-same-level
    \"gk\" 'outline-backward-same-level)

  (defun my/python-newline-beg ()
    (interactive)
    (evil-insert-state)
    (newline)
    (beginning-of-line))

  (defun my/python-colon-newline ()
    (interactive)
    (end-of-line)
    (insert \":\")
    (newline-and-indent))

  (general-imap
    :keymaps 'python-mode-map
    \"C-=\"   'my/python-colon-newline
    \"C-ç\" 'my/python-newline-beg
    \"<C-return>\" 'my-quickrun
    \"C-h\" 'python-indent-dedent-line-backspace
    \"M-a\" 'python-nav-backward-statement
    \"M-e\" 'python-nav-forward-statement
    \"C-S-p\" 'python-nav-backward-sexp
    \"C-S-n\" 'python-nav-forward-sexp
    )

  ;; PYTHON FUNCTIONS;;

  (defun execute-python-program ()
    (interactive)
    (my/window-to-register-91)
    (my/quiet-save-buffer)
    (defvar foo-execute-python)
    (setq foo-execute-python (concat \"python3 \" (buffer-file-name)))
    (other-window 1)
    (switch-to-buffer-other-window \"*Async Shell Command*\")
    (shell-command foo))

  (defun my/execute-python-program-shell-simple  ()
    (interactive)
    (my/window-to-register-91)
    (my/quiet-save-buffer)
    (defvar foo-execute-python-simple)
    (setq foo-execute-python-simple (concat \"python3 \" (prelude-copy-file-name-to-clipboard)))
    (shell-command foo))

  (defun my/ex-python-run ()
    (interactive)
    (evil-ex \"w !python3\"))

  (defun my/execute-python-program-shell ()
    (interactive)
    (progn
      (my/quiet-save-buffer)
      (prelude-copy-file-name-to-clipboard)
      (shell)
      (sit-for 0.3)
      (insert \"source ~/scripts/cline_scripts/smallprompt.sh\")
      (comint-send-input)
      (insert \"python3 \")
      (yank)
      (comint-send-input)
      (evil-insert-state)
      (sit-for 0.3)
      (comint-clear-buffer)
      (company-mode -1)))

  (general-unbind 'python-mode-map
    :with 'elpy-doc
    [remap helpful-at-point])

  (defun my/run-python-external ()
    (interactive)
    (progn
      (prelude-copy-file-name-to-clipboard)
      (start-process-shell-command
       \"call term\" nil
       \"~/scripts/i3_scripts/show_term_right\")))

  (defun my/erase-python-file ()
    (interactive)
    (erase-buffer)
    (insert \"#!/usr/bin/env python3\\n\\n\")
    (evil-insert-state)
    (flycheck-clear))

  (defun my/erase-python-file-and-yank ()
    (interactive)
    (erase-buffer)
    (insert \"#!/usr/bin/env python3\\n\\n\")
    (yank))

  (defun my/kill-python-file ()
    (interactive)
    (kill-region (point-min) (point-max))
    (insert \"#!/usr/bin/env python3\\n\\n\")
    (evil-insert-state)
    (flycheck-clear))

  (defun my/python-save-buffer ()
    (interactive)
    (evil-ex-nohighlight)
    (let ((inhibit-message t))
      (delete-trailing-whitespace)
      (save-buffer)))

  ;; PYTHON SETTINGS

  (setq comment-auto-fill-only-comments t
        python-indent-offset 4
        python-indent-guess-indent-offset nil)

  (auto-fill-mode 1))
" . 162137) 162153 (t 24239 51986 267069 482000) nil (32212 . 46135) ("(use-package org
  :defer t
  :init

  ;; (add-hook 'org-cycle-hook 'org-toggle-tag-visibility)
  (add-hook 'org-mode-hook 'my-org-hooks)
  (add-hook 'org-src-mode-hook 'my-only-indent-buffer)
  (add-hook 'org-agenda-mode-hook 'my-org-agenda-hooks)

  (remove-hook 'org-cycle-hook #'org-optimize-window-after-visibility-change)

  :bind (:map org-src-mode-map
              (\"C-c DEL\" . org-edit-src-exit)
              (\"C-c RET\" . my-eval-buffer-and-leave-org-source))
  :config

  (defun my-org-agenda-goto ()
    (interactive)
    (org-agenda-goto)
    (delete-windows-on \"*Org Agenda*\"))

  (defun my-org-agenda-hooks ()
    (interactive)
    (hl-line-mode +1)
    (olivetti-mode +1))

  (defun my-org-hooks ()
    (interactive)
    ;; (evil-org-mode +1)
    (org-bullets-mode +1)
    (visual-line-mode +1)
    ;; (tab-jump-out-mode +1)
    (setq-local doom-modeline-enable-word-count nil))

  (general-unbind 'org-columns-map
    :with 'org-columns-quit
    [remap org-columns]
    [remap save-buffer])

  (general-define-key
   :keymaps 'org-mode-map
   \"C-x <up>\"   'org-shiftup
   \"C-x <down>\"   'org-shiftdown
   \"C-x <left>\"   'org-shiftleft
   \"C-x <right>\"   'org-shiftright
   \"C-c l\" 'evil-org-org-insert-heading-respect-content-below
   \"C-x ;\" 'org-timestamp-down
   \"C-x .\" 'org-timestamp-up
   \"M-p\" 'org-backward-paragraph
   \"M-n\" 'org-forward-paragraph
   \"C-c -\" 'my-insert-em-dash-space
   \"C-c C-n\" 'org-add-note
   \"C-c n\" 'org-add-note
   \"C-c y\" 'org-evaluate-time-range
   \"C-c C-s\" 'org-emphasize
   \"C-c o\" 'counsel-outline
   \"C-ç\" 'counsel-outline
   \"C-c q\" 'org-columns
   \"C-M-k\" 'org-metaup
   \"C-M-j\" 'org-metadown
   \"C-<\" 'org-priority-up
   \"C->\" 'org-priority-down
   \"C-c C-s\" 'org-emphasize
   \"<C-S-up>\" 'org-priority-up
   \"<C-S-down>\" 'org-priority-down)

  (general-nvmap
    :keymaps 'org-mode-map
    \"zb\" 'evil-scroll-line-to-bottom
    \"C-k\" 'my-kill-line)

  (general-nmap
    :keymaps 'org-mode-map
    \"C-c -\" 'my-insert-em-dash-space)

  (general-define-key
   :keymaps 'org-agenda-mode-map
   \"<S-left>\" 'org-agenda-date-earlier
   \"<S-right>\" 'org-agenda-date-later
   \"<escape>\" 'org-agenda-quit)

  (general-unbind 'org-agenda-mode-map
    :with 'windmove-up
    [remap org-agenda-drag-line-backward])

  (general-unbind 'org-agenda-mode-map
    :with 'windmove-down
    [remap org-agenda-drag-line-forward])

  (general-unbind 'org-agenda-mode-map
    :with 'my-org-agenda-goto
    [remap org-agenda-switch-to]
    [remap evil-ret])

  (general-unbind 'org-agenda-mode-map
    :with 'org-agenda-quit
    [remap evil-repeat-find-char-reverse]
    [remap org-agenda-goto-today])

  (general-unbind 'org-agenda-mode-map
    :with 'org-agenda-previous-item
    [remap org-agenda-previous-line]
    [remap evil-previous-visual-line])

  (general-unbind 'org-agenda-mode-map
    :with 'org-agenda-next-item
    [remap org-agenda-next-line]
    [remap evil-next-visual-line])

  (general-unbind 'org-agenda-mode-map
    :with 'org-todo-list
    [remap evil-find-char-to-backward])

  (general-unbind 'org-agenda-mode-map
    :with 'org-agenda-quit
    [remap minibuffer-keyboard-quit])

  (general-unbind 'org-mode-map
    :with 'org-emphasize
    [remap pyenv-mode-set])

  (general-unbind 'org-mode-map
    :with 'cool-moves-line-backward
    [remap org-shiftcontrolup])

  (general-unbind 'org-mode-map
    :with 'cool-moves-line-forward
    [remap org-shiftcontroldown])

  (general-define-key
   :keymaps 'org-mode-map
   :states   '(normal visual)
   \"TAB\"   'org-cycle)

  (general-unbind 'org-mode-map
    :with 'delete-char
    [remap org-metaleft])

  (general-define-key
   :keymaps 'org-mode-map
   :states '(normal visual)
   \"DEL\" 'org-edit-special)

  (general-nvmap
    :keymaps 'org-src-mode-map
    \"DEL\" 'org-edit-src-exit
    \"<backspace>\" 'org-edit-src-exit)

  (general-define-key
   :keymaps 'org-mode-map
   :states '(normal visual)
   \"<insert>\" 'org-insert-link
   \"DEL\" 'org-edit-special)

  (defun my-org-started-with-clock ()
    (interactive)
    (org-todo \"STRT\")
    (org-clock-in))

  (defun my-org-started-with-pomodoro ()
    (interactive)
    (org-todo \"STRT\")
    (org-pomodoro))

  (defun my-org-goto-clock-and-start-pomodoro ()
    (interactive)
    (org-clock-goto)
    (org-todo \"STRT\")
    (org-pomodoro))

  (defun my-org-started-no-clock ()
    (interactive)
    (org-todo \"STRT\"))

  (defun my-org-todo-done ()
    (interactive)
    (org-todo \"DONE\"))

  (defun my-org-todo-done-pomodoro ()
    (interactive)
    (org-todo \"DONE\")
    (org-pomodoro))

  (defun my-org-todo ()
    (interactive)
    (org-todo \"TODO\")
    (org-clock-out))

  (defun my-org-agenda ()
    (interactive)
    (org-agenda t \"a\"))

  (defun my-org-todos-agenda ()
    (interactive)
    (org-agenda t \"T\"))

  (defun org-today-agenda ()
    (interactive)
    (let ((current-prefix-arg 1)
          (org-deadline-warning-days 0))
      (org-agenda t \"a\")))

  (defun org-1-day-agenda ()
    (interactive)
    (let ((current-prefix-arg 1)
          (org-deadline-warning-days -1))
      (org-agenda t \"a\")))

  (defun org-2-days-agenda ()
    (interactive)
    (let ((current-prefix-arg 2)
          (org-deadline-warning-days 0))
      (org-agenda t \"a\")))

  (defun org-3-days-agenda ()
    (interactive)
    (let ((current-prefix-arg 3)
          (org-deadline-warning-days 0))
      (org-agenda t \"a\")))

  (defun org-4-days-agenda ()
    (interactive)
    (let ((current-prefix-arg 4)
          (org-deadline-warning-days 0))
      (org-agenda t \"a\")))

  (defun org-5-days-agenda ()
    (interactive)
    (let ((current-prefix-arg 5)
          (org-deadline-warning-days 0))
      (org-agenda t \"a\")))

  (defun org-6-days-agenda ()
    (interactive)
    (let ((current-prefix-arg 6)
          (org-deadline-warning-days 0))
      (org-agenda t \"a\")))

  (defun org-7-days-agenda ()
    (interactive)
    (let ((current-prefix-arg 7)
          (org-deadline-warning-days 0))
      (org-agenda t \"a\")))

  (defun org-30-days-agenda ()
    (interactive)
    (let ((current-prefix-arg 30)
          (org-deadline-warning-days 0))
      (org-agenda t \"a\")))

  ;; \"TODO(t)\" \"STRT(s)\" \"|\" \"DONE(d)\"
  ;; MAKES SOURCE BUFFER NAMES NICER ;;
  (defun org-src--construct-edit-buffer-name (org-buffer-name lang)
    (concat \"[S] \"org-buffer-name\"\"))

  ;; https://emacs.stackexchange.com/a/32039
  (defun org-toggle-tag-visibility (state)
    \"Run in `org-cycle-hook'.\"
    (interactive)
    (message \"%s\" state)
    (cond
     ;; global cycling
     ((memq state '(overview contents showall))
      (org-map-entries
       (lambda ()
         (let ((tagstring (nth 5 (org-heading-components)))
               start end)
           (when tagstring
             (save-excursion
               (beginning-of-line)
               (re-search-forward tagstring)
               (setq start (match-beginning 0)
                     end (match-end 0)))
             (cond
              ((memq state '(overview contents))
               (outline-flag-region start end t))
              (t
               (outline-flag-region start end nil))))))))
     ;; local cycling
     ((memq state '(folded children subtree))
      (save-restriction
        (org-narrow-to-subtree)
        (org-map-entries
         (lambda ()
           (let ((tagstring (nth 5 (org-heading-components)))
                 start end)
             (when tagstring
               (save-excursion
                 (beginning-of-line)
                 (re-search-forward tagstring)
                 (setq start (match-beginning 0)
                       end (match-end 0)))
               (cond
                ((memq state '(folded children))
                 (outline-flag-region start end t))
                (t
                 (outline-flag-region start end nil)))))))))))

  ;; REMOVE LINK
  ;; https://emacs.stackexchange.com/a/21945
  (defun my-org-remove-link  ()
    \"Replace an org link by its description or if empty its address\"
    (interactive)
    (if (org-in-regexp org-bracket-link-regexp 1)
        (save-excursion
          (let ((remove (list (match-beginning 0) (match-end 0)))
                (description (if (match-end 3)
                                 (match-string-no-properties 3)
                               (match-string-no-properties 1))))
            (apply 'delete-region remove)
            (insert description)))))

  ;; (setq org-agenda-files '(\"~/org/agenda.org\"))
  (setq org-agenda-files '(\"~/org/Agenda\"))

  ;; ORG FONTIFICATION AND SRC BLOCKS ;;
  (setq org-fontify-done-headline t
        org-src-fontify-natively t
        org-odt-fontify-srcblocks t
        org-src-tab-acts-natively t
        org-fontify-whole-heading-line nil
        org-fontify-quote-and-verse-blocks nil)

  (setq org-indent-mode nil
        org-clock-persist t
        org-tags-column -77
        org-clock-in-resume t
        org-pretty-entities t
        org-log-into-drawer t
        org-lowest-priority 73
        org-startup-indented t
        org-clock-into-drawer t
        org-default-priority 65
        org-export-with-toc nil
        org-cycle-level-faces t
        org-export-with-tags nil
        org-use-speed-commands t
        require-final-newline nil
        org-return-follows-link t
        org-image-actual-width nil
        org-agenda-tags-column -80
        org-id-link-to-org-use-id t
        org-clock-history-length 10
        org-clock-update-period 240
        org-footnote-auto-adjust 't
        org-export-preserve-breaks t
        org-hide-emphasis-markers t
        org-replace-disputed-keys t
        org-timer-display 'mode-line
        org-deadline-warning-days 14
        org-agenda-show-all-dates nil
        calendar-date-style 'european
        org-export-html-postamble nil
        mode-require-final-newline nil
        org-export-with-broken-links t
        org-export-time-stamp-file nil
        org-src-preserve-indentation t
        org-confirm-babel-evaluate nil
        org-clock-mode-line-total 'auto
        org-agenda-hide-tags-regexp \".\"
        org-agenda-show-outline-path nil
        org-export-with-todo-keywords nil
        org-show-notification-handler nil
        org-refile-use-outline-path 'file
        org-link-file-path-type 'relative
        org-clock-persist-query-resume t
        org-agenda-skip-archived-trees nil
        org-edit-src-content-indentation 1
        org-export-with-archived-trees nil
        org-agenda-skip-deadline-if-done t
        org-agenda-skip-timestamp-if-done t
        org-agenda-skip-scheduled-if-done t
        org-clock-auto-clock-resolution nil
        org-edit-src-persistent-message nil
        org-edit-src-auto-save-idle-delay 1
        org-src-window-setup 'current-window
        org-clock-sound \"~/Sounds/cuckoo.au\"
        org-agenda-show-future-repeats 'next
        org-agenda-skip-unavailable-files 't
        org-babel-no-eval-on-ctrl-c-ctrl-c t
        org-src-window-setup 'current-window
        org-outline-path-complete-in-steps nil
        org-clock-out-remove-zero-time-clocks t
        org-clock-report-include-clocking-task t
        org-clock-clocked-in-display 'mode-line
        org-allow-promoting-top-level-subtree nil
        org-enforce-todo-checkbox-dependencies t
        org-refile-allow-creating-parent-nodes nil
        org-src-ask-before-returning-to-edit-buffer nil
        org-agenda-skip-timestamp-if-deadline-is-shown t
        org-pretty-entities-include-sub-superscripts nil
        org-agenda-skip-additional-timestamps-same-entry 't)

  (setq org-ellipsis \".\")
  (setq org-timer-format \"%s \")
  (setq-default org-export-html-postamble nil)
  (setq org-refile-targets '((projectile-project-buffers :maxlevel . 3)))
  (setq org-blank-before-new-entry '((heading . nil) (plain-list-item . nil)))
  (setq org-global-properties
        '((\"Effort_ALL\" .
           \"00:04 00:08 00:12 00:16 00:20 00:24 00:28\")))
  (setq org-html-htmlize-output-type 'css)

  ;; (setq org-modules '(ol-w3m ol-bbdb ol-bibtex ol-docview ol-gnus ol-info ol-irc ol-mhe ol-rmail ol-eww ol-habit))
  ;; (setq org-modules '(ol-w3m ol-bbdb ol-bibtex ol-docview ol-gnus ol-info ol-irc ol-mhe ol-rmail ol-eww))

  (setq org-babel-temporary-directory (concat user-emacs-directory \"babel-temp\"))

  (setq org-archive-location \".%s::datetree/\")
  (setq org-drawers (quote (\"PROPERTIES\" \"LOGBOOK\"))) ;; Separate drawers for clocking and logs
  (setq org-format-latex-options
        (plist-put org-format-latex-options :scale 1.3))

  (setq org-todo-keywords
        '((sequence \"TODO(t)\" \"STRT(s!)\" \"|\" \"DONE(d!)\")))

  (setq org-file-apps (quote ((auto-mode . emacs)
                              (\"\\\\.mm\\\\'\" . default)
                              (\"\\\\.x?html?\\\\'\" . default)
                              (\"\\\\.jpg\\\\'\" . \"viewnior %s\")
                              (\"\\\\.mp4\\\\'\" . \"vlc %s\")
                              (\"\\\\.webm\\\\'\" . \"vlc %s\")
                              (\"\\\\.pdf\\\\'\" . \"zathura %s\")
                              (\"\\\\.epub\\\\'\" . \"ebook-viewer %s\")
                              ;; (\"\\\\.pdf\\\\'\" . \"org-pdfview-open %s\")
                              )))
  (add-to-list 'org-src-lang-modes '(\"i3\" . i3wm-config))

  ;; CAPTURE TEMPLATES ;;
  (setq org-capture-templates
        '((\"a\" \"Agenda\" entry
           (file+headline
            \"~/org/Agenda/agenda.org\" \"Tasks\")
           \"* TODO %i%^{1|Title}\\nDEADLINE: \\%^t\\n%^{2}\" :immediate-finish t)

          (\"t\" \"Tech\" entry
           (file+headline \"~/org/Agenda/agenda.org\" \"Tech\")
           \"* TODO %i%^{1|Title}\\n\\%u\\n%^{2}\"
           :immediate-finish t)

          (\"e\" \"Emacs\" entry
           (file+headline
            \"~/org/Agenda/agenda.org\" \"Emacs\")
           \"* TODO %i%^{1|Title}\\n\\%u\\n%^{2}\" :immediate-finish t)

          ))

  ;; https://emacs.stackexchange.com/a/41685
  ;; Requires org-plus-contrib (above)
  (require 'ox-extra)
  (ox-extras-activate '(ignore-headlines)))
" . 32212) 43314 (t 24239 51951 446503 744000)) (emacs-buffer-undo-list nil (609 . 615) (t 24242 33689 577716 641000) nil (170 . 173) (t 24241 17510 505857 749000) nil ("
" . 2269) ((marker* . 2278) . 1) nil ("
" . 2269) ((marker* . 2278) . 1) nil ("Maybe I'll " . -2269) ((marker . 2278) . -11) ((marker . 2278) . -1) ((marker . 2278) . -1) ((marker . 2278) . -2) ((marker . 2278) . -1) ((marker . 2278) . -2) ((marker . 2278) . -3) ((marker . 2278) . -2) ((marker . 2278) . -3) ((marker . 2278) . -4) ((marker . 2278) . -3) ((marker . 2278) . -4) ((marker . 2278) . -5) ((marker . 2278) . -4) ((marker . 2278) . -5) ((marker . 2278) . -6) ((marker . 2278) . -5) ((marker . 2278) . -6) ((marker . 2278) . -7) ((marker . 2278) . -6) ((marker . 2278) . -7) ((marker . 2278) . -6) ((marker . 2278) . -8) ((marker . 2278) . -6) ((marker . 2278) . -7) ((marker . 2278) . -6) ((marker . 2278) . -8) ((marker . 2278) . -6) ((marker . 2278) . -7) ((marker . 2278) . -8) ((marker . 2278) . -7) ((marker . 2278) . -8) ((marker . 2278) . -9) ((marker . 2278) . -8) ((marker . 2278) . -9) ((marker . 2278) . -10) ((marker . 2278) . -9) ((marker . 2278) . -10) ((marker . 2278) . -11) ((marker . 2278) . -10) ((marker . 2278) . -11) 2280 (2269 . 2280) (2268 . 2269) (2267 . 2268) 2225 nil (2224 . 2225) nil ("

" . 2224) ((marker . 2233) . -2) ((marker . 2233) . -1) ((marker . 2233) . -1) ((marker . 2233) . -1) ((marker . 2233) . -2) ((marker . 2233) . -2) ((marker . 2233) . -2) ((marker . 2233) . -2) ((marker . 2233) . -2) ((marker . 2233) . -2) ((marker . 2233) . -2) ((marker . 2233) . -2) ((marker . 2233) . -2) ((marker . 2233) . -1) ((marker . 2233) . -1) ((marker . 2233) . -1) ((marker . 2233) . -1) ((marker . 2233) . -1) ((marker . 2233) . -1) ((marker . 2233) . -2) ((marker . 2233) . -2) ((marker . 2233) . -2) ((marker . 2233) . -2) ((marker . 2233) . -2) ((marker . 2233) . -2) ((marker . 2233) . -1) ((marker . 2233) . -1) ((marker . 2233) . -1) ((marker) . -1) (2223 . 2224) (t 24241 17482 377780 140000) 2203 nil (" " . -2223) ((marker . 2278) . -1) ((marker . 2232) . -1) ((marker . 2232) . -1) 2224 (2222 . 2224) (". " . -2222) ((marker . 2278) . -1) ((marker . 2231) . -1) ((marker . 2231) . -1) 2224 (2223 . 2224) (t 24241 17432 516679 671000) nil (2091 . 2093) (t 24241 17413 372082 786000) nil ("great " . 1776) (t 24241 17411 49705 180000) nil (1734 . 1747) (t 24241 17384 699739 306000) nil (1604 . 1614) ("more common and" . 1604) ((marker . 2101) . -14) ((marker . 1668) . -14) ((marker . 2278) . -14) ((marker) . -14) 1618 (t 24241 17346 930984 116000) nil (1311 . 1317) ("superior" . 1311) (t 24241 17339 291804 853000) nil (1262 . 1267) (t 24241 17301 227317 244000) nil (1237 . 1249) ("I have at" . 1237) ((marker . 2101) . -8) ((marker . 1668) . -8) ((marker . 2278) . -8) ((marker) . -8) 1245 (t 24241 17274 425344 881000) nil (1046 . 1049) ("or" . 1046) (t 24241 17199 57870 3000) nil (465 . 466) ("After failing as a filmmaker (in terms of putting food on the table), i" . 465) ((marker . 2101) . -70) ((marker . 1668) . -70) ((marker . 2278) . -70) ((marker) . -70) 535 (t 24241 17180 72647 167000) nil (" " . 382) ((marker* . 1669) . 1) ((marker* . 2278) . 1) nil ("everything I'm doing and" . 382) ((marker . 2101) . -23) ((marker . 1668) . -23) ((marker* . 2278) . 24) ((marker . 2278) . -23) ((marker) . -23) 405 (t 24241 17158 118747 732000) nil (" " . 2423) nil (2422 . 2424) ("." . -2422) 2423 (2407 . 2423) (2400 . 2407) ("," . -2400) 2401 (2395 . 2401) ("r" . -2395) ((marker . 2278) . -1) ("e" . -2396) ((marker . 2278) . -1) 2397 (2381 . 2397) (",  " . -2381) ((marker . 2278) . -2) 2384 (2381 . 2384) ("," . -2381) 2382 (2376 . 2382) (": " . -2376) ((marker . 2278) . -1) 2378 (2377 . 2378) (t 24241 17147 302503 887000) nil (1993 . 1995) (".  " . 1993) ((marker* . 2278) . 1) ((marker . 2278) . -1) 1995 (1994 . 1995) (t 24241 17131 600532 175000) nil (" " . 2377) 1685 (t 24241 17128 243788 185000) nil (2376 . 2378) (":" . -2376) 2377 (2376 . 2377) (2356 . 2376) ("y" . -2356) ((marker . 2278) . -1) ("a" . -2357) ((marker . 2278) . -1) 2358 (2353 . 2358) ("O" . -2353) ((marker . 2278) . -1) 2354 (2353 . 2354) (2352 . 2353) (2351 . 2352) (t 24241 17114 748907 323000) 2350 nil ("at least I " . 2320) ((marker . 2101) . -10) ((marker . 1668) . -10) ((marker . 2278) . -10) ((marker) . -10) 2330 (t 24241 17088 517297 465000) nil (2216 . 2269) ("this book" . -2216) ((marker . 1668) . -8) ((marker) . -9) ((marker . 2231) . -9) ((marker . 2278) . -8) (t 24241 17061 35689 435000) nil (2231 . 2240) (t 24241 17057 36407 986000) nil (" " . 2254) 2209 (t 24241 17054 733742 706000) nil (2253 . 2255) ("." . -2253) 2254 (2249 . 2254) nil ("some " . 2244) nil (2244 . 2254) ("moe" . -2244) ((marker . 2278) . -3) 2247 (2235 . 2247) ("l" . -2235) ((marker . 2278) . -1) ("k" . -2236) ((marker . 2278) . -1) 2237 (2225 . 2237) ("," . -2225) 2226 (2225 . 2226) (2204 . 2225) (2202 . 2204) (t 24241 17027 636844 748000) (2200 . 2202) (". " . -2200) ((marker . 2278) . -1) 2202 (2201 . 2202) (" " . -2201) ((marker . 2278) . -1) 2202 (2200 . 2202) (". " . -2200) ((marker . 2278) . -1) 2202 (2201 . 2202) (t 24241 17020 602933 621000) nil ("of Python " . 2155) (t 24241 17016 286275 532000) nil (2170 . 2171) ("S" . 2170) ((marker* . 2278) . 1) nil (2168 . 2170) (", " . 2168) 2169 (2168 . 2169) ("." . 2168) (t 24241 17004 380323 764000) nil ("And " . 2084) (t 24241 17000 997666 323000) nil (2036 . 2042) (2034 . 2036) (t 24241 16995 602751 367000) nil (2004 . 2005) (t 24241 16994 233203 199000) nil ("m" . 2004) ((marker* . 2278) . 1) nil ("*actually* " . 2004) ((marker* . 2278) . 11) nil (2000 . 2004) ("s" . -2000) ((marker . 2278) . -1) 2001 (1993 . 2001) (". " . 1993) 1994 (1993 . 1994) ("," . -1993) ((marker . 2278) . -1) 1994 (t 24241 16979 71036 394000) nil (1964 . 1969) ("weaks" . 1964) ((marker . 2101) . -5) ((marker . 1887) . -5) ((marker . 2231) . -5) (t 24241 16965 172841 496000) nil (1969 . 1971) ("," . -1969) 1970 (1968 . 1970) (1947 . 1968) ("Now " . -1947) ((marker . 2278) . -4) 1951 ("n" . -1951) ((marker . 2278) . -1) ("o" . -1952) ((marker . 2278) . -1) 1953 (1951 . 1953) (t 24241 16939 972893 637000) nil (2047 . 2056) (2043 . 2047) ("i" . -2043) ((marker . 2231) . -1) ((marker . 2278) . -1) (" " . -2044) ((marker . 2231) . -1) ((marker . 2278) . -1) 2045 (2027 . 2045) ("qutting" . -2027) ((marker . 2278) . -7) 2034 (2022 . 2034) nil ("and " . 2009) ((marker* . 2278) . 4) (t 24241 16913 525702 581000) nil (2181 . 2188) (t 24241 16907 781611 234000) nil ("have " . 2172) (t 24241 16906 211469 95000) nil (" " . 2212) nil (2211 . 2213) ("." . -2211) 2212 (2203 . 2212) (2190 . 2203) ("reason to" . 2190) ((marker . 2231) . -8) (t 24241 16901 105984 137000) nil (" " . 2199) nil (2190 . 2200) ("h" . -2190) ((marker . 2278) . -1) 2191 (2177 . 2191) (t 24241 16885 531220 636000) (2170 . 2177) (2168 . 2170) ("," . -2168) 2169 (2161 . 2169) (2160 . 2161) (2159 . 2160) (t 24241 16877 448358 938000) 2118 nil (" " . 2159) nil (2158 . 2160) ("." . -2158) 2159 (2145 . 2159) ("l" . -2145) ((marker . 2278) . -1) 2146 (2136 . 2146) (t 24241 16872 814036 838000) (2118 . 2136) ("Two " . -2118) ((marker . 2278) . -4) 2122 ("day" . -2122) ((marker . 2278) . -3) 2125 ("! " . -2125) ((marker . 2278) . -2) 2127 (2116 . 2127) (". " . -2116) ((marker . 2278) . -1) 2118 (2117 . 2118) (t 24241 16796 525062 667000) nil (" " . 2117) nil (2116 . 2118) ("." . -2116) 2117 (2108 . 2117) ("u" . -2108) ((marker . 2278) . -1) 2109 (2107 . 2109) ("u" . -2107) ((marker . 2278) . -1) ("y" . -2108) ((marker . 2278) . -1) ("t" . -2109) ((marker . 2278) . -1) 2110 (2106 . 2110) ("p" . -2106) ((marker . 2278) . -1) 2107 (2096 . 2107) (2084 . 2096) (t 24241 16784 886365 848000) (2077 . 2084) (t 24241 16778 315884 975000) nil ("of " . 2073) ((marker . 2278) . -2) nil (2073 . 2076) (t 24241 16778 315884 975000) nil (2072 . 2077) (t 24241 16773 353234 6000) nil (1847 . 1853) ("plays" . 1847) ((marker* . 2278) . 5) nil (1833 . 1847) (1820 . 1833) (t 24241 16764 965693 746000) nil (" " . 2044) ((marker . 2231) . -1) ((marker . 2047) . -1) ((marker . 2047) . -1) (t 24241 16761 448967 616000) nil (2036 . 2045) (t 24241 16757 932159 227000) (2034 . 2036) (". " . -2034) ((marker . 2278) . -1) ((marker . 2037) . -1) ((marker . 2037) . -1) ((marker . 2037) . -1) ((marker . 2037) . -1) ((marker . 2037) . -1) ((marker . 2037) . -1) ((marker . 2037) . -1) ((marker . 2037) . -1) 2036 (2035 . 2036) (t 24241 16747 152586 522000) nil (" " . 2035) ((marker . 2037) . -1) ((marker . 2037) . -1) (t 24241 16742 619166 590000) nil (2034 . 2036) ("." . -2034) 2035 (2029 . 2035) ("r" . -2029) ((marker . 2278) . -1) ((marker . 2032) . -1) ((marker . 2032) . -1) 2030 (2022 . 2030) (t 24241 16738 136157 19000) (2018 . 2022) (t 24241 16728 411696 241000) (2010 . 2018) ("r" . -2010) ((marker . 2278) . -1) 2011 (2008 . 2011) ("l" . -2008) ((marker . 2278) . -1) 2009 (1998 . 2009) (". " . -1998) ((marker . 2278) . -1) 2000 (1999 . 2000) (t 24241 16710 820146 589000) nil (1846 . 1863) (", " . 1846) ((marker* . 2278) . 1) ((marker . 1797) . -2) ((marker . 1797) . -2) ((marker . 1797) . -2) ((marker . 1797) . -2) ((marker . 1797) . -2) ((marker . 1797) . -2) ((marker . 1797) . -2) ((marker . 1797) . -2) ((marker . 1797) . -2) ((marker . 1797) . -2) ((marker . 1797) . -2) ((marker . 1797) . -2) ((marker . 1797) . -2) ((marker . 1797) . -2) ((marker . 1797) . -2) ((marker . 1797) . -2) ((marker . 1797) . -2) 1847 (1834 . 1847) (1820 . 1834) ("has " . -1820) ((marker . 2278) . -4) ((marker . 1736) . -2) ((marker . 1736) . -2) ((marker . 1736) . -4) ((marker . 1736) . -2) ((marker . 1736) . -4) ((marker . 1736) . -4) ((marker . 1736) . -4) ((marker . 1736) . -4) ((marker . 1736) . -4) ((marker . 1736) . -4) ((marker . 1736) . -4) ((marker . 1736) . -4) ((marker . 1736) . -4) ((marker . 1736) . -4) ((marker . 1736) . -4) ((marker . 1736) . -4) ((marker . 1736) . -4) ((marker . 1736) . -4) ((marker . 1736) . -4) ((marker . 1736) . -4) ((marker . 1736) . -4) ((marker . 1736) . -4) ((marker . 1736) . -4) 1824 ("a " . -1824) ((marker . 2278) . -2) ((marker . 1736) . -2) ((marker . 1736) . -2) ((marker . 1736) . -2) ((marker . 1736) . -2) ((marker . 1736) . -2) ((marker . 1736) . -2) ((marker . 1736) . -2) ((marker . 1736) . -2) ((marker . 1736) . -2) ((marker . 1736) . -2) ((marker . 1736) . -2) ((marker . 1736) . -2) ((marker . 1736) . -2) ((marker . 1736) . -2) 1826 ("great " . -1826) ((marker . 2278) . -6) ((marker . 1736) . -3) ((marker . 1736) . -3) ((marker . 1736) . -4) ((marker . 1736) . -3) ((marker . 1736) . -4) ((marker . 1736) . -5) ((marker . 1736) . -4) ((marker . 1736) . -5) ((marker . 1736) . -6) ((marker . 1736) . -5) ((marker . 1736) . -6) 1832 (1830 . 1832) nil (1815 . 1830) ("I" . 1815) (t 24241 16686 960932 327000) nil (" " . 1953) ((marker . 2231) . -1) (t 24241 16684 480330 737000) nil (1952 . 1954) ("." . -1952) 1953 (1952 . 1953) (t 24241 16678 596879 345000) nil (1899 . 1901) (", " . 1899) ((marker* . 2278) . 1) 1900 (1899 . 1900) (t 24241 16676 619876 361000) nil (1888 . 1899) ("p" . -1888) ((marker . 2278) . -1) ("i" . -1889) ((marker . 2278) . -1) ("n" . -1890) ((marker . 2278) . -1) 1891 (1885 . 1891) ("ju" . -1885) ((marker . 2278) . -2) 1887 (1885 . 1887) ("taking " . -1885) ((marker . 2278) . -7) 1892 (1880 . 1892) (t 24241 16664 406159 873000) nil (1913 . 1919) ("," . -1913) 1914 (1907 . 1914) ("t" . -1907) ((marker . 2278) . -1) 1908 (1904 . 1908) (t 24241 16658 17927 845000) nil ("," . -1917) ((marker . 2278) . -1) (" " . -1918) ((marker . 2278) . -1) 1919 (1917 . 1919) ("," . -1917) 1918 (1910 . 1918) (1873 . 1874) ("n" . 1873) nil ("So " . 1873) nil (1905 . 1913) ("," . -1905) 1906 (1887 . 1906) ("u" . -1887) ((marker . 2278) . -1) ("t" . -1888) ((marker . 2278) . -1) 1889 (1880 . 1889) (1873 . 1880) (1872 . 1873) (1871 . 1872) 1871 ("


So I established a cutoff: I won’t study more than 2.5 hours a day. I can and will increase the amount of time from there, but only when my brain acquires enough resilience to deal with the extra load.

2.5 hours may look like nothing, but it’s a great achievement for me.

I'm actually doing fine for the most part." . 1871) ((marker . 2101) . -3) ((marker . 1668) . -3) ((marker* . 1669) . 316) ((marker . 1668) . -3) ((marker . 1668) . -3) ((marker . 2231) . -3) ((marker . 2278) . -1) ((marker . 1868) . -2) ((marker . 1868) . -2) ((marker . 1868) . -2) ((marker . 1868) . -2) ((marker . 1868) . -2) ((marker . 1868) . -2) ((marker . 1868) . -2) ((marker . 1868) . -2) ((marker . 1868) . -2) ((marker . 1868) . -2) ((marker . 1868) . -2) ((marker . 1868) . -2) ((marker . 1868) . -2) ((marker . 1868) . -2) ((marker . 1868) . -2) ((marker . 1868) . -2) ((marker . 1868) . -2) ((marker . 1868) . -2) ((marker . 1868) . -2) ((marker . 1868) . -2) ((marker . 1868) . -2) ((marker . 1868) . -2) ((marker . 1868) . -2) ((marker . 1868) . -2) 1872 (t 24241 16636 469421 449000) nil (" I have severe ADHD, and every time I start something I want to dedicate 4-6 hours a day. That doesn’t work, and I give up stressed and burnt out.

" . 1874) ((marker . 2101) . -147) ((marker . 1668) . -147) ((marker . 2278) . -147) ((marker) . -147) 2021 (t 24241 16634 279448 285000) nil ("The desire to push myself to the limit is at the root of many of my failures." . 1874) ((marker . 2278) . -77) 1951 (t 24241 16630 585044 316000) nil (1814 . 1815) ("
" . -1814) ((marker) . -1) ((marker . 1730) . -1) ((marker . 1730) . -1) ((marker . 1730) . -1) ((marker . 1730) . -1) ((marker . 1730) . -1) ((marker . 1730) . -1) ((marker . 1730) . -1) ((marker . 1730) . -1) ((marker . 1730) . -1) ((marker . 1730) . -1) ((marker . 1730) . -1) ((marker . 1730) . -1) ((marker . 1730) . -1) ((marker . 1730) . -1) ((marker . 1730) . -1) ((marker . 1730) . -1) ((marker . 1730) . -1) ((marker . 1730) . -1) ((marker . 1730) . -1) ((marker . 1730) . -1) ((marker . 1730) . -1) ((marker . 1730) . -1) ((marker . 1730) . -1) 1813 nil ("
" . -1814) 1813 nil (" It's better to do less while keeping a healthy mind than to do a lot and get burnt out." . 1872) ((marker . 2231) . -3) (t 24241 16625 760927 323000) nil (1875 . 1876) ("’" . 1875) (t 24241 16622 913023 570000) nil (1860 . 1861) (1855 . 1860) ("everything" . 1855) (t 24241 16617 691377 942000) nil (1849 . 1854) nil ("learn" . 1849) (t 24241 16617 691377 942000) nil (1832 . 1839) (t 24241 16615 424417 489000) nil (1830 . 1832) (", " . 1830) ((marker* . 1669) . 1) ((marker . 1826) . -2) ((marker . 1826) . -2) ((marker . 1826) . -2) 1831 (1818 . 1831) ("spent 3 years arrogantly" . 1818) ((marker . 2101) . -23) ((marker . 1668) . -23) ((marker . 2278) . -23) ((marker) . -24) ((marker) . -23) ((marker . 1797) . -4) ((marker . 1797) . -4) ((marker . 1797) . -6) ((marker . 1797) . -4) ((marker . 1797) . -6) ((marker . 1797) . -12) ((marker . 1797) . -6) ((marker . 1797) . -12) ((marker . 1797) . -23) ((marker . 1797) . -12) ((marker . 1797) . -23) ((marker . 1797) . -23) ((marker . 1797) . -14) ((marker . 1797) . -14) ((marker . 1797) . -23) ((marker . 1797) . -14) ((marker . 1797) . -23) 1841 (t 24241 16602 774702 729000) nil (" " . 1814) ((marker . 1730) . -1) ((marker . 1730) . -1) 1817 nil ("Don’t rush. Even if something looks silly, do not skip steps. " . 1817) ((marker . 2278) . -62) ((marker . 1730) . -39) ((marker . 1730) . -39) ((marker . 1730) . -41) ((marker . 1730) . -39) ((marker . 1730) . -41) ((marker . 1730) . -43) ((marker . 1730) . -41) ((marker . 1730) . -43) ((marker . 1730) . -46) ((marker . 1730) . -43) ((marker . 1730) . -46) ((marker . 1730) . -50) ((marker . 1730) . -46) ((marker . 1730) . -50) ((marker . 1730) . -55) ((marker . 1730) . -50) ((marker . 1730) . -55) ((marker . 1730) . -60) ((marker . 1730) . -55) ((marker . 1730) . -60) ((marker . 1730) . -62) ((marker . 1730) . -60) ((marker . 1730) . -62) 1879 nil (1813 . 1815) ("." . -1813) 1814 (1799 . 1814) ("," . -1799) 1800 (1799 . 1800) ("." . 1799) ((marker . 1715) . -1) ((marker . 1715) . -1) ((marker . 1715) . -1) ((marker . 1715) . -1) ((marker . 1715) . -1) ((marker . 1715) . -1) ((marker . 1715) . -1) ((marker . 1715) . -1) ((marker . 1715) . -1) (t 24241 16595 840711 699000) nil (1800 . 1801) 1799 (t 24241 16594 466031 600000) nil ("
" . -1800) ((marker* . 1669) . 1) ((marker* . 2278) . 1) 1799 (t 24241 16593 477520 76000) nil (" " . 1800) ((marker . 1715) . -1) ((marker . 1715) . -1) nil (1799 . 1801) ("." . -1799) 1800 (1780 . 1800) ("a" . -1780) ((marker . 2278) . -1) ((marker . 1696) . -1) ((marker . 1696) . -1) 1781 (1773 . 1781) ("i " . -1773) ((marker . 2278) . -2) ((marker . 1689) . -1) ((marker . 1689) . -1) ((marker . 1689) . -2) ((marker . 1689) . -1) ((marker . 1689) . -2) ((marker . 1689) . -2) ((marker . 1689) . -2) ((marker . 1689) . -2) ((marker . 1689) . -2) ((marker . 1689) . -2) ((marker . 1689) . -2) ((marker . 1689) . -2) ((marker . 1689) . -2) ((marker . 1689) . -2) ((marker . 1689) . -2) ((marker . 1689) . -2) ((marker . 1689) . -2) 1775 ("mus" . -1775) ((marker . 2278) . -3) ((marker . 1689) . -1) ((marker . 1689) . -1) ((marker . 1689) . -2) ((marker . 1689) . -1) ((marker . 1689) . -2) ((marker . 1689) . -3) ((marker . 1689) . -2) ((marker . 1689) . -3) 1778 (1773 . 1778) ("and you’ll eventually do more." . 1773) ((marker . 2101) . -20) ((marker* . 1669) . 9) ((marker . 1668) . -20) ((marker . 1689) . -30) ((marker . 1689) . -29) ((marker . 1689) . -29) ((marker . 1689) . -4) ((marker . 1689) . -29) ((marker . 1689) . -4) ((marker . 1689) . -4) ((marker . 1689) . -2) ((marker . 1689) . -2) ((marker . 1689) . -6) ((marker . 1689) . -2) ((marker . 1689) . -6) ((marker . 1689) . -7) ((marker . 1689) . -6) ((marker . 1689) . -7) ((marker . 1689) . -8) ((marker . 1689) . -7) ((marker . 1689) . -8) ((marker . 1689) . -9) ((marker . 1689) . -8) ((marker . 1689) . -9) ((marker . 1689) . -20) ((marker . 1689) . -9) ((marker . 1689) . -20) ((marker . 1689) . -20) ((marker . 1689) . -20) ((marker . 1689) . -20) ((marker . 1689) . -20) ((marker . 1689) . -20) ((marker . 1689) . -20) ((marker . 1689) . -20) ((marker) . -20) ((marker . 1689) . -20) ((marker . 1689) . -20) ((marker . 1689) . -20) ((marker . 1689) . -20) ((marker . 1689) . -20) ((marker . 1689) . -20) ((marker . 1689) . -20) ((marker . 1689) . -20) ((marker . 1689) . -20) ((marker . 1689) . -11) ((marker . 1689) . -20) ((marker . 1689) . -11) ((marker . 1689) . -8) ((marker . 1689) . -11) ((marker . 1689) . -8) ((marker . 1689) . -7) ((marker . 1689) . -8) ((marker . 1689) . -7) ((marker . 1689) . -4) ((marker . 1689) . -7) ((marker . 1689) . -4) ((marker . 1689) . -4) nil (1767 . 1771) ("less" . 1767) ((marker . 1683) . -4) ((marker . 1683) . -4) ((marker . 1683) . -4) (t 24241 16574 659862 876000) nil (1764 . 1766) (1752 . 1764) ("Do" . 1752) ((marker* . 2278) . 2) nil (1751 . 1752) ("
" . -1751) ((marker . 1667) . -1) ((marker . 1667) . -1) ((marker . 1667) . -1) 1689 (t 24241 16563 724901 728000) nil ("is " . 1692) ((marker . 1613) . -3) ((marker . 1613) . -3) ((marker . 1613) . -3) ((marker*) . 3) ((marker) . -2) (t 24241 16561 477375 194000) nil ("Anxiety " . 1692) nil (1691 . 1692) ("
" . -1691) ((marker . 1612) . -1) ((marker . 1612) . -1) ((marker . 1612) . -1) ((marker . 1612) . -1) 1690 nil ("
" . -1691) ((marker . 1612) . -1) ((marker . 1612) . -1) ((marker . 1612) . -1) ((marker . 1612) . -1) ((marker . 1612) . -1) ((marker . 1612) . -1) ((marker . 1612) . -1) ((marker . 1612) . -1) ((marker . 1612) . -1) ((marker . 1612) . -1) 1689 nil (nil rear-nonsticky nil 1692 . 1693) ("
" . -1803) (1692 . 1804) (t 24241 16559 19656 403000) nil (1691 . 1693) 1689 (t 24241 16557 336021 402000) nil ("Anxiety is more common and harder to deal than a lack of intelligence.
Do less, and you’ll eventually do more.
" . 1908) ((marker . 2101) . -79) ((marker . 1668) . -8) ((marker . 1668) . -79) ((marker . 1689) . -69) ((marker . 2278) . -79) ((marker* . 2278) . 1) ((marker . 1868) . -109) ((marker . 1868) . -109) ((marker . 1868) . -109) ((marker . 1868) . -109) ((marker . 1868) . -109) ((marker . 1868) . -109) ((marker . 1868) . -70) ((marker . 1868) . -69) ((marker . 1868) . -69) ((marker . 1868) . -69) ((marker . 1868) . -69) ((marker . 1868) . -69) ((marker . 1868) . -69) ((marker . 1868) . -8) ((marker . 1868) . -8) ((marker . 1868) . -8) ((marker . 1868) . -8) ((marker . 1868) . -8) ((marker) . -111) ((marker . 1868) . -8) ((marker . 1868) . -8) ((marker) . -8) ((marker) . -79) ((marker . 1868) . -8) ((marker . 1868) . -79) ((marker . 1868) . -8) ((marker . 1868) . -79) 1987 (t 24241 16553 380067 326000) nil (" " . 1908) nil ("." . 1908) nil ("e" . 1908) (t 24241 16552 227470 655000) nil (nil rear-nonsticky nil 1980 . 1981) (nil fontified nil 1908 . 1981) (1908 . 1981) nil (1907 . 1908) (t 24241 16542 818760 549000) nil (nil rear-nonsticky nil 1946 . 1947) (nil fontified nil 1692 . 1947) (1692 . 1947) nil (1691 . 1692) 1690 (t 24241 16541 248773 822000) nil (" " . 1691) ((marker . 2231) . -1) ((marker . 1612) . -1) ((marker . 1612) . -1) (t 24241 16517 925630 892000) nil (1689 . 1692) (t 24241 16511 232607 949000) (1675 . 1689) (". " . -1675) ((marker . 2278) . -1) ((marker . 1596) . -1) ((marker . 1596) . -1) 1677 (1676 . 1677) (t 24241 16501 66872 931000) nil (" " . 1676) ((marker . 1596) . -1) ((marker . 1596) . -1) nil (1675 . 1677) ("." . -1675) 1676 (1674 . 1676) ("." . -1674) ((marker . 2278) . -1) ((marker . 1595) . -1) ((marker . 1595) . -1) ((marker . 1595) . -1) ((marker . 1595) . -1) ((marker . 1595) . -1) (" " . -1675) ((marker . 2278) . -1) ((marker . 1595) . -1) ((marker . 1595) . -1) 1676 (1674 . 1676) ("." . -1674) 1675 (1659 . 1675) ("o" . -1659) ((marker . 2278) . -1) ((marker . 1580) . -1) ((marker . 1580) . -1) ((marker . 1580) . -1) ((marker . 1580) . -1) ((marker . 1580) . -1) ((marker . 1580) . -1) ((marker . 1580) . -1) ((marker . 1580) . -1) ("u" . -1660) ((marker . 2278) . -1) ((marker . 1580) . -1) ((marker . 1580) . -1) 1661 (1658 . 1661) ("t" . -1658) ((marker . 2278) . -1) ((marker . 1579) . -1) ((marker . 1579) . -1) ((marker . 1579) . -1) ((marker . 1579) . -1) ((marker . 1579) . -1) ((marker . 1579) . -1) ((marker . 1579) . -1) ((marker . 1579) . -1) (" " . -1659) ((marker . 2278) . -1) ((marker . 1579) . -1) ((marker . 1579) . -1) 1660 (1648 . 1660) ("n" . -1648) ((marker . 2278) . -1) ((marker . 1569) . -1) ((marker . 1569) . -1) ((marker . 1569) . -1) ((marker . 1569) . -1) ((marker . 1569) . -1) ((marker . 1569) . -1) ((marker . 1569) . -1) ((marker . 1569) . -1) ("o" . -1649) ((marker . 2278) . -1) ((marker . 1569) . -1) ((marker . 1569) . -1) 1650 (1648 . 1650) (1646 . 1648) ("," . -1646) 1647 (1637 . 1647) (t 24241 16486 57681 565000) nil (" " . 1637) ((marker . 1558) . -1) ((marker . 1558) . -1) nil (1631 . 1638) ("." . -1631) 1632 (1626 . 1632) (1604 . 1626) (", " . 1604) 1605 (1604 . 1605) ("," . 1604) ((marker . 2101) . -1) ((marker . 2231) . -1) ((marker . 1525) . -1) ((marker . 1525) . -1) ((marker . 1525) . -1) ((marker . 1525) . -1) ((marker . 1525) . -1) ((marker . 1525) . -1) ((marker . 1525) . -1) ((marker . 1525) . -1) ((marker . 1525) . -1) ((marker . 1525) . -1) ((marker . 1525) . -1) ((marker . 1525) . -1) ((marker . 1525) . -1) ((marker . 1525) . -1) (t 24241 16475 588415 304000) nil (1605 . 1606) ("w" . -1605) ((marker . 2278) . -1) ((marker . 1525) . -1) ("i" . -1606) ((marker . 2278) . -1) 1607 (1604 . 1607) ("." . -1604) ((marker . 1525) . -1) ((marker . 1525) . -1) ((marker . 1525) . -1) ((marker . 1525) . -1) ((marker . 1525) . -1) ((marker . 1525) . -1) ((marker . 2101) . -1) ((marker . 2278) . -1) ((marker . 1525) . -1) (" " . -1605) ((marker . 1525) . -1) ((marker . 1525) . -1) ((marker . 1525) . -1) ((marker . 1525) . -1) ((marker . 1525) . -1) ((marker . 1525) . -1) ((marker . 2101) . -1) ((marker . 2278) . -1) ((marker . 1525) . -1) 1606 ("I " . -1606) ((marker . 2278) . -2) 1608 ("believed" . -1608) ((marker . 2278) . -8) 1616 (t 24241 16462 953568 60000) nil ("
" . 1617) (t 24241 16440 511806 39000) nil (" " . 1616) (" " . 320) 2161 nil (nil rear-nonsticky nil 2161 . 2162) (nil fontified nil 1 . 2162) (1 . 2162) ("# Meu Amigo
" . 1) ((marker . 1) . -12) ((marker . 1) . -12) ((marker . 1) . -12) ((marker . 1) . -12) ((marker . 1) . -12) ((marker . 1) . -12) ((marker . 1) . -12) ((marker . 1) . -12) ((marker . 1) . -12) ((marker . 1) . -12) ((marker . 1) . -12) ((marker . 1) . -12) ((marker . 1) . -12) ((marker . 1) . -12) ((marker . 1) . -12) ((marker . 1) . -12) ((marker . 1) . -12) ((marker . 1) . -12) ((marker . 1) . -12) ((marker . 1) . -12) ((marker . 1) . -12) ((marker . 1) . -12) ((marker . 1) . -12) ((marker . 1) . -12) ((marker . 1) . -12) ((marker . 1) . -12) ((marker . 1) . -12) ((marker . 1) . -12) ((marker . 1) . -12) ((marker . 1) . -12) ((marker . 1) . -12) ((marker . 1) . -12) ((marker . 1) . -12) ((marker . 1) . -12) ((marker . 1) . -12) ((marker . 1) . -12) ((marker . 1) . -12) ((marker . 1) . -12) ((marker . 1) . -12) ((marker . 1) . -12) ((marker . 1) . -12) ((marker . 1) . -12) ((marker . 1) . -12) ((marker . 1) . -12) ((marker . 1) . -12) ((marker . 1) . -12) ((marker . 1) . -12) ((marker . 1) . -12) ((marker . 1) . -12) ((marker . 1) . -12) ((marker . 1) . -12) ((marker . 1) . -12) ((marker . 1) . -12) ((marker . 1) . -12) ((marker . 1) . -12) ((marker . 1) . -12) ((marker . 1) . -12) ((marker . 1) . -12) ((marker . 1) . -12) ((marker . 1) . -12) ((marker . 1) . -12) ((marker . 1) . -12) ((marker . 1) . -12) ((marker . 1) . -12) ((marker . 1) . -12) ((marker . 1) . -12) ((marker . 1) . -12) ((marker . 1) . -12) ((marker . 1) . -12) ((marker . 1) . -12) ((marker . 1) . -12) ((marker . 1) . -12) ((marker . 1) . -12) ((marker . 1) . -12) ((marker . 1) . -12) ((marker . 1) . -12) ((marker . 1) . -12) ((marker . 1) . -12) ((marker . 1) . -12) ((marker . 1) . -12) ((marker . 1) . -12) ((marker . 1) . -12) ((marker . 1) . -12) ((marker . 1) . -12) ((marker . 1) . -12) ((marker . 1) . -12) ((marker . 1) . -12) ((marker . 1) . -12) ((marker . 1) . -12) ((marker . 1) . -12) ((marker . 1) . -12) ((marker . 1) . -12) ((marker . 1) . -12) ((marker . 2101) . -12) ((marker . 1668) . -11) ((marker) . -11) (t 24238 31072 646618 259000) nil ("4" . -1) 2 (1 . 2) (t 24235 25380 891098 539000) nil ("," . -12) 13 (t 24235 22679 69606 660000) nil (" " . 13) nil (12 . 14) (",  " . -12) 15 (12 . 15) ("," . -12) 13 (7 . 13) ("Aigo" . -7) 11 (7 . 11) (t 24235 22672 978329 592000) ("ada " . -7) 11 (t 24235 22671 598951 775000) nil (6 . 11) nil (5 . 6) ("y" . -5) (" " . -6) 7 (1 . 7) (1 . 2) ("I have a partial solution:

    (defun my-shfmt-fix-file ()
        (interactive)
        (message \"shfmt fix buffer\" (buffer-file-name))
        (shell-command (concat \"shfmt -i 2 -s -w \" (buffer-file-name))))

      (defun my-shfmt-fix-file-and-revert ()
        (interactive)
        (my-shfmt-fix-file)
        (revert-buffer t t))

It does work, but it conflicts with both persistent undo packages I tried — `undohist` and `undo-fu-session`. I would have to give up persistent undo, at least for the time being.

Message from `undo-fu-session`:

    Undo-Fu-Session discarding undo data: file length mismatch

Undohist ask for confirmation to recover the undo file and gives a similar message afterwards." . 1) (t 24221 58092 609634 137000)) (emacs-undo-equiv-table (81 . 83) (55 . 57)))