((buffer-size . 640) (buffer-checksum . "6503d4c2184be155f8f23240985ec79fef6c385a"))
((emacs-pending-undo-list (551 . 553) nil (519 . 520) ("m" . 519) ((marker* . 641) . 1) ((marker* . 641) . 1) nil (" " . 519) ((marker* . 641) . 1) ((marker* . 641) . 1) nil ("This is the" . 519) ((marker . 552) . -10) ((marker . 613) . -10) ((marker . 641) . -10) ((marker) . -11) ((marker) . -10) ((marker . 519) . -10) ((marker . 519) . -6) 529 (t 24221 57886 477002 891000) nil (562 . 563) ("
" . -562) ((marker . 552) . -1) ((marker . 613) . -1) ((marker . 550) . -1) ((marker . 641) . -1) ((marker) . -1) 563 (t 24221 57884 938172 467000) nil (" " . 562) ((marker . 550) . -1) ((marker . 550) . -1) ((marker . 550) . -1) ((marker . 550) . -1) ((marker . 550) . -1) ((marker . 550) . -1) 519 nil (518 . 519) (t 24221 57884 438689 156000) nil ("
" . -518) ((marker . 519) . -1) ((marker . 519) . -1) nil ("

revert-buffer--default:" . 622) ((marker . 552) . -2) ((marker . 552) . -1) ((marker . 552) . -1) ((marker . 613) . -2) ((marker . 614) . -1) ((marker . 614) . -24) ((marker . 614) . -24) ((marker . 614) . -24) ((marker . 614) . -24) ((marker . 614) . -24) ((marker . 614) . -1) ((marker . 614) . -1) ((marker . 614) . -1) ((marker . 614) . -1) ((marker . 614) . -1) ((marker . 614) . -1) ((marker . 614) . -1) ((marker . 614) . -1) ((marker . 614) . -1) ((marker . 614) . -1) ((marker . 614) . -1) ((marker . 614) . -1) ((marker . 614) . -1) ((marker . 614) . -1) ((marker . 641) . -2) ((marker . 614) . -1) ((marker . 614) . -1) ((marker) . -1) ((marker) . -25) ((marker . 614) . -1) ((marker . 614) . -1) ((marker) . -1) ((marker) . -2) ((marker . 614) . -2) ((marker . 614) . -1) 624 (t 24221 57875 8780 939000) nil (564 . 623) 597 (563 . 564) ("ng undo data: file length mismatch" . 563) ((marker . 552) . -34) ((marker . 613) . -33) ((marker . 550) . -3) ((marker . 641) . -33) ((marker) . -33) 597 (t 24221 57850 971225 837000) nil (nil rear-nonsticky nil 620 . 621) (nil fontified nil 563 . 621) (563 . 621) 562 nil (561 . 563) nil (560 . 561) (544 . 545) (t 24221 57846 584355 597000) nil (548 . 559) (t 24221 57843 169179 126000) (544 . 548) (t 24221 57841 650068 936000) (536 . 544) (" " . -536) ((marker . 641) . -1) 537 (524 . 537) (t 24221 57836 968953 393000) (519 . 524) (518 . 519) (517 . 518) (t 24221 57796 870307 399000) 456 nil (516 . 517) nil (503 . 516) (487 . 503) (" " . -487) ((marker . 641) . -1) 488 (469 . 488) (t 24221 57784 912134 212000) (468 . 469) (448 . 468) (t 24221 57781 397009 74000) (447 . 448) (" " . -447) ((marker . 641) . -1) 448 (447 . 448) (t 24221 57777 204614 937000) nil (412 . 414) (t 24221 57775 651627 556000) (406 . 412) (t 24221 57771 873776 284000) (400 . 406) (379 . 400) (t 24221 57761 76409 247000) nil (411 . 412) (t 24221 57757 46500 658000) nil (394 . 395) (409 . 410) 394 nil (nil rear-nonsticky nil 408 . 409) (nil fontified nil 394 . 409) (394 . 409) 393 (t 24221 57751 998244 248000) nil (389 . 394) nil (380 . 388) (379 . 381) ("`" . -379) (379 . 380) (t 24221 57747 123055 909000) ("ù" . -379) ((marker . 641) . -1) ("n" . -380) ((marker . 641) . -1) 381 (379 . 381) (t 24221 57744 498208 453000) (378 . 379) (374 . 378) (t 24221 57742 769778 946000) ("nob" . 374) ((marker . 552) . -1) ((marker . 374) . -1) ((marker . 374) . -1) ((marker . 374) . -1) ((marker . 374) . -1) ((marker . 374) . -1) ((marker . 374) . -1) ((marker . 614) . -1) nil (376 . 377) (t 24221 57737 554341 6000) nil (374 . 376) (t 24221 57734 810140 635000) (369 . 374) (361 . 369) (t 24221 57732 13947 603000) (351 . 361) (t 24221 57728 627167 414000) nil (" " . 351) ((marker* . 641) . 1) ("        " . 337) 358 (t 24221 57719 351937 829000) nil (349 . 360) (t 24221 57716 121295 469000) (346 . 349) ("        " . -346) ((marker . 641) . -8) 354 (345 . 354) (336 . 345) (t 24221 57710 236791 688000) 312 nil ("
" . 29) ((marker . 552) . -1) ((marker . 552) . -1) ((marker . 552) . -1) ((marker . 550) . -1) ((marker . 29) . -1) (t 24221 57705 873872 301000) nil (309 . 313) (281 . 285) (259 . 263) (214 . 218) (140 . 144) (84 . 88) (62 . 66) (30 . 34) ("  " . 30) ((marker . 552) . -2) ((marker . 29) . -2) ((marker) . -2) 307 nil ("
  ```" . 307) ((marker* . 641) . 5) ("
" . 30) ((marker . 552) . -1) ("  ```" . 30) (nil markdown-gfm-block-begin (30 35 32 35 35 35 nil nil nil nil 35 35 #<buffer scratch.md>) 30 . 32) (nil markdown-gfm-block-begin (30 35 32 35 35 35 nil nil nil nil 35 35 #<buffer scratch.md>) 32 . 35) (t 24221 57703 769468 786000) nil (nil markdown-gfm-block-begin nil 32 . 35) (nil markdown-gfm-block-begin nil 30 . 32) (30 . 35) (30 . 31) (307 . 313) (t 24221 57698 897690 867000) nil (";; " . 285) ((marker . 552) . -2) ((marker . 552) . -2) ((marker . 641) . -2) (";; " . 261) (";; " . 243) (";; " . 202) (";; " . 132) (";; " . 80) (";; " . 62) (";; " . 32) 308 nil ("<!-- " . 32) (" -->" . 67) ("<!-- " . 74) (" -->" . 97) ("<!-- " . 104) (" -->" . 161) ("<!-- " . 168) (" -->" . 242) ("<!-- " . 250) (" -->" . 296) ("<!-- " . 303) (" -->" . 326) ("<!-- " . 333) (" -->" . 362) ("<!-- " . 369) (" -->" . 399) (t 24221 57694 910098 799000) nil (399 . 403) (369 . 374) (362 . 366) (333 . 338) (326 . 330) (303 . 308) (296 . 300) (250 . 255) (242 . 246) (168 . 173) (161 . 165) (104 . 109) (97 . 101) (74 . 79) (67 . 71) (32 . 37) (t 24221 57694 111314 45000) nil (nil rear-nonsticky nil 31 . 32) ("
" . -331) (29 . 332) nil (28 . 29) (t 24221 57681 420337 597000) nil ("
" . 28) ((marker . 641) . -1) ((marker . 552) . -1) ((marker . 28) . -1) ((marker . 28) . -1) 29 nil ("# A simple menu:
while true; do
    echo \"Welcome to the Menu\"
    echo \"  1. Say hello\"
    echo \"  2. Say good-bye\"

    read -p \"-> \" response
    case $response in
        1) echo 'Hello there!' ;;
        2) echo 'See you later!'; break ;;
        *) echo 'What was that?' ;;
    esac
done

# Alternative: use a variable to terminate the loop instead of an
# explicit break command.

quit=
while test -z \"$quit\"; do
    echo \"....\"
    read -p \"-> \" response
    case $response in
        ...
        2) echo 'See you later!'; quit=y ;;
        ...
    esac
done
" . 29) ((marker . 552) . -568) ((marker . 28) . -568) (t 24221 57677 915079 209000) nil ("
" . 29) nil ("I have a partial solution:
" . 29) (t 24221 57675 726815 770000) nil (nil rear-nonsticky nil 624 . 625) (nil fontified nil 29 . 625) (29 . 625) nil (28 . 29) (t 24221 57666 145963 997000) nil ("
" . 28) ((marker . 641) . -1) ((marker . 552) . -1) ((marker . 28) . -1) 29 nil ("# A simple menu:
while true; do
    echo \"Welcome to the Menu\"
    echo \"  1. Say hello\"
    echo \"  2. Say good-bye\"

    read -p \"-> \" response
    case $response in
        1) echo 'Hello there!' ;;
        2) echo 'See you later!'; break ;;
        *) echo 'What was that?' ;;
    esac
done

# Alternative: use a variable to terminate the loop instead of an
# explicit break command.

quit=
while test -z \"$quit\"; do
    echo \"....\"
    read -p \"-> \" response
    case $response in
        ...
        2) echo 'See you later!'; quit=y ;;
        ...
    esac
done
" . 29) ((marker . 552) . -568) ((marker . 28) . -568) (t 24221 57660 503927 889000) nil (nil rear-nonsticky nil 596 . 597) (nil fontified nil 1 . 597) (1 . 597) nil ("
  ;; (defun my-shfmt-fix-file ()
  ;;   (interactive)
  ;;   (message \"shfmt fix buffer\" (buffer-file-name))
  ;;   (shell-command (concat \"shfmt -i 2 -s -w \" (buffer-file-name))))

  ;; (defun my-shfmt-fix-file-and-revert ()
  ;;   (interactive)
  ;;   (my-shfmt-fix-file)
  ;;   (revert-buffer t t))" . 1) ((marker . 552) . -301) ((marker . 552) . -301) ((marker . 550) . -1) ((marker . 614) . -302) ((marker . 1) . -3) ((marker) . -301) (t 24221 57652 552117 604000) nil (nil rear-nonsticky nil 3 . 4) ("
" . -303) (1 . 304) ("Any tips on making Emacs work nicer on macOS?

Right now I am constrained, by no choice of my own, to use a Macbook Air with macOs Mojave. I installed Emacs using homebrew with the command `brew cask install`. I tried [emacs-plus](https://github.com/railwaycat/homebrew-emacsmacport/issues/191) but it had behaviors I did not wanted, especially related to how it uses the `option` key. I opened an issue but sadly got no useful response." . 1) ((marker . 552) . -437) ((marker . 552) . -436) ((marker) . -436) (t 24221 27130 644108 708000)) (emacs-buffer-undo-list ("
" . 641) ((marker . 641) . -1) ((marker . 641) . -1) ((marker . 641) . -1) ((marker . 641) . -1) ((marker) . -1) ("    " . 615) 646 nil (645 . 646) (644 . 645) (643 . 644) nil (634 . 642) (633 . 635) ("`" . -633) ((marker . 629) . -1) ((marker . 629) . -1) (632 . 634) ("`" . -632) ((marker . 641) . -1) ((marker . 628) . -1) ((marker . 628) . -1) ((marker . 628) . -1) ((marker . 628) . -1) ((marker . 628) . -1) ((marker . 628) . -1) ((marker . 628) . -1) ((marker . 628) . -1) ((marker . 628) . -1) ((marker . 628) . -1) ((marker . 628) . -1) ((marker . 628) . -1) ((marker . 628) . -1) ((marker . 628) . -1) ((marker . 628) . -1) ((marker . 628) . -1) ((marker . 628) . -1) ((marker . 628) . -1) ((marker . 628) . -1) ((marker . 628) . -1) ((marker . 628) . -1) ((marker . 628) . -1) ((marker . 628) . -1) (" " . -633) ((marker . 641) . -1) ((marker . 628) . -1) ((marker . 628) . -1) ((marker . 628) . -1) ((marker . 628) . -1) ((marker . 628) . -1) ((marker . 628) . -1) ((marker . 628) . -1) ((marker . 628) . -1) ((marker . 628) . -1) ((marker . 628) . -1) ((marker . 628) . -1) ((marker . 628) . -1) ((marker . 628) . -1) ((marker . 628) . -1) ((marker . 628) . -1) ("`" . -634) ((marker . 641) . -1) ((marker . 628) . -1) ((marker . 628) . -1) ((marker . 628) . -1) ((marker . 628) . -1) ((marker . 628) . -1) ((marker . 628) . -1) 635 ("`" . 635) ((marker) . -1) (633 . 635) (632 . 634) ("`" . -632) ((marker . 628) . -1) ((marker . 628) . -1) (632 . 633) (" " . -632) ((marker . 641) . -1) ((marker . 628) . -1) ((marker . 628) . -1) ((marker . 628) . -1) ((marker . 628) . -1) ((marker . 628) . -1) ((marker . 628) . -1) ((marker . 628) . -1) ((marker . 628) . -1) ((marker . 628) . -1) ((marker . 628) . -1) ((marker . 628) . -1) ((marker . 628) . -1) ((marker . 628) . -1) ((marker . 628) . -1) ("ù" . -633) ((marker . 641) . -1) ((marker . 628) . -1) ((marker . 628) . -1) ((marker . 628) . -1) ((marker . 628) . -1) ((marker . 628) . -1) ("n" . -634) ((marker . 641) . -1) ((marker . 628) . -1) 635 (633 . 635) (t 24221 57909 238034 659000) ("ù" . -633) ((marker . 641) . -1) ((marker . 628) . -1) ((marker . 628) . -1) ((marker . 628) . -1) ((marker . 628) . -1) ("n" . -634) ((marker . 641) . -1) ((marker . 628) . -1) ((marker . 628) . -1) ("d" . -635) ((marker . 641) . -1) ("o" . -636) ((marker . 641) . -1) 637 (633 . 637) (t 24221 57906 744650 620000) (620 . 633) ("    " . -620) ((marker . 641) . -4) 624 (619 . 624) (614 . 619) (t 24221 57901 339384 843000) 613 nil (" " . 550) ((marker . 550) . -1) ((marker . 550) . -1) ((marker . 550) . -1) ((marker . 550) . -1) ((marker . 550) . -1) ((marker . 550) . -1) 614 nil (553 . 557) 611 nil ("    

" . 553) ((marker . 641) . -3) ((marker . 552) . -4) ((marker . 552) . -3) (t 24221 57899 115346 27000) nil (553 . 559) nil (551 . 553) nil (519 . 520) ("m" . 519) ((marker* . 641) . 1) ((marker* . 641) . 1) nil (" " . 519) ((marker* . 641) . 1) ((marker* . 641) . 1) nil ("This is the" . 519) ((marker . 552) . -10) ((marker . 613) . -10) ((marker . 641) . -10) ((marker) . -11) ((marker) . -10) ((marker . 519) . -10) ((marker . 519) . -6) 529 (t 24221 57886 477002 891000) nil (562 . 563) ("
" . -562) ((marker . 552) . -1) ((marker . 613) . -1) ((marker . 550) . -1) ((marker . 641) . -1) ((marker) . -1) 563 (t 24221 57884 938172 467000) nil (" " . 562) ((marker . 550) . -1) ((marker . 550) . -1) ((marker . 550) . -1) ((marker . 550) . -1) ((marker . 550) . -1) ((marker . 550) . -1) 519 nil (518 . 519) (t 24221 57884 438689 156000) nil ("
" . -518) ((marker . 519) . -1) ((marker . 519) . -1) nil ("

revert-buffer--default:" . 622) ((marker . 552) . -2) ((marker . 552) . -1) ((marker . 552) . -1) ((marker . 613) . -2) ((marker . 614) . -1) ((marker . 614) . -24) ((marker . 614) . -24) ((marker . 614) . -24) ((marker . 614) . -24) ((marker . 614) . -24) ((marker . 614) . -1) ((marker . 614) . -1) ((marker . 614) . -1) ((marker . 614) . -1) ((marker . 614) . -1) ((marker . 614) . -1) ((marker . 614) . -1) ((marker . 614) . -1) ((marker . 614) . -1) ((marker . 614) . -1) ((marker . 614) . -1) ((marker . 614) . -1) ((marker . 614) . -1) ((marker . 614) . -1) ((marker . 641) . -2) ((marker . 614) . -1) ((marker . 614) . -1) ((marker) . -1) ((marker) . -25) ((marker . 614) . -1) ((marker . 614) . -1) ((marker) . -1) ((marker) . -2) ((marker . 614) . -2) ((marker . 614) . -1) 624 (t 24221 57875 8780 939000) nil (564 . 623) 597 (563 . 564) ("ng undo data: file length mismatch" . 563) ((marker . 552) . -34) ((marker . 613) . -33) ((marker . 550) . -3) ((marker . 641) . -33) ((marker) . -33) 597 (t 24221 57850 971225 837000) nil (nil rear-nonsticky nil 620 . 621) (nil fontified nil 563 . 621) (563 . 621) 562 nil (561 . 563) nil (560 . 561) (544 . 545) (t 24221 57846 584355 597000) nil (548 . 559) (t 24221 57843 169179 126000) (544 . 548) (t 24221 57841 650068 936000) (536 . 544) (" " . -536) ((marker . 641) . -1) 537 (524 . 537) (t 24221 57836 968953 393000) (519 . 524) (518 . 519) (517 . 518) (t 24221 57796 870307 399000) 456 nil (516 . 517) nil (503 . 516) (487 . 503) (" " . -487) ((marker . 641) . -1) 488 (469 . 488) (t 24221 57784 912134 212000) (468 . 469) (448 . 468) (t 24221 57781 397009 74000) (447 . 448) (" " . -447) ((marker . 641) . -1) 448 (447 . 448) (t 24221 57777 204614 937000) nil (412 . 414) (t 24221 57775 651627 556000) (406 . 412) (t 24221 57771 873776 284000) (400 . 406) (379 . 400) (t 24221 57761 76409 247000) nil (411 . 412) (t 24221 57757 46500 658000) nil (394 . 395) (409 . 410) 394 nil (nil rear-nonsticky nil 408 . 409) (nil fontified nil 394 . 409) (394 . 409) 393 (t 24221 57751 998244 248000) nil (389 . 394) nil (380 . 388) (379 . 381) ("`" . -379) (379 . 380) (t 24221 57747 123055 909000) ("ù" . -379) ((marker . 641) . -1) ("n" . -380) ((marker . 641) . -1) 381 (379 . 381) (t 24221 57744 498208 453000) (378 . 379) (374 . 378) (t 24221 57742 769778 946000) ("nob" . 374) ((marker . 552) . -1) ((marker . 374) . -1) ((marker . 374) . -1) ((marker . 374) . -1) ((marker . 374) . -1) ((marker . 374) . -1) ((marker . 374) . -1) ((marker . 614) . -1) nil (376 . 377) (t 24221 57737 554341 6000) nil (374 . 376) (t 24221 57734 810140 635000) (369 . 374) (361 . 369) (t 24221 57732 13947 603000) (351 . 361) (t 24221 57728 627167 414000) nil (" " . 351) ((marker* . 641) . 1) ("        " . 337) 358 (t 24221 57719 351937 829000) nil (349 . 360) (t 24221 57716 121295 469000) (346 . 349) ("        " . -346) ((marker . 641) . -8) 354 (345 . 354) (336 . 345) (t 24221 57710 236791 688000) 312 nil ("
" . 29) ((marker . 552) . -1) ((marker . 552) . -1) ((marker . 552) . -1) ((marker . 550) . -1) ((marker . 29) . -1) (t 24221 57705 873872 301000) nil (309 . 313) (281 . 285) (259 . 263) (214 . 218) (140 . 144) (84 . 88) (62 . 66) (30 . 34) ("  " . 30) ((marker . 552) . -2) ((marker . 29) . -2) ((marker) . -2) 307 nil ("
  ```" . 307) ((marker* . 641) . 5) ("
" . 30) ((marker . 552) . -1) ("  ```" . 30) (nil markdown-gfm-block-begin (30 35 32 35 35 35 nil nil nil nil 35 35 #<buffer scratch.md>) 30 . 32) (nil markdown-gfm-block-begin (30 35 32 35 35 35 nil nil nil nil 35 35 #<buffer scratch.md>) 32 . 35) (t 24221 57703 769468 786000) nil (nil markdown-gfm-block-begin nil 32 . 35) (nil markdown-gfm-block-begin nil 30 . 32) (30 . 35) (30 . 31) (307 . 313) (t 24221 57698 897690 867000) nil (";; " . 285) ((marker . 552) . -2) ((marker . 552) . -2) ((marker . 641) . -2) (";; " . 261) (";; " . 243) (";; " . 202) (";; " . 132) (";; " . 80) (";; " . 62) (";; " . 32) 308 nil ("<!-- " . 32) (" -->" . 67) ("<!-- " . 74) (" -->" . 97) ("<!-- " . 104) (" -->" . 161) ("<!-- " . 168) (" -->" . 242) ("<!-- " . 250) (" -->" . 296) ("<!-- " . 303) (" -->" . 326) ("<!-- " . 333) (" -->" . 362) ("<!-- " . 369) (" -->" . 399) (t 24221 57694 910098 799000) nil (399 . 403) (369 . 374) (362 . 366) (333 . 338) (326 . 330) (303 . 308) (296 . 300) (250 . 255) (242 . 246) (168 . 173) (161 . 165) (104 . 109) (97 . 101) (74 . 79) (67 . 71) (32 . 37) (t 24221 57694 111314 45000) nil (nil rear-nonsticky nil 31 . 32) ("
" . -331) (29 . 332) nil (28 . 29) (t 24221 57681 420337 597000) nil ("
" . 28) ((marker . 641) . -1) ((marker . 552) . -1) ((marker . 28) . -1) ((marker . 28) . -1) 29 nil ("# A simple menu:
while true; do
    echo \"Welcome to the Menu\"
    echo \"  1. Say hello\"
    echo \"  2. Say good-bye\"

    read -p \"-> \" response
    case $response in
        1) echo 'Hello there!' ;;
        2) echo 'See you later!'; break ;;
        *) echo 'What was that?' ;;
    esac
done

# Alternative: use a variable to terminate the loop instead of an
# explicit break command.

quit=
while test -z \"$quit\"; do
    echo \"....\"
    read -p \"-> \" response
    case $response in
        ...
        2) echo 'See you later!'; quit=y ;;
        ...
    esac
done
" . 29) ((marker . 552) . -568) ((marker . 28) . -568) (t 24221 57677 915079 209000) nil ("
" . 29) nil ("I have a partial solution:
" . 29) (t 24221 57675 726815 770000) nil (nil rear-nonsticky nil 624 . 625) (nil fontified nil 29 . 625) (29 . 625) nil (28 . 29) (t 24221 57666 145963 997000) nil ("
" . 28) ((marker . 641) . -1) ((marker . 552) . -1) ((marker . 28) . -1) 29 nil ("# A simple menu:
while true; do
    echo \"Welcome to the Menu\"
    echo \"  1. Say hello\"
    echo \"  2. Say good-bye\"

    read -p \"-> \" response
    case $response in
        1) echo 'Hello there!' ;;
        2) echo 'See you later!'; break ;;
        *) echo 'What was that?' ;;
    esac
done

# Alternative: use a variable to terminate the loop instead of an
# explicit break command.

quit=
while test -z \"$quit\"; do
    echo \"....\"
    read -p \"-> \" response
    case $response in
        ...
        2) echo 'See you later!'; quit=y ;;
        ...
    esac
done
" . 29) ((marker . 552) . -568) ((marker . 28) . -568) (t 24221 57660 503927 889000) nil (nil rear-nonsticky nil 596 . 597) (nil fontified nil 1 . 597) (1 . 597) nil ("
  ;; (defun my-shfmt-fix-file ()
  ;;   (interactive)
  ;;   (message \"shfmt fix buffer\" (buffer-file-name))
  ;;   (shell-command (concat \"shfmt -i 2 -s -w \" (buffer-file-name))))

  ;; (defun my-shfmt-fix-file-and-revert ()
  ;;   (interactive)
  ;;   (my-shfmt-fix-file)
  ;;   (revert-buffer t t))" . 1) ((marker . 552) . -301) ((marker . 552) . -301) ((marker . 550) . -1) ((marker . 614) . -302) ((marker . 1) . -3) ((marker) . -301) (t 24221 57652 552117 604000) nil (nil rear-nonsticky nil 3 . 4) ("
" . -303) (1 . 304) ("Any tips on making Emacs work nicer on macOS?

Right now I am constrained, by no choice of my own, to use a Macbook Air with macOs Mojave. I installed Emacs using homebrew with the command `brew cask install`. I tried [emacs-plus](https://github.com/railwaycat/homebrew-emacsmacport/issues/191) but it had behaviors I did not wanted, especially related to how it uses the `option` key. I opened an issue but sadly got no useful response." . 1) ((marker . 552) . -437) ((marker . 552) . -436) ((marker) . -436) (t 24221 27130 644108 708000)) (emacs-undo-equiv-table (5 . -1) (-32 . -34) (-29 . -31) (-7 . -9)))