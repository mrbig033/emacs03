((buffer-size . 319) (buffer-checksum . "15cf1af30bd33abe6126e15652c900f1ddaa2212"))
((emacs-pending-undo-list ("** Misc
#+BEGIN_SRC sh :tangle bash_aliases
#+END_SRC
" . 1767) ((marker) . -44) ((marker*) . 10) ((marker) . -44) ((marker) . -44) ((marker) . -44) ((marker) . -44) ((marker) . -44) ((marker) . -44) ((marker) . -44) ((marker) . -44) ((marker) . -44) ((marker) . -44) ((marker) . -44) ((marker) . -44) ((marker) . -44) ((marker) . -44) ((marker) . -44) ((marker) . -44) ((marker) . -44) ((marker) . -44) ((marker) . -15) ((marker) . -44) ((marker) . -15) ((marker) . -6) ((marker) . -15) ((marker) . -6) ((marker) . -6) ((marker) . -6) ((marker) . -6) ((marker) . -6) ((marker) . -3) ((marker) . -3) ((marker) . -3) ((marker) . -3) ((marker) . -3) ((marker) . -3) ((marker) . -3) ((marker) . -3) ((marker) . -3) ((marker) . -3) ((marker) . -3) ((marker) . -8) ((marker) . -3) ((marker) . -8) ((marker) . -44) ((marker) . -8) ((marker) . -44) ((marker) . -44) ((marker) . -1) ((marker) . -44) ((marker) . -44) ((marker) . -44) ((marker) . -44) ((marker) . -44) ((marker) . -44) ((marker) . -44) ((marker) . -44) ((marker) . -44) ((marker) . -44) ((marker) . -44) ((marker) . -44) ((marker) . -44) ((marker) . -44) ((marker) . -44) ((marker) . -44) ((marker) . -8) ((marker) . -44) ((marker) . -8) ((marker) . -1) ((marker) . -8) ((marker) . -1) ((marker) . -8) ((marker) . -1) ((marker) . -8) ((marker) . -1) ((marker) . -8) ((marker) . -1) ((marker) . -54) ((marker) . -1) ((marker) . -1) ((marker) . -1) ((marker) . -44) ((marker) . -1) ((marker) . -8) ((marker) . -1) ((marker) . -8) ((marker) . -44) ((marker) . -8) ((marker) . -44) 1811 (t 24236 62382 144180 817000) nil ("
" . 3597) ((marker) . -1) ((marker) . -1) ((marker) . -1) ((marker) . -1) nil (nil rear-nonsticky nil 3597 . 3598) ("
" . -3657) (3597 . 3658) nil (3596 . 3597) 3563 nil ("alias n='nvim'
alias py='python'
alias k2='~/maps/k2pdfopt'
" . 1811) ((marker) . -22) ((marker) . -22) ((marker) . -33) ((marker) . -22) ((marker) . -22) ((marker) . -22) ((marker) . -15) ((marker) . -32) ((marker) . -22) ((marker) . -22) ((marker) . -22) ((marker) . -22) ((marker) . -7) ((marker) . -22) ((marker) . -7) ((marker) . -7) ((marker) . -33) ((marker) . -33) ((marker) . -60) ((marker) . -33) ((marker) . -15) ((marker) . -15) ((marker) . -33) ((marker) . -15) ((marker) . -33) 1844 (t 24235 27318 472788 962000) nil (1811 . 1871) ("alias n='nvim'
alias py='python'
alias k2='~/maps/k2pdfopt
" . 1811) 1870 (t 24235 27315 563627 540000) nil (1811 . 1870) ("alias n='nvim'
alias py='python'
alias k2='~/maps/k
" . 1811) 1863 (t 24235 27313 420865 225000) nil (1811 . 1863) ("alias n='nvim'
alias py='python'
alias k2='~/maps/
" . 1811) 1862 (t 24235 27311 253202 487000) nil (1811 . 1862) ("alias n='nvim'
alias py='python'
alias k2='~/maps
" . 1811) 1861 (t 24235 27309 934525 896000) nil (1811 . 1861) ("alias n='nvim'
alias py='python'
alias k2='~/map
" . 1811) 1860 (t 24235 27307 38841 576000) nil (1811 . 1860) ("alias n='nvim'
alias py='python'
alias k2='~/map
" . 1811) 1860 (t 24235 27303 180196 611000) nil (1811 . 1860) ("alias n='nvim'
alias py='python'
alias k2='~/ma
" . 1811) ((marker) . -46) ((marker*) . 1) ((marker) . -46) ((marker) . -46) ((marker) . -46) 1857 nil (1854 . 1858) ("~" . -1854) ((marker) . -1) (1854 . 1855) (t 24235 27285 824315 297000) (1853 . 1854) ("!" . -1853) ((marker) . -1) 1854 (1853 . 1854) ("1" . -1853) ((marker) . -1) 1854 (1853 . 1854) (1852 . 1853) ("0" . -1852) ((marker) . -1) 1853 (1844 . 1853) (1843 . 1844) 1826 nil ("
" . 4256) ((marker) . -1) (t 24235 27271 321608 566000) nil (4256 . 4257) (t 24226 13625 170272 741000) 4200 nil ("alias which='which -a'
" . 3816) ((marker) . -6) ((marker) . -6) ((marker) . -6) ((marker) . -6) ((marker) . -6) ((marker) . -6) ((marker) . -6) 3822 (t 24226 12330 771803 695000)) (emacs-buffer-undo-list nil (168 . 174) ("P" . -168) ((marker . 173) . -1) ((marker) . -1) ((marker . 168) . -1) ((marker . 168) . -1) 169 (168 . 169) (167 . 168) ("    " . -167) ((marker . 173) . -4) ((marker) . -1) ((marker . 167) . -4) ((marker . 167) . -4) ((marker) . -1) ((marker . 167) . -4) 171 (167 . 171) (167 . 168) nil (25 . 30) (24 . 25) (t 24241 6491 978433 348000) 24 nil (nil rear-nonsticky nil 160 . 161) ("
" . -306) (160 . 307) nil (159 . 160) (t 24241 6122 374451 0)) (emacs-undo-equiv-table))