((buffer-size . 141) (buffer-checksum . "bf5f433f17cb23f6b55820ed665cbe8834e01be8"))
((emacs-pending-undo-list (109164 . 110171) ("(use-package super-save
  ;; :disabled
  :config

  ;; (setq super-save-exclude '(\"\\\\.pdf\" \"\\\\.py\" \"+new-snippet+\"))
  ;; (setq-default super-save-exclude '(\"\\\\.pdf\" \"\\\\.py\" \"+new-snippet+\"))

  (setq super-save-exclude '(\"pdf\" \"\\\\.pdf\" \"+new-snippet+\"))
  (setq-default super-save-exclude '(\"pdf\" \"\\\\.pdf\" \"+new-snippet+\"))

  (setq auto-save-default nil
        super-save-idle-duration 2
        super-save-auto-save-when-idle nil
        auto-save-file-name-transforms `((\".*\" \"~/emacs-profiles/my-emacs/var/temp\" t)))

  (setq super-save-hook-triggers '(mouse-leave-buffer-hook focus-out-hook))

  (setq super-save-triggers
        '(quickrun
          quit-window
          last-buffer
          windmove-up
          windmove-down
          windmove-left
          windmove-right
          switch-to-buffer
          delete-window
          eyebrowse-close-window-config
          eyebrowse-create-window-config
          eyebrowse-next-window-config
          eyebrowse-prev-window-config))

  (auto-save-mode -1)
  (super-save-mode +1))
" . 109164) ((marker . 109164) . -379) ((marker . 109164) . -1000) ((marker . 109164) . -787) ((marker . 109164) . -1000) ((marker . 109164) . -1000) ((marker . 109164) . -787) ((marker . 109164) . -787) ((marker . 109164) . -787) ((marker . 109164) . -787) ((marker . 109164) . -787) ((marker . 109164) . -18) ((marker . 109164) . -18) ((marker . 110083) . -18) 109182 (t 24239 53491 766742 544000) nil (162137 . 169852) ("(use-package python
  :ensure nil
  :init
  (add-hook 'python-mode-hook 'my-python-hooks)
  (add-hook 'inferior-python-mode-hook 'my-inferior-python-mode-hooks)

  ;; https://stackoverflow.com/a/6141681
  ;; (add-hook 'python-mode-hook
  ;;           (lambda ()
  ;;             (add-hook 'write-contents-functions (lambda() (elpy-black-fix-code)) nil t)))

  :config
  (font-lock-add-keywords 'python-mode
                          '((\"cls\" . font-lock-keyword-face)))
  (setq python-shell-interpreter \"python3\")
  (setq python-shell-interpreter-args \"-i -q\")

  (setq python-shell-completion-native-enable nil)

  (defun my-python-hooks ()
    (interactive)
    (flymake-mode -1)
    (electric-operator-mode +1)
    (flycheck-mode +1)
    (rainbow-delimiters-mode +1)
    (highlight-operators-mode +1)
    (evil-swap-keys-swap-double-single-quotes)
    (evil-swap-keys-swap-underscore-dash)
    (evil-swap-keys-swap-colon-semicolon)
    (smartparens-strict-mode +1)
    (my-company-idle-one-prefix-one-quiet)
    (highlight-numbers-mode +1)
    (yafolding-mode +1)
    (apheleia-mode +1)
    (importmagic-mode +1)
    (elpy-enable +1))

  (defun my-inferior-python-mode-hooks ()
    (interactive)
    (electric-operator-mode +1)
    (flycheck-mode +1)
    (rainbow-delimiters-mode +1)
    (highlight-operators-mode +1)
    (evil-swap-keys-swap-double-single-quotes)
    (evil-swap-keys-swap-underscore-dash)
    (evil-swap-keys-swap-colon-semicolon)
    (smartparens-strict-mode +1)
    (my-company-idle-one-prefix-one-quiet)
    (company-mode +1)
    (highlight-numbers-mode +1))

  (add-to-list 'company-backends 'company-jedi)

  ;; (setq-local company-backends '(company-jedi
  ;;                                company-dabbrev-code
  ;;                                company-files
  ;;                                (company-semantic
  ;;                                 company-capf
  ;;                                 company-keywords
  ;;                                 company-dabbrev
  ;;                                 company-shell)))

  (defun my/olivetti-narrow ()
    (interactive)
    (olivetti-mode +1)
    (setq-local olivetti-body-width 60))

  (defun my-python-hooks ()
    (interactive)
    (subword-mode 1)
    (electric-operator-mode +1)
    (company-mode)
    (flycheck-mode +1)
    (rainbow-delimiters-mode +1)
    (highlight-operators-mode +1)
    (evil-swap-keys-swap-double-single-quotes)
    (evil-swap-keys-swap-underscore-dash)
    (evil-swap-keys-swap-colon-semicolon)
    (smartparens-strict-mode +1)
    (my-company-idle-one-prefix-one-quiet)
    (highlight-numbers-mode +1)
    (elpy-enable +1)
    )

  ;; PYTHON KEYS ;;
  (general-define-key
   :keymaps 'inferior-python-mode-map
   \"C-j\" 'elpy-shell-switch-to-buffer
   \"M-e\" 'counsel-shell-history
   \"C-c j\" 'my/evil-shell-bottom
   \"C-c u\" 'universal-argument
   \"C-u\" 'comint-kill-input
   \"C-l\" 'comint-clear-buffer
   \"C-;\" 'my-elpy-switch-to-buffer
   \"C-n\" 'comint-next-input
   \"C-p\" 'comint-previous-input)

  (general-unbind 'inferior-python-mode-map
    :with 'elpy-shell-switch-to-buffer
    [remap save-buffer]
    [remap my-save-buffer]
    [remap comint-next-prompt])

  (general-unbind 'python-mode-map
    :with 'elpy-folding-toggle-at-point
    [remap hs-toggle-hiding])

  (general-unbind 'python-mode-map
    :with 'my-python-shebang
    [remap my-bash-shebang])

  (general-define-key
   :keymaps 'python-mode-map
   \"<M-return>\" 'apheleia-format-buffer
   \"M-a\" 'python-nav-backward-statement
   \"M-e\" 'python-nav-forward-statement
   \"C-S-p\" 'python-nav-backward-sexp
   \"C-S-n\" 'python-nav-forward-sexp
   \"C-x o\" 'my/olivetti-narrow
   \"C-x m\" 'elpy-multiedit-python-symbol-at-point
   \"C-x M\" 'elpy-multiedit-stop
   \"C-c g\" 'my/counsel-ag-python
   \"M-m\" 'flycheck-first-error
   \"C-c p\" 'my/python-make-print
   \"C-c f\" 'my/python-make-fstring
   \"C-c DEL\" 'my/erase-python-file
   \"C-c =\" 'my/erase-python-file-and-yank
   )

  (general-unbind 'python-mode-map
    :with 'yafolding-hide-all
    [remap evil-close-folds])

  (general-nmap
    :keymaps 'python-mode-map
    \"<escape>\" 'my-prog-save-buffer)

  (general-nvmap
    :keymaps 'python-mode-map
    \"zi\" 'yafolding-show-all
    \"M-a\" 'python-nav-backward-statement
    \"M-e\" 'python-nav-forward-statement
    \"C-S-p\" 'python-nav-backward-sexp
    \"C-S-n\" 'python-nav-forward-sexp
    \"C-ç\" 'my/python-newline-beg
    \"<backspace>\" 'org-edit-src-exit
    \"<C-return>\" 'my-quickrun
    \"<tab>\" 'elpy-folding-toggle-at-point
    \"<tab>\" 'elpy-folding-toggle-at-point
    \"RET\" 'hydra-python-mode/body
    \"zm\" 'evil-close-folds
    \"gh\" 'outline-up-heading
    \"gl\" 'outline-next-heading
    \"zl\" 'outline-show-subtree
    \"<\" 'python-indent-shift-left
    \">\" 'python-indent-shift-right
    \"gj\" 'outline-forward-same-level
    \"gk\" 'outline-backward-same-level)

  (defun my/python-newline-beg ()
    (interactive)
    (evil-insert-state)
    (newline)
    (beginning-of-line))

  (defun my/python-colon-newline ()
    (interactive)
    (end-of-line)
    (insert \":\")
    (newline-and-indent))

  (general-imap
    :keymaps 'python-mode-map
    \"C-=\"   'my/python-colon-newline
    \"C-ç\" 'my/python-newline-beg
    \"<C-return>\" 'my-quickrun
    \"C-h\" 'python-indent-dedent-line-backspace
    \"M-a\" 'python-nav-backward-statement
    \"M-e\" 'python-nav-forward-statement
    \"C-S-p\" 'python-nav-backward-sexp
    \"C-S-n\" 'python-nav-forward-sexp
    )

  ;; PYTHON FUNCTIONS;;

  (defun execute-python-program ()
    (interactive)
    (my/window-to-register-91)
    (my/quiet-save-buffer)
    (defvar foo-execute-python)
    (setq foo-execute-python (concat \"python3 \" (buffer-file-name)))
    (other-window 1)
    (switch-to-buffer-other-window \"*Async Shell Command*\")
    (shell-command foo))

  (defun my/execute-python-program-shell-simple  ()
    (interactive)
    (my/window-to-register-91)
    (my/quiet-save-buffer)
    (defvar foo-execute-python-simple)
    (setq foo-execute-python-simple (concat \"python3 \" (prelude-copy-file-name-to-clipboard)))
    (shell-command foo))

  (defun my/ex-python-run ()
    (interactive)
    (evil-ex \"w !python3\"))

  (defun my/execute-python-program-shell ()
    (interactive)
    (progn
      (my/quiet-save-buffer)
      (prelude-copy-file-name-to-clipboard)
      (shell)
      (sit-for 0.3)
      (insert \"source ~/scripts/cline_scripts/smallprompt.sh\")
      (comint-send-input)
      (insert \"python3 \")
      (yank)
      (comint-send-input)
      (evil-insert-state)
      (sit-for 0.3)
      (comint-clear-buffer)
      (company-mode -1)))

  (general-unbind 'python-mode-map
    :with 'elpy-doc
    [remap helpful-at-point])

  (defun my/run-python-external ()
    (interactive)
    (progn
      (prelude-copy-file-name-to-clipboard)
      (start-process-shell-command
       \"call term\" nil
       \"~/scripts/i3_scripts/show_term_right\")))

  (defun my/erase-python-file ()
    (interactive)
    (erase-buffer)
    (insert \"#!/usr/bin/env python3\\n\\n\")
    (evil-insert-state)
    (flycheck-clear))

  (defun my/erase-python-file-and-yank ()
    (interactive)
    (erase-buffer)
    (insert \"#!/usr/bin/env python3\\n\\n\")
    (yank))

  (defun my/kill-python-file ()
    (interactive)
    (kill-region (point-min) (point-max))
    (insert \"#!/usr/bin/env python3\\n\\n\")
    (evil-insert-state)
    (flycheck-clear))

  (defun my/python-save-buffer ()
    (interactive)
    (evil-ex-nohighlight)
    (let ((inhibit-message t))
      (delete-trailing-whitespace)
      (save-buffer)))

  ;; PYTHON SETTINGS

  (setq comment-auto-fill-only-comments t
        python-indent-offset 4
        python-indent-guess-indent-offset nil)

  (auto-fill-mode 1))
" . 162137) ((marker . 162098) . -4127) ((marker . 162809) . -16) ((marker . 162098) . -16) ((marker . 92) . -16) ((marker . 89) . -16) 162153 (t 24239 51986 267069 482000) nil (32212 . 46135) ("(use-package org
  :defer t
  :init

  ;; (add-hook 'org-cycle-hook 'org-toggle-tag-visibility)
  (add-hook 'org-mode-hook 'my-org-hooks)
  (add-hook 'org-src-mode-hook 'my-only-indent-buffer)
  (add-hook 'org-agenda-mode-hook 'my-org-agenda-hooks)

  (remove-hook 'org-cycle-hook #'org-optimize-window-after-visibility-change)

  :bind (:map org-src-mode-map
              (\"C-c DEL\" . org-edit-src-exit)
              (\"C-c RET\" . my-eval-buffer-and-leave-org-source))
  :config

  (defun my-org-agenda-goto ()
    (interactive)
    (org-agenda-goto)
    (delete-windows-on \"*Org Agenda*\"))

  (defun my-org-agenda-hooks ()
    (interactive)
    (hl-line-mode +1)
    (olivetti-mode +1))

  (defun my-org-hooks ()
    (interactive)
    ;; (evil-org-mode +1)
    (org-bullets-mode +1)
    (visual-line-mode +1)
    ;; (tab-jump-out-mode +1)
    (setq-local doom-modeline-enable-word-count nil))

  (general-unbind 'org-columns-map
    :with 'org-columns-quit
    [remap org-columns]
    [remap save-buffer])

  (general-define-key
   :keymaps 'org-mode-map
   \"C-x <up>\"   'org-shiftup
   \"C-x <down>\"   'org-shiftdown
   \"C-x <left>\"   'org-shiftleft
   \"C-x <right>\"   'org-shiftright
   \"C-c l\" 'evil-org-org-insert-heading-respect-content-below
   \"C-x ;\" 'org-timestamp-down
   \"C-x .\" 'org-timestamp-up
   \"M-p\" 'org-backward-paragraph
   \"M-n\" 'org-forward-paragraph
   \"C-c -\" 'my-insert-em-dash-space
   \"C-c C-n\" 'org-add-note
   \"C-c n\" 'org-add-note
   \"C-c y\" 'org-evaluate-time-range
   \"C-c C-s\" 'org-emphasize
   \"C-c o\" 'counsel-outline
   \"C-ç\" 'counsel-outline
   \"C-c q\" 'org-columns
   \"C-M-k\" 'org-metaup
   \"C-M-j\" 'org-metadown
   \"C-<\" 'org-priority-up
   \"C->\" 'org-priority-down
   \"C-c C-s\" 'org-emphasize
   \"<C-S-up>\" 'org-priority-up
   \"<C-S-down>\" 'org-priority-down)

  (general-nvmap
    :keymaps 'org-mode-map
    \"zb\" 'evil-scroll-line-to-bottom
    \"C-k\" 'my-kill-line)

  (general-nmap
    :keymaps 'org-mode-map
    \"C-c -\" 'my-insert-em-dash-space)

  (general-define-key
   :keymaps 'org-agenda-mode-map
   \"<S-left>\" 'org-agenda-date-earlier
   \"<S-right>\" 'org-agenda-date-later
   \"<escape>\" 'org-agenda-quit)

  (general-unbind 'org-agenda-mode-map
    :with 'windmove-up
    [remap org-agenda-drag-line-backward])

  (general-unbind 'org-agenda-mode-map
    :with 'windmove-down
    [remap org-agenda-drag-line-forward])

  (general-unbind 'org-agenda-mode-map
    :with 'my-org-agenda-goto
    [remap org-agenda-switch-to]
    [remap evil-ret])

  (general-unbind 'org-agenda-mode-map
    :with 'org-agenda-quit
    [remap evil-repeat-find-char-reverse]
    [remap org-agenda-goto-today])

  (general-unbind 'org-agenda-mode-map
    :with 'org-agenda-previous-item
    [remap org-agenda-previous-line]
    [remap evil-previous-visual-line])

  (general-unbind 'org-agenda-mode-map
    :with 'org-agenda-next-item
    [remap org-agenda-next-line]
    [remap evil-next-visual-line])

  (general-unbind 'org-agenda-mode-map
    :with 'org-todo-list
    [remap evil-find-char-to-backward])

  (general-unbind 'org-agenda-mode-map
    :with 'org-agenda-quit
    [remap minibuffer-keyboard-quit])

  (general-unbind 'org-mode-map
    :with 'org-emphasize
    [remap pyenv-mode-set])

  (general-unbind 'org-mode-map
    :with 'cool-moves-line-backward
    [remap org-shiftcontrolup])

  (general-unbind 'org-mode-map
    :with 'cool-moves-line-forward
    [remap org-shiftcontroldown])

  (general-define-key
   :keymaps 'org-mode-map
   :states   '(normal visual)
   \"TAB\"   'org-cycle)

  (general-unbind 'org-mode-map
    :with 'delete-char
    [remap org-metaleft])

  (general-define-key
   :keymaps 'org-mode-map
   :states '(normal visual)
   \"DEL\" 'org-edit-special)

  (general-nvmap
    :keymaps 'org-src-mode-map
    \"DEL\" 'org-edit-src-exit
    \"<backspace>\" 'org-edit-src-exit)

  (general-define-key
   :keymaps 'org-mode-map
   :states '(normal visual)
   \"<insert>\" 'org-insert-link
   \"DEL\" 'org-edit-special)

  (defun my-org-started-with-clock ()
    (interactive)
    (org-todo \"STRT\")
    (org-clock-in))

  (defun my-org-started-with-pomodoro ()
    (interactive)
    (org-todo \"STRT\")
    (org-pomodoro))

  (defun my-org-goto-clock-and-start-pomodoro ()
    (interactive)
    (org-clock-goto)
    (org-todo \"STRT\")
    (org-pomodoro))

  (defun my-org-started-no-clock ()
    (interactive)
    (org-todo \"STRT\"))

  (defun my-org-todo-done ()
    (interactive)
    (org-todo \"DONE\"))

  (defun my-org-todo-done-pomodoro ()
    (interactive)
    (org-todo \"DONE\")
    (org-pomodoro))

  (defun my-org-todo ()
    (interactive)
    (org-todo \"TODO\")
    (org-clock-out))

  (defun my-org-agenda ()
    (interactive)
    (org-agenda t \"a\"))

  (defun my-org-todos-agenda ()
    (interactive)
    (org-agenda t \"T\"))

  (defun org-today-agenda ()
    (interactive)
    (let ((current-prefix-arg 1)
          (org-deadline-warning-days 0))
      (org-agenda t \"a\")))

  (defun org-1-day-agenda ()
    (interactive)
    (let ((current-prefix-arg 1)
          (org-deadline-warning-days -1))
      (org-agenda t \"a\")))

  (defun org-2-days-agenda ()
    (interactive)
    (let ((current-prefix-arg 2)
          (org-deadline-warning-days 0))
      (org-agenda t \"a\")))

  (defun org-3-days-agenda ()
    (interactive)
    (let ((current-prefix-arg 3)
          (org-deadline-warning-days 0))
      (org-agenda t \"a\")))

  (defun org-4-days-agenda ()
    (interactive)
    (let ((current-prefix-arg 4)
          (org-deadline-warning-days 0))
      (org-agenda t \"a\")))

  (defun org-5-days-agenda ()
    (interactive)
    (let ((current-prefix-arg 5)
          (org-deadline-warning-days 0))
      (org-agenda t \"a\")))

  (defun org-6-days-agenda ()
    (interactive)
    (let ((current-prefix-arg 6)
          (org-deadline-warning-days 0))
      (org-agenda t \"a\")))

  (defun org-7-days-agenda ()
    (interactive)
    (let ((current-prefix-arg 7)
          (org-deadline-warning-days 0))
      (org-agenda t \"a\")))

  (defun org-30-days-agenda ()
    (interactive)
    (let ((current-prefix-arg 30)
          (org-deadline-warning-days 0))
      (org-agenda t \"a\")))

  ;; \"TODO(t)\" \"STRT(s)\" \"|\" \"DONE(d)\"
  ;; MAKES SOURCE BUFFER NAMES NICER ;;
  (defun org-src--construct-edit-buffer-name (org-buffer-name lang)
    (concat \"[S] \"org-buffer-name\"\"))

  ;; https://emacs.stackexchange.com/a/32039
  (defun org-toggle-tag-visibility (state)
    \"Run in `org-cycle-hook'.\"
    (interactive)
    (message \"%s\" state)
    (cond
     ;; global cycling
     ((memq state '(overview contents showall))
      (org-map-entries
       (lambda ()
         (let ((tagstring (nth 5 (org-heading-components)))
               start end)
           (when tagstring
             (save-excursion
               (beginning-of-line)
               (re-search-forward tagstring)
               (setq start (match-beginning 0)
                     end (match-end 0)))
             (cond
              ((memq state '(overview contents))
               (outline-flag-region start end t))
              (t
               (outline-flag-region start end nil))))))))
     ;; local cycling
     ((memq state '(folded children subtree))
      (save-restriction
        (org-narrow-to-subtree)
        (org-map-entries
         (lambda ()
           (let ((tagstring (nth 5 (org-heading-components)))
                 start end)
             (when tagstring
               (save-excursion
                 (beginning-of-line)
                 (re-search-forward tagstring)
                 (setq start (match-beginning 0)
                       end (match-end 0)))
               (cond
                ((memq state '(folded children))
                 (outline-flag-region start end t))
                (t
                 (outline-flag-region start end nil)))))))))))

  ;; REMOVE LINK
  ;; https://emacs.stackexchange.com/a/21945
  (defun my-org-remove-link  ()
    \"Replace an org link by its description or if empty its address\"
    (interactive)
    (if (org-in-regexp org-bracket-link-regexp 1)
        (save-excursion
          (let ((remove (list (match-beginning 0) (match-end 0)))
                (description (if (match-end 3)
                                 (match-string-no-properties 3)
                               (match-string-no-properties 1))))
            (apply 'delete-region remove)
            (insert description)))))

  ;; (setq org-agenda-files '(\"~/org/agenda.org\"))
  (setq org-agenda-files '(\"~/org/Agenda\"))

  ;; ORG FONTIFICATION AND SRC BLOCKS ;;
  (setq org-fontify-done-headline t
        org-src-fontify-natively t
        org-odt-fontify-srcblocks t
        org-src-tab-acts-natively t
        org-fontify-whole-heading-line nil
        org-fontify-quote-and-verse-blocks nil)

  (setq org-indent-mode nil
        org-clock-persist t
        org-tags-column -77
        org-clock-in-resume t
        org-pretty-entities t
        org-log-into-drawer t
        org-lowest-priority 73
        org-startup-indented t
        org-clock-into-drawer t
        org-default-priority 65
        org-export-with-toc nil
        org-cycle-level-faces t
        org-export-with-tags nil
        org-use-speed-commands t
        require-final-newline nil
        org-return-follows-link t
        org-image-actual-width nil
        org-agenda-tags-column -80
        org-id-link-to-org-use-id t
        org-clock-history-length 10
        org-clock-update-period 240
        org-footnote-auto-adjust 't
        org-export-preserve-breaks t
        org-hide-emphasis-markers t
        org-replace-disputed-keys t
        org-timer-display 'mode-line
        org-deadline-warning-days 14
        org-agenda-show-all-dates nil
        calendar-date-style 'european
        org-export-html-postamble nil
        mode-require-final-newline nil
        org-export-with-broken-links t
        org-export-time-stamp-file nil
        org-src-preserve-indentation t
        org-confirm-babel-evaluate nil
        org-clock-mode-line-total 'auto
        org-agenda-hide-tags-regexp \".\"
        org-agenda-show-outline-path nil
        org-export-with-todo-keywords nil
        org-show-notification-handler nil
        org-refile-use-outline-path 'file
        org-link-file-path-type 'relative
        org-clock-persist-query-resume t
        org-agenda-skip-archived-trees nil
        org-edit-src-content-indentation 1
        org-export-with-archived-trees nil
        org-agenda-skip-deadline-if-done t
        org-agenda-skip-timestamp-if-done t
        org-agenda-skip-scheduled-if-done t
        org-clock-auto-clock-resolution nil
        org-edit-src-persistent-message nil
        org-edit-src-auto-save-idle-delay 1
        org-src-window-setup 'current-window
        org-clock-sound \"~/Sounds/cuckoo.au\"
        org-agenda-show-future-repeats 'next
        org-agenda-skip-unavailable-files 't
        org-babel-no-eval-on-ctrl-c-ctrl-c t
        org-src-window-setup 'current-window
        org-outline-path-complete-in-steps nil
        org-clock-out-remove-zero-time-clocks t
        org-clock-report-include-clocking-task t
        org-clock-clocked-in-display 'mode-line
        org-allow-promoting-top-level-subtree nil
        org-enforce-todo-checkbox-dependencies t
        org-refile-allow-creating-parent-nodes nil
        org-src-ask-before-returning-to-edit-buffer nil
        org-agenda-skip-timestamp-if-deadline-is-shown t
        org-pretty-entities-include-sub-superscripts nil
        org-agenda-skip-additional-timestamps-same-entry 't)

  (setq org-ellipsis \".\")
  (setq org-timer-format \"%s \")
  (setq-default org-export-html-postamble nil)
  (setq org-refile-targets '((projectile-project-buffers :maxlevel . 3)))
  (setq org-blank-before-new-entry '((heading . nil) (plain-list-item . nil)))
  (setq org-global-properties
        '((\"Effort_ALL\" .
           \"00:04 00:08 00:12 00:16 00:20 00:24 00:28\")))
  (setq org-html-htmlize-output-type 'css)

  ;; (setq org-modules '(ol-w3m ol-bbdb ol-bibtex ol-docview ol-gnus ol-info ol-irc ol-mhe ol-rmail ol-eww ol-habit))
  ;; (setq org-modules '(ol-w3m ol-bbdb ol-bibtex ol-docview ol-gnus ol-info ol-irc ol-mhe ol-rmail ol-eww))

  (setq org-babel-temporary-directory (concat user-emacs-directory \"babel-temp\"))

  (setq org-archive-location \".%s::datetree/\")
  (setq org-drawers (quote (\"PROPERTIES\" \"LOGBOOK\"))) ;; Separate drawers for clocking and logs
  (setq org-format-latex-options
        (plist-put org-format-latex-options :scale 1.3))

  (setq org-todo-keywords
        '((sequence \"TODO(t)\" \"STRT(s!)\" \"|\" \"DONE(d!)\")))

  (setq org-file-apps (quote ((auto-mode . emacs)
                              (\"\\\\.mm\\\\'\" . default)
                              (\"\\\\.x?html?\\\\'\" . default)
                              (\"\\\\.jpg\\\\'\" . \"viewnior %s\")
                              (\"\\\\.mp4\\\\'\" . \"vlc %s\")
                              (\"\\\\.webm\\\\'\" . \"vlc %s\")
                              (\"\\\\.pdf\\\\'\" . \"zathura %s\")
                              (\"\\\\.epub\\\\'\" . \"ebook-viewer %s\")
                              ;; (\"\\\\.pdf\\\\'\" . \"org-pdfview-open %s\")
                              )))
  (add-to-list 'org-src-lang-modes '(\"i3\" . i3wm-config))

  ;; CAPTURE TEMPLATES ;;
  (setq org-capture-templates
        '((\"a\" \"Agenda\" entry
           (file+headline
            \"~/org/Agenda/agenda.org\" \"Tasks\")
           \"* TODO %i%^{1|Title}\\nDEADLINE: \\%^t\\n%^{2}\" :immediate-finish t)

          (\"t\" \"Tech\" entry
           (file+headline \"~/org/Agenda/agenda.org\" \"Tech\")
           \"* TODO %i%^{1|Title}\\n\\%u\\n%^{2}\"
           :immediate-finish t)

          (\"e\" \"Emacs\" entry
           (file+headline
            \"~/org/Agenda/agenda.org\" \"Emacs\")
           \"* TODO %i%^{1|Title}\\n\\%u\\n%^{2}\" :immediate-finish t)

          ))

  ;; https://emacs.stackexchange.com/a/41685
  ;; Requires org-plus-contrib (above)
  (require 'ox-extra)
  (ox-extras-activate '(ignore-headlines)))
" . 32212) ((marker . 181405) . -11131) ((marker* . 181431) . 2789) ((marker . 181405) . -11131) ((marker . 181430) . -11131) ((marker . 32212) . -11131) ((marker . 32212) . -11140) ((marker* . 110180) . 2798) ((marker . 32212) . -11131) ((marker . 32212) . -11094) 43314 (t 24239 51951 446503 744000) nil (162144 . 169828) ("(use-package python
  :ensure nil
  :init
  (add-hook 'python-mode-hook 'my-python-hooks)
  (add-hook 'inferior-python-mode-hook 'my-inferior-python-mode-hooks)

  ;; https://stackoverflow.com/a/6141681
  ;; (add-hook 'python-mode-hook
  ;;           (lambda ()
  ;;             (add-hook 'write-contents-functions (lambda() (elpy-black-fix-code)) nil t)))

  :config
  (font-lock-add-keywords 'python-mode
                          '((\"cls\" . font-lock-keyword-face)))
  (setq python-shell-interpreter \"python3\")
  (setq python-shell-interpreter-args \"-i -q\")

  (setq python-shell-completion-native-enable nil)

  (defun my-python-hooks ()
    (interactive)
    (flymake-mode -1)
    (electric-operator-mode +1)
    (flycheck-mode +1)
    (rainbow-delimiters-mode +1)
    (highlight-operators-mode +1)
    (evil-swap-keys-swap-double-single-quotes)
    (evil-swap-keys-swap-underscore-dash)
    (evil-swap-keys-swap-colon-semicolon)
    (smartparens-strict-mode +1)
    (my-company-idle-one-prefix-one-quiet)
    (highlight-numbers-mode +1)
    (yafolding-mode +1)
    (apheleia-mode +1)
    (importmagic-mode +1)
    (elpy-enable +1))

  (defun my-inferior-python-mode-hooks ()
    (interactive)
    (electric-operator-mode +1)
    (flycheck-mode +1)
    (rainbow-delimiters-mode +1)
    (highlight-operators-mode +1)
    (evil-swap-keys-swap-double-single-quotes)
    (evil-swap-keys-swap-underscore-dash)
    (evil-swap-keys-swap-colon-semicolon)
    (smartparens-strict-mode +1)
    (my-company-idle-one-prefix-one-quiet)
    (company-mode +1)
    (highlight-numbers-mode +1))

  (add-to-list 'company-backends 'company-jedi)

  ;; (setq-local company-backends '(company-jedi
  ;;                                company-dabbrev-code
  ;;                                company-files
  ;;                                (company-semantic
  ;;                                 company-capf
  ;;                                 company-keywords
  ;;                                 company-dabbrev
  ;;                                 company-shell)))

  (defun my/olivetti-narrow ()
    (interactive)
    (olivetti-mode +1)
    (setq-local olivetti-body-width 60))

  (defun my-python-hooks ()
    (interactive)
    (subword-mode 1)
    (electric-operator-mode +1)
    (company-mode)
    (flycheck-mode +1)
    (rainbow-delimiters-mode +1)
    (highlight-operators-mode +1)
    (evil-swap-keys-swap-double-single-quotes)
    (evil-swap-keys-swap-underscore-dash)
    (evil-swap-keys-swap-colon-semicolon)
    (smartparens-strict-mode +1)
    (my-company-idle-one-prefix-one-quiet)
    (highlight-numbers-mode +1)
    (elpy-enable +1)
    )

  ;; PYTHON KEYS ;;
  (general-define-key
   :keymaps 'inferior-python-mode-map
   \"C-j\" 'elpy-shell-switch-to-buffer
   \"M-e\" 'counsel-shell-history
   \"C-c j\" 'my/evil-shell-bottom
   \"C-c u\" 'universal-argument
   \"C-u\" 'comint-kill-input
   \"C-l\" 'comint-clear-buffer
   \"C-;\" 'my-elpy-switch-to-buffer
   \"C-n\" 'comint-next-input
   \"C-p\" 'comint-previous-input)

  (general-unbind 'inferior-python-mode-map
    :with 'elpy-shell-switch-to-buffer
    [remap save-buffer]
    [remap my-save-buffer]
    [remap comint-next-prompt])

  (general-unbind 'python-mode-map
    :with 'elpy-folding-toggle-at-point
    [remap hs-toggle-hiding])

  (general-unbind 'python-mode-map
    :with 'my-python-shebang
    [remap my-bash-shebang])

  (general-define-key
   :keymaps 'python-mode-map
   \"<M-return>\" 'apheleia-format-buffer
   \"M-a\" 'python-nav-backward-statement
   \"M-e\" 'python-nav-forward-statement
   \"C-S-p\" 'python-nav-backward-sexp
   \"C-S-n\" 'python-nav-forward-sexp
   \"C-x o\" 'my/olivetti-narrow
   \"C-x m\" 'elpy-multiedit-python-symbol-at-point
   \"C-x M\" 'elpy-multiedit-stop
   \"C-c g\" 'my/counsel-ag-python
   \"M-m\" 'flycheck-first-error
   \"C-c p\" 'my/python-make-print
   \"C-c f\" 'my/python-make-fstring
   \"C-c DEL\" 'my/erase-python-file
   \"C-c =\" 'my/erase-python-file-and-yank
   )

  (general-unbind 'python-mode-map
    :with 'yafolding-hide-all
    [remap evil-close-folds])

  (general-nmap
    :keymaps 'python-mode-map
    \"<escape>\" 'save-buffer)

  (general-nvmap
    :keymaps 'python-mode-map
    \"zi\" 'yafolding-show-all
    \"M-a\" 'python-nav-backward-statement
    \"M-e\" 'python-nav-forward-statement
    \"C-S-p\" 'python-nav-backward-sexp
    \"C-S-n\" 'python-nav-forward-sexp
    \"C-ç\" 'my/python-newline-beg
    \"<backspace>\" 'org-edit-src-exit
    \"<C-return>\" 'my-quickrun
    \"<tab>\" 'elpy-folding-toggle-at-point
    \"<tab>\" 'elpy-folding-toggle-at-point
    \"RET\" 'hydra-python-mode/body
    \"zm\" 'evil-close-folds
    \"gh\" 'outline-up-heading
    \"gl\" 'outline-next-heading
    \"zl\" 'outline-show-subtree
    \"<\" 'python-indent-shift-left
    \">\" 'python-indent-shift-right
    \"gj\" 'outline-forward-same-level
    \"gk\" 'outline-backward-same-level)

  (defun my/python-newline-beg ()
    (interactive)
    (evil-insert-state)
    (newline)
    (beginning-of-line))

  (defun my/python-colon-newline ()
    (interactive)
    (end-of-line)
    (insert \":\")
    (newline-and-indent))

  (general-imap
    :keymaps 'python-mode-map
    \"C-=\"   'my/python-colon-newline
    \"C-ç\" 'my/python-newline-beg
    \"<C-return>\" 'my-quickrun
    \"C-h\" 'python-indent-dedent-line-backspace
    \"M-a\" 'python-nav-backward-statement
    \"M-e\" 'python-nav-forward-statement
    \"C-S-p\" 'python-nav-backward-sexp
    \"C-S-n\" 'python-nav-forward-sexp
    )

  ;; PYTHON FUNCTIONS;;

  (defun execute-python-program ()
    (interactive)
    (my/window-to-register-91)
    (my/quiet-save-buffer)
    (defvar foo-execute-python)
    (setq foo-execute-python (concat \"python3 \" (buffer-file-name)))
    (other-window 1)
    (switch-to-buffer-other-window \"*Async Shell Command*\")
    (shell-command foo))

  (defun my/execute-python-program-shell-simple  ()
    (interactive)
    (my/window-to-register-91)
    (my/quiet-save-buffer)
    (defvar foo-execute-python-simple)
    (setq foo-execute-python-simple (concat \"python3 \" (prelude-copy-file-name-to-clipboard)))
    (shell-command foo))

  (defun my/ex-python-run ()
    (interactive)
    (evil-ex \"w !python3\"))

  (defun my/execute-python-program-shell ()
    (interactive)
    (progn
      (my/quiet-save-buffer)
      (prelude-copy-file-name-to-clipboard)
      (shell)
      (sit-for 0.3)
      (insert \"source ~/scripts/cline_scripts/smallprompt.sh\")
      (comint-send-input)
      (insert \"python3 \")
      (yank)
      (comint-send-input)
      (evil-insert-state)
      (sit-for 0.3)
      (comint-clear-buffer)
      (company-mode -1)))

  (general-unbind 'python-mode-map
    :with 'elpy-doc
    [remap helpful-at-point])

  (defun my/run-python-external ()
    (interactive)
    (progn
      (prelude-copy-file-name-to-clipboard)
      (start-process-shell-command
       \"call term\" nil
       \"~/scripts/i3_scripts/show_term_right\")))

  (defun my/erase-python-file ()
    (interactive)
    (erase-buffer)
    (insert \"#!/usr/bin/env python3\\n\\n\")
    (evil-insert-state)
    (flycheck-clear))

  (defun my/erase-python-file-and-yank ()
    (interactive)
    (erase-buffer)
    (insert \"#!/usr/bin/env python3\\n\\n\")
    (yank))

  (defun my/kill-python-file ()
    (interactive)
    (kill-region (point-min) (point-max))
    (insert \"#!/usr/bin/env python3\\n\\n\")
    (evil-insert-state)
    (flycheck-clear))

  (defun my/python-save-buffer ()
    (interactive)
    (evil-ex-nohighlight)
    (let ((inhibit-message t))
      (delete-trailing-whitespace)
      (save-buffer)))

  ;; PYTHON SETTINGS

  (setq comment-auto-fill-only-comments t
        python-indent-offset 4
        python-indent-guess-indent-offset nil)

  (auto-fill-mode 1))
" . 162144) ((marker . 162098) . -4109) 166253 (t 24239 51891 978418 541000) nil (162144 . 169820) ("(use-package python
  :ensure nil
  :init
  (add-hook 'python-mode-hook 'my-python-hooks)
  (add-hook 'inferior-python-mode-hook 'my-inferior-python-mode-hooks)

  ;; https://stackoverflow.com/a/6141681
  ;; (add-hook 'python-mode-hook
  ;;           (lambda ()
  ;;             (add-hook 'write-contents-functions (lambda() (elpy-black-fix-code)) nil t)))

  :config
  (font-lock-add-keywords 'python-mode
                          '((\"cls\" . font-lock-keyword-face)))
  (setq python-shell-interpreter \"python3\")
  (setq python-shell-interpreter-args \"-i -q\")

  (setq python-shell-completion-native-enable nil)

  (defun my-python-hooks ()
    (interactive)
    (flymake-mode -1)
    (electric-operator-mode +1)
    (flycheck-mode +1)
    (rainbow-delimiters-mode +1)
    (highlight-operators-mode +1)
    (evil-swap-keys-swap-double-single-quotes)
    (evil-swap-keys-swap-underscore-dash)
    (evil-swap-keys-swap-colon-semicolon)
    (smartparens-strict-mode +1)
    (my-company-idle-one-prefix-one-quiet)
    (highlight-numbers-mode +1)
    (yafolding-mode +1)
    (apheleia-mode +1)
    (importmagic-mode +1)
    (elpy-enable +1))

  (defun my-inferior-python-mode-hooks ()
    (interactive)
    (electric-operator-mode +1)
    (flycheck-mode +1)
    (rainbow-delimiters-mode +1)
    (highlight-operators-mode +1)
    (evil-swap-keys-swap-double-single-quotes)
    (evil-swap-keys-swap-underscore-dash)
    (evil-swap-keys-swap-colon-semicolon)
    (smartparens-strict-mode +1)
    (my-company-idle-one-prefix-one-quiet)
    (company-mode +1)
    (highlight-numbers-mode +1))

  (add-to-list 'company-backends 'company-jedi)

  ;; (setq-local company-backends '(company-jedi
  ;;                                company-dabbrev-code
  ;;                                company-files
  ;;                                (company-semantic
  ;;                                 company-capf
  ;;                                 company-keywords
  ;;                                 company-dabbrev
  ;;                                 company-shell)))

  (defun my/olivetti-narrow ()
    (interactive)
    (olivetti-mode +1)
    (setq-local olivetti-body-width 60))

  (defun my-python-hooks ()
    (interactive)
    (subword-mode 1)
    (electric-operator-mode +1)
    (company-mode)
    (flycheck-mode +1)
    (rainbow-delimiters-mode +1)
    (highlight-operators-mode +1)
    (evil-swap-keys-swap-double-single-quotes)
    (evil-swap-keys-swap-underscore-dash)
    (evil-swap-keys-swap-colon-semicolon)
    (smartparens-strict-mode +1)
    (my-company-idle-one-prefix-one-quiet)
    (highlight-numbers-mode +1)
    (elpy-enable +1)
    )

  ;; PYTHON KEYS ;;
  (general-define-key
   :keymaps 'inferior-python-mode-map
   \"C-j\" 'elpy-shell-switch-to-buffer
   \"M-e\" 'counsel-shell-history
   \"C-c j\" 'my/evil-shell-bottom
   \"C-c u\" 'universal-argument
   \"C-u\" 'comint-kill-input
   \"C-l\" 'comint-clear-buffer
   \"C-;\" 'my-elpy-switch-to-buffer
   \"C-n\" 'comint-next-input
   \"C-p\" 'comint-previous-input)

  (general-unbind 'inferior-python-mode-map
    :with 'elpy-shell-switch-to-buffer
    [remap save-buffer]
    [remap my-save-buffer]
    [remap comint-next-prompt])

  (general-unbind 'python-mode-map
    :with 'elpy-folding-toggle-at-point
    [remap hs-toggle-hiding])

  (general-unbind 'python-mode-map
    :with 'my-python-shebang
    [remap my-bash-shebang])

  (general-define-key
   :keymaps 'python-mode-map
   \"<escape>\" 'my-save-buffer-only
   \"<M-return>\" 'apheleia-format-buffer
   \"M-a\" 'python-nav-backward-statement
   \"M-e\" 'python-nav-forward-statement
   \"C-S-p\" 'python-nav-backward-sexp
   \"C-S-n\" 'python-nav-forward-sexp
   \"C-x o\" 'my/olivetti-narrow
   \"C-x m\" 'elpy-multiedit-python-symbol-at-point
   \"C-x M\" 'elpy-multiedit-stop
   \"C-c g\" 'my/counsel-ag-python
   \"M-m\" 'flycheck-first-error
   \"C-c p\" 'my/python-make-print
   \"C-c f\" 'my/python-make-fstring
   \"C-c DEL\" 'my/erase-python-file
   \"C-c =\" 'my/erase-python-file-and-yank
   )

  (general-unbind 'python-mode-map
    :with 'yafolding-hide-all
    [remap evil-close-folds])

  (general-nmap
    :keymaps 'python-mode-map
    \"<escape>\" 'save-buffer)

  (general-nvmap
    :keymaps 'python-mode-map
    \"zi\" 'yafolding-show-all
    \"M-a\" 'python-nav-backward-statement
    \"M-e\" 'python-nav-forward-statement
    \"C-S-p\" 'python-nav-backward-sexp
    \"C-S-n\" 'python-nav-forward-sexp
    \"C-ç\" 'my/python-newline-beg
    \"<backspace>\" 'org-edit-src-exit
    \"<C-return>\" 'my-quickrun
    \"<tab>\" 'elpy-folding-toggle-at-point
    \"<tab>\" 'elpy-folding-toggle-at-point
    \"RET\" 'hydra-python-mode/body
    \"zm\" 'evil-close-folds
    \"gh\" 'outline-up-heading
    \"gl\" 'outline-next-heading
    \"zl\" 'outline-show-subtree
    \"<\" 'python-indent-shift-left
    \">\" 'python-indent-shift-right
    \"gj\" 'outline-forward-same-level
    \"gk\" 'outline-backward-same-level)

  (defun my/python-newline-beg ()
    (interactive)
    (evil-insert-state)
    (newline)
    (beginning-of-line))

  (defun my/python-colon-newline ()
    (interactive)
    (end-of-line)
    (insert \":\")
    (newline-and-indent))

  (general-imap
    :keymaps 'python-mode-map
    \"C-=\"   'my/python-colon-newline
    \"C-ç\" 'my/python-newline-beg
    \"<C-return>\" 'my-quickrun
    \"C-h\" 'python-indent-dedent-line-backspace
    \"M-a\" 'python-nav-backward-statement
    \"M-e\" 'python-nav-forward-statement
    \"C-S-p\" 'python-nav-backward-sexp
    \"C-S-n\" 'python-nav-forward-sexp
    )

  ;; PYTHON FUNCTIONS;;

  (defun execute-python-program ()
    (interactive)
    (my/window-to-register-91)
    (my/quiet-save-buffer)
    (defvar foo-execute-python)
    (setq foo-execute-python (concat \"python3 \" (buffer-file-name)))
    (other-window 1)
    (switch-to-buffer-other-window \"*Async Shell Command*\")
    (shell-command foo))

  (defun my/execute-python-program-shell-simple  ()
    (interactive)
    (my/window-to-register-91)
    (my/quiet-save-buffer)
    (defvar foo-execute-python-simple)
    (setq foo-execute-python-simple (concat \"python3 \" (prelude-copy-file-name-to-clipboard)))
    (shell-command foo))

  (defun my/ex-python-run ()
    (interactive)
    (evil-ex \"w !python3\"))

  (defun my/execute-python-program-shell ()
    (interactive)
    (progn
      (my/quiet-save-buffer)
      (prelude-copy-file-name-to-clipboard)
      (shell)
      (sit-for 0.3)
      (insert \"source ~/scripts/cline_scripts/smallprompt.sh\")
      (comint-send-input)
      (insert \"python3 \")
      (yank)
      (comint-send-input)
      (evil-insert-state)
      (sit-for 0.3)
      (comint-clear-buffer)
      (company-mode -1)))

  (general-unbind 'python-mode-map
    :with 'elpy-doc
    [remap helpful-at-point])

  (defun my/run-python-external ()
    (interactive)
    (progn
      (prelude-copy-file-name-to-clipboard)
      (start-process-shell-command
       \"call term\" nil
       \"~/scripts/i3_scripts/show_term_right\")))

  (defun my/erase-python-file ()
    (interactive)
    (erase-buffer)
    (insert \"#!/usr/bin/env python3\\n\\n\")
    (evil-insert-state)
    (flycheck-clear))

  (defun my/erase-python-file-and-yank ()
    (interactive)
    (erase-buffer)
    (insert \"#!/usr/bin/env python3\\n\\n\")
    (yank))

  (defun my/kill-python-file ()
    (interactive)
    (kill-region (point-min) (point-max))
    (insert \"#!/usr/bin/env python3\\n\\n\")
    (evil-insert-state)
    (flycheck-clear))

  (defun my/python-save-buffer ()
    (interactive)
    (evil-ex-nohighlight)
    (let ((inhibit-message t))
      (delete-trailing-whitespace)
      (save-buffer)))

  ;; PYTHON SETTINGS

  (setq comment-auto-fill-only-comments t
        python-indent-offset 4
        python-indent-guess-indent-offset nil)

  (auto-fill-mode 1))
" . 162144) ((marker . 110083) . -16) 162160 (t 24239 50556 754121 452000) nil (162144 . 169855) ("(use-package python
  :ensure nil
  :init
  (add-hook 'python-mode-hook 'my-python-hooks)
  (add-hook 'inferior-python-mode-hook 'my-inferior-python-mode-hooks)

  ;; https://stackoverflow.com/a/6141681
  ;; (add-hook 'python-mode-hook
  ;;           (lambda ()
  ;;             (add-hook 'write-contents-functions (lambda() (elpy-black-fix-code)) nil t)))

  :config
  (font-lock-add-keywords 'python-mode
                          '((\"cls\" . font-lock-keyword-face)))
  (setq python-shell-interpreter \"python3\")
  (setq python-shell-interpreter-args \"-i -q\")

  (setq python-shell-completion-native-enable nil)

  (defun my-python-hooks ()
    (interactive)
    (flymake-mode -1)
    (electric-operator-mode +1)
    (flycheck-mode +1)
    (rainbow-delimiters-mode +1)
    (highlight-operators-mode +1)
    (evil-swap-keys-swap-double-single-quotes)
    (evil-swap-keys-swap-underscore-dash)
    (evil-swap-keys-swap-colon-semicolon)
    (smartparens-strict-mode +1)
    (my-company-idle-one-prefix-one-quiet)
    (highlight-numbers-mode +1)
    (yafolding-mode +1)
    (apheleia-mode +1)
(importmagic-mode +1)
    (elpy-enable +1))

  (defun my-inferior-python-mode-hooks ()
    (interactive)
    (electric-operator-mode +1)
    (flycheck-mode +1)
    (rainbow-delimiters-mode +1)
    (highlight-operators-mode +1)
    (evil-swap-keys-swap-double-single-quotes)
    (evil-swap-keys-swap-underscore-dash)
    (evil-swap-keys-swap-colon-semicolon)
    (smartparens-strict-mode +1)
    (my-company-idle-one-prefix-one-quiet)
    (company-mode +1)
    (highlight-numbers-mode +1))

  (add-to-list 'company-backends 'company-jedi)

  ;; (setq-local company-backends '(company-jedi
  ;;                                company-dabbrev-code
  ;;                                company-files
  ;;                                (company-semantic
  ;;                                 company-capf
  ;;                                 company-keywords
  ;;                                 company-dabbrev
  ;;                                 company-shell)))

  (defun my/olivetti-narrow ()
    (interactive)
    (olivetti-mode +1)
    (setq-local olivetti-body-width 60))

  (defun my-python-hooks ()
    (interactive)
    (subword-mode 1)
    (electric-operator-mode +1)
    (company-mode)
    (flycheck-mode +1)
    (rainbow-delimiters-mode +1)
    (highlight-operators-mode +1)
    (evil-swap-keys-swap-double-single-quotes)
    (evil-swap-keys-swap-underscore-dash)
    (evil-swap-keys-swap-colon-semicolon)
    (smartparens-strict-mode +1)
    (my-company-idle-one-prefix-one-quiet)
    (highlight-numbers-mode +1)
    (elpy-enable +1)
    )

  ;; PYTHON KEYS ;;
  (general-define-key
   :keymaps 'inferior-python-mode-map
   \"C-j\" 'elpy-shell-switch-to-buffer
   \"M-e\" 'counsel-shell-history
   \"C-c j\" 'my/evil-shell-bottom
   \"C-c u\" 'universal-argument
   \"C-u\" 'comint-kill-input
   \"C-l\" 'comint-clear-buffer
   \"C-;\" 'my-elpy-switch-to-buffer
   \"C-n\" 'comint-next-input
   \"C-p\" 'comint-previous-input)

  (general-unbind 'inferior-python-mode-map
    :with 'elpy-shell-switch-to-buffer
    [remap save-buffer]
    [remap my-save-buffer]
    [remap comint-next-prompt])

  (general-unbind 'python-mode-map
    :with 'elpy-folding-toggle-at-point
    [remap hs-toggle-hiding])

  (general-unbind 'python-mode-map
    :with 'my-python-shebang
    [remap my-bash-shebang])

  (general-define-key
   :keymaps 'python-mode-map
   \"<escape>\" 'my-save-buffer-only
   \"<M-return>\" 'apheleia-format-buffer
   \"M-a\" 'python-nav-backward-statement
   \"M-e\" 'python-nav-forward-statement
   \"C-S-p\" 'python-nav-backward-sexp
   \"C-S-n\" 'python-nav-forward-sexp
   \"C-x o\" 'my/olivetti-narrow
   \"C-x m\" 'elpy-multiedit-python-symbol-at-point
   \"C-x M\" 'elpy-multiedit-stop
   \"C-c g\" 'my/counsel-ag-python
   \"M-m\" 'flycheck-first-error
   \"C-c p\" 'my/python-make-print
   \"C-c f\" 'my/python-make-fstring
   \"C-c DEL\" 'my/erase-python-file
   \"C-c =\" 'my/erase-python-file-and-yank
   )

  (general-unbind 'python-mode-map
    :with 'yafolding-hide-all
    [remap evil-close-folds])

  (general-nmap
    :keymaps 'python-mode-map
    \"<escape>\" 'save-buffer)

  (general-nvmap
    :keymaps 'python-mode-map
    \"zi\" 'yafolding-show-all
    \"M-a\" 'python-nav-backward-statement
    \"M-e\" 'python-nav-forward-statement
    \"C-S-p\" 'python-nav-backward-sexp
    \"C-S-n\" 'python-nav-forward-sexp
    \"C-ç\" 'my/python-newline-beg
    \"<backspace>\" 'org-edit-src-exit
    \"<C-return>\" 'my-quickrun
    \"<tab>\" 'elpy-folding-toggle-at-point
    \"<tab>\" 'elpy-folding-toggle-at-point
    \"RET\" 'hydra-python-mode/body
    \"zm\" 'evil-close-folds
    \"gh\" 'outline-up-heading
    \"gl\" 'outline-next-heading
    \"zl\" 'outline-show-subtree
    \"<\" 'python-indent-shift-left
    \">\" 'python-indent-shift-right
    \"gj\" 'outline-forward-same-level
    \"gk\" 'outline-backward-same-level)

  (defun my/python-newline-beg ()
    (interactive)
    (evil-insert-state)
    (newline)
    (beginning-of-line))

  (defun my/python-colon-newline ()
    (interactive)
    (end-of-line)
    (insert \":\")
    (newline-and-indent))

  (general-imap
    :keymaps 'python-mode-map
    \"C-=\"   'my/python-colon-newline
    \"C-ç\" 'my/python-newline-beg
    \"<C-return>\" 'my-quickrun
    \"C-h\" 'python-indent-dedent-line-backspace
    \"M-a\" 'python-nav-backward-statement
    \"M-e\" 'python-nav-forward-statement
    \"C-S-p\" 'python-nav-backward-sexp
    \"C-S-n\" 'python-nav-forward-sexp
    )

  ;; PYTHON FUNCTIONS;;

  (defun execute-python-program ()
    (interactive)
    (my/window-to-register-91)
    (my/quiet-save-buffer)
    (defvar foo-execute-python)
    (setq foo-execute-python (concat \"python3 \" (buffer-file-name)))
    (other-window 1)
    (switch-to-buffer-other-window \"*Async Shell Command*\")
    (shell-command foo))

  (defun my/execute-python-program-shell-simple  ()
    (interactive)
    (my/window-to-register-91)
    (my/quiet-save-buffer)
    (defvar foo-execute-python-simple)
    (setq foo-execute-python-simple (concat \"python3 \" (prelude-copy-file-name-to-clipboard)))
    (shell-command foo))

  (defun my/ex-python-run ()
    (interactive)
    (evil-ex \"w !python3\"))

  (defun my/execute-python-program-shell ()
    (interactive)
    (progn
      (my/quiet-save-buffer)
      (prelude-copy-file-name-to-clipboard)
      (shell)
      (sit-for 0.3)
      (insert \"source ~/scripts/cline_scripts/smallprompt.sh\")
      (comint-send-input)
      (insert \"python3 \")
      (yank)
      (comint-send-input)
      (evil-insert-state)
      (sit-for 0.3)
      (comint-clear-buffer)
      (company-mode -1)))

  (general-unbind 'python-mode-map
    :with 'elpy-doc
    [remap helpful-at-point])

  (defun my/run-python-external ()
    (interactive)
    (progn
      (prelude-copy-file-name-to-clipboard)
      (start-process-shell-command
       \"call term\" nil
       \"~/scripts/i3_scripts/show_term_right\")))

  (defun my/erase-python-file ()
    (interactive)
    (erase-buffer)
    (insert \"#!/usr/bin/env python3\\n\\n\")
    (evil-insert-state)
    (flycheck-clear))

  (defun my/erase-python-file-and-yank ()
    (interactive)
    (erase-buffer)
    (insert \"#!/usr/bin/env python3\\n\\n\")
    (yank))

  (defun my/kill-python-file ()
    (interactive)
    (kill-region (point-min) (point-max))
    (insert \"#!/usr/bin/env python3\\n\\n\")
    (evil-insert-state)
    (flycheck-clear))

  (defun my/python-save-buffer ()
    (interactive)
    (evil-ex-nohighlight)
    (let ((inhibit-message t))
      (delete-trailing-whitespace)
      (save-buffer)))

  ;; PYTHON SETTINGS

  (setq comment-auto-fill-only-comments t
        python-indent-offset 4
        python-indent-guess-indent-offset nil)

  (auto-fill-mode 1))
" . 162144) ((marker . 92) . -1109) ((marker . 89) . -1109) ((marker . 1) . -561) 163253 nil (162144 . 169851) ("(use-package python
  :ensure nil
  :init
  (add-hook 'python-mode-hook 'my-python-hooks)
  (add-hook 'inferior-python-mode-hook 'my-inferior-python-mode-hooks)

  ;; https://stackoverflow.com/a/6141681
  ;; (add-hook 'python-mode-hook
  ;;           (lambda ()
  ;;             (add-hook 'write-contents-functions (lambda() (elpy-black-fix-code)) nil t)))

  :config
  (font-lock-add-keywords 'python-mode
                          '((\"cls\" . font-lock-keyword-face)))
  (setq python-shell-interpreter \"python3\")
  (setq python-shell-interpreter-args \"-i -q\")

  (setq python-shell-completion-native-enable nil)

  (defun my-python-hooks ()
    (interactive)
    (flymake-mode -1)
    (electric-operator-mode +1)
    (flycheck-mode +1)
    (rainbow-delimiters-mode +1)
    (highlight-operators-mode +1)
    (evil-swap-keys-swap-double-single-quotes)
    (evil-swap-keys-swap-underscore-dash)
    (evil-swap-keys-swap-colon-semicolon)
    (smartparens-strict-mode +1)
    (my-company-idle-one-prefix-one-quiet)
    (highlight-numbers-mode +1)
    (yafolding-mode +1)
    (apheleia-mode +1)
    (elpy-enable +1))

  (defun my-inferior-python-mode-hooks ()
    (interactive)
    (electric-operator-mode +1)
    (flycheck-mode +1)
    (rainbow-delimiters-mode +1)
    (highlight-operators-mode +1)
    (evil-swap-keys-swap-double-single-quotes)
    (evil-swap-keys-swap-underscore-dash)
    (evil-swap-keys-swap-colon-semicolon)
    (smartparens-strict-mode +1)
    (my-company-idle-one-prefix-one-quiet)
    (company-mode +1)
    (highlight-numbers-mode +1))

  (add-to-list 'company-backends 'company-jedi)

  ;; (setq-local company-backends '(company-jedi
  ;;                                company-dabbrev-code
  ;;                                company-files
  ;;                                (company-semantic
  ;;                                 company-capf
  ;;                                 company-keywords
  ;;                                 company-dabbrev
  ;;                                 company-shell)))

  (defun my/olivetti-narrow ()
    (interactive)
    (olivetti-mode +1)
    (setq-local olivetti-body-width 60))

  (defun my-python-hooks ()
    (interactive)
    (subword-mode 1)
    (electric-operator-mode +1)
    (company-mode)
    (flycheck-mode +1)
    (rainbow-delimiters-mode +1)
    (highlight-operators-mode +1)
    (evil-swap-keys-swap-double-single-quotes)
    (evil-swap-keys-swap-underscore-dash)
    (evil-swap-keys-swap-colon-semicolon)
    (smartparens-strict-mode +1)
    (my-company-idle-one-prefix-one-quiet)
    (highlight-numbers-mode +1)
    (elpy-enable +1)
    )

  ;; PYTHON KEYS ;;
  (general-define-key
   :keymaps 'inferior-python-mode-map
   \"C-j\" 'elpy-shell-switch-to-buffer
   \"M-e\" 'counsel-shell-history
   \"C-c j\" 'my/evil-shell-bottom
   \"C-c u\" 'universal-argument
   \"C-u\" 'comint-kill-input
   \"C-l\" 'comint-clear-buffer
   \"C-;\" 'my-elpy-switch-to-buffer
   \"C-n\" 'comint-next-input
   \"C-p\" 'comint-previous-input)

  (general-unbind 'inferior-python-mode-map
    :with 'elpy-shell-switch-to-buffer
    [remap save-buffer]
    [remap my-save-buffer]
    [remap comint-next-prompt])

  (general-unbind 'python-mode-map
    :with 'elpy-folding-toggle-at-point
    [remap hs-toggle-hiding])

  (general-unbind 'python-mode-map
    :with 'my-python-shebang
    [remap my-bash-shebang])

  (general-define-key
   :keymaps 'python-mode-map
   \"<escape>\" 'my-save-buffer-only
   \"<M-return>\" 'apheleia-format-buffer
   \"M-a\" 'python-nav-backward-statement
   \"M-e\" 'python-nav-forward-statement
   \"C-S-p\" 'python-nav-backward-sexp
   \"C-S-n\" 'python-nav-forward-sexp
   \"C-x o\" 'my/olivetti-narrow
   \"C-x m\" 'elpy-multiedit-python-symbol-at-point
   \"C-x M\" 'elpy-multiedit-stop
   \"C-c g\" 'my/counsel-ag-python
   \"M-m\" 'flycheck-first-error
   \"C-c p\" 'my/python-make-print
   \"C-c f\" 'my/python-make-fstring
   \"C-c DEL\" 'my/erase-python-file
   \"C-c =\" 'my/erase-python-file-and-yank
   )

  (general-unbind 'python-mode-map
    :with 'yafolding-hide-all
    [remap evil-close-folds])

  (general-nmap
    :keymaps 'python-mode-map
    \"<escape>\" 'save-buffer)

  (general-nvmap
    :keymaps 'python-mode-map
    \"zi\" 'yafolding-show-all
    \"M-a\" 'python-nav-backward-statement
    \"M-e\" 'python-nav-forward-statement
    \"C-S-p\" 'python-nav-backward-sexp
    \"C-S-n\" 'python-nav-forward-sexp
    \"C-ç\" 'my/python-newline-beg
    \"<backspace>\" 'org-edit-src-exit
    \"<C-return>\" 'my-quickrun
    \"<tab>\" 'elpy-folding-toggle-at-point
    \"<tab>\" 'elpy-folding-toggle-at-point
    \"RET\" 'hydra-python-mode/body
    \"zm\" 'evil-close-folds
    \"gh\" 'outline-up-heading
    \"gl\" 'outline-next-heading
    \"zl\" 'outline-show-subtree
    \"<\" 'python-indent-shift-left
    \">\" 'python-indent-shift-right
    \"gj\" 'outline-forward-same-level
    \"gk\" 'outline-backward-same-level)

  (defun my/python-newline-beg ()
    (interactive)
    (evil-insert-state)
    (newline)
    (beginning-of-line))

  (defun my/python-colon-newline ()
    (interactive)
    (end-of-line)
    (insert \":\")
    (newline-and-indent))

  (general-imap
    :keymaps 'python-mode-map
    \"C-=\"   'my/python-colon-newline
    \"C-ç\" 'my/python-newline-beg
    \"<C-return>\" 'my-quickrun
    \"C-h\" 'python-indent-dedent-line-backspace
    \"M-a\" 'python-nav-backward-statement
    \"M-e\" 'python-nav-forward-statement
    \"C-S-p\" 'python-nav-backward-sexp
    \"C-S-n\" 'python-nav-forward-sexp
    )

  ;; PYTHON FUNCTIONS;;

  (defun execute-python-program ()
    (interactive)
    (my/window-to-register-91)
    (my/quiet-save-buffer)
    (defvar foo-execute-python)
    (setq foo-execute-python (concat \"python3 \" (buffer-file-name)))
    (other-window 1)
    (switch-to-buffer-other-window \"*Async Shell Command*\")
    (shell-command foo))

  (defun my/execute-python-program-shell-simple  ()
    (interactive)
    (my/window-to-register-91)
    (my/quiet-save-buffer)
    (defvar foo-execute-python-simple)
    (setq foo-execute-python-simple (concat \"python3 \" (prelude-copy-file-name-to-clipboard)))
    (shell-command foo))

  (defun my/ex-python-run ()
    (interactive)
    (evil-ex \"w !python3\"))

  (defun my/execute-python-program-shell ()
    (interactive)
    (progn
      (my/quiet-save-buffer)
      (prelude-copy-file-name-to-clipboard)
      (shell)
      (sit-for 0.3)
      (insert \"source ~/scripts/cline_scripts/smallprompt.sh\")
      (comint-send-input)
      (insert \"python3 \")
      (yank)
      (comint-send-input)
      (evil-insert-state)
      (sit-for 0.3)
      (comint-clear-buffer)
      (company-mode -1)))

  (general-unbind 'python-mode-map
    :with 'elpy-doc
    [remap helpful-at-point])

  (defun my/run-python-external ()
    (interactive)
    (progn
      (prelude-copy-file-name-to-clipboard)
      (start-process-shell-command
       \"call term\" nil
       \"~/scripts/i3_scripts/show_term_right\")))

  (defun my/erase-python-file ()
    (interactive)
    (erase-buffer)
    (insert \"#!/usr/bin/env python3\\n\\n\")
    (evil-insert-state)
    (flycheck-clear))

  (defun my/erase-python-file-and-yank ()
    (interactive)
    (erase-buffer)
    (insert \"#!/usr/bin/env python3\\n\\n\")
    (yank))

  (defun my/kill-python-file ()
    (interactive)
    (kill-region (point-min) (point-max))
    (insert \"#!/usr/bin/env python3\\n\\n\")
    (evil-insert-state)
    (flycheck-clear))

  (defun my/python-save-buffer ()
    (interactive)
    (evil-ex-nohighlight)
    (let ((inhibit-message t))
      (delete-trailing-whitespace)
      (save-buffer)))

  ;; PYTHON SETTINGS

  (setq comment-auto-fill-only-comments t
        python-indent-offset 4
        python-indent-guess-indent-offset nil)

  (auto-fill-mode 1))
" . 162144) ((marker . 92) . -16) ((marker . 89) . -16) 162160 (t 24239 49886 623465 460000) nil (47311 . 47935) ("(use-package org-pomodoro
  :after org
  :config
  (setq org-pomodoro-offset 1
        org-pomodoro-length (* 25 org-pomodoro-offset)
        org-pomodoro-long-break-length (* 20 org-pomodoro-offset)
        org-pomodoro-short-break-length (* 5 org-pomodoro-offset)
        org-pomodoro-long-break-frequency 4
        org-pomodoro-ask-upon-killing t
        org-pomodoro-manual-break nil
        org-pomodoro-keep-killed-pomodoro-time t
        org-pomodoro-time-format \"%.2m\"
        org-pomodoro-short-break-format \"SHORT: %s\"
        org-pomodoro-long-break-format \"LONG: %s\"
        org-pomodoro-format \"P: %s\"
        ))
" . 47311) ((marker . 47304) . -310) ((marker . 92) . -21) ((marker . 89) . -21) 47332 (t 24239 49551 490308 995000) nil (109173 . 110219) ("(use-package super-save
  ;; :disabled
  :config

  ;; (setq super-save-exclude '(\"\\\\.pdf\" \"\\\\.py\" \"+new-snippet+\"))
  ;; (setq-default super-save-exclude '(\"\\\\.pdf\" \"\\\\.py\" \"+new-snippet+\"))

  (setq super-save-exclude '(\"pdf\" \"\\\\.pdf\" \"+new-snippet+\"))
  (setq-default super-save-exclude '(\"pdf\" \"\\\\.pdf\" \"+new-snippet+\"))

  (setq auto-save-default nil
        super-save-idle-duration 5
        super-save-auto-save-when-idle nil
        auto-save-file-name-transforms `((\".*\" \"~/emacs-profiles/my-emacs/var/temp\" t)))

  (setq super-save-hook-triggers '(mouse-leave-buffer-hook focus-out-hook))

  (setq super-save-triggers
        '(quickrun
          quit-window
          last-buffer
          windmove-up
          windmove-down
          windmove-left
          windmove-right
          switch-to-buffer
          delete-window
          eyebrowse-close-window-config
          eyebrowse-create-window-config
          eyebrowse-next-window-config
          eyebrowse-prev-window-config))

  (auto-save-mode -1)
  (super-save-mode +1))
" . 109173) 109191 (t 24239 48745 936643 88000) nil (43343 . 43344) nil (nil rear-nonsticky nil 43351 . 43352) (nil fontified nil 43343 . 43352) (43343 . 43352) 43346 ("nil" . 43343) ((marker . 110083) . -3) ((marker . 181430) . -2) 43346 (t 24239 48192 444073 533000) nil (47304 . 47930) ("(use-package org-pomodoro
  :after org
  :config
  (setq org-pomodoro-offset 1
        org-pomodoro-length (* 25 org-pomodoro-offset)
        org-pomodoro-long-break-length (* 20 org-pomodoro-offset)
        org-pomodoro-short-break-length (* 5 org-pomodoro-offset)
        org-pomodoro-long-break-frequency 4
        org-pomodoro-ask-upon-killing nil
        org-pomodoro-manual-break nil
        org-pomodoro-keep-killed-pomodoro-time t
        org-pomodoro-time-format \"%.2m\"
        org-pomodoro-short-break-format \"SHORT: %s\"
        org-pomodoro-long-break-format \"LONG: %s\"
        org-pomodoro-format \"P: %s\"
        ))
" . 47304) ((marker) . -20) ((marker) . -20) 47324 (t 24239 47488 465742 64000) nil (149464 . 150064) ("(use-package flycheck
  :ensure t
  :config

  (general-define-key
   :keymaps 'flycheck-mode-map
   :states '(normal visual insert)
   \"ç\" 'flycheck-display-error-at-point)

  (setq flycheck-mode-line nil
        flycheck-gcc-warnings nil
        flycheck-clang-warnings nil
        flycheck-display-errors-delay 0.5
        flycheck-idle-change-delay 0.3
        flycheck-clang-pedantic t
        flycheck-gcc-pedantic t
        flycheck-check-syntax-automatically '(save idle-change idle-buffer-switch new-line mode-enabled)
        flycheck-sh-shellcheck-executable \"/usr/local/bin/shellcheck\"))
" . 149464) 150064 (t 24239 47483 548169 116000) nil (149464 . 150064) ("(use-package flycheck
  :ensure t
  :config

  (general-define-key
   :keymaps 'flycheck-mode-map
   :states '(normal visual insert)
   \"ç\" 'flycheck-display-error-at-point)

  (setq flycheck-mode-line nil
        flycheck-gcc-warnings nil
        flycheck-clang-warnings nil
        flycheck-display-errors-delay 0.5
        flycheck-idle-change-delay 0.3
        flycheck-clang-pedantic t
        flycheck-gcc-pedantic t
        flycheck-check-syntax-automatically '(save idle-change new-line mode-enabled)
        flycheck-sh-shellcheck-executable \"/usr/local/bin/shellcheck\"))
" . 149464) 150045 (t 24239 47466 76615 336000) nil (149464 . 150045) ("(use-package flycheck
  :ensure t
  :config

  (general-define-key
   :keymaps 'flycheck-mode-map
   :states '(normal visual insert)
   \"ç\" 'flycheck-display-error-at-point)

  (setq flycheck-mode-line nil
        flycheck-gcc-warnings nil
        flycheck-clang-warnings nil
        flycheck-display-errors-delay 0.5
        flycheck-idle-change-delay 0.3
        flycheck-clang-pedantic t
        flycheck-gcc-pedantic t
        flycheck-check-syntax-automatically '(save mode-enabled)
        flycheck-sh-shellcheck-executable \"/usr/local/bin/shellcheck\"))
" . 149464) 150024 (t 24239 47451 642776 630000) nil (149464 . 150024) ("(use-package flycheck
  :ensure t
  :config

  (general-define-key
   :keymaps 'flycheck-mode-map
   :states '(normal visual insert)
   \"ç\" 'flycheck-display-error-at-point)

  (setq flycheck-mode-line nil
        flycheck-gcc-warnings nil
        flycheck-clang-warnings nil
        flycheck-display-errors-delay 0.5
        flycheck-idle-change-delay 0.5
        flycheck-clang-pedantic t
        flycheck-gcc-pedantic t
        flycheck-check-syntax-automatically '(save mode-enabled)
        flycheck-sh-shellcheck-executable \"/usr/local/bin/shellcheck\"))
" . 149464) ((marker . 110083) . -474) 149480 (t 24239 46645 24770 680000) nil (149464 . 150024) ("(use-package flycheck
  :ensure t
  :config

  (general-define-key
   :keymaps 'flycheck-mode-map
   :states '(normal visual insert)
   \"ç\" 'flycheck-display-error-at-point)

  (setq flycheck-mode-line nil
        flycheck-gcc-warnings nil
        flycheck-clang-warnings nil
        flycheck-display-errors-delay 0.5
        flycheck-idle-change-delay 0.5
        flycheck-clang-pedantic t
        flycheck-gcc-pedantic t
        flycheck-check-syntax-automatically '(save idle-change mode-enabled)
        flycheck-sh-shellcheck-executable \"/usr/local/bin/shellcheck\"))
" . 149464) 149481 (t 24239 46393 489056 804000) nil (162113 . 169798) ("(use-package python
  :ensure nil
  :init
  (add-hook 'python-mode-hook 'my-python-hooks)
  (add-hook 'inferior-python-mode-hook 'my-inferior-python-mode-hooks)

  ;; https://stackoverflow.com/a/6141681
  ;; (add-hook 'python-mode-hook
  ;;           (lambda ()
  ;;             (add-hook 'write-contents-functions (lambda() (elpy-black-fix-code)) nil t)))

  :config
  (font-lock-add-keywords 'python-mode
                          '((\"cls\" . font-lock-keyword-face)))
  (setq python-shell-interpreter \"python3\")
  (setq python-shell-interpreter-args \"-i -q\")

  (setq python-shell-completion-native-enable nil)

  (defun my-python-hooks ()
    (interactive)
    (flymake-mode -1)
    (electric-operator-mode +1)
    (flycheck-mode +1)
    (rainbow-delimiters-mode +1)
    (highlight-operators-mode +1)
    (evil-swap-keys-swap-double-single-quotes)
    (evil-swap-keys-swap-underscore-dash)
    (evil-swap-keys-swap-colon-semicolon)
    (smartparens-strict-mode +1)
    (my-company-idle-one-prefix-one-quiet)
    (highlight-numbers-mode +1)
    (yafolding-mode +1)
    (apheleia-mode +1)
    (elpy-enable +1))

  (defun my-inferior-python-mode-hooks ()
    (interactive)
    (electric-operator-mode +1)
    (flycheck-mode +1)
    (rainbow-delimiters-mode +1)
    (highlight-operators-mode +1)
    (evil-swap-keys-swap-double-single-quotes)
    (evil-swap-keys-swap-underscore-dash)
    (evil-swap-keys-swap-colon-semicolon)
    (smartparens-strict-mode +1)
    (my-company-idle-one-prefix-one-quiet)
    (company-mode +1)
    (highlight-numbers-mode +1))

  (add-to-list 'company-backends 'company-jedi)

  ;; (setq-local company-backends '(company-jedi
  ;;                                company-dabbrev-code
  ;;                                company-files
  ;;                                (company-semantic
  ;;                                 company-capf
  ;;                                 company-keywords
  ;;                                 company-dabbrev
  ;;                                 company-shell)))

  (defun my/olivetti-narrow ()
    (interactive)
    (olivetti-mode +1)
    (setq-local olivetti-body-width 60))

  (defun my-python-hooks ()
    (interactive)
    (line-numbers)
    (subword-mode 1)
    (electric-operator-mode +1)
    (company-mode)
    (flycheck-mode +1)
    (rainbow-delimiters-mode +1)
    (highlight-operators-mode +1)
    (evil-swap-keys-swap-double-single-quotes)
    (evil-swap-keys-swap-underscore-dash)
    (evil-swap-keys-swap-colon-semicolon)
    (smartparens-strict-mode +1)
    (my-company-idle-one-prefix-one-quiet)
    (highlight-numbers-mode +1)
    (elpy-enable +1)
    )

  ;; PYTHON KEYS ;;
  (general-define-key
   :keymaps 'inferior-python-mode-map
   \"C-j\" 'elpy-shell-switch-to-buffer
   \"M-e\" 'counsel-shell-history
   \"C-c j\" 'my/evil-shell-bottom
   \"C-c u\" 'universal-argument
   \"C-u\" 'comint-kill-input
   \"C-l\" 'comint-clear-buffer
   \"C-;\" 'my-elpy-switch-to-buffer
   \"C-n\" 'comint-next-input
   \"C-p\" 'comint-previous-input)

  (general-unbind 'inferior-python-mode-map
    :with 'elpy-shell-switch-to-buffer
    [remap save-buffer]
    [remap my-save-buffer]
    [remap comint-next-prompt])

  (general-unbind 'python-mode-map
    :with 'elpy-folding-toggle-at-point
    [remap hs-toggle-hiding])

  (general-unbind 'python-mode-map
    :with 'my-python-shebang
    [remap my-bash-shebang])

  (general-define-key
   :keymaps 'python-mode-map
   \"<escape>\" 'my-save-buffer-only
   \"<M-return>\" 'apheleia-format-buffer
   \"M-a\" 'python-nav-backward-statement
   \"M-e\" 'python-nav-forward-statement
   \"C-S-p\" 'python-nav-backward-sexp
   \"C-S-n\" 'python-nav-forward-sexp
   \"C-x o\" 'my/olivetti-narrow
   \"C-x m\" 'elpy-multiedit-python-symbol-at-point
   \"C-x M\" 'elpy-multiedit-stop
   \"C-c g\" 'my/counsel-ag-python
   \"M-m\" 'flycheck-first-error
   \"C-c p\" 'my/python-make-print
   \"C-c f\" 'my/python-make-fstring
   \"C-c DEL\" 'my/erase-python-file
   \"C-c =\" 'my/erase-python-file-and-yank
   )

  (general-unbind 'python-mode-map
    :with 'yafolding-hide-all
    [remap evil-close-folds])

  (general-nmap
    :keymaps 'python-mode-map
    \"<escape>\" 'save-buffer)

  (general-nvmap
    :keymaps 'python-mode-map
    \"zi\" 'yafolding-show-all
    \"M-a\" 'python-nav-backward-statement
    \"M-e\" 'python-nav-forward-statement
    \"C-S-p\" 'python-nav-backward-sexp
    \"C-S-n\" 'python-nav-forward-sexp
    \"C-ç\" 'my/python-newline-beg
    \"<backspace>\" 'org-edit-src-exit
    \"<C-return>\" 'my-quickrun
    \"<tab>\" 'elpy-folding-toggle-at-point
    \"<tab>\" 'elpy-folding-toggle-at-point
    \"RET\" 'hydra-python-mode/body
    \"zm\" 'evil-close-folds
    \"gh\" 'outline-up-heading
    \"gl\" 'outline-next-heading
    \"zl\" 'outline-show-subtree
    \"<\" 'python-indent-shift-left
    \">\" 'python-indent-shift-right
    \"gj\" 'outline-forward-same-level
    \"gk\" 'outline-backward-same-level)

  (defun my/python-newline-beg ()
    (interactive)
    (evil-insert-state)
    (newline)
    (beginning-of-line))

  (defun my/python-colon-newline ()
    (interactive)
    (end-of-line)
    (insert \":\")
    (newline-and-indent))

  (general-imap
    :keymaps 'python-mode-map
    \"C-=\"   'my/python-colon-newline
    \"C-ç\" 'my/python-newline-beg
    \"<C-return>\" 'my-quickrun
    \"C-h\" 'python-indent-dedent-line-backspace
    \"M-a\" 'python-nav-backward-statement
    \"M-e\" 'python-nav-forward-statement
    \"C-S-p\" 'python-nav-backward-sexp
    \"C-S-n\" 'python-nav-forward-sexp
    )

  ;; PYTHON FUNCTIONS;;

  (defun execute-python-program ()
    (interactive)
    (my/window-to-register-91)
    (my/quiet-save-buffer)
    (defvar foo-execute-python)
    (setq foo-execute-python (concat \"python3 \" (buffer-file-name)))
    (other-window 1)
    (switch-to-buffer-other-window \"*Async Shell Command*\")
    (shell-command foo))

  (defun my/execute-python-program-shell-simple  ()
    (interactive)
    (my/window-to-register-91)
    (my/quiet-save-buffer)
    (defvar foo-execute-python-simple)
    (setq foo-execute-python-simple (concat \"python3 \" (prelude-copy-file-name-to-clipboard)))
    (shell-command foo))

  (defun my/ex-python-run ()
    (interactive)
    (evil-ex \"w !python3\"))

  (defun my/execute-python-program-shell ()
    (interactive)
    (progn
      (my/quiet-save-buffer)
      (prelude-copy-file-name-to-clipboard)
      (shell)
      (sit-for 0.3)
      (insert \"source ~/scripts/cline_scripts/smallprompt.sh\")
      (comint-send-input)
      (insert \"python3 \")
      (yank)
      (comint-send-input)
      (evil-insert-state)
      (sit-for 0.3)
      (comint-clear-buffer)
      (company-mode -1)))

  (general-unbind 'python-mode-map
    :with 'elpy-doc
    [remap helpful-at-point])

  (defun my/run-python-external ()
    (interactive)
    (progn
      (prelude-copy-file-name-to-clipboard)
      (start-process-shell-command
       \"call term\" nil
       \"~/scripts/i3_scripts/show_term_right\")))

  (defun my/erase-python-file ()
    (interactive)
    (erase-buffer)
    (insert \"#!/usr/bin/env python3\\n\\n\")
    (evil-insert-state)
    (flycheck-clear))

  (defun my/erase-python-file-and-yank ()
    (interactive)
    (erase-buffer)
    (insert \"#!/usr/bin/env python3\\n\\n\")
    (yank))

  (defun my/kill-python-file ()
    (interactive)
    (kill-region (point-min) (point-max))
    (insert \"#!/usr/bin/env python3\\n\\n\")
    (evil-insert-state)
    (flycheck-clear))

  (defun my/python-save-buffer ()
    (interactive)
    (evil-ex-nohighlight)
    (let ((inhibit-message t))
      (delete-trailing-whitespace)
      (save-buffer)))

  ;; PYTHON SETTINGS

  (setq comment-auto-fill-only-comments t
        python-indent-offset 4
        python-indent-guess-indent-offset nil)

  (auto-fill-mode 1))
" . 162113) 162129 (t 24239 46207 995661 841000) nil (47304 . 47932) ("(use-package org-pomodoro
  :after org
  :config
  (setq org-pomodoro-offset 0.8
        org-pomodoro-length (* 25 org-pomodoro-offset)
        org-pomodoro-long-break-length (* 20 org-pomodoro-offset)
        org-pomodoro-short-break-length (* 5 org-pomodoro-offset)
        org-pomodoro-long-break-frequency 4
        org-pomodoro-ask-upon-killing nil
        org-pomodoro-manual-break nil
        org-pomodoro-keep-killed-pomodoro-time t
        org-pomodoro-time-format \"%.2m\"
        org-pomodoro-short-break-format \"SHORT: %s\"
        org-pomodoro-long-break-format \"LONG: %s\"
        org-pomodoro-format \"P: %s\"
        ))
" . 47304) ((marker) . -21) ((marker) . -21) 47325 (t 24239 46165 55419 469000) nil (150084 . 150194) ("(use-package flymake
  :ensure nil
  :init
  (setq python-flymake-command '(\"~/.pyenv/shims/flake8\" \"-\")))
" . 150084) 150107 (t 24239 46155 510107 133000) nil (150084 . 150191) ("(use-package flymake
  :disabled
  :ensure nil
  :init
  (setq python-flymake-command '(\"~/.pyenv/shims/flake8\" \"-\")))
" . 150084) 150119 (t 24239 46152 721959 643000) nil (150084 . 150203) ("(use-package flymake
  :disabled
  :ensure nil
  :init
(setq python-flymake-command '(\"~/.pyenv/shims/flake8\" \"-\"))
;; (setq-default flymake-no-changes-timeout 0.5)
)
" . 150084) 150251 (t 24239 46146 536396 126000) nil (150084 . 150251) ("(use-package flymake
  :disabled
  :ensure nil
  :init
  (setq-default flymake-no-changes-timeout 0.5))
" . 150084) 150102 (t 24239 46058 146839 41000) nil (149466 . 150038) ("(use-package flycheck
  :ensure t
  :init
  (add-hook 'flycheck-mode-hook)
  :config

  (general-define-key
   :keymaps 'flycheck-mode-map
   :states '(normal visual insert)
   \"ç\" 'flycheck-display-error-at-point)

  (setq flycheck-mode-line nil
        flycheck-gcc-warnings nil
        flycheck-clang-warnings nil
        flycheck-display-errors-delay 0.5
        flycheck-idle-change-delay 0.5
        flycheck-clang-pedantic t
        flycheck-gcc-pedantic t
        flycheck-check-syntax-automatically '(save idle-change mode-enabled)
        flycheck-sh-shellcheck-executable \"/usr/local/bin/shellcheck\"))
" . 149466) 150079 (t 24239 46055 98160 657000) nil (149466 . 150079) ("(use-package flycheck
  :ensure t
  :init
  (add-hook flycheck-mode-hook)
  :config

  (general-define-key
   :keymaps 'flycheck-mode-map
   :states '(normal visual insert)
   \"ç\" 'flycheck-display-error-at-point)

  (setq flycheck-mode-line nil
        flycheck-gcc-warnings nil
        flycheck-clang-warnings nil
        flycheck-display-errors-delay 0.5
        flycheck-idle-change-delay 0.5
        flycheck-clang-pedantic t
        flycheck-gcc-pedantic t
        flycheck-check-syntax-automatically '(save idle-change mode-enabled)
        flycheck-sh-shellcheck-executable \"/usr/local/bin/shellcheck\"))
" . 149466) 150078 (t 24239 46053 524163 111000) nil (149466 . 150078) ("(use-package flycheck
  :ensure t
  :init
  
  :config

  (general-define-key
   :keymaps 'flycheck-mode-map
   :states '(normal visual insert)
   \"ç\" 'flycheck-display-error-at-point)

  (setq flycheck-mode-line nil
        flycheck-gcc-warnings nil
        flycheck-clang-warnings nil
        flycheck-display-errors-delay 0.5
        flycheck-idle-change-delay 0.5
        flycheck-clang-pedantic t
        flycheck-gcc-pedantic t
        flycheck-check-syntax-automatically '(save idle-change mode-enabled)
        flycheck-sh-shellcheck-executable \"/usr/local/bin/shellcheck\"))
" . 149466) 150049 (t 24239 46049 725460 911000) nil (149466 . 150049) ("(use-package flycheck
  :ensure t
  :config

  (general-define-key
   :keymaps 'flycheck-mode-map
   :states '(normal visual insert)
   \"ç\" 'flycheck-display-error-at-point)

  (setq flycheck-mode-line nil
        flycheck-gcc-warnings nil
        flycheck-clang-warnings nil
        flycheck-display-errors-delay 0.5
        flycheck-idle-change-delay 0.5
        flycheck-clang-pedantic t
        flycheck-gcc-pedantic t
        flycheck-check-syntax-automatically '(save idle-change mode-enabled)
        flycheck-sh-shellcheck-executable \"/usr/local/bin/shellcheck\"))
" . 149466) 149483 (t 24239 46025 531995 958000) nil (162109 . 169813) ("(use-package python
  :ensure nil
  :init
  (add-hook 'python-mode-hook 'my-python-hooks)
  (add-hook 'inferior-python-mode-hook 'my-inferior-python-mode-hooks)

  ;; https://stackoverflow.com/a/6141681
  ;; (add-hook 'python-mode-hook
  ;;           (lambda ()
  ;;             (add-hook 'write-contents-functions (lambda() (elpy-black-fix-code)) nil t)))

  :config
  (font-lock-add-keywords 'python-mode
                          '((\"cls\" . font-lock-keyword-face)))
  (setq python-shell-interpreter \"python3\")
  (setq python-shell-interpreter-args \"-i -q\")

  (setq python-shell-completion-native-enable nil)

  (defun my-python-hooks ()
    (interactive)
    (electric-operator-mode +1)
    (flycheck-mode +1)
    (rainbow-delimiters-mode +1)
    (highlight-operators-mode +1)
    (evil-swap-keys-swap-double-single-quotes)
    (evil-swap-keys-swap-underscore-dash)
    (evil-swap-keys-swap-colon-semicolon)
    (smartparens-strict-mode +1)
    (my-company-idle-one-prefix-one-quiet)
    (highlight-numbers-mode +1)
    (yafolding-mode +1)
    (apheleia-mode +1)
    (elpy-enable +1))

  (defun my-inferior-python-mode-hooks ()
    (interactive)
    (electric-operator-mode +1)
    (flycheck-mode +1)
    (rainbow-delimiters-mode +1)
    (highlight-operators-mode +1)
    (evil-swap-keys-swap-double-single-quotes)
    (evil-swap-keys-swap-underscore-dash)
    (evil-swap-keys-swap-colon-semicolon)
    (smartparens-strict-mode +1)
    (my-company-idle-one-prefix-one-quiet)
    (company-mode +1)
    (highlight-numbers-mode +1))

  (add-to-list 'company-backends 'company-jedi)

  ;; (setq-local company-backends '(company-jedi
  ;;                                company-dabbrev-code
  ;;                                company-files
  ;;                                (company-semantic
  ;;                                 company-capf
  ;;                                 company-keywords
  ;;                                 company-dabbrev
  ;;                                 company-shell)))

  (defun my/olivetti-narrow ()
    (interactive)
    (olivetti-mode +1)
    (setq-local olivetti-body-width 60))

  (defun my-python-hooks ()
    (interactive)
    (line-numbers)
    (subword-mode 1)
    (electric-operator-mode +1)
    (company-mode)
    (flycheck-mode +1)
    (rainbow-delimiters-mode +1)
    (highlight-operators-mode +1)
    (evil-swap-keys-swap-double-single-quotes)
    (evil-swap-keys-swap-underscore-dash)
    (evil-swap-keys-swap-colon-semicolon)
    (smartparens-strict-mode +1)
    (my-company-idle-one-prefix-one-quiet)
    (highlight-numbers-mode +1)
    (elpy-enable +1)
    )

  ;; PYTHON KEYS ;;
  (general-define-key
   :keymaps 'inferior-python-mode-map
   \"C-j\" 'elpy-shell-switch-to-buffer
   \"M-e\" 'counsel-shell-history
   \"C-c j\" 'my/evil-shell-bottom
   \"C-c u\" 'universal-argument
   \"C-u\" 'comint-kill-input
   \"C-l\" 'comint-clear-buffer
   \"C-;\" 'my-elpy-switch-to-buffer
   \"C-n\" 'comint-next-input
   \"C-p\" 'comint-previous-input)

  (general-unbind 'inferior-python-mode-map
    :with 'elpy-shell-switch-to-buffer
    [remap save-buffer]
    [remap my-save-buffer]
    [remap comint-next-prompt])

  (general-unbind 'python-mode-map
    :with 'elpy-folding-toggle-at-point
    [remap hs-toggle-hiding])

  (general-unbind 'python-mode-map
    :with 'my-python-shebang
    [remap my-bash-shebang])

  (general-define-key
   :keymaps 'python-mode-map
   \"<escape>\" 'my-save-buffer-only
   \"<M-return>\" 'apheleia-format-buffer
   \"M-a\" 'python-nav-backward-statement
   \"M-e\" 'python-nav-forward-statement
   \"C-S-p\" 'python-nav-backward-sexp
   \"C-S-n\" 'python-nav-forward-sexp
   \"C-x o\" 'my/olivetti-narrow
   \"C-x m\" 'elpy-multiedit-python-symbol-at-point
   \"C-x M\" 'elpy-multiedit-stop
   \"C-c g\" 'my/counsel-ag-python
   \"M-m\" 'flycheck-first-error
   \"C-c p\" 'my/python-make-print
   \"C-c f\" 'my/python-make-fstring
   \"C-c DEL\" 'my/erase-python-file
   \"C-c =\" 'my/erase-python-file-and-yank
   )

  (general-unbind 'python-mode-map
    :with 'yafolding-hide-all
    [remap evil-close-folds])

  (general-nmap
    :keymaps 'python-mode-map
    \"<escape>\" 'save-buffer)

  (general-nvmap
    :keymaps 'python-mode-map
    \"zi\" 'yafolding-show-all
    \"M-a\" 'python-nav-backward-statement
    \"M-e\" 'python-nav-forward-statement
    \"C-S-p\" 'python-nav-backward-sexp
    \"C-S-n\" 'python-nav-forward-sexp
    \"C-ç\" 'my/python-newline-beg
    \"<backspace>\" 'org-edit-src-exit
    \"<C-return>\" 'my-quickrun
    \"<tab>\" 'elpy-folding-toggle-at-point
    \"<tab>\" 'elpy-folding-toggle-at-point
    \"RET\" 'hydra-python-mode/body
    \"zm\" 'evil-close-folds
    \"gh\" 'outline-up-heading
    \"gl\" 'outline-next-heading
    \"zl\" 'outline-show-subtree
    \"<\" 'python-indent-shift-left
    \">\" 'python-indent-shift-right
    \"gj\" 'outline-forward-same-level
    \"gk\" 'outline-backward-same-level)

  (defun my/python-newline-beg ()
    (interactive)
    (evil-insert-state)
    (newline)
    (beginning-of-line))

  (defun my/python-colon-newline ()
    (interactive)
    (end-of-line)
    (insert \":\")
    (newline-and-indent))

  (general-imap
    :keymaps 'python-mode-map
    \"C-=\"   'my/python-colon-newline
    \"C-ç\" 'my/python-newline-beg
    \"<C-return>\" 'my-quickrun
    \"C-h\" 'python-indent-dedent-line-backspace
    \"M-a\" 'python-nav-backward-statement
    \"M-e\" 'python-nav-forward-statement
    \"C-S-p\" 'python-nav-backward-sexp
    \"C-S-n\" 'python-nav-forward-sexp
    )

  ;; PYTHON FUNCTIONS;;

  (defun execute-python-program ()
    (interactive)
    (my/window-to-register-91)
    (my/quiet-save-buffer)
    (defvar foo-execute-python)
    (setq foo-execute-python (concat \"python3 \" (buffer-file-name)))
    (other-window 1)
    (switch-to-buffer-other-window \"*Async Shell Command*\")
    (shell-command foo))

  (defun my/execute-python-program-shell-simple  ()
    (interactive)
    (my/window-to-register-91)
    (my/quiet-save-buffer)
    (defvar foo-execute-python-simple)
    (setq foo-execute-python-simple (concat \"python3 \" (prelude-copy-file-name-to-clipboard)))
    (shell-command foo))

  (defun my/ex-python-run ()
    (interactive)
    (evil-ex \"w !python3\"))

  (defun my/execute-python-program-shell ()
    (interactive)
    (progn
      (my/quiet-save-buffer)
      (prelude-copy-file-name-to-clipboard)
      (shell)
      (sit-for 0.3)
      (insert \"source ~/scripts/cline_scripts/smallprompt.sh\")
      (comint-send-input)
      (insert \"python3 \")
      (yank)
      (comint-send-input)
      (evil-insert-state)
      (sit-for 0.3)
      (comint-clear-buffer)
      (company-mode -1)))

  (general-unbind 'python-mode-map
    :with 'elpy-doc
    [remap helpful-at-point])

  (defun my/run-python-external ()
    (interactive)
    (progn
      (prelude-copy-file-name-to-clipboard)
      (start-process-shell-command
       \"call term\" nil
       \"~/scripts/i3_scripts/show_term_right\")))

  (defun my/erase-python-file ()
    (interactive)
    (erase-buffer)
    (insert \"#!/usr/bin/env python3\\n\\n\")
    (evil-insert-state)
    (flycheck-clear))

  (defun my/erase-python-file-and-yank ()
    (interactive)
    (erase-buffer)
    (insert \"#!/usr/bin/env python3\\n\\n\")
    (yank))

  (defun my/kill-python-file ()
    (interactive)
    (kill-region (point-min) (point-max))
    (insert \"#!/usr/bin/env python3\\n\\n\")
    (evil-insert-state)
    (flycheck-clear))

  (defun my/python-save-buffer ()
    (interactive)
    (evil-ex-nohighlight)
    (let ((inhibit-message t))
      (delete-trailing-whitespace)
      (save-buffer)))

  ;; PYTHON SETTINGS

  (setq comment-auto-fill-only-comments t
        python-indent-offset 4
        python-indent-guess-indent-offset nil)

  (auto-fill-mode 1))
" . 162109) 162125 (t 24239 45888 86537 580000) nil (162109 . 169791) ("(use-package python
  :ensure nil
  :init
  (add-hook 'python-mode-hook 'my-python-hooks)
  (add-hook 'inferior-python-mode-hook 'my-inferior-python-mode-hooks)

  ;; https://stackoverflow.com/a/6141681
  ;; (add-hook 'python-mode-hook
  ;;           (lambda ()
  ;;             (add-hook 'write-contents-functions (lambda() (elpy-black-fix-code)) nil t)))

  :config
  (font-lock-add-keywords 'python-mode
                          '((\"cls\" . font-lock-keyword-face)))
  (setq python-shell-interpreter \"python3\")
  (setq python-shell-interpreter-args \"-i -q\")

  (setq python-shell-completion-native-enable nil)

  (defun my-python-hooks ()
    (interactive)
    (electric-operator-mode +1)
    (flycheck-mode +1)
    (rainbow-delimiters-mode +1)
    (highlight-operators-mode +1)
    (evil-swap-keys-swap-double-single-quotes)
    (evil-swap-keys-swap-underscore-dash)
    (evil-swap-keys-swap-colon-semicolon)
    (smartparens-strict-mode +1)
    (my-company-idle-one-prefix-one-quiet)
    (highlight-numbers-mode +1)
    (yafolding-mode +1)
    (apheleia-mode +1)
    (elpy-enable +1))

  (defun my-inferior-python-mode-hooks ()
    (interactive)
    (electric-operator-mode +1)
    (flycheck-mode +1)
    (rainbow-delimiters-mode +1)
    (highlight-operators-mode +1)
    (evil-swap-keys-swap-double-single-quotes)
    (evil-swap-keys-swap-underscore-dash)
    (evil-swap-keys-swap-colon-semicolon)
    (smartparens-strict-mode +1)
    (my-company-idle-one-prefix-one-quiet)
(company-mode +1)
    (highlight-numbers-mode +1))

  (add-to-list 'company-backends 'company-jedi)

  ;; (setq-local company-backends '(company-jedi
  ;;                                company-dabbrev-code
  ;;                                company-files
  ;;                                (company-semantic
  ;;                                 company-capf
  ;;                                 company-keywords
  ;;                                 company-dabbrev
  ;;                                 company-shell)))

  (defun my/olivetti-narrow ()
    (interactive)
    (olivetti-mode +1)
    (setq-local olivetti-body-width 60))

  (defun my-python-hooks ()
    (interactive)
    (line-numbers)
    (subword-mode 1)
    (electric-operator-mode +1)
    (company-mode)
    (flycheck-mode +1)
    (rainbow-delimiters-mode +1)
    (highlight-operators-mode +1)
    (evil-swap-keys-swap-double-single-quotes)
    (evil-swap-keys-swap-underscore-dash)
    (evil-swap-keys-swap-colon-semicolon)
    (smartparens-strict-mode +1)
    (my-company-idle-one-prefix-one-quiet)
    (highlight-numbers-mode +1)
    (elpy-enable +1)
    )

  ;; PYTHON KEYS ;;
  (general-define-key
   :keymaps 'inferior-python-mode-map
   \"C-j\" 'elpy-shell-switch-to-buffer
   \"M-e\" 'counsel-shell-history
   \"C-c j\" 'my/evil-shell-bottom
   \"C-c u\" 'universal-argument
   \"C-u\" 'comint-kill-input
   \"C-l\" 'comint-clear-buffer
   \"C-;\" 'my-elpy-switch-to-buffer
   \"C-n\" 'comint-next-input
   \"C-p\" 'comint-previous-input)

  (general-unbind 'inferior-python-mode-map
    :with 'elpy-shell-switch-to-buffer
    [remap save-buffer]
    [remap my-save-buffer]
    [remap comint-next-prompt])

  (general-unbind 'python-mode-map
    :with 'elpy-folding-toggle-at-point
    [remap hs-toggle-hiding])

  (general-unbind 'python-mode-map
    :with 'my-python-shebang
    [remap my-bash-shebang])

  (general-define-key
   :keymaps 'python-mode-map
   \"<escape>\" 'my-save-buffer-only
   \"<M-return>\" 'apheleia-format-buffer
   \"M-a\" 'python-nav-backward-statement
   \"M-e\" 'python-nav-forward-statement
   \"C-S-p\" 'python-nav-backward-sexp
   \"C-S-n\" 'python-nav-forward-sexp
   \"C-x o\" 'my/olivetti-narrow
   \"C-x m\" 'elpy-multiedit-python-symbol-at-point
   \"C-x M\" 'elpy-multiedit-stop
   \"C-c g\" 'my/counsel-ag-python
   \"M-m\" 'flycheck-first-error
   \"C-c p\" 'my/python-make-print
   \"C-c f\" 'my/python-make-fstring
   \"C-c DEL\" 'my/erase-python-file
   \"C-c =\" 'my/erase-python-file-and-yank
   )

  (general-unbind 'python-mode-map
    :with 'yafolding-hide-all
    [remap evil-close-folds])

  (general-nmap
    :keymaps 'python-mode-map
    \"<escape>\" 'save-buffer)

  (general-nvmap
    :keymaps 'python-mode-map
    \"zi\" 'yafolding-show-all
    \"M-a\" 'python-nav-backward-statement
    \"M-e\" 'python-nav-forward-statement
    \"C-S-p\" 'python-nav-backward-sexp
    \"C-S-n\" 'python-nav-forward-sexp
    \"C-ç\" 'my/python-newline-beg
    \"<backspace>\" 'org-edit-src-exit
    \"<C-return>\" 'my-quickrun
    \"<tab>\" 'elpy-folding-toggle-at-point
    \"<tab>\" 'elpy-folding-toggle-at-point
    \"RET\" 'hydra-python-mode/body
    \"zm\" 'evil-close-folds
    \"gh\" 'outline-up-heading
    \"gl\" 'outline-next-heading
    \"zl\" 'outline-show-subtree
    \"<\" 'python-indent-shift-left
    \">\" 'python-indent-shift-right
    \"gj\" 'outline-forward-same-level
    \"gk\" 'outline-backward-same-level)

  (defun my/python-newline-beg ()
    (interactive)
    (evil-insert-state)
    (newline)
    (beginning-of-line))

  (defun my/python-colon-newline ()
    (interactive)
    (end-of-line)
    (insert \":\")
    (newline-and-indent))

  (general-imap
    :keymaps 'python-mode-map
    \"C-=\"   'my/python-colon-newline
    \"C-ç\" 'my/python-newline-beg
    \"<C-return>\" 'my-quickrun
    \"C-h\" 'python-indent-dedent-line-backspace
    \"M-a\" 'python-nav-backward-statement
    \"M-e\" 'python-nav-forward-statement
    \"C-S-p\" 'python-nav-backward-sexp
    \"C-S-n\" 'python-nav-forward-sexp
    )

  ;; PYTHON FUNCTIONS;;

  (defun execute-python-program ()
    (interactive)
    (my/window-to-register-91)
    (my/quiet-save-buffer)
    (defvar foo-execute-python)
    (setq foo-execute-python (concat \"python3 \" (buffer-file-name)))
    (other-window 1)
    (switch-to-buffer-other-window \"*Async Shell Command*\")
    (shell-command foo))

  (defun my/execute-python-program-shell-simple  ()
    (interactive)
    (my/window-to-register-91)
    (my/quiet-save-buffer)
    (defvar foo-execute-python-simple)
    (setq foo-execute-python-simple (concat \"python3 \" (prelude-copy-file-name-to-clipboard)))
    (shell-command foo))

  (defun my/ex-python-run ()
    (interactive)
    (evil-ex \"w !python3\"))

  (defun my/execute-python-program-shell ()
    (interactive)
    (progn
      (my/quiet-save-buffer)
      (prelude-copy-file-name-to-clipboard)
      (shell)
      (sit-for 0.3)
      (insert \"source ~/scripts/cline_scripts/smallprompt.sh\")
      (comint-send-input)
      (insert \"python3 \")
      (yank)
      (comint-send-input)
      (evil-insert-state)
      (sit-for 0.3)
      (comint-clear-buffer)
      (company-mode -1)))

  (general-unbind 'python-mode-map
    :with 'elpy-doc
    [remap helpful-at-point])

  (defun my/run-python-external ()
    (interactive)
    (progn
      (prelude-copy-file-name-to-clipboard)
      (start-process-shell-command
       \"call term\" nil
       \"~/scripts/i3_scripts/show_term_right\")))

  (defun my/erase-python-file ()
    (interactive)
    (erase-buffer)
    (insert \"#!/usr/bin/env python3\\n\\n\")
    (evil-insert-state)
    (flycheck-clear))

  (defun my/erase-python-file-and-yank ()
    (interactive)
    (erase-buffer)
    (insert \"#!/usr/bin/env python3\\n\\n\")
    (yank))

  (defun my/kill-python-file ()
    (interactive)
    (kill-region (point-min) (point-max))
    (insert \"#!/usr/bin/env python3\\n\\n\")
    (evil-insert-state)
    (flycheck-clear))

  (defun my/python-save-buffer ()
    (interactive)
    (evil-ex-nohighlight)
    (let ((inhibit-message t))
      (delete-trailing-whitespace)
      (save-buffer)))

  ;; PYTHON SETTINGS

  (setq comment-auto-fill-only-comments t
        python-indent-offset 4
        python-indent-guess-indent-offset nil)

  (auto-fill-mode 1))
" . 162109) ((marker) . -1495) ((marker) . -1495) ((marker) . -368) 163604 (t 24239 45885 980533 307000) nil (162109 . 169787) ("(use-package python
  :ensure nil
  :init
  (add-hook 'python-mode-hook 'my-python-hooks)
  (add-hook 'inferior-python-mode-hook 'my-inferior-python-mode-hooks)

  ;; https://stackoverflow.com/a/6141681
  ;; (add-hook 'python-mode-hook
  ;;           (lambda ()
  ;;             (add-hook 'write-contents-functions (lambda() (elpy-black-fix-code)) nil t)))

  :config
  (font-lock-add-keywords 'python-mode
                          '((\"cls\" . font-lock-keyword-face)))
  (setq python-shell-interpreter \"python3\")
  (setq python-shell-interpreter-args \"-i -q\")

  (setq python-shell-completion-native-enable nil)

  (defun my-python-hooks ()
    (interactive)
    (electric-operator-mode +1)
    (flycheck-mode +1)
    (rainbow-delimiters-mode +1)
    (highlight-operators-mode +1)
    (evil-swap-keys-swap-double-single-quotes)
    (evil-swap-keys-swap-underscore-dash)
    (evil-swap-keys-swap-colon-semicolon)
    (smartparens-strict-mode +1)
    (my-company-idle-one-prefix-one-quiet)
    (highlight-numbers-mode +1)
    (yafolding-mode +1)
    (apheleia-mode +1)
    (elpy-enable +1))

  (defun my-inferior-python-mode-hooks ()
    (interactive)
    (electric-operator-mode +1)
    (flycheck-mode +1)
    (rainbow-delimiters-mode +1)
    (highlight-operators-mode +1)
    (evil-swap-keys-swap-double-single-quotes)
    (evil-swap-keys-swap-underscore-dash)
    (evil-swap-keys-swap-colon-semicolon)
    (smartparens-strict-mode +1)
    (my-company-idle-one-prefix-one-quiet)
    (highlight-numbers-mode +1))

  (add-to-list 'company-backends 'company-jedi)

  ;; (setq-local company-backends '(company-jedi
  ;;                                company-dabbrev-code
  ;;                                company-files
  ;;                                (company-semantic
  ;;                                 company-capf
  ;;                                 company-keywords
  ;;                                 company-dabbrev
  ;;                                 company-shell)))

  (defun my/olivetti-narrow ()
    (interactive)
    (olivetti-mode +1)
    (setq-local olivetti-body-width 60))

  (defun my-python-hooks ()
    (interactive)
    (line-numbers)
    (subword-mode 1)
    (electric-operator-mode +1)
    (company-mode)
    (flycheck-mode +1)
    (rainbow-delimiters-mode +1)
    (highlight-operators-mode +1)
    (evil-swap-keys-swap-double-single-quotes)
    (evil-swap-keys-swap-underscore-dash)
    (evil-swap-keys-swap-colon-semicolon)
    (smartparens-strict-mode +1)
    (my-company-idle-one-prefix-one-quiet)
    (highlight-numbers-mode +1)
    (elpy-enable +1)
    )

  ;; PYTHON KEYS ;;
  (general-define-key
   :keymaps 'inferior-python-mode-map
   \"C-j\" 'elpy-shell-switch-to-buffer
   \"M-e\" 'counsel-shell-history
   \"C-c j\" 'my/evil-shell-bottom
   \"C-c u\" 'universal-argument
   \"C-u\" 'comint-kill-input
   \"C-l\" 'comint-clear-buffer
   \"C-;\" 'my-elpy-switch-to-buffer
   \"C-n\" 'comint-next-input
   \"C-p\" 'comint-previous-input)

  (general-unbind 'inferior-python-mode-map
    :with 'elpy-shell-switch-to-buffer
    [remap save-buffer]
    [remap my-save-buffer]
    [remap comint-next-prompt])

  (general-unbind 'python-mode-map
    :with 'elpy-folding-toggle-at-point
    [remap hs-toggle-hiding])

  (general-unbind 'python-mode-map
    :with 'my-python-shebang
    [remap my-bash-shebang])

  (general-define-key
   :keymaps 'python-mode-map
   \"<escape>\" 'my-save-buffer-only
   \"<M-return>\" 'apheleia-format-buffer
   \"M-a\" 'python-nav-backward-statement
   \"M-e\" 'python-nav-forward-statement
   \"C-S-p\" 'python-nav-backward-sexp
   \"C-S-n\" 'python-nav-forward-sexp
   \"C-x o\" 'my/olivetti-narrow
   \"C-x m\" 'elpy-multiedit-python-symbol-at-point
   \"C-x M\" 'elpy-multiedit-stop
   \"C-c g\" 'my/counsel-ag-python
   \"M-m\" 'flycheck-first-error
   \"C-c p\" 'my/python-make-print
   \"C-c f\" 'my/python-make-fstring
   \"C-c DEL\" 'my/erase-python-file
   \"C-c =\" 'my/erase-python-file-and-yank
   )

  (general-unbind 'python-mode-map
    :with 'yafolding-hide-all
    [remap evil-close-folds])

  (general-nmap
    :keymaps 'python-mode-map
    \"<escape>\" 'save-buffer)

  (general-nvmap
    :keymaps 'python-mode-map
    \"zi\" 'yafolding-show-all
    \"M-a\" 'python-nav-backward-statement
    \"M-e\" 'python-nav-forward-statement
    \"C-S-p\" 'python-nav-backward-sexp
    \"C-S-n\" 'python-nav-forward-sexp
    \"C-ç\" 'my/python-newline-beg
    \"<backspace>\" 'org-edit-src-exit
    \"<C-return>\" 'my-quickrun
    \"<tab>\" 'elpy-folding-toggle-at-point
    \"<tab>\" 'elpy-folding-toggle-at-point
    \"RET\" 'hydra-python-mode/body
    \"zm\" 'evil-close-folds
    \"gh\" 'outline-up-heading
    \"gl\" 'outline-next-heading
    \"zl\" 'outline-show-subtree
    \"<\" 'python-indent-shift-left
    \">\" 'python-indent-shift-right
    \"gj\" 'outline-forward-same-level
    \"gk\" 'outline-backward-same-level)

  (defun my/python-newline-beg ()
    (interactive)
    (evil-insert-state)
    (newline)
    (beginning-of-line))

  (defun my/python-colon-newline ()
    (interactive)
    (end-of-line)
    (insert \":\")
    (newline-and-indent))

  (general-imap
    :keymaps 'python-mode-map
    \"C-=\"   'my/python-colon-newline
    \"C-ç\" 'my/python-newline-beg
    \"<C-return>\" 'my-quickrun
    \"C-h\" 'python-indent-dedent-line-backspace
    \"M-a\" 'python-nav-backward-statement
    \"M-e\" 'python-nav-forward-statement
    \"C-S-p\" 'python-nav-backward-sexp
    \"C-S-n\" 'python-nav-forward-sexp
    )

  ;; PYTHON FUNCTIONS;;

  (defun execute-python-program ()
    (interactive)
    (my/window-to-register-91)
    (my/quiet-save-buffer)
    (defvar foo-execute-python)
    (setq foo-execute-python (concat \"python3 \" (buffer-file-name)))
    (other-window 1)
    (switch-to-buffer-other-window \"*Async Shell Command*\")
    (shell-command foo))

  (defun my/execute-python-program-shell-simple  ()
    (interactive)
    (my/window-to-register-91)
    (my/quiet-save-buffer)
    (defvar foo-execute-python-simple)
    (setq foo-execute-python-simple (concat \"python3 \" (prelude-copy-file-name-to-clipboard)))
    (shell-command foo))

  (defun my/ex-python-run ()
    (interactive)
    (evil-ex \"w !python3\"))

  (defun my/execute-python-program-shell ()
    (interactive)
    (progn
      (my/quiet-save-buffer)
      (prelude-copy-file-name-to-clipboard)
      (shell)
      (sit-for 0.3)
      (insert \"source ~/scripts/cline_scripts/smallprompt.sh\")
      (comint-send-input)
      (insert \"python3 \")
      (yank)
      (comint-send-input)
      (evil-insert-state)
      (sit-for 0.3)
      (comint-clear-buffer)
      (company-mode -1)))

  (general-unbind 'python-mode-map
    :with 'elpy-doc
    [remap helpful-at-point])

  (defun my/run-python-external ()
    (interactive)
    (progn
      (prelude-copy-file-name-to-clipboard)
      (start-process-shell-command
       \"call term\" nil
       \"~/scripts/i3_scripts/show_term_right\")))

  (defun my/erase-python-file ()
    (interactive)
    (erase-buffer)
    (insert \"#!/usr/bin/env python3\\n\\n\")
    (evil-insert-state)
    (flycheck-clear))

  (defun my/erase-python-file-and-yank ()
    (interactive)
    (erase-buffer)
    (insert \"#!/usr/bin/env python3\\n\\n\")
    (yank))

  (defun my/kill-python-file ()
    (interactive)
    (kill-region (point-min) (point-max))
    (insert \"#!/usr/bin/env python3\\n\\n\")
    (evil-insert-state)
    (flycheck-clear))

  (defun my/python-save-buffer ()
    (interactive)
    (evil-ex-nohighlight)
    (let ((inhibit-message t))
      (delete-trailing-whitespace)
      (save-buffer)))

  ;; PYTHON SETTINGS

  (setq comment-auto-fill-only-comments t
        python-indent-offset 4
        python-indent-guess-indent-offset nil)

  (auto-fill-mode 1))
" . 162109) ((marker . 110083) . -1088) 163331 (t 24239 45613 932450 259000) nil (162109 . 169769) ("(use-package python
  :ensure nil
  :init
  (add-hook 'python-mode-hook 'my-python-hooks)
  (add-hook 'inferior-python-mode-hook 'my-inferior-python-mode-hooks)

  ;; https://stackoverflow.com/a/6141681
  ;; (add-hook 'python-mode-hook
  ;;           (lambda ()
  ;;             (add-hook 'write-contents-functions (lambda() (elpy-black-fix-code)) nil t)))

  :config
  (font-lock-add-keywords 'python-mode
                          '((\"cls\" . font-lock-keyword-face)))
  (setq python-shell-interpreter \"python3\")
  (setq python-shell-interpreter-args \"-i -q\")

  (setq python-shell-completion-native-enable nil)

  (defun my-python-hooks ()
    (interactive)
    (electric-operator-mode +1)
    (flycheck-mode +1)
    (rainbow-delimiters-mode +1)
    (highlight-operators-mode +1)
    (evil-swap-keys-swap-double-single-quotes)
    (evil-swap-keys-swap-underscore-dash)
    (evil-swap-keys-swap-colon-semicolon)
    (smartparens-strict-mode +1)
    (my-company-idle-one-prefix-one-quiet)
    (highlight-numbers-mode +1)
    (yafolding-mode +1)
    (apheleia-mode +1)
        (elpy-enable +1)


)

  (defun my-inferior-python-mode-hooks ()
    (interactive)
    (electric-operator-mode +1)
    (flycheck-mode +1)
    (rainbow-delimiters-mode +1)
    (highlight-operators-mode +1)
    (evil-swap-keys-swap-double-single-quotes)
    (evil-swap-keys-swap-underscore-dash)
    (evil-swap-keys-swap-colon-semicolon)
    (smartparens-strict-mode +1)
    (my-company-idle-one-prefix-one-quiet)
    (highlight-numbers-mode +1))

  (add-to-list 'company-backends 'company-jedi)

  ;; (setq-local company-backends '(company-jedi
  ;;                                company-dabbrev-code
  ;;                                company-files
  ;;                                (company-semantic
  ;;                                 company-capf
  ;;                                 company-keywords
  ;;                                 company-dabbrev
  ;;                                 company-shell)))

  (defun my/olivetti-narrow ()
    (interactive)
    (olivetti-mode +1)
    (setq-local olivetti-body-width 60))

  (defun my-python-hooks ()
    (interactive)
    (line-numbers)
    (subword-mode 1)
    (electric-operator-mode +1)
    (company-mode)
    (flycheck-mode +1)
    (rainbow-delimiters-mode +1)
    (highlight-operators-mode +1)
    (evil-swap-keys-swap-double-single-quotes)
    (evil-swap-keys-swap-underscore-dash)
    (evil-swap-keys-swap-colon-semicolon)
    (smartparens-strict-mode +1)
    (my-company-idle-one-prefix-one-quiet)
    (highlight-numbers-mode +1)
    (elpy-enable +1)
    )

  ;; PYTHON KEYS ;;
  (general-define-key
   :keymaps 'inferior-python-mode-map
   \"C-j\" 'elpy-shell-switch-to-buffer
   \"M-e\" 'counsel-shell-history
   \"C-c j\" 'my/evil-shell-bottom
   \"C-c u\" 'universal-argument
   \"C-u\" 'comint-kill-input
   \"C-l\" 'comint-clear-buffer
   \"C-;\" 'my-elpy-switch-to-buffer
   \"C-n\" 'comint-next-input
   \"C-p\" 'comint-previous-input)

  (general-unbind 'inferior-python-mode-map
    :with 'elpy-shell-switch-to-buffer
    [remap save-buffer]
    [remap my-save-buffer]
    [remap comint-next-prompt])

  (general-unbind 'python-mode-map
    :with 'elpy-folding-toggle-at-point
    [remap hs-toggle-hiding])

  (general-unbind 'python-mode-map
    :with 'my-python-shebang
    [remap my-bash-shebang])

  (general-define-key
   :keymaps 'python-mode-map
   \"<escape>\" 'my-save-buffer-only
   \"<M-return>\" 'apheleia-format-buffer
   \"M-a\" 'python-nav-backward-statement
   \"M-e\" 'python-nav-forward-statement
   \"C-S-p\" 'python-nav-backward-sexp
   \"C-S-n\" 'python-nav-forward-sexp
   \"C-x o\" 'my/olivetti-narrow
   \"C-x m\" 'elpy-multiedit-python-symbol-at-point
   \"C-x M\" 'elpy-multiedit-stop
   \"C-c g\" 'my/counsel-ag-python
   \"M-m\" 'flycheck-first-error
   \"C-c p\" 'my/python-make-print
   \"C-c f\" 'my/python-make-fstring
   \"C-c DEL\" 'my/erase-python-file
   \"C-c =\" 'my/erase-python-file-and-yank
   )

  (general-unbind 'python-mode-map
    :with 'yafolding-hide-all
    [remap evil-close-folds])

  (general-nmap
    :keymaps 'python-mode-map
    \"<escape>\" 'save-buffer)

  (general-nvmap
    :keymaps 'python-mode-map
    \"zi\" 'yafolding-show-all
    \"M-a\" 'python-nav-backward-statement
    \"M-e\" 'python-nav-forward-statement
    \"C-S-p\" 'python-nav-backward-sexp
    \"C-S-n\" 'python-nav-forward-sexp
    \"C-ç\" 'my/python-newline-beg
    \"<backspace>\" 'org-edit-src-exit
    \"<C-return>\" 'my-quickrun
    \"<tab>\" 'elpy-folding-toggle-at-point
    \"<tab>\" 'elpy-folding-toggle-at-point
    \"RET\" 'hydra-python-mode/body
    \"zm\" 'evil-close-folds
    \"gh\" 'outline-up-heading
    \"gl\" 'outline-next-heading
    \"zl\" 'outline-show-subtree
    \"<\" 'python-indent-shift-left
    \">\" 'python-indent-shift-right
    \"gj\" 'outline-forward-same-level
    \"gk\" 'outline-backward-same-level)

  (defun my/python-newline-beg ()
    (interactive)
    (evil-insert-state)
    (newline)
    (beginning-of-line))

  (defun my/python-colon-newline ()
    (interactive)
    (end-of-line)
    (insert \":\")
    (newline-and-indent))

  (general-imap
    :keymaps 'python-mode-map
    \"C-=\"   'my/python-colon-newline
    \"C-ç\" 'my/python-newline-beg
    \"<C-return>\" 'my-quickrun
    \"C-h\" 'python-indent-dedent-line-backspace
    \"M-a\" 'python-nav-backward-statement
    \"M-e\" 'python-nav-forward-statement
    \"C-S-p\" 'python-nav-backward-sexp
    \"C-S-n\" 'python-nav-forward-sexp
    )

  ;; PYTHON FUNCTIONS;;

  (defun execute-python-program ()
    (interactive)
    (my/window-to-register-91)
    (my/quiet-save-buffer)
    (defvar foo-execute-python)
    (setq foo-execute-python (concat \"python3 \" (buffer-file-name)))
    (other-window 1)
    (switch-to-buffer-other-window \"*Async Shell Command*\")
    (shell-command foo))

  (defun my/execute-python-program-shell-simple  ()
    (interactive)
    (my/window-to-register-91)
    (my/quiet-save-buffer)
    (defvar foo-execute-python-simple)
    (setq foo-execute-python-simple (concat \"python3 \" (prelude-copy-file-name-to-clipboard)))
    (shell-command foo))

  (defun my/ex-python-run ()
    (interactive)
    (evil-ex \"w !python3\"))

  (defun my/execute-python-program-shell ()
    (interactive)
    (progn
      (my/quiet-save-buffer)
      (prelude-copy-file-name-to-clipboard)
      (shell)
      (sit-for 0.3)
      (insert \"source ~/scripts/cline_scripts/smallprompt.sh\")
      (comint-send-input)
      (insert \"python3 \")
      (yank)
      (comint-send-input)
      (evil-insert-state)
      (sit-for 0.3)
      (comint-clear-buffer)
      (company-mode -1)))

  (general-unbind 'python-mode-map
    :with 'elpy-doc
    [remap helpful-at-point])

  (defun my/run-python-external ()
    (interactive)
    (progn
      (prelude-copy-file-name-to-clipboard)
      (start-process-shell-command
       \"call term\" nil
       \"~/scripts/i3_scripts/show_term_right\")))

  (defun my/erase-python-file ()
    (interactive)
    (erase-buffer)
    (insert \"#!/usr/bin/env python3\\n\\n\")
    (evil-insert-state)
    (flycheck-clear))

  (defun my/erase-python-file-and-yank ()
    (interactive)
    (erase-buffer)
    (insert \"#!/usr/bin/env python3\\n\\n\")
    (yank))

  (defun my/kill-python-file ()
    (interactive)
    (kill-region (point-min) (point-max))
    (insert \"#!/usr/bin/env python3\\n\\n\")
    (evil-insert-state)
    (flycheck-clear))

  (defun my/python-save-buffer ()
    (interactive)
    (evil-ex-nohighlight)
    (let ((inhibit-message t))
      (delete-trailing-whitespace)
      (save-buffer)))

  ;; PYTHON SETTINGS

  (setq comment-auto-fill-only-comments t
        python-indent-offset 4
        python-indent-guess-indent-offset nil)

  (auto-fill-mode 1))
" . 162109) 163200 nil (nil rear-nonsticky nil 163201 . 163202) (nil fontified nil 163181 . 163202) (163181 . 163202) 163195 ("(elpy-mode +1)" . 163181) 163195 nil (163195 . 163197) (t 24239 45435 180246 218000) nil (162109 . 169767) ("(use-package python
  :ensure nil
  :init
  (add-hook 'python-mode-hook 'my-python-hooks)
  (add-hook 'inferior-python-mode-hook 'my-inferior-python-mode-hooks)

  ;; https://stackoverflow.com/a/6141681
  ;; (add-hook 'python-mode-hook
  ;;           (lambda ()
  ;;             (add-hook 'write-contents-functions (lambda() (elpy-black-fix-code)) nil t)))

  :config
  (font-lock-add-keywords 'python-mode
                          '((\"cls\" . font-lock-keyword-face)))
  (setq python-shell-interpreter \"python3\")
  (setq python-shell-interpreter-args \"-i -q\")

  (setq python-shell-completion-native-enable nil)

  (defun my-python-hooks ()
    (interactive)
    (electric-operator-mode +1)
    (flycheck-mode +1)
    (rainbow-delimiters-mode +1)
    (highlight-operators-mode +1)
    (evil-swap-keys-swap-double-single-quotes)
    (evil-swap-keys-swap-underscore-dash)
    (evil-swap-keys-swap-colon-semicolon)
    (smartparens-strict-mode +1)
    (my-company-idle-one-prefix-one-quiet)
    (highlight-numbers-mode +1)
    (yafolding-mode +1)
    (apheleia-mode +1)
    (elpy-mode +1))

  (defun my-inferior-python-mode-hooks ()
    (interactive)
    (electric-operator-mode +1)
    (flycheck-mode +1)
    (rainbow-delimiters-mode +1)
    (highlight-operators-mode +1)
    (evil-swap-keys-swap-double-single-quotes)
    (evil-swap-keys-swap-underscore-dash)
    (evil-swap-keys-swap-colon-semicolon)
    (smartparens-strict-mode +1)
    (my-company-idle-one-prefix-one-quiet)
    (highlight-numbers-mode +1))

  (add-to-list 'company-backends 'company-jedi)

  ;; (setq-local company-backends '(company-jedi
  ;;                                company-dabbrev-code
  ;;                                company-files
  ;;                                (company-semantic
  ;;                                 company-capf
  ;;                                 company-keywords
  ;;                                 company-dabbrev
  ;;                                 company-shell)))

  (defun my/olivetti-narrow ()
    (interactive)
    (olivetti-mode +1)
    (setq-local olivetti-body-width 60))

  (defun my-python-hooks ()
    (interactive)
    (line-numbers)
    (subword-mode 1)
    (electric-operator-mode +1)
    (company-mode)
    (flycheck-mode +1)
    (rainbow-delimiters-mode +1)
    (highlight-operators-mode +1)
    (evil-swap-keys-swap-double-single-quotes)
    (evil-swap-keys-swap-underscore-dash)
    (evil-swap-keys-swap-colon-semicolon)
    (smartparens-strict-mode +1)
    (my-company-idle-one-prefix-one-quiet)
    (highlight-numbers-mode +1)
    (elpy-enable +1)
    )

  ;; PYTHON KEYS ;;
  (general-define-key
   :keymaps 'inferior-python-mode-map
   \"C-j\" 'elpy-shell-switch-to-buffer
   \"M-e\" 'counsel-shell-history
   \"C-c j\" 'my/evil-shell-bottom
   \"C-c u\" 'universal-argument
   \"C-u\" 'comint-kill-input
   \"C-l\" 'comint-clear-buffer
   \"C-;\" 'my-elpy-switch-to-buffer
   \"C-n\" 'comint-next-input
   \"C-p\" 'comint-previous-input)

  (general-unbind 'inferior-python-mode-map
    :with 'elpy-shell-switch-to-buffer
    [remap save-buffer]
    [remap my-save-buffer]
    [remap comint-next-prompt])

  (general-unbind 'python-mode-map
    :with 'elpy-folding-toggle-at-point
    [remap hs-toggle-hiding])

  (general-unbind 'python-mode-map
    :with 'my-python-shebang
    [remap my-bash-shebang])

  (general-define-key
   :keymaps 'python-mode-map
   \"<escape>\" 'my-save-buffer-only
   \"<M-return>\" 'apheleia-format-buffer
   \"M-a\" 'python-nav-backward-statement
   \"M-e\" 'python-nav-forward-statement
   \"C-S-p\" 'python-nav-backward-sexp
   \"C-S-n\" 'python-nav-forward-sexp
   \"C-x o\" 'my/olivetti-narrow
   \"C-x m\" 'elpy-multiedit-python-symbol-at-point
   \"C-x M\" 'elpy-multiedit-stop
   \"C-c g\" 'my/counsel-ag-python
   \"M-m\" 'flycheck-first-error
   \"C-c p\" 'my/python-make-print
   \"C-c f\" 'my/python-make-fstring
   \"C-c DEL\" 'my/erase-python-file
   \"C-c =\" 'my/erase-python-file-and-yank
   )

  (general-unbind 'python-mode-map
    :with 'yafolding-hide-all
    [remap evil-close-folds])

  (general-nmap
    :keymaps 'python-mode-map
    \"<escape>\" 'save-buffer)

  (general-nvmap
    :keymaps 'python-mode-map
    \"zi\" 'yafolding-show-all
    \"M-a\" 'python-nav-backward-statement
    \"M-e\" 'python-nav-forward-statement
    \"C-S-p\" 'python-nav-backward-sexp
    \"C-S-n\" 'python-nav-forward-sexp
    \"C-ç\" 'my/python-newline-beg
    \"<backspace>\" 'org-edit-src-exit
    \"<C-return>\" 'my-quickrun
    \"<tab>\" 'elpy-folding-toggle-at-point
    \"<tab>\" 'elpy-folding-toggle-at-point
    \"RET\" 'hydra-python-mode/body
    \"zm\" 'evil-close-folds
    \"gh\" 'outline-up-heading
    \"gl\" 'outline-next-heading
    \"zl\" 'outline-show-subtree
    \"<\" 'python-indent-shift-left
    \">\" 'python-indent-shift-right
    \"gj\" 'outline-forward-same-level
    \"gk\" 'outline-backward-same-level)

  (defun my/python-newline-beg ()
    (interactive)
    (evil-insert-state)
    (newline)
    (beginning-of-line))

  (defun my/python-colon-newline ()
    (interactive)
    (end-of-line)
    (insert \":\")
    (newline-and-indent))

  (general-imap
    :keymaps 'python-mode-map
    \"C-=\"   'my/python-colon-newline
    \"C-ç\" 'my/python-newline-beg
    \"<C-return>\" 'my-quickrun
    \"C-h\" 'python-indent-dedent-line-backspace
    \"M-a\" 'python-nav-backward-statement
    \"M-e\" 'python-nav-forward-statement
    \"C-S-p\" 'python-nav-backward-sexp
    \"C-S-n\" 'python-nav-forward-sexp
    )

  ;; PYTHON FUNCTIONS;;

  (defun execute-python-program ()
    (interactive)
    (my/window-to-register-91)
    (my/quiet-save-buffer)
    (defvar foo-execute-python)
    (setq foo-execute-python (concat \"python3 \" (buffer-file-name)))
    (other-window 1)
    (switch-to-buffer-other-window \"*Async Shell Command*\")
    (shell-command foo))

  (defun my/execute-python-program-shell-simple  ()
    (interactive)
    (my/window-to-register-91)
    (my/quiet-save-buffer)
    (defvar foo-execute-python-simple)
    (setq foo-execute-python-simple (concat \"python3 \" (prelude-copy-file-name-to-clipboard)))
    (shell-command foo))

  (defun my/ex-python-run ()
    (interactive)
    (evil-ex \"w !python3\"))

  (defun my/execute-python-program-shell ()
    (interactive)
    (progn
      (my/quiet-save-buffer)
      (prelude-copy-file-name-to-clipboard)
      (shell)
      (sit-for 0.3)
      (insert \"source ~/scripts/cline_scripts/smallprompt.sh\")
      (comint-send-input)
      (insert \"python3 \")
      (yank)
      (comint-send-input)
      (evil-insert-state)
      (sit-for 0.3)
      (comint-clear-buffer)
      (company-mode -1)))

  (general-unbind 'python-mode-map
    :with 'elpy-doc
    [remap helpful-at-point])

  (defun my/run-python-external ()
    (interactive)
    (progn
      (prelude-copy-file-name-to-clipboard)
      (start-process-shell-command
       \"call term\" nil
       \"~/scripts/i3_scripts/show_term_right\")))

  (defun my/erase-python-file ()
    (interactive)
    (erase-buffer)
    (insert \"#!/usr/bin/env python3\\n\\n\")
    (evil-insert-state)
    (flycheck-clear))

  (defun my/erase-python-file-and-yank ()
    (interactive)
    (erase-buffer)
    (insert \"#!/usr/bin/env python3\\n\\n\")
    (yank))

  (defun my/kill-python-file ()
    (interactive)
    (kill-region (point-min) (point-max))
    (insert \"#!/usr/bin/env python3\\n\\n\")
    (evil-insert-state)
    (flycheck-clear))

  (defun my/python-save-buffer ()
    (interactive)
    (evil-ex-nohighlight)
    (let ((inhibit-message t))
      (delete-trailing-whitespace)
      (save-buffer)))

  ;; PYTHON SETTINGS

  (setq comment-auto-fill-only-comments t
        python-indent-offset 4
        python-indent-guess-indent-offset nil)

  (auto-fill-mode 1))
" . 162109) 169767 (t 24239 45429 333661 526000) nil (162109 . 169767) ("(use-package python
  :defer t
  :ensure nil
  :init
  (add-hook 'python-mode-hook 'my-python-hooks)
  (add-hook 'inferior-python-mode-hook 'my-inferior-python-mode-hooks)

  ;; https://stackoverflow.com/a/6141681
  ;; (add-hook 'python-mode-hook
  ;;           (lambda ()
  ;;             (add-hook 'write-contents-functions (lambda() (elpy-black-fix-code)) nil t)))

  :config
  (font-lock-add-keywords 'python-mode
                          '((\"cls\" . font-lock-keyword-face)))
  (setq python-shell-interpreter \"python3\")
  (setq python-shell-interpreter-args \"-i -q\")

  (setq python-shell-completion-native-enable nil)

  (defun my-python-hooks ()
    (interactive)
    (electric-operator-mode +1)
    (flycheck-mode +1)
    (rainbow-delimiters-mode +1)
    (highlight-operators-mode +1)
    (evil-swap-keys-swap-double-single-quotes)
    (evil-swap-keys-swap-underscore-dash)
    (evil-swap-keys-swap-colon-semicolon)
    (smartparens-strict-mode +1)
    (my-company-idle-one-prefix-one-quiet)
    (highlight-numbers-mode +1)
    (yafolding-mode +1)
    (apheleia-mode +1)
    (elpy-mode +1))

  (defun my-inferior-python-mode-hooks ()
    (interactive)
    (electric-operator-mode +1)
    (flycheck-mode +1)
    (rainbow-delimiters-mode +1)
    (highlight-operators-mode +1)
    (evil-swap-keys-swap-double-single-quotes)
    (evil-swap-keys-swap-underscore-dash)
    (evil-swap-keys-swap-colon-semicolon)
    (smartparens-strict-mode +1)
    (my-company-idle-one-prefix-one-quiet)
    (highlight-numbers-mode +1))

  (add-to-list 'company-backends 'company-jedi)

  ;; (setq-local company-backends '(company-jedi
  ;;                                company-dabbrev-code
  ;;                                company-files
  ;;                                (company-semantic
  ;;                                 company-capf
  ;;                                 company-keywords
  ;;                                 company-dabbrev
  ;;                                 company-shell)))

  (defun my/olivetti-narrow ()
    (interactive)
    (olivetti-mode +1)
    (setq-local olivetti-body-width 60))

  (defun my-python-hooks ()
    (interactive)
    (line-numbers)
    (subword-mode 1)
    (electric-operator-mode +1)
    (company-mode)
    (flycheck-mode +1)
    (rainbow-delimiters-mode +1)
    (highlight-operators-mode +1)
    (evil-swap-keys-swap-double-single-quotes)
    (evil-swap-keys-swap-underscore-dash)
    (evil-swap-keys-swap-colon-semicolon)
    (smartparens-strict-mode +1)
    (my-company-idle-one-prefix-one-quiet)
    (highlight-numbers-mode +1)
    (elpy-enable +1)
    )

  ;; PYTHON KEYS ;;
  (general-define-key
   :keymaps 'inferior-python-mode-map
   \"C-j\" 'elpy-shell-switch-to-buffer
   \"M-e\" 'counsel-shell-history
   \"C-c j\" 'my/evil-shell-bottom
   \"C-c u\" 'universal-argument
   \"C-u\" 'comint-kill-input
   \"C-l\" 'comint-clear-buffer
   \"C-;\" 'my-elpy-switch-to-buffer
   \"C-n\" 'comint-next-input
   \"C-p\" 'comint-previous-input)

  (general-unbind 'inferior-python-mode-map
    :with 'elpy-shell-switch-to-buffer
    [remap save-buffer]
    [remap my-save-buffer]
    [remap comint-next-prompt])

  (general-unbind 'python-mode-map
    :with 'elpy-folding-toggle-at-point
    [remap hs-toggle-hiding])

  (general-unbind 'python-mode-map
    :with 'my-python-shebang
    [remap my-bash-shebang])

  (general-define-key
   :keymaps 'python-mode-map
   \"<escape>\" 'my-save-buffer-only
   \"<M-return>\" 'apheleia-format-buffer
   \"M-a\" 'python-nav-backward-statement
   \"M-e\" 'python-nav-forward-statement
   \"C-S-p\" 'python-nav-backward-sexp
   \"C-S-n\" 'python-nav-forward-sexp
   \"C-x o\" 'my/olivetti-narrow
   \"C-x m\" 'elpy-multiedit-python-symbol-at-point
   \"C-x M\" 'elpy-multiedit-stop
   \"C-c g\" 'my/counsel-ag-python
   \"M-m\" 'flycheck-first-error
   \"C-c p\" 'my/python-make-print
   \"C-c f\" 'my/python-make-fstring
   \"C-c DEL\" 'my/erase-python-file
   \"C-c =\" 'my/erase-python-file-and-yank
   )

  (general-unbind 'python-mode-map
    :with 'yafolding-hide-all
    [remap evil-close-folds])

  (general-nmap
    :keymaps 'python-mode-map
    \"<escape>\" 'save-buffer)

  (general-nvmap
    :keymaps 'python-mode-map
    \"zi\" 'yafolding-show-all
    \"M-a\" 'python-nav-backward-statement
    \"M-e\" 'python-nav-forward-statement
    \"C-S-p\" 'python-nav-backward-sexp
    \"C-S-n\" 'python-nav-forward-sexp
    \"C-ç\" 'my/python-newline-beg
    \"<backspace>\" 'org-edit-src-exit
    \"<C-return>\" 'my-quickrun
    \"<tab>\" 'elpy-folding-toggle-at-point
    \"<tab>\" 'elpy-folding-toggle-at-point
    \"RET\" 'hydra-python-mode/body
    \"zm\" 'evil-close-folds
    \"gh\" 'outline-up-heading
    \"gl\" 'outline-next-heading
    \"zl\" 'outline-show-subtree
    \"<\" 'python-indent-shift-left
    \">\" 'python-indent-shift-right
    \"gj\" 'outline-forward-same-level
    \"gk\" 'outline-backward-same-level)

  (defun my/python-newline-beg ()
    (interactive)
    (evil-insert-state)
    (newline)
    (beginning-of-line))

  (defun my/python-colon-newline ()
    (interactive)
    (end-of-line)
    (insert \":\")
    (newline-and-indent))

  (general-imap
    :keymaps 'python-mode-map
    \"C-=\"   'my/python-colon-newline
    \"C-ç\" 'my/python-newline-beg
    \"<C-return>\" 'my-quickrun
    \"C-h\" 'python-indent-dedent-line-backspace
    \"M-a\" 'python-nav-backward-statement
    \"M-e\" 'python-nav-forward-statement
    \"C-S-p\" 'python-nav-backward-sexp
    \"C-S-n\" 'python-nav-forward-sexp
    )

  ;; PYTHON FUNCTIONS;;

  (defun execute-python-program ()
    (interactive)
    (my/window-to-register-91)
    (my/quiet-save-buffer)
    (defvar foo-execute-python)
    (setq foo-execute-python (concat \"python3 \" (buffer-file-name)))
    (other-window 1)
    (switch-to-buffer-other-window \"*Async Shell Command*\")
    (shell-command foo))

  (defun my/execute-python-program-shell-simple  ()
    (interactive)
    (my/window-to-register-91)
    (my/quiet-save-buffer)
    (defvar foo-execute-python-simple)
    (setq foo-execute-python-simple (concat \"python3 \" (prelude-copy-file-name-to-clipboard)))
    (shell-command foo))

  (defun my/ex-python-run ()
    (interactive)
    (evil-ex \"w !python3\"))

  (defun my/execute-python-program-shell ()
    (interactive)
    (progn
      (my/quiet-save-buffer)
      (prelude-copy-file-name-to-clipboard)
      (shell)
      (sit-for 0.3)
      (insert \"source ~/scripts/cline_scripts/smallprompt.sh\")
      (comint-send-input)
      (insert \"python3 \")
      (yank)
      (comint-send-input)
      (evil-insert-state)
      (sit-for 0.3)
      (comint-clear-buffer)
      (company-mode -1)))

  (general-unbind 'python-mode-map
    :with 'elpy-doc
    [remap helpful-at-point])

  (defun my/run-python-external ()
    (interactive)
    (progn
      (prelude-copy-file-name-to-clipboard)
      (start-process-shell-command
       \"call term\" nil
       \"~/scripts/i3_scripts/show_term_right\")))

  (defun my/erase-python-file ()
    (interactive)
    (erase-buffer)
    (insert \"#!/usr/bin/env python3\\n\\n\")
    (evil-insert-state)
    (flycheck-clear))

  (defun my/erase-python-file-and-yank ()
    (interactive)
    (erase-buffer)
    (insert \"#!/usr/bin/env python3\\n\\n\")
    (yank))

  (defun my/kill-python-file ()
    (interactive)
    (kill-region (point-min) (point-max))
    (insert \"#!/usr/bin/env python3\\n\\n\")
    (evil-insert-state)
    (flycheck-clear))

  (defun my/python-save-buffer ()
    (interactive)
    (evil-ex-nohighlight)
    (let ((inhibit-message t))
      (delete-trailing-whitespace)
      (save-buffer)))

  ;; PYTHON SETTINGS

  (setq comment-auto-fill-only-comments t
        python-indent-offset 4
        python-indent-guess-indent-offset nil)

  (auto-fill-mode 1))
" . 162109) 163206 (t 24239 45357 842316 127000)) (emacs-buffer-undo-list nil ("
" . 89) ((marker . 125) . -1) ((marker . 89) . -1) ((marker . 89) . -1) ((marker . 89) . -1) ((marker . 89) . -1) ((marker . 89) . -1) ((marker . 89) . -1) ((marker . 89) . -1) ((marker . 89) . -1) ((marker . 89) . -1) (t 24239 55143 509247 380000) nil (132 . 141) ("rep" . -132) ((marker . 89) . -3) 135 (132 . 135) ("contents" . 132) nil ("
" . 126) ((marker . 125) . -1) ((marker* . 140) . 1) nil ("
" . 126) ((marker . 125) . -1) ((marker . 125) . -1) ((marker* . 140) . 1) ((marker . 125) . -1) ((marker . 125) . -1) ((marker . 125) . -1) ((marker . 125) . -1) ((marker . 125) . -1) ((marker . 125) . -1) ((marker . 125) . -1) ((marker . 125) . -1) ((marker . 125) . -1) ((marker . 125) . -1) ((marker . 125) . -1) ((marker . 125) . -1) ((marker . 125) . -1) ((marker . 125) . -1) ((marker . 125) . -1) ((marker . 125) . -1) ((marker . 125) . -1) ((marker . 125) . -1) ((marker . 125) . -1) ((marker . 125) . -1) ((marker . 125) . -1) ((marker . 125) . -1) ((marker . 125) . -1) ((marker . 125) . -1) ((marker . 125) . -1) ((marker . 125) . -1) ((marker . 125) . -1) ((marker . 125) . -1) ((marker . 125) . -1) ((marker . 125) . -1) ((marker . 125) . -1) ((marker . 125) . -1) ((marker . 125) . -1) ((marker . 125) . -1) ((marker . 125) . -1) ((marker . 125) . -1) ((marker . 125) . -1) ((marker . 125) . -1) ((marker . 125) . -1) ((marker . 125) . -1) ((marker . 125) . -1) ((marker . 125) . -1) ((marker . 125) . -1) ((marker . 125) . -1) ((marker . 125) . -1) ((marker . 125) . -1) ((marker . 125) . -1) ((marker . 125) . -1) ((marker . 125) . -1) ((marker . 92) . -1) nil (125 . 126) (t 24239 55132 989564 189000) 102 nil (nil rear-nonsticky nil 124 . 125) (nil fontified nil 102 . 125) (102 . 125) 105 nil (99 . 102) ("=" . -99) 100 (90 . 100) ("w" . -90) ((marker . 89) . -1) 91 (90 . 91) ("repeated =" . -90) ((marker . 89) . -10) 100 (" " . -100) ((marker . 89) . -1) 101 (98 . 101) ("=" . -98) 99 (94 . 99) ("t" . -94) ((marker . 89) . -1) 95 (90 . 95) ("pere" . -90) ((marker . 89) . -4) 94 (90 . 94) ("    " . -90) ((marker . 89) . -4) 94 (90 . 94) ("    " . 89) ((marker . 89) . -4) (93 . 94) (88 . 93) (t 24239 55112 800349 526000) 88 nil ("    " . 88) ((marker . 89) . -3) 91 nil ("contents.count(\"jones\")" . 92) ((marker* . 140) . 2) (t 24239 55108 213172 667000) nil (108 . 113) (107 . 108) ("\"" . -107) (107 . 108) ("\"" . -107) (107 . 109) ("\"" . -107) (107 . 108) (101 . 108) ("c" . -101) ((marker . 89) . -1) 102 (101 . 102) (92 . 101) ("con" . -92) ((marker . 89) . -3) 95 (92 . 95) (87 . 92) (t 24239 55062 484264 679000) 60 nil ("    contents = contents.split()
" . 88) ((marker . 125) . -32) ((marker* . 140) . 2) ((marker . 125) . -32) ((marker . 125) . -32) ((marker . 125) . -32) ((marker . 125) . -32) ((marker . 125) . -32) ((marker . 125) . -32) ((marker . 125) . -32) ((marker . 125) . -32) ((marker . 125) . -32) ((marker . 125) . -32) ((marker . 125) . -32) ((marker . 125) . -32) ((marker . 125) . -32) ((marker . 125) . -32) ((marker . 125) . -32) ((marker . 125) . -32) ((marker . 125) . -32) ((marker . 125) . -32) ((marker . 125) . -32) ((marker . 125) . -32) ((marker . 125) . -32) ((marker . 125) . -32) ((marker . 125) . -32) ((marker . 125) . -32) ((marker . 125) . -32) ((marker . 125) . -32) ((marker . 125) . -32) ((marker . 125) . -32) ((marker . 125) . -32) ((marker . 92) . -15) ((marker . 89) . -17) ((marker . 125) . -28) ((marker . 125) . -29) ((marker . 125) . -28) ((marker . 125) . -28) ((marker . 125) . -28) ((marker . 125) . -28) ((marker . 125) . -28) ((marker . 125) . -28) ((marker . 125) . -15) ((marker . 125) . -15) ((marker . 125) . -15) 105 (t 24239 55013 468078 783000) nil (112 . 119) ("spl" . -112) ((marker . 89) . -3) 115 (112 . 115) (103 . 112) ("con" . -103) ((marker . 89) . -3) 106 (100 . 106) ("=" . -100) 101 (100 . 101) (92 . 100) ("con" . -92) ((marker . 89) . -3) 95 (92 . 95) (87 . 92) (t 24239 55000 476018 415000) 86 nil (".split()" . 87) ((marker . 92) . -7) ((marker . 87) . -7) ((marker . 87) . -7) ((marker . 87) . -7) ((marker . 87) . -7) (t 24239 54992 562494 444000) nil (94 . 95) (")" . -94) ((marker) . -1) (")" . 95) ((marker*) . 1) ((marker) . -1) (93 . 95) ("(" . -93) (93 . 95) ("(" . -93) (88 . 94) (":" . -88) ((marker . 89) . -1) 89 (87 . 89) (t 24239 54976 619406 40000) nil (85 . 86) ("(" . -85) (85 . 87) ("(" . -85) (79 . 86) (t 24239 54969 126551 591000) nil (":" . -79) ((marker . 89) . -1) 80 (79 . 80) (t 24239 54954 73324 381000) nil (87 . 95) ("typoe" . 87) ((marker . 92) . -3) ((marker . 89) . -5) ((marker . 131) . -4) ((marker . 131) . -5) ((marker . 131) . -4) ((marker . 131) . -5) ((marker . 131) . -4) ((marker . 131) . -4) ((marker . 131) . -4) ((marker . 131) . -3) ((marker . 131) . -3) ((marker . 131) . -3) ((marker . 131) . -3) ((marker . 131) . -3) ((marker . 131) . -3) ((marker . 131) . -3) ((marker . 131) . -3) ((marker . 131) . -3) ((marker . 131) . -3) ((marker . 131) . -3) ((marker . 131) . -3) ((marker . 131) . -3) ((marker . 131) . -3) ((marker . 131) . -3) ((marker . 131) . -3) ((marker . 131) . -3) ((marker . 131) . -3) ((marker . 131) . -3) ((marker . 131) . -3) ((marker . 131) . -3) ((marker . 131) . -3) ((marker . 131) . -3) ((marker . 131) . -3) (90 . 92) ("e(" . 90) ((marker . 92) . -1) ((marker . 89) . -1) ((marker . 131) . -2) ((marker . 131) . -2) ((marker . 131) . -1) ((marker . 131) . -1) ((marker . 131) . -1) ((marker . 131) . -1) ((marker . 131) . -1) ((marker . 131) . -1) ((marker . 131) . -1) ((marker . 131) . -1) ((marker . 131) . -1) ((marker . 131) . -1) ((marker . 131) . -1) ((marker . 131) . -1) ((marker . 131) . -1) ((marker . 131) . -1) ((marker . 131) . -1) ((marker . 131) . -1) ((marker . 131) . -1) ((marker . 131) . -1) ((marker . 131) . -1) ((marker . 131) . -1) ((marker . 131) . -1) ((marker . 131) . -1) (91 . 92) ("()" . 91) ((marker* . 140) . 1) ((marker . 131) . -1) (91 . 92) ("(conte" . 91) ((marker . 92) . -1) ((marker . 89) . -6) ((marker . 131) . -2) ((marker . 131) . -2) ((marker . 131) . -3) ((marker . 131) . -2) ((marker . 131) . -3) ((marker . 131) . -4) ((marker . 131) . -3) ((marker . 131) . -4) ((marker . 131) . -4) ((marker . 131) . -4) ((marker . 131) . -4) ((marker . 131) . -5) ((marker . 131) . -4) ((marker . 131) . -5) ((marker . 131) . -6) ((marker . 131) . -5) ((marker . 131) . -6) ((marker . 131) . -1) ((marker . 131) . -1) ((marker . 131) . -1) ((marker . 131) . -1) (92 . 97) ("contents" . 92) ((marker . 92) . -7) ((marker . 89) . -7) ((marker . 131) . -7) ((marker . 131) . -7) ((marker . 131) . -7) ((marker . 131) . -7) (t 24239 54951 501349 251000) nil (92 . 100) ("conte" . -92) ((marker . 89) . -5) ((marker . 131) . -1) ((marker . 131) . -1) ((marker . 131) . -2) ((marker . 131) . -1) ((marker . 131) . -2) ((marker . 131) . -3) ((marker . 131) . -2) ((marker) . -5) ((marker . 131) . -3) ((marker . 131) . -3) ((marker . 131) . -3) ((marker . 131) . -3) ((marker . 131) . -4) ((marker . 131) . -3) ((marker . 131) . -4) ((marker . 131) . -5) ((marker . 131) . -4) ((marker) . -5) ((marker . 131) . -5) 97 (91 . 97) ("(" . -91) ((marker . 131) . -1) (91 . 93) ("(" . -91) ((marker . 131) . -1) ((marker . 131) . -1) (90 . 92) ("o" . -90) ((marker . 89) . -1) ((marker . 131) . -1) ((marker . 131) . -1) ((marker . 131) . -1) ((marker . 131) . -1) ((marker . 131) . -1) ((marker . 131) . -1) ((marker) . -1) ((marker . 131) . -1) ("e" . -91) ((marker . 89) . -1) ((marker . 131) . -1) ((marker) . -1) ((marker . 131) . -1) 92 (87 . 92) ("contents" . 87) (t 24239 54914 698635 246000) nil (", \"r\"" . 48) ((marker . 125) . -2) ((marker . 125) . -2) ((marker* . 140) . 3) ((marker . 48) . -2) ((marker . 48) . -2) ((marker . 48) . -2) ((marker . 48) . -2) ((marker . 48) . -2) ((marker . 48) . -2) ((marker . 48) . -2) ((marker . 48) . -2) ((marker . 48) . -2) ((marker . 48) . -2) ((marker . 48) . -2) ((marker . 48) . -2) ((marker . 48) . -2) ((marker . 48) . -2) ((marker . 48) . -2) ((marker . 48) . -2) ((marker . 48) . -2) ((marker . 48) . -2) ((marker . 48) . -2) ((marker . 48) . -2) ((marker . 48) . -3) ((marker . 48) . -2) ((marker . 48) . -2) ((marker . 48) . -2) ((marker . 48) . -2) ((marker . 48) . -2) ((marker . 48) . -2) ((marker . 48) . -2) ((marker . 48) . -2) ((marker . 48) . -2) ((marker . 48) . -2) ((marker . 48) . -2) ((marker . 48) . -2) ((marker . 48) . -2) ((marker . 48) . -2) ((marker . 48) . -2) ((marker . 48) . -2) ((marker . 48) . -2) ((marker . 48) . -2) ((marker . 48) . -2) ((marker . 48) . -2) ((marker . 48) . -2) ((marker . 48) . -2) ((marker . 48) . -2) ((marker . 48) . -2) ((marker . 48) . -2) ((marker . 48) . -2) ((marker . 48) . -2) ((marker . 48) . -2) ((marker . 48) . -2) ((marker . 48) . -2) ((marker . 48) . -2) ((marker . 48) . -2) ((marker . 48) . -2) ((marker . 48) . -3) ((marker . 101) . -2) ((marker . 123) . -2) ((marker . 48) . -2) ((marker . 48) . -2) ((marker . 48) . -2) ((marker . 48) . -2) ((marker . 48) . -2) ((marker . 48) . -2) ((marker . 48) . -2) ((marker . 48) . -2) ((marker . 48) . -2) ((marker . 48) . -2) ((marker . 48) . -2) ((marker . 48) . -2) ((marker . 48) . -2) ((marker . 48) . -2) ((marker . 48) . -2) ((marker . 48) . -2) ((marker . 48) . -2) ((marker . 48) . -2) ((marker . 92) . -2) ((marker . 48) . -2) ((marker . 48) . -2) ((marker . 48) . -2) ((marker . 48) . -2) (t 24239 54794 768156 969000) nil ("endoci" . 50) ((marker . 89) . -6) ((marker . 48) . -1) ((marker . 48) . -1) ((marker . 48) . -2) ((marker . 48) . -1) ((marker . 48) . -2) ((marker . 48) . -3) ((marker . 48) . -2) ((marker . 48) . -3) ((marker . 48) . -4) ((marker . 48) . -3) ((marker . 48) . -4) ((marker . 48) . -5) ((marker . 48) . -4) ((marker . 48) . -5) ((marker . 48) . -6) ((marker . 48) . -5) ((marker . 48) . -6) (50 . 56) ("endocing=" . 50) ((marker* . 140) . 9) ((marker . 89) . -8) ((marker . 48) . -8) ((marker . 48) . -8) ((marker . 48) . -8) ((marker . 48) . -8) ((marker . 48) . -8) ((marker . 48) . -8) ((marker . 48) . -8) ((marker . 48) . -8) ((marker . 48) . -8) ((marker . 48) . -8) ((marker . 48) . -8) ((marker . 48) . -8) ((marker . 48) . -8) ((marker . 48) . -8) ((marker . 48) . -8) ((marker . 48) . -8) ((marker . 48) . -8) ((marker . 48) . -8) ((marker . 48) . -8) ((marker . 48) . -8) ((marker . 48) . -8) ((marker . 48) . -8) ((marker . 48) . -8) ((marker . 48) . -8) ((marker . 48) . -8) ((marker . 48) . -8) ((marker . 48) . -8) ((marker . 48) . -8) ((marker . 48) . -8) ((marker . 48) . -8) ((marker . 48) . -8) ((marker . 48) . -8) ((marker . 48) . -8) ((marker . 48) . -8) ((marker . 48) . -8) ((marker . 48) . -8) (58 . 59) ("=\"" . 58) ((marker . 89) . -1) ((marker . 48) . -2) ((marker . 48) . -2) ((marker . 48) . -1) ((marker . 48) . -1) ((marker . 48) . -1) ((marker . 48) . -1) ((marker . 48) . -1) ((marker . 48) . -1) ((marker . 48) . -1) ((marker . 48) . -1) ((marker . 48) . -1) ((marker . 48) . -1) ((marker . 48) . -1) ((marker . 48) . -1) ((marker . 48) . -1) ((marker . 48) . -1) ((marker . 48) . -1) ((marker . 48) . -1) ((marker . 48) . -1) ((marker . 48) . -1) ((marker . 48) . -1) ((marker . 48) . -1) ((marker . 48) . -1) ((marker . 48) . -1) ((marker . 48) . -1) ((marker . 48) . -1) ((marker . 48) . -1) ((marker . 48) . -1) ((marker . 48) . -1) ((marker . 48) . -1) ((marker . 48) . -1) ((marker . 48) . -1) ((marker . 48) . -1) ((marker . 48) . -1) ((marker . 48) . -1) ((marker . 48) . -1) (59 . 60) (" " . 59) ((marker . 48) . -1) (59 . 60) ("\"" . 59) (59 . 60) ("\"\"" . 59) ((marker . 89) . -2) ((marker . 48) . -1) ((marker . 48) . -2) ((marker . 48) . -2) ((marker . 48) . -2) ((marker . 48) . -2) ((marker . 48) . -2) ((marker . 48) . -2) ((marker . 48) . -2) ((marker . 48) . -2) ((marker . 48) . -2) ((marker . 48) . -2) ((marker . 48) . -2) ((marker . 48) . -2) ((marker . 48) . -2) ((marker . 48) . -2) ((marker . 48) . -2) ((marker . 48) . -2) ((marker . 48) . -2) ((marker . 48) . -2) ((marker . 48) . -2) ((marker . 48) . -2) ((marker . 48) . -2) ((marker . 48) . -2) ((marker . 48) . -2) ((marker . 48) . -2) ((marker . 48) . -2) ((marker . 48) . -2) ((marker . 48) . -2) ((marker . 48) . -2) ((marker . 48) . -2) ((marker . 48) . -2) (59 . 60) ("\"" . 59) (59 . 60) ("\"utf_" . 59) ((marker . 48) . -5) ((marker . 48) . -5) (63 . 64) ("-8" . 63) ("," . 66) (66 . 67) (", " . 66) ((marker . 48) . -2) ((marker . 48) . -2) ((marker . 48) . -1) ((marker . 48) . -1) ((marker . 48) . -1) ((marker . 48) . -1) ((marker . 48) . -1) ((marker . 48) . -1) ((marker . 48) . -1) ((marker . 48) . -1) ((marker . 48) . -1) ((marker . 48) . -1) ((marker . 48) . -1) ((marker . 48) . -1) ((marker . 48) . -1) ((marker . 48) . -1) ((marker . 48) . -1) ((marker . 48) . -1) ((marker . 48) . -2) ((marker . 48) . -2) ((marker . 48) . -1) ((marker . 48) . -2) ((marker . 48) . -1) ((marker . 48) . -1) ((marker . 48) . -2) ((marker . 48) . -2) ((marker . 48) . -1) ((marker . 48) . -2) ((marker . 48) . -1) ((marker . 48) . -1) (nil face nil 67 . 68) (nil face highlight-operators-face 66 . 67) (nil fontified t 67 . 68) (nil fontified t 66 . 67) nil (66 . 71) nil (", \"r\"" . 50) ((marker . 92) . -5) ((marker . 89) . -5) ((marker . 123) . -4) ((marker . 48) . -5) ((marker . 48) . -5) ((marker . 48) . -5) ((marker . 48) . -5) (nil rear-nonsticky t 54 . 55) (t 24239 54792 581331 683000) nil ("," . 55) (55 . 56) (", " . 55) ((marker . 92) . -2) ((marker . 48) . -2) ((marker . 48) . -2) ((marker . 48) . -2) ((marker . 48) . -2) nil (50 . 52) nil (55 . 63) ("enco" . 55) ((marker . 92) . -4) ((marker . 89) . -4) ((marker . 48) . -4) ((marker . 48) . -4) ((marker . 48) . -4) ((marker . 48) . -4) ("ding" . 59) ((marker . 92) . -3) ((marker . 89) . -3) ((marker . 48) . -3) ((marker . 48) . -3) ((marker . 48) . -3) ((marker . 48) . -3) (t 24239 54785 355636 941000) nil (59 . 63) (55 . 59) ("endocing" . 55) ((marker* . 140) . 8) nil (", " . 50) ((marker) . -1) nil (55 . 57) ("," . -55) 56 (55 . 56) nil (nil rear-nonsticky nil 54 . 55) (nil fontified nil 50 . 55) (50 . 55) nil (", \"r\"" . 66) ((marker* . 140) . 3) ((marker . 92) . -1) ((marker . 48) . -3) ((marker . 48) . -2) ((marker . 48) . -2) ((marker . 48) . -1) ((marker . 48) . -1) ((marker . 48) . -1) ((marker . 48) . -1) ((marker . 48) . -1) ((marker . 48) . -1) ((marker . 48) . -1) ((marker . 48) . -1) ((marker . 48) . -1) ((marker . 48) . -1) ((marker . 48) . -1) ((marker . 48) . -1) ((marker . 48) . -1) ((marker . 48) . -1) ((marker . 48) . -1) ((marker . 48) . -1) ((marker . 48) . -2) ((marker . 48) . -2) ((marker . 48) . -1) ((marker . 48) . -2) ((marker . 48) . -1) ((marker . 48) . -1) ((marker . 48) . -2) ((marker . 48) . -2) ((marker . 48) . -1) ((marker . 48) . -2) ((marker . 48) . -1) ((marker . 48) . -1) ((marker . 48) . -3) (t 24239 54762 976298 264000) nil (66 . 67) nil (66 . 67) nil (66 . 69) nil ("\"r\"" . 66) ((marker* . 140) . 3) ((marker . 48) . -1) ((marker) . -3) ((marker) . -1) ((marker . 48) . -1) nil (" " . 66) ((marker . 48) . -1) ((marker . 48) . -1) ((marker) . -1) ((marker . 48) . -1) ((marker) . -1) ((marker . 48) . -1) ((marker . 48) . -1) ((marker . 48) . -1) ((marker . 48) . -1) ((marker . 48) . -1) nil ("," . 66) ((marker . 92) . -1) ((marker . 48) . -1) ((marker . 48) . -1) ((marker . 48) . -1) ((marker . 48) . -1) ((marker . 48) . -1) ((marker . 48) . -1) ((marker . 48) . -1) ((marker . 48) . -1) ((marker . 48) . -1) ((marker . 48) . -1) ((marker . 48) . -1) ((marker . 48) . -1) ((marker . 48) . -1) ((marker . 48) . -1) ((marker . 48) . -1) ((marker . 48) . -1) ((marker . 48) . -1) ((marker . 48) . -1) ((marker . 48) . -1) ((marker . 48) . -1) ((marker . 48) . -1) ((marker . 48) . -1) (t 24239 54762 976298 264000) nil (nil fontified nil 66 . 68) (nil face font-lock-string-face 66 . 68) (66 . 68) ("," . -66) 67 (66 . 67) (63 . 65) ("_" . -63) ((marker . 89) . -1) ((marker . 48) . -1) ((marker . 48) . -1) 64 (59 . 64) ("\"" . -59) (59 . 60) ("\"" . -59) ((marker . 48) . -1) (59 . 61) ("\"" . -59) (59 . 60) (" " . -59) ((marker . 48) . -1) (59 . 60) ("\"" . -59) ((marker . 48) . -1) ((marker . 48) . -1) (58 . 60) ("=" . -58) 59 (50 . 59) ("endoci" . -50) ((marker . 89) . -6) ((marker . 48) . -1) ((marker . 48) . -1) ((marker . 48) . -2) ((marker . 48) . -1) ((marker . 48) . -2) ((marker . 48) . -3) ((marker . 48) . -2) ((marker . 48) . -3) ((marker . 48) . -4) ((marker . 48) . -3) ((marker . 48) . -4) ((marker . 48) . -5) ((marker . 48) . -4) ((marker . 48) . -5) ((marker . 48) . -6) ((marker . 48) . -5) ((marker) . -6) ((marker . 48) . -6) 56 (50 . 56) (t 24239 54628 74449 425000) nil (38 . 43) ("b" . 38) (t 24239 54624 593101 109000) nil (38 . 39) ("bacon" . 38) (t 24239 54588 840976 96000) nil (101 . 102) (t 24239 54577 696823 312000) 100 nil (92 . 100) ("co" . -92) ((marker . 89) . -2) 94 (92 . 94) (apply yas--snippet-revive 86 93 #s(yas--snippet nil nil #s(yas--exit 92 nil) 26 nil nil nil nil)) (apply yas--take-care-of-redo #s(yas--snippet nil nil #s(yas--exit 92 nil) 26 nil nil nil nil)) (86 . 93) ("p" . 86) ((marker . 125) . -1) ((marker . 89) . -1) 87 nil (86 . 87) ("
" . 86) ((marker . 125) . -1) ((marker* . 140) . 1) ((marker*) . 1) ("(# comment)" . 86) ((marker* . 140) . 11) ((marker*) . 11) ((marker) . -1) ("()" . 86) ((marker* . 140) . 1) ((marker*) . 2) ((marker) . -1) ((marker*) . 1) ((marker) . -2) ("print" . 86) nil (apply yas--snippet-revive 86 93 #s(yas--snippet nil nil #s(yas--exit 92 nil) 25 nil nil nil nil)) (apply yas--take-care-of-redo #s(yas--snippet nil nil #s(yas--exit 92 nil) 25 nil nil nil nil)) (86 . 93) ("p" . 86) ((marker . 89) . -1) 87 nil (86 . 87) ("print" . 86) nil (apply yas--snippet-revive 92 101 #s(yas--snippet nil (#s(yas--field 1 94 101 nil nil nil nil #s(yas--exit 101 nil))) #s(yas--exit 101 nil) 24 nil #s(yas--field 1 94 101 nil nil nil nil #s(yas--exit 101 nil)) nil nil)) nil (apply yas--take-care-of-redo #s(yas--snippet nil (#s(yas--field 1 94 101 nil nil nil nil #s(yas--exit 101 nil))) #s(yas--exit 101 nil) 24 nil #s(yas--field 1 94 101 nil nil nil nil #s(yas--exit 101 nil)) nil nil)) (92 . 101) ("co" . 92) ((marker . 89) . -2) 94 nil (92 . 94) (apply yas--snippet-revive 86 93 #s(yas--snippet nil nil #s(yas--exit 92 nil) 23 nil nil nil nil)) (apply yas--take-care-of-redo #s(yas--snippet nil nil #s(yas--exit 92 nil) 23 nil nil nil nil)) (86 . 93) ("p" . 86) ((marker . 89) . -1) 87 nil (86 . 87) ("    " . -86) ((marker . 89) . -4) 90 (86 . 90) ("    " . 85) ((marker . 89) . -4) (89 . 90) (84 . 89) (t 24239 54566 250545 806000) 82 nil (78 . 84) (73 . 78) ("=" . -73) 74 (65 . 74) ("pass" . 65) ((marker . 125) . -4) ((marker* . 140) . 4) (t 24239 54552 105128 959000) nil (apply yas--snippet-revive 25 70 #s(yas--snippet nil (#s(yas--field 1 36 47 nil nil nil t #s(yas--field 2 48 53 nil nil nil nil #s(yas--field 3 51 52 #6 nil nil t #s(yas--field 4 58 59 nil nil nil nil #s(yas--field 0 65 69 nil nil nil nil nil))))) #s(yas--field 2 48 53 nil nil nil nil #s(yas--field 3 51 52 #5 nil nil t #s(yas--field 4 58 59 nil nil nil nil #s(yas--field 0 65 69 nil nil nil nil nil)))) #s(yas--field 3 51 52 #s(yas--field 2 48 53 nil nil nil nil #5) nil nil t #s(yas--field 4 58 59 nil nil nil nil #s(yas--field 0 65 69 nil nil nil nil nil))) #s(yas--field 4 58 59 nil nil nil nil #s(yas--field 0 65 69 nil nil nil nil nil)) #s(yas--field 0 65 69 nil nil nil nil nil)) nil 22 nil #s(yas--field 4 58 59 nil nil nil nil #s(yas--field 0 65 69 nil nil nil nil nil)) nil nil)) (69 . 70) ("mode" . 52) (51 . 52) (nil fontified nil 36 . 47) (nil face font-lock-string-face 36 . 47) (36 . 47) ("./b" . -36) ((marker . 89) . -3) 39 (36 . 39) (":" . -36) ((marker . 89) . -1) ("?" . -37) ((marker . 89) . -1) 38 (37 . 38) ("file" . 37) (36 . 37) (apply yas--take-care-of-redo #s(yas--snippet nil (#s(yas--field 1 36 47 nil nil nil t #s(yas--field 2 48 53 nil nil nil nil #s(yas--field 3 51 52 #6 nil nil t #s(yas--field 4 58 59 nil nil nil nil #s(yas--field 0 65 69 nil nil nil nil nil))))) #s(yas--field 2 48 53 nil nil nil nil #s(yas--field 3 51 52 #5 nil nil t #s(yas--field 4 58 59 nil nil nil nil #s(yas--field 0 65 69 nil nil nil nil nil)))) #s(yas--field 3 51 52 #s(yas--field 2 48 53 nil nil nil nil #5) nil nil t #s(yas--field 4 58 59 nil nil nil nil #s(yas--field 0 65 69 nil nil nil nil nil))) #s(yas--field 4 58 59 nil nil nil nil #s(yas--field 0 65 69 nil nil nil nil nil)) #s(yas--field 0 65 69 nil nil nil nil nil)) nil 22 nil #s(yas--field 4 58 59 nil nil nil nil #s(yas--field 0 65 69 nil nil nil nil nil)) nil nil)) (25 . 65) ("open" . 25) ((marker . 125) . -4) ((marker . 89) . -4) 29 nil (25 . 29) ("w" . -25) ((marker . 125) . -1) ((marker . 89) . -1) ("i" . -26) ((marker . 125) . -1) ((marker . 89) . -1) 27 (25 . 27) (24 . 25) (t 24239 54505 759020 162000) 24 nil ("
" . 24) ((marker . 89) . -1) ((marker . 125) . -1) ((marker . 125) . -1) ((marker . 125) . -1) ((marker . 24) . -1) ((marker . 24) . -1) ((marker . 24) . -1) ((marker . 92) . -1) ((marker . 89) . -1) 25 nil (1 . 25) (t 24239 48961 605863 104000)) (emacs-undo-equiv-table (17 . 19) (23 . 29) (38 . 40) (20 . 38) (32 . 36) (25 . 27) (33 . 35) (22 . 30) (31 . 37) (24 . 28) (21 . 31)))