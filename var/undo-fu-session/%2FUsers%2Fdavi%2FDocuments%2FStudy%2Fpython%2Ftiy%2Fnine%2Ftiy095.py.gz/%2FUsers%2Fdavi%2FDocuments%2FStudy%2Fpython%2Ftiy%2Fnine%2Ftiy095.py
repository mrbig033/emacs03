((buffer-size . 755) (buffer-checksum . "709d12af88f37899b6113295027a688cb4fdbcd4"))
((emacs-pending-undo-list (nil rear-nonsticky nil 642 . 643) ("
" . -660) (642 . 661) 625 nil (nil rear-nonsticky nil 624 . 625) ("
" . -642) (624 . 643) 623 (t 24235 37994 970109 413000) nil (413 . 415) (t 24235 37985 436712 316000) nil (604 . 622) 587 nil (452 . 455) nil (413 . 416) (t 24235 37976 386362 782000) nil ("        print(\"## User Info ##\\n\")
" . 397) ((marker . 756) . -35) ((marker . 738) . -8) 405 nil ("        print(f\"Age: {self.age}\")
" . 487) ((marker . 756) . -34) ((marker . 738) . -32) ((marker*) . 2) ((marker) . -33) ((marker*) . 21) ((marker) . -14) 519 (t 24235 37973 790976 314000) nil (474 . 483) ("{" . -474) (474 . 476) ("{" . -474) (472 . 475) ("m" . -472) ((marker . 738) . -1) 473 (472 . 473) nil (" " . 448) nil (":" . 448) nil ("Name" . 448) (t 24235 37954 848209 518000) nil (579 . 584) (t 24235 37950 362696 270000) nil (603 . 604) ("(" . -603) (603 . 605) ("(" . -603) (603 . 604) (" " . -603) ((marker . 738) . -1) ("*" . -604) ((marker . 738) . -1) (" " . -605) ((marker . 738) . -1) 606 (603 . 606) ("*" . -603) 604 (603 . 604) (t 24235 37946 69685 439000) nil (579 . 603) ("incre" . -579) ((marker . 738) . -5) 584 (579 . 584) (570 . 579) (t 24235 37926 725669 404000) 523 nil ("
u.describe_user()" . 621) ((marker . 738) . -1) ((marker . 755) . -1) ((marker . 1) . -1) ((marker . 738) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) (t 24235 37924 61588 458000) nil (621 . 639) 604 nil ("u.greet_user()
" . 622) ((marker . 756) . -15) ((marker . 738) . -15) ((marker . 755) . -15) ((marker . 1) . -14) ((marker . 1) . -15) ((marker . 1) . -15) ((marker . 1) . -15) ((marker . 1) . -15) ((marker . 1) . -15) ((marker . 1) . -15) ((marker . 1) . -15) ((marker . 1) . -15) ((marker . 1) . -15) ((marker . 1) . -15) ((marker . 1) . -15) ((marker . 1) . -15) ((marker . 1) . -15) ((marker . 1) . -15) ((marker . 1) . -15) (t 24235 37912 930034 872000) nil ("
    def increment_login_attempts(self):
        self.login_attempts += 1
" . 367) ((marker . 738) . -1) ((marker . 756) . -41) ((marker . 755) . -1) ((marker . 1) . -1) ((marker . 738) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker) . -41) ((marker) . -42) ((marker) . -45) ((marker) . -46) ((marker) . -1) ((marker) . -2) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker) . -1) ((marker) . -2) ((marker) . -1) ((marker) . -2) (277 . 367) ("
    def greet_user(self):
        print(f\"\\n>> Welcome, {self.first} {self.last}! <<\\n\")
" . 203) ((marker . 585) . -27) ((marker) . -1) ((marker) . -2) ((marker) . -27) ((marker) . -28) ((marker) . -31) ((marker) . -32) ((marker . 1) . -27) ((marker . 1) . -27) ((marker . 1) . -27) (293 . 367) 294 (t 24235 37911 623774 671000) nil ("
    def increment_login_attempts(self):
        self.login_attempts += 1
" . 571) ((marker . 738) . -1) ((marker . 756) . -41) ((marker . 755) . -1) ((marker . 1) . -1) ((marker . 1) . -41) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 738) . -1) ((marker . 1) . -74) ((marker . 1) . -74) ((marker) . -41) ((marker) . -42) ((marker) . -45) ((marker) . -46) ((marker) . -1) ((marker) . -2) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -41) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker) . -1) ((marker) . -2) ((marker) . -1) ((marker) . -2) (367 . 571) ("
    def describe_user(self):
        print(\"## User Info ##\\n\")
        print(f\"Name: {self.first} {self.last}\")
        print(f\"Age: {self.age}\")
        print(f\"Login Attempts: {self.login_attempts}\")
" . 293) ((marker) . -148) ((marker) . -149) ((marker) . -152) ((marker) . -153) ((marker) . -114) ((marker) . -115) ((marker) . -118) ((marker) . -119) ((marker) . -65) ((marker) . -66) ((marker) . -69) ((marker) . -70) ((marker) . -30) ((marker) . -31) ((marker) . -34) ((marker) . -35) ((marker) . -1) ((marker) . -2) (497 . 571) 498 (t 24235 37907 290515 769000) nil ("
u.describe_user()
u.greet_user()
" . 637) ((marker . 756) . -1) ((marker . 755) . -32) ((marker . 1) . -32) ((marker . 738) . -33) ((marker . 755) . -33) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -33) ((marker . 1) . -33) ((marker . 1) . -33) ((marker . 1) . -1) ((marker . 1) . -33) ((marker . 1) . -33) ((marker) . -32) nil ("
" . 670) ((marker . 738) . -1) ((marker . 755) . -1) ((marker . 738) . -1) ((marker . 755) . -1) ((marker . 1) . -1) ((marker . 738) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) (1 . 672) ("#!/usr/bin/env python3


class User:
    def __init__(self, first, last, age):
        self.first = first.title()
        self.last = last.title()
        self.age = age
        self.login_attempts = 1

    def greet_user(self):
        print(f\"\\n>> Welcome, {self.first} {self.last}! <<\\n\")

    def describe_user(self):
        print(\"## User Info ##\\n\")
        print(f\"Name: {self.first} {self.last}\")
        print(f\"Age: {self.age}\")
        print(f\"Login Attempts: {self.login_attempts}\")

    def increment_login_attempts(self):
        self.login_attempts += 1


u = User(\"dave\", \"jones\", 37)

u.describe_user()
u.greet_user()

u.describe_user()
u.greet_user()
" . 1) ((marker . 585) . -570) ((marker . 738) . -670) (t 24235 37905 220859 173000) (1 . 671) ("#!/usr/bin/env python3


class User:
    def __init__(self, first, last, age):
        self.first = first.title()
        self.last = last.title()
        self.age = age
        self.login_attempts = 1

    def greet_user(self):
        print(f\"\\n>> Welcome, {self.first} {self.last}! <<\\n\")

    def describe_user(self):
        print(\"## User Info ##\\n\")
        print(f\"Name: {self.first} {self.last}\")
        print(f\"Age: {self.age}\")
        print(f\"Login Attempts: {self.login_attempts}\")

    def increment_login_attempts(self):
        self.login_attempts += 1


u = User(\"dave\", \"jones\", 37)

u.describe_user()
u.greet_user()

u.describe_user()
u.greet_user()

" . 1) ((marker . 738) . -670) ((marker . 756) . -671) ((marker . 755) . -670) ((marker . 1) . -637) ((marker . 1) . -637) ((marker . 1) . -669) ((marker . 738) . -670) ((marker . 755) . -670) ((marker . 1) . -603) ((marker . 1) . -602) ((marker . 1) . -292) ((marker . 1) . -603) ((marker) . -603) ((marker . 1) . -603) ((marker . 1) . -603) ((marker . 1) . -603) ((marker . 1) . -292) ((marker . 1) . -635) ((marker . 1) . -637) ((marker . 1) . -603) ((marker . 1) . -292) ((marker . 1) . -637) ((marker . 1) . -637) ((marker . 1) . -637) ((marker . 1) . -637) ((marker . 1) . -637) ((marker . 1) . -637) ((marker . 1) . -292) ((marker . 1) . -669) ((marker . 585) . -570) ((marker . 1) . -670) ((marker . 738) . -670) ((marker . 1) . -670) ((marker . 1) . -637) ((marker . 1) . -570) ((marker . 1) . -670) ((marker . 1) . -670) ((marker . 1) . -570) nil ("
u.describe_user()
u.greet_user()
" . 671) ((marker . 755) . -33) ((marker . 738) . -1) ((marker . 755) . -33) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) (704 . 705) (nil rear-nonsticky t 671 . 672) (t 24235 37896 268692 448000) nil (nil rear-nonsticky nil 671 . 672) ("
" . -704) (671 . 705) nil (670 . 671) 669 (t 24235 37895 228189 52000) nil (nil rear-nonsticky nil 637 . 638) ("
" . -670) (637 . 671) nil (636 . 637) 635 (t 24235 37892 187545 322000) nil (1 . 637) ("#!/usr/bin/env python3


class User:
    def __init__(self, first, last, age):
        self.first = first.title()
        self.last = last.title()
        self.age = age
        self.login_attempts = 1

    def greet_user(self):
        print(f\"\\n>> Welcome, {self.first} {self.last}! <<\\n\")

    def describe_user(self):
        print(\"## User Info ##\\n\")
        print(f\"Name: {self.first} {self.last}\")
        print(f\"Age: {self.age}\")
        print(f\"Login Attempts: {self.login_attempts}\")

    def increment_login_attempts(self):
        self.login_attempts += 1

u = User(\"dave\", \"jones\", 37)

u.describe_user()
u.greet_user()
" . 1) ((marker . 738) . -570) ((marker . 756) . -571) ((marker . 755) . -497) ((marker . 1) . -170) ((marker . 1) . -233) ((marker* . 756) . 143) ((marker . 1) . -497) ((marker* . 756) . 65) ((marker . 1) . -497) ((marker . 1) . -537) ((marker . 1) . -568) ((marker . 1) . -568) ((marker . 1) . -568) ((marker . 1) . -568) ((marker . 1) . -568) ((marker . 1) . -568) ((marker . 1) . -568) ((marker . 1) . -568) ((marker . 1) . -24) ((marker . 1) . -568) ((marker . 1) . -568) ((marker . 1) . -24) ((marker . 1) . -496) ((marker . 1) . -496) ((marker . 1) . -24) ((marker . 1) . -568) ((marker . 1) . -496) ((marker . 1) . -496) ((marker . 1) . -496) ((marker . 1) . -496) ((marker . 1) . -24) ((marker . 1) . -496) ((marker . 1) . -203) ((marker . 1) . -203) ((marker . 1) . -203) ((marker . 1) . -203) ((marker . 1) . -203) ((marker . 1) . -24) ((marker . 1) . -203) ((marker . 1) . -203) ((marker . 1) . -24) ((marker . 1) . -203) ((marker . 1) . -203) ((marker . 1) . -24) ((marker . 1) . -284) ((marker . 1) . -284) ((marker . 1) . -203) ((marker . 1) . -284) ((marker . 1) . -284) ((marker . 1) . -284) ((marker . 1) . -496) ((marker . 1) . -496) ((marker . 1) . -284) ((marker . 1) . -496) ((marker . 1) . -496) ((marker . 1) . -496) ((marker . 1) . -496) ((marker . 1) . -501) ((marker . 1) . -497) ((marker . 1) . -501) ((marker . 1) . -501) ((marker . 1) . -202) ((marker . 1) . -501) ((marker . 1) . -501) ((marker . 1) . -202) ((marker . 1) . -297) ((marker . 1) . -326) ((marker . 1) . -170) ((marker . 1) . -207) ((marker . 1) . -233) ((marker . 1) . -170) ((marker . 1) . -233) ((marker . 1) . -233) ((marker . 1) . -170) ((marker . 1) . -233) ((marker . 1) . -233) ((marker . 1) . -170) ((marker . 1) . -233) ((marker . 738) . -570) ((marker . 585) . -292) ((marker) . -537) ((marker) . -538) ((marker) . -541) ((marker) . -542) ((marker) . -497) ((marker) . -498) ((marker) . -440) ((marker) . -441) ((marker) . -444) ((marker) . -445) ((marker) . -406) ((marker) . -407) ((marker) . -410) ((marker) . -411) ((marker) . -357) ((marker) . -358) ((marker) . -361) ((marker) . -362) ((marker) . -322) ((marker) . -323) ((marker) . -326) ((marker) . -327) ((marker) . -293) ((marker) . -294) ((marker) . -229) ((marker) . -230) ((marker) . -233) ((marker) . -234) ((marker) . -203) ((marker) . -204) ((marker) . -170) ((marker) . -171) ((marker) . -174) ((marker) . -175) ((marker) . -147) ((marker) . -148) ((marker) . -151) ((marker) . -152) ((marker) . -114) ((marker) . -115) ((marker) . -118) ((marker) . -119) ((marker) . -79) ((marker) . -80) ((marker) . -83) ((marker) . -84) ((marker) . -37) ((marker) . -38) ((marker . 1) . -570) ((marker . 1) . -570) ((marker . 1) . -292) ((marker . 1) . -237) ((marker . 1) . -237) ((marker . 1) . -330) ((marker . 1) . -330) ((marker . 1) . -365) ((marker . 1) . -365) ((marker . 1) . -414) ((marker . 1) . -414) ((marker . 1) . -448) ((marker . 1) . -448) ((marker . 1) . -571) ((marker . 1) . -571) ((marker . 1) . -575) ((marker . 1) . -571) ((marker . 1) . -571) ((marker . 1) . -575) ((marker . 1) . -570) 571 nil (1 . 636) ("#!/usr/bin/env python3


class User:
    def __init__(self, first, last, age):
        self.first = first.title()
        self.last = last.title()
        self.age = age
        self.login_attempts = 1

    def greet_user(self):
        print(f\"\\n>> Welcome, {self.first} {self.last}! <<\\n\")

    def describe_user(self):
        print(\"## User Info ##\\n\")
        print(f\"Name: {self.first} {self.last}\")
        print(f\"Age: {self.age}\")
        print(f\"Login Attempts: {self.login_attempts}\")

    def increment_login_attempts(self):
        self.login_attempts += 1


u = User(\"dave\", \"jones\", 37)

u.describe_user()
u.greet_user()
" . 1) ((marker . 738) . -603) ((marker . 756) . -621) ((marker . 1) . -537) ((marker . 738) . -603) ((marker . 585) . -229) ((marker) . -203) ((marker) . -204) ((marker) . -170) ((marker) . -171) ((marker) . -174) ((marker) . -175) ((marker) . -147) ((marker) . -148) ((marker) . -151) ((marker) . -152) ((marker) . -114) ((marker) . -115) ((marker) . -118) ((marker) . -119) ((marker) . -79) ((marker) . -80) ((marker) . -83) ((marker) . -84) ((marker) . -37) ((marker) . -38) ((marker . 1) . -537) ((marker . 1) . -537) ((marker . 1) . -292) ((marker . 1) . -537) ((marker . 1) . -537) ((marker . 1) . -292) ((marker . 1) . -537) ((marker . 1) . -537) ((marker . 1) . -229) ((marker . 1) . -537) ((marker) . -537) ((marker) . -538) ((marker) . -541) ((marker) . -542) ((marker) . -497) ((marker) . -498) ((marker) . -440) ((marker) . -441) ((marker) . -444) ((marker) . -445) ((marker) . -406) ((marker) . -407) ((marker) . -410) ((marker) . -411) ((marker) . -357) ((marker) . -358) ((marker) . -361) ((marker) . -362) ((marker) . -322) ((marker) . -323) ((marker) . -326) ((marker) . -327) ((marker) . -293) ((marker) . -294) ((marker) . -229) ((marker) . -230) ((marker) . -233) ((marker) . -234) ((marker . 1) . -537) ((marker . 1) . -537) ((marker . 1) . -537) ((marker . 1) . -229) ((marker . 1) . -537) ((marker . 1) . -570) ((marker . 1) . -537) ((marker . 1) . -229) ((marker . 1) . -570) ((marker . 1) . -571) ((marker . 1) . -570) ((marker . 1) . -229) ((marker . 1) . -571) ((marker . 1) . -572) ((marker . 1) . -571) ((marker . 1) . -229) ((marker . 1) . -572) ((marker . 1) . -602) ((marker . 1) . -572) ((marker . 1) . -229) ((marker . 1) . -602) ((marker . 1) . -603) ((marker . 1) . -602) ((marker . 1) . -229) ((marker . 1) . -603) ((marker . 1) . -621) ((marker . 1) . -603) ((marker . 1) . -229) ((marker . 1) . -621) ((marker . 1) . -636) ((marker . 1) . -621) ((marker . 1) . -229) ((marker . 1) . -636) ((marker . 1) . -636) ((marker . 1) . -636) ((marker . 1) . -229) ((marker . 1) . -636) ((marker . 1) . -636) ((marker . 1) . -636) ((marker . 1) . -229) ((marker . 1) . -636) ((marker . 1) . -636) ((marker . 1) . -636) ((marker . 1) . -229) ((marker . 1) . -636) ((marker . 1) . -621) ((marker . 1) . -636) ((marker . 1) . -229) ((marker . 1) . -621) ((marker . 1) . -603) ((marker . 1) . -621) ((marker . 1) . -229) ((marker . 1) . -603) (t 24235 37884 282371 978000) nil (1 . 637) ("#!/usr/bin/env python3


class User:
    def __init__(self, first, last, age):
        self.first = first.title()
        self.last = last.title()
        self.age = age
        self.login_attempts = 1

    def greet_user(self):
        print(f\"\\n>> Welcome, {self.first} {self.last}! <<\\n\")

    def describe_user(self):
        print(\"## User Info ##\\n\")
        print(f\"Name: {self.first} {self.last}\")
        print(f\"Age: {self.age}\")
        print(f\"Login Attempts: {self.login_attempts}\")

    def increment_login_attempts(self):
        self.login_attempts += 1

u = User(\"dave\", \"jones\", 37)

u.describe_user()
u.greet_user()
" . 1) ((marker . 738) . -570) ((marker . 756) . -571) ((marker . 755) . -497) ((marker . 1) . -170) ((marker . 1) . -233) ((marker* . 756) . 143) ((marker . 1) . -497) ((marker* . 756) . 65) ((marker . 1) . -497) ((marker . 1) . -537) ((marker . 1) . -568) ((marker . 1) . -568) ((marker . 1) . -568) ((marker . 1) . -568) ((marker . 1) . -568) ((marker . 1) . -568) ((marker . 1) . -568) ((marker . 1) . -568) ((marker . 1) . -24) ((marker . 1) . -568) ((marker . 1) . -568) ((marker . 1) . -24) ((marker . 1) . -496) ((marker . 1) . -496) ((marker . 1) . -24) ((marker . 1) . -568) ((marker . 1) . -496) ((marker . 1) . -496) ((marker . 1) . -496) ((marker . 1) . -496) ((marker . 1) . -24) ((marker . 1) . -496) ((marker . 1) . -203) ((marker . 1) . -203) ((marker . 1) . -203) ((marker . 1) . -203) ((marker . 1) . -203) ((marker . 1) . -24) ((marker . 1) . -203) ((marker . 1) . -203) ((marker . 1) . -24) ((marker . 1) . -203) ((marker . 1) . -203) ((marker . 1) . -24) ((marker . 1) . -284) ((marker . 1) . -284) ((marker . 1) . -203) ((marker . 1) . -284) ((marker . 1) . -284) ((marker . 1) . -284) ((marker . 1) . -496) ((marker . 1) . -496) ((marker . 1) . -284) ((marker . 1) . -496) ((marker . 1) . -496) ((marker . 1) . -496) ((marker . 1) . -496) ((marker . 1) . -501) ((marker . 1) . -497) ((marker . 1) . -501) ((marker . 1) . -501) ((marker . 1) . -202) ((marker . 1) . -501) ((marker . 1) . -501) ((marker . 1) . -202) ((marker . 1) . -297) ((marker . 1) . -326) ((marker . 1) . -170) ((marker . 1) . -207) ((marker . 1) . -233) ((marker . 1) . -170) ((marker . 1) . -233) ((marker . 1) . -233) ((marker . 1) . -170) ((marker . 1) . -233) ((marker . 1) . -233) ((marker . 1) . -170) ((marker . 1) . -233) ((marker . 738) . -570) ((marker . 585) . -292) 571 nil ("
" . 571) ((marker . 756) . -1) ((marker* . 756) . 1) (t 24235 37881 920829 990000) nil (479 . 493) ("lo" . -479) ((marker . 738) . -2) 481 (479 . 481) ("age" . 479) (t 24235 37877 770537 251000) nil (457 . 471) ("Age" . 457) nil (440 . 474) 415 nil ("1" . 518) nil ("1" . 550) nil ("1" . 569) (t 24235 37632 549003 129000) nil ("        print(f\"Birth Year: {self.age}\")
" . 441) ((marker . 756) . -41) ((marker . 738) . -39) ((marker . 1) . -41) ((marker . 1) . -41) ((marker . 1) . -41) ((marker . 1) . -41) ((marker . 1) . -41) ((marker . 1) . -41) ((marker . 1) . -41) ((marker*) . 2) ((marker) . -40) ((marker*) . 28) ((marker) . -14) 480 (t 24235 37617 217738 296000) nil (285 . 286) ("m" . -285) ((marker . 738) . -1) 286 (285 . 286) (t 24235 37600 219893 840000) nil ("
    def greet_user(self):
        print(f\"\\n>> Welcome, {self.first} {self.last}!<<\\n\")
" . 481) ((marker . 738) . -27) ((marker . 756) . -89) ((marker . 755) . -58) ((marker . 1) . -58) ((marker . 738) . -58) ((marker . 1) . -58) ((marker . 1) . -89) ((marker . 1) . -58) ((marker . 1) . -58) ((marker . 1) . -58) ((marker . 1) . -58) (292 . 481) ("
    def describe_user(self):
        print(\"## User Info ##\\n\")
        print(f\"Name: {self.first} {self.last}\")
        print(f\"Age: {self.age}\")
        print(f\"Birth Year: {self.age}\")
" . 203) (392 . 481) 450 (t 24235 37573 968146 156000) nil (1 . 624) ("#!/usr/bin/env python3


class User:
    def __init__(self, first, last, age):
        self.first = first.title()
        self.last = last.title()
        self.age = age
        self.login_attempts = 1

    def describe_user(self):
        print(\"## User Info ##\\n\")
        print(f\"Name: {self.first} {self.last}\")
        print(f\"Age: {self.age}\")
        print(f\"Birth Year: {self.age}\")

    def greet_user(self):
        print(f\"\\n>> Welcome, {self.first} {self.last}!<<\\n\")

    def increment_login_attempts(self):
        self.login_attempts += 1



u1 = User(\"dave\", \"jones\", 37)

u1.describe_user()
u1.greet_user()
" . 1) ((marker . 738) . -521) ((marker . 756) . -554) ((marker . 755) . -554) ((marker . 1) . -554) ((marker* . 756) . 71) ((marker . 1) . -588) ((marker* . 756) . 36) ((marker . 1) . -588) ((marker . 1) . -588) ((marker . 755) . -624) ((marker . 1) . -624) ((marker . 1) . -24) ((marker . 1) . -200) ((marker . 1) . -200) ((marker . 1) . -200) ((marker . 1) . -200) ((marker . 1) . -554) ((marker . 1) . -554) ((marker . 1) . -554) ((marker . 1) . -554) ((marker . 1) . -554) ((marker . 1) . -554) ((marker . 1) . -554) ((marker . 738) . -552) 553 nil (549 . 554) (" +=" . -549) ((marker . 738) . -2) 552 (551 . 552) (" " . -551) ((marker . 738) . -1) ("1" . -552) ((marker . 738) . -1) 553 (549 . 553) (" +" . -549) ((marker . 738) . -1) 551 (549 . 551) (535 . 549) ("log" . -535) ((marker . 738) . -3) 538 (535 . 538) ("o" . -535) ((marker . 738) . -1) 536 (530 . 536) (521 . 530) (t 24235 37562 783197 195000) 518 nil ("        " . 522) ((marker . 755) . -7) ((marker . 1) . -7) ((marker . 1) . -7) ((marker . 1) . -7) ((marker . 1) . -7) ((marker . 1) . -7) ((marker . 1) . -7) ((marker . 1) . -7) ((marker . 1) . -7) 518 nil ("," . -519) ((marker . 738) . -1) (" " . -520) ((marker . 738) . -1) 521 (519 . 521) ("," . -519) 520 (519 . 520) (t 24235 37477 221570 520000) nil (520 . 530) (514 . 519) ("(" . -514) (514 . 516) ("(" . -514) (507 . 515) (486 . 507) ("    " . -486) ((marker . 738) . -4) 490 (482 . 490) ("        " . 481) ((marker . 738) . -8) (489 . 490) (480 . 489) (t 24235 37441 392430 4000) 419 nil (198 . 202) ("=" . -198) 199 (195 . 199) (184 . 195) (apply yas--snippet-revive 179 184 #s(yas--snippet nil nil #s(yas--exit 184 nil) 7 nil nil nil nil)) (apply yas--take-care-of-redo #s(yas--snippet nil nil #s(yas--exit 184 nil) 7 nil nil nil nil)) (179 . 184) ("." . 179) ((marker . 738) . -1) 180 nil (179 . 180) (170 . 179) (t 24235 37431 457648 748000) 160 nil ("
u2.describe_user()
u2.greet_user()

u3.describe_user()
u3.greet_user()
" . 518) ((marker . 756) . -1) ((marker . 755) . -71) ((marker . 1) . -70) nil ("u2 = User(\"mr\", \"big\", 27)
u3 = User(\"laura\", \"black\", 15)
" . 482) ((marker . 738) . -27) ((marker . 756) . -59) ((marker . 755) . -27) ((marker . 738) . -27) ((marker . 1) . -27) ((marker) . -27) 509 (t 24235 37372 946243 993000) nil (nil rear-nonsticky nil 648 . 649) (nil fontified nil 1 . 649) (1 . 649) ("#!/usr/bin/env python3
" . 1) ((marker . 756) . -23) ((marker . 755) . -23) ((marker . 1) . -23) ((marker . 1) . -23) ((marker . 1) . -23) ((marker . 1) . -22) ((marker) . -22) (t 24235 37366 377315 991000) nil (1 . 24) ("#!/usr/bin/env python3

" . -1) ((marker . 738) . -24) ((marker . 756) . -24) ((marker . 1) . -23) ((marker . 738) . -24) ((marker . 1) . -24) ((marker . 1) . -24) 25 nil (24 . 25) (t 24235 37354 74208 625000) (1 . 24) ("#!/usr/bin/env python3

" . -1) ((marker . 738) . -24) ((marker . 756) . -24) ((marker . 1) . -23) ((marker . 738) . -24) 25 (24 . 25) (t 24235 37342 356597 773000) (1 . 24) ("#!/usr/bin/env python3

" . -1) ((marker . 738) . -24) ((marker . 756) . -24) ((marker . 1) . -23) ((marker . 738) . -24) 25 (24 . 25) (t 24235 37310 960529 982000) 24 nil (1 . 24) ("#!/usr/bin/env python3

" . -1) ((marker . 738) . -24) ((marker . 756) . -24) ((marker . 738) . -24) 25 nil (1 . 25) (t 24234 22106 276802 932000)) (emacs-buffer-undo-list nil (nil rear-nonsticky nil 737 . 738) ("
" . -755) (737 . 756) 729 (t 24235 38088 932657 751000) nil (1 . 738) ("#!/usr/bin/env python3


class User:
    def __init__(self, first, last, age):
        self.first = first.title()
        self.last = last.title()
        self.age = age
        self.login_attempts = 1

    def increment_login_attempts(self):
        self.login_attempts += 1

    def reset_login_attempts(self):
        self.login_attempts = 0

    def greet_user(self):
        print(f\"\\n>> Welcome, {self.first} {self.last}! <<\\n\")

    def describe_user(self):
        print(f\"\\n## {self.first} {self.last}, {self.age} ##\")
        print(f\"Login Attempts: {self.login_attempts}\")
        self.increment_login_attempts()


u = User(\"dave\", \"jones\", 37)

u.describe_user()
u.describe_user()
u.describe_user()

u.reset_login_attempts()" . 1) ((marker . 738) . -712) ((marker . 756) . -736) ((marker . 755) . -243) ((marker* . 756) . 1) ((marker . 1) . -624) ((marker* . 756) . 112) ((marker . 1) . -624) ((marker . 1) . -624) ((marker . 738) . -710) ((marker . 755) . -710) ((marker . 1) . -657) ((marker . 1) . -656) ((marker . 1) . -345) ((marker . 1) . -657) ((marker . 1) . -657) ((marker . 1) . -657) ((marker . 1) . -657) ((marker . 1) . -345) ((marker . 1) . -711) ((marker . 1) . -711) ((marker . 1) . -657) ((marker . 1) . -345) ((marker . 1) . -711) ((marker . 1) . -711) ((marker . 1) . -711) ((marker . 1) . -711) ((marker . 1) . -711) ((marker . 1) . -711) ((marker . 1) . -345) ((marker . 1) . -711) ((marker . 1) . -711) ((marker . 1) . -711) ((marker . 1) . -624) ((marker . 1) . -711) ((marker . 1) . -711) ((marker . 1) . -624) ((marker . 1) . -624) ((marker . 1) . -624) ((marker . 1) . -202) ((marker . 1) . -624) ((marker . 1) . -624) ((marker . 1) . -624) ((marker . 1) . -624) ((marker . 1) . -624) ((marker . 1) . -624) ((marker . 1) . -624) ((marker . 1) . -624) ((marker . 1) . -202) ((marker . 1) . -624) ((marker . 1) . -624) ((marker . 1) . -435) ((marker . 1) . -435) ((marker . 1) . -435) ((marker . 1) . -435) ((marker . 1) . -435) ((marker . 1) . -435) ((marker . 1) . -435) ((marker . 1) . -435) ((marker . 1) . -435) ((marker . 1) . -202) ((marker . 1) . -435) ((marker . 1) . -435) ((marker . 1) . -203) ((marker . 1) . -203) ((marker . 1) . -203) ((marker . 1) . -203) ((marker . 1) . -203) ((marker . 1) . -202) ((marker . 1) . -203) ((marker . 1) . -203) ((marker . 1) . -202) ((marker . 1) . -247) ((marker . 1) . -207) ((marker . 1) . -203) ((marker . 1) . -247) ((marker . 1) . -247) ((marker . 1) . -247) ((marker . 1) . -711) ((marker . 1) . -711) ((marker . 1) . -711) ((marker . 1) . -674) ((marker . 1) . -657) ((marker . 1) . -247) ((marker . 1) . -674) ((marker . 1) . -674) ((marker . 1) . -674) ((marker . 1) . -620) ((marker . 1) . -620) ((marker . 1) . -674) ((marker . 1) . -620) ((marker . 1) . -620) ((marker . 1) . -620) ((marker . 1) . -620) ((marker . 1) . -621) ((marker . 1) . -597) ((marker . 1) . -596) ((marker . 1) . -621) ((marker . 1) . -597) ((marker . 1) . -597) ((marker . 1) . -597) ((marker . 1) . -711) ((marker . 1) . -597) ((marker . 1) . -25) ((marker . 1) . -597) ((marker . 1) . -711) ((marker . 1) . -711) ((marker . 1) . -711) ((marker . 1) . -25) ((marker . 1) . -524) ((marker . 1) . -524) ((marker . 1) . -202) ((marker . 1) . -711) ((marker . 1) . -524) ((marker . 1) . -524) ((marker . 1) . -524) ((marker . 1) . -202) ((marker . 1) . -675) ((marker . 1) . -657) ((marker . 1) . -524) ((marker . 1) . -675) ((marker . 1) . -675) ((marker . 1) . -675) ((marker . 1) . -483) ((marker . 1) . -483) ((marker . 1) . -675) ((marker . 1) . -483) ((marker . 1) . -483) ((marker . 1) . -483) ((marker . 1) . -483) ((marker . 1) . -483) ((marker . 1) . -483) ((marker . 1) . -483) ((marker . 1) . -483) ((marker . 1) . -710) ((marker . 1) . -710) ((marker . 1) . -710) ((marker . 1) . -710) ((marker . 1) . -710) ((marker . 1) . -710) ((marker . 1) . -710) ((marker . 1) . -203) ((marker . 1) . -710) ((marker . 1) . -710) ((marker . 1) . -710) ((marker . 1) . -203) ((marker . 1) . -710) ((marker . 1) . -693) ((marker . 1) . -693) ((marker . 585) . -346) ((marker . 738) . -734) ((marker) . -79) ((marker) . -80) ((marker) . -83) ((marker) . -84) ((marker) . -37) ((marker) . -38) ((marker . 1) . -344) ((marker . 1) . -343) ((marker . 1) . -114) ((marker . 1) . -344) ((marker . 1) . -343) ((marker . 1) . -343) ((marker . 1) . -114) ((marker . 1) . -343) ((marker . 1) . -343) ((marker . 1) . -343) ((marker . 1) . -114) ((marker . 1) . -343) ((marker . 1) . -343) ((marker . 1) . -343) ((marker . 1) . -114) ((marker . 1) . -693) ((marker . 1) . -343) ((marker . 1) . -343) ((marker . 1) . -343) ((marker . 1) . -343) ((marker . 1) . -343) ((marker . 1) . -711) ((marker . 1) . -343) ((marker . 1) . -346) ((marker . 1) . -711) ((marker . 1) . -711) ((marker . 1) . -711) ((marker . 1) . -711) ((marker . 1) . -346) ((marker . 1) . -380) ((marker . 1) . -380) ((marker . 1) . -473) ((marker . 1) . -473) ((marker . 1) . -536) ((marker . 1) . -536) ((marker . 1) . -626) ((marker . 1) . -626) ((marker . 1) . -630) ((marker . 1) . -626) ((marker . 1) . -626) ((marker . 1) . -630) ((marker . 1) . -711) ((marker . 1) . -693) ((marker . 1) . -711) ((marker . 1) . -346) ((marker . 1) . -693) ((marker . 1) . -675) ((marker . 1) . -693) ((marker . 1) . -346) ((marker . 1) . -675) ((marker . 1) . -657) ((marker . 1) . -675) ((marker . 1) . -346) ((marker . 1) . -657) ((marker . 1) . -656) ((marker . 1) . -657) ((marker . 1) . -346) ((marker . 1) . -656) ((marker . 1) . -626) ((marker . 1) . -656) ((marker . 1) . -346) ((marker . 1) . -626) ((marker . 1) . -625) ((marker . 1) . -626) ((marker . 1) . -346) ((marker . 1) . -625) ((marker . 1) . -624) ((marker . 1) . -625) ((marker . 1) . -346) ((marker . 1) . -624) ((marker . 1) . -584) ((marker . 1) . -624) ((marker . 1) . -346) ((marker . 1) . -584) ((marker . 1) . -528) ((marker . 1) . -584) ((marker . 1) . -346) ((marker . 1) . -528) ((marker . 1) . -465) ((marker . 1) . -528) ((marker . 1) . -346) ((marker . 1) . -465) ((marker . 1) . -436) ((marker . 1) . -465) ((marker . 1) . -346) ((marker . 1) . -436) ((marker . 1) . -435) ((marker . 1) . -436) ((marker . 1) . -346) ((marker . 1) . -435) ((marker . 1) . -372) ((marker . 1) . -435) ((marker . 1) . -346) ((marker . 1) . -372) ((marker . 1) . -346) ((marker . 1) . -372) ((marker . 1) . -346) ((marker . 1) . -346) ((marker . 1) . -345) ((marker . 1) . -346) ((marker . 1) . -346) ((marker) . -313) ((marker) . -314) ((marker) . -317) ((marker) . -318) ((marker) . -277) ((marker) . -278) ((marker) . -243) ((marker) . -244) ((marker) . -247) ((marker) . -248) ((marker) . -203) ((marker) . -204) ((marker) . -170) ((marker) . -171) ((marker) . -174) ((marker) . -175) ((marker) . -147) ((marker) . -148) ((marker) . -151) ((marker) . -152) ((marker) . -114) ((marker) . -115) ((marker) . -118) ((marker) . -119) ((marker . 1) . -345) ((marker . 1) . -345) ((marker . 1) . -313) ((marker . 1) . -345) ((marker . 1) . -114) ((marker . 1) . -313) ((marker . 1) . -277) ((marker . 1) . -313) ((marker . 1) . -114) ((marker . 1) . -277) ((marker . 1) . -276) ((marker . 1) . -277) ((marker . 1) . -114) ((marker . 1) . -276) ((marker . 1) . -243) ((marker . 1) . -276) ((marker . 1) . -114) ((marker . 1) . -343) ((marker . 1) . -243) ((marker . 1) . -243) ((marker . 1) . -243) ((marker . 1) . -243) ((marker . 1) . -243) ((marker . 1) . -711) ((marker . 1) . -243) ((marker . 1) . -346) ((marker) . -584) ((marker) . -585) ((marker) . -588) ((marker) . -589) ((marker) . -528) ((marker) . -529) ((marker) . -532) ((marker) . -533) ((marker) . -465) ((marker) . -466) ((marker) . -469) ((marker) . -470) ((marker) . -436) ((marker) . -437) ((marker) . -372) ((marker) . -373) ((marker) . -376) ((marker) . -377) ((marker) . -346) ((marker) . -347) ((marker . 1) . -711) ((marker . 1) . -711) ((marker . 1) . -711) ((marker . 1) . -711) ((marker . 1) . -346) ((marker . 1) . -711) ((marker . 1) . -712) ((marker . 1) . -693) ((marker . 1) . -693) ((marker . 1) . -712) ((marker . 1) . -712) ((marker . 1) . -711) ((marker . 1) . -346) ((marker . 1) . -712) ((marker . 1) . -712) ((marker . 1) . -712) ((marker . 1) . -346) ((marker . 1) . -712) ((marker . 1) . -712) ((marker . 1) . -712) ((marker . 1) . -346) ((marker . 1) . -712) ((marker . 1) . -713) ((marker . 1) . -712) ((marker . 1) . -346) ((marker . 1) . -713) ((marker . 1) . -714) ((marker . 1) . -713) ((marker . 1) . -346) ((marker . 1) . -714) ((marker . 1) . -714) ((marker . 1) . -714) ((marker . 1) . -346) ((marker . 1) . -714) ((marker . 1) . -714) ((marker . 1) . -714) ((marker . 1) . -346) ((marker . 1) . -714) ((marker . 1) . -714) ((marker . 1) . -714) ((marker . 1) . -346) ((marker) . -714) ((marker) . -714) ((marker . 1) . -714) ((marker . 1) . -735) ((marker . 1) . -714) ((marker . 1) . -346) ((marker*) . 2) ((marker) . -735) ((marker*) . 1) ((marker) . -736) ((marker . 1) . -735) ((marker . 1) . -734) ((marker . 1) . -734) ((marker . 1) . -346) ((marker . 1) . -734) 735 nil (715 . 737) ("re" . -715) ((marker . 756) . -2) ((marker . 738) . -2) ((marker) . -2) ((marker . 1) . -1) ((marker . 1) . -1) ((marker) . -2) ((marker . 1) . -2) ((marker . 1) . -1) ((marker) . -1) ((marker) . -2) ((marker . 1) . -2) 717 (713 . 717) ("." . -713) ((marker . 756) . -1) ((marker . 738) . -1) ((marker . 1) . -1) ((marker . 1) . -1) 714 (713 . 714) (712 . 713) (t 24235 38076 442676 417000) 712 nil (344 . 345) (327 . 344) ("lo" . -327) ((marker . 738) . -2) 329 (328 . 329) ("o" . -328) ((marker . 738) . -1) 329 (322 . 329) (312 . 322) (306 . 311) ("(" . -306) (306 . 308) ("(" . -306) (300 . 307) ("e" . -300) ((marker . 738) . -1) 301 (286 . 301) ("r" . -286) ((marker . 738) . -1) 287 (282 . 287) ("    " . -282) ((marker . 738) . -4) 286 (278 . 286) ("        " . 277) ((marker . 738) . -8) (285 . 286) (276 . 285) (t 24235 38032 931265 287000) 244 nil ("u.describe_user()
" . 625) ((marker . 756) . -18) ((marker . 755) . -18) ((marker . 1) . -18) ((marker . 1) . -18) (t 24235 38013 687203 696000) nil ("
u.describe_user()
" . 660) ((marker . 738) . -1) ((marker . 755) . -17) ((marker* . 756) . 2) ((marker . 738) . -1) ((marker . 755) . -18) ((marker . 1) . -17) ((marker . 738) . -17) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -17) ((marker . 1) . -17) ((marker . 1) . -17) ((marker . 1) . -17) ((marker . 1) . -17) (678 . 679) (nil rear-nonsticky t 660 . 661) (t 24235 38013 61415 315000) nil ("_1" . 677) (t 24235 38012 635088 37000) nil (677 . 678) (t 24235 38009 857774 343000) nil ("_" . 677) nil (677 . 679) (t 24235 38003 16238 721000) nil (nil rear-nonsticky nil 660 . 661) ("
" . -678) (660 . 679) 643 nil (nil rear-nonsticky nil 642 . 643) ("
" . -660) (642 . 661) 625 nil (nil rear-nonsticky nil 624 . 625) ("
" . -642) (624 . 643) 623 (t 24235 37994 970109 413000) nil (413 . 415) (t 24235 37985 436712 316000) nil (604 . 622) 587 nil (452 . 455) nil (413 . 416) (t 24235 37976 386362 782000) nil ("        print(\"## User Info ##\\n\")
" . 397) ((marker . 756) . -35) ((marker . 738) . -8) 405 nil ("        print(f\"Age: {self.age}\")
" . 487) ((marker . 756) . -34) ((marker . 738) . -32) ((marker*) . 2) ((marker) . -33) ((marker*) . 21) ((marker) . -14) 519 (t 24235 37973 790976 314000) nil (474 . 483) ("{" . -474) (474 . 476) ("{" . -474) (472 . 475) ("m" . -472) ((marker . 738) . -1) 473 (472 . 473) nil (" " . 448) nil (":" . 448) nil ("Name" . 448) (t 24235 37954 848209 518000) nil (579 . 584) (t 24235 37950 362696 270000) nil (603 . 604) ("(" . -603) (603 . 605) ("(" . -603) (603 . 604) (" " . -603) ((marker . 738) . -1) ("*" . -604) ((marker . 738) . -1) (" " . -605) ((marker . 738) . -1) 606 (603 . 606) ("*" . -603) 604 (603 . 604) (t 24235 37946 69685 439000) nil (579 . 603) ("incre" . -579) ((marker . 738) . -5) 584 (579 . 584) (570 . 579) (t 24235 37926 725669 404000) 523 nil ("
u.describe_user()" . 621) ((marker . 738) . -1) ((marker . 755) . -1) ((marker . 1) . -1) ((marker . 738) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) (t 24235 37924 61588 458000) nil (621 . 639) 604 nil ("u.greet_user()
" . 622) ((marker . 756) . -15) ((marker . 738) . -15) ((marker . 755) . -15) ((marker . 1) . -14) ((marker . 1) . -15) ((marker . 1) . -15) ((marker . 1) . -15) ((marker . 1) . -15) ((marker . 1) . -15) ((marker . 1) . -15) ((marker . 1) . -15) ((marker . 1) . -15) ((marker . 1) . -15) ((marker . 1) . -15) ((marker . 1) . -15) ((marker . 1) . -15) ((marker . 1) . -15) ((marker . 1) . -15) ((marker . 1) . -15) (t 24235 37912 930034 872000) nil ("
    def increment_login_attempts(self):
        self.login_attempts += 1
" . 367) ((marker . 738) . -1) ((marker . 756) . -41) ((marker . 755) . -1) ((marker . 1) . -1) ((marker . 738) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker) . -41) ((marker) . -42) ((marker) . -45) ((marker) . -46) ((marker) . -1) ((marker) . -2) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker) . -1) ((marker) . -2) ((marker) . -1) ((marker) . -2) (277 . 367) ("
    def greet_user(self):
        print(f\"\\n>> Welcome, {self.first} {self.last}! <<\\n\")
" . 203) ((marker . 585) . -27) ((marker) . -1) ((marker) . -2) ((marker) . -27) ((marker) . -28) ((marker) . -31) ((marker) . -32) ((marker . 1) . -27) ((marker . 1) . -27) ((marker . 1) . -27) (293 . 367) 294 (t 24235 37911 623774 671000) nil ("
    def increment_login_attempts(self):
        self.login_attempts += 1
" . 571) ((marker . 738) . -1) ((marker . 756) . -41) ((marker . 755) . -1) ((marker . 1) . -1) ((marker . 1) . -41) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 738) . -1) ((marker . 1) . -74) ((marker . 1) . -74) ((marker) . -41) ((marker) . -42) ((marker) . -45) ((marker) . -46) ((marker) . -1) ((marker) . -2) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -41) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker) . -1) ((marker) . -2) ((marker) . -1) ((marker) . -2) (367 . 571) ("
    def describe_user(self):
        print(\"## User Info ##\\n\")
        print(f\"Name: {self.first} {self.last}\")
        print(f\"Age: {self.age}\")
        print(f\"Login Attempts: {self.login_attempts}\")
" . 293) ((marker) . -148) ((marker) . -149) ((marker) . -152) ((marker) . -153) ((marker) . -114) ((marker) . -115) ((marker) . -118) ((marker) . -119) ((marker) . -65) ((marker) . -66) ((marker) . -69) ((marker) . -70) ((marker) . -30) ((marker) . -31) ((marker) . -34) ((marker) . -35) ((marker) . -1) ((marker) . -2) (497 . 571) 498 (t 24235 37907 290515 769000) nil ("
u.describe_user()
u.greet_user()
" . 637) ((marker . 756) . -1) ((marker . 755) . -32) ((marker . 1) . -32) ((marker . 738) . -33) ((marker . 755) . -33) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -33) ((marker . 1) . -33) ((marker . 1) . -33) ((marker . 1) . -1) ((marker . 1) . -33) ((marker . 1) . -33) ((marker) . -32) nil ("
" . 670) ((marker . 738) . -1) ((marker . 755) . -1) ((marker . 738) . -1) ((marker . 755) . -1) ((marker . 1) . -1) ((marker . 738) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) (1 . 672) ("#!/usr/bin/env python3


class User:
    def __init__(self, first, last, age):
        self.first = first.title()
        self.last = last.title()
        self.age = age
        self.login_attempts = 1

    def greet_user(self):
        print(f\"\\n>> Welcome, {self.first} {self.last}! <<\\n\")

    def describe_user(self):
        print(\"## User Info ##\\n\")
        print(f\"Name: {self.first} {self.last}\")
        print(f\"Age: {self.age}\")
        print(f\"Login Attempts: {self.login_attempts}\")

    def increment_login_attempts(self):
        self.login_attempts += 1


u = User(\"dave\", \"jones\", 37)

u.describe_user()
u.greet_user()

u.describe_user()
u.greet_user()
" . 1) ((marker . 585) . -570) ((marker . 738) . -670) (t 24235 37905 220859 173000) (1 . 671) ("#!/usr/bin/env python3


class User:
    def __init__(self, first, last, age):
        self.first = first.title()
        self.last = last.title()
        self.age = age
        self.login_attempts = 1

    def greet_user(self):
        print(f\"\\n>> Welcome, {self.first} {self.last}! <<\\n\")

    def describe_user(self):
        print(\"## User Info ##\\n\")
        print(f\"Name: {self.first} {self.last}\")
        print(f\"Age: {self.age}\")
        print(f\"Login Attempts: {self.login_attempts}\")

    def increment_login_attempts(self):
        self.login_attempts += 1


u = User(\"dave\", \"jones\", 37)

u.describe_user()
u.greet_user()

u.describe_user()
u.greet_user()

" . 1) ((marker . 738) . -670) ((marker . 756) . -671) ((marker . 755) . -670) ((marker . 1) . -637) ((marker . 1) . -637) ((marker . 1) . -669) ((marker . 738) . -670) ((marker . 755) . -670) ((marker . 1) . -603) ((marker . 1) . -602) ((marker . 1) . -292) ((marker . 1) . -603) ((marker) . -603) ((marker . 1) . -603) ((marker . 1) . -603) ((marker . 1) . -603) ((marker . 1) . -292) ((marker . 1) . -635) ((marker . 1) . -637) ((marker . 1) . -603) ((marker . 1) . -292) ((marker . 1) . -637) ((marker . 1) . -637) ((marker . 1) . -637) ((marker . 1) . -637) ((marker . 1) . -637) ((marker . 1) . -637) ((marker . 1) . -292) ((marker . 1) . -669) ((marker . 585) . -570) ((marker . 1) . -670) ((marker . 738) . -670) ((marker . 1) . -670) ((marker . 1) . -637) ((marker . 1) . -570) ((marker . 1) . -670) ((marker . 1) . -670) ((marker . 1) . -570) nil ("
u.describe_user()
u.greet_user()
" . 671) ((marker . 755) . -33) ((marker . 738) . -1) ((marker . 755) . -33) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) (704 . 705) (nil rear-nonsticky t 671 . 672) (t 24235 37896 268692 448000) nil (nil rear-nonsticky nil 671 . 672) ("
" . -704) (671 . 705) nil (670 . 671) 669 (t 24235 37895 228189 52000) nil (nil rear-nonsticky nil 637 . 638) ("
" . -670) (637 . 671) nil (636 . 637) 635 (t 24235 37892 187545 322000) nil (1 . 637) ("#!/usr/bin/env python3


class User:
    def __init__(self, first, last, age):
        self.first = first.title()
        self.last = last.title()
        self.age = age
        self.login_attempts = 1

    def greet_user(self):
        print(f\"\\n>> Welcome, {self.first} {self.last}! <<\\n\")

    def describe_user(self):
        print(\"## User Info ##\\n\")
        print(f\"Name: {self.first} {self.last}\")
        print(f\"Age: {self.age}\")
        print(f\"Login Attempts: {self.login_attempts}\")

    def increment_login_attempts(self):
        self.login_attempts += 1

u = User(\"dave\", \"jones\", 37)

u.describe_user()
u.greet_user()
" . 1) ((marker . 738) . -570) ((marker . 756) . -571) ((marker . 755) . -497) ((marker . 1) . -170) ((marker . 1) . -233) ((marker* . 756) . 143) ((marker . 1) . -497) ((marker* . 756) . 65) ((marker . 1) . -497) ((marker . 1) . -537) ((marker . 1) . -568) ((marker . 1) . -568) ((marker . 1) . -568) ((marker . 1) . -568) ((marker . 1) . -568) ((marker . 1) . -568) ((marker . 1) . -568) ((marker . 1) . -568) ((marker . 1) . -24) ((marker . 1) . -568) ((marker . 1) . -568) ((marker . 1) . -24) ((marker . 1) . -496) ((marker . 1) . -496) ((marker . 1) . -24) ((marker . 1) . -568) ((marker . 1) . -496) ((marker . 1) . -496) ((marker . 1) . -496) ((marker . 1) . -496) ((marker . 1) . -24) ((marker . 1) . -496) ((marker . 1) . -203) ((marker . 1) . -203) ((marker . 1) . -203) ((marker . 1) . -203) ((marker . 1) . -203) ((marker . 1) . -24) ((marker . 1) . -203) ((marker . 1) . -203) ((marker . 1) . -24) ((marker . 1) . -203) ((marker . 1) . -203) ((marker . 1) . -24) ((marker . 1) . -284) ((marker . 1) . -284) ((marker . 1) . -203) ((marker . 1) . -284) ((marker . 1) . -284) ((marker . 1) . -284) ((marker . 1) . -496) ((marker . 1) . -496) ((marker . 1) . -284) ((marker . 1) . -496) ((marker . 1) . -496) ((marker . 1) . -496) ((marker . 1) . -496) ((marker . 1) . -501) ((marker . 1) . -497) ((marker . 1) . -501) ((marker . 1) . -501) ((marker . 1) . -202) ((marker . 1) . -501) ((marker . 1) . -501) ((marker . 1) . -202) ((marker . 1) . -297) ((marker . 1) . -326) ((marker . 1) . -170) ((marker . 1) . -207) ((marker . 1) . -233) ((marker . 1) . -170) ((marker . 1) . -233) ((marker . 1) . -233) ((marker . 1) . -170) ((marker . 1) . -233) ((marker . 1) . -233) ((marker . 1) . -170) ((marker . 1) . -233) ((marker . 738) . -570) ((marker . 585) . -292) ((marker) . -537) ((marker) . -538) ((marker) . -541) ((marker) . -542) ((marker) . -497) ((marker) . -498) ((marker) . -440) ((marker) . -441) ((marker) . -444) ((marker) . -445) ((marker) . -406) ((marker) . -407) ((marker) . -410) ((marker) . -411) ((marker) . -357) ((marker) . -358) ((marker) . -361) ((marker) . -362) ((marker) . -322) ((marker) . -323) ((marker) . -326) ((marker) . -327) ((marker) . -293) ((marker) . -294) ((marker) . -229) ((marker) . -230) ((marker) . -233) ((marker) . -234) ((marker) . -203) ((marker) . -204) ((marker) . -170) ((marker) . -171) ((marker) . -174) ((marker) . -175) ((marker) . -147) ((marker) . -148) ((marker) . -151) ((marker) . -152) ((marker) . -114) ((marker) . -115) ((marker) . -118) ((marker) . -119) ((marker) . -79) ((marker) . -80) ((marker) . -83) ((marker) . -84) ((marker) . -37) ((marker) . -38) ((marker . 1) . -570) ((marker . 1) . -570) ((marker . 1) . -292) ((marker . 1) . -237) ((marker . 1) . -237) ((marker . 1) . -330) ((marker . 1) . -330) ((marker . 1) . -365) ((marker . 1) . -365) ((marker . 1) . -414) ((marker . 1) . -414) ((marker . 1) . -448) ((marker . 1) . -448) ((marker . 1) . -571) ((marker . 1) . -571) ((marker . 1) . -575) ((marker . 1) . -571) ((marker . 1) . -571) ((marker . 1) . -575) ((marker . 1) . -570) 571 nil (1 . 636) ("#!/usr/bin/env python3


class User:
    def __init__(self, first, last, age):
        self.first = first.title()
        self.last = last.title()
        self.age = age
        self.login_attempts = 1

    def greet_user(self):
        print(f\"\\n>> Welcome, {self.first} {self.last}! <<\\n\")

    def describe_user(self):
        print(\"## User Info ##\\n\")
        print(f\"Name: {self.first} {self.last}\")
        print(f\"Age: {self.age}\")
        print(f\"Login Attempts: {self.login_attempts}\")

    def increment_login_attempts(self):
        self.login_attempts += 1


u = User(\"dave\", \"jones\", 37)

u.describe_user()
u.greet_user()
" . 1) ((marker . 738) . -603) ((marker . 756) . -621) ((marker . 1) . -537) ((marker . 738) . -603) ((marker . 585) . -229) ((marker) . -203) ((marker) . -204) ((marker) . -170) ((marker) . -171) ((marker) . -174) ((marker) . -175) ((marker) . -147) ((marker) . -148) ((marker) . -151) ((marker) . -152) ((marker) . -114) ((marker) . -115) ((marker) . -118) ((marker) . -119) ((marker) . -79) ((marker) . -80) ((marker) . -83) ((marker) . -84) ((marker) . -37) ((marker) . -38) ((marker . 1) . -537) ((marker . 1) . -537) ((marker . 1) . -292) ((marker . 1) . -537) ((marker . 1) . -537) ((marker . 1) . -292) ((marker . 1) . -537) ((marker . 1) . -537) ((marker . 1) . -229) ((marker . 1) . -537) ((marker) . -537) ((marker) . -538) ((marker) . -541) ((marker) . -542) ((marker) . -497) ((marker) . -498) ((marker) . -440) ((marker) . -441) ((marker) . -444) ((marker) . -445) ((marker) . -406) ((marker) . -407) ((marker) . -410) ((marker) . -411) ((marker) . -357) ((marker) . -358) ((marker) . -361) ((marker) . -362) ((marker) . -322) ((marker) . -323) ((marker) . -326) ((marker) . -327) ((marker) . -293) ((marker) . -294) ((marker) . -229) ((marker) . -230) ((marker) . -233) ((marker) . -234) ((marker . 1) . -537) ((marker . 1) . -537) ((marker . 1) . -537) ((marker . 1) . -229) ((marker . 1) . -537) ((marker . 1) . -570) ((marker . 1) . -537) ((marker . 1) . -229) ((marker . 1) . -570) ((marker . 1) . -571) ((marker . 1) . -570) ((marker . 1) . -229) ((marker . 1) . -571) ((marker . 1) . -572) ((marker . 1) . -571) ((marker . 1) . -229) ((marker . 1) . -572) ((marker . 1) . -602) ((marker . 1) . -572) ((marker . 1) . -229) ((marker . 1) . -602) ((marker . 1) . -603) ((marker . 1) . -602) ((marker . 1) . -229) ((marker . 1) . -603) ((marker . 1) . -621) ((marker . 1) . -603) ((marker . 1) . -229) ((marker . 1) . -621) ((marker . 1) . -636) ((marker . 1) . -621) ((marker . 1) . -229) ((marker . 1) . -636) ((marker . 1) . -636) ((marker . 1) . -636) ((marker . 1) . -229) ((marker . 1) . -636) ((marker . 1) . -636) ((marker . 1) . -636) ((marker . 1) . -229) ((marker . 1) . -636) ((marker . 1) . -636) ((marker . 1) . -636) ((marker . 1) . -229) ((marker . 1) . -636) ((marker . 1) . -621) ((marker . 1) . -636) ((marker . 1) . -229) ((marker . 1) . -621) ((marker . 1) . -603) ((marker . 1) . -621) ((marker . 1) . -229) ((marker . 1) . -603) (t 24235 37884 282371 978000) nil (1 . 637) ("#!/usr/bin/env python3


class User:
    def __init__(self, first, last, age):
        self.first = first.title()
        self.last = last.title()
        self.age = age
        self.login_attempts = 1

    def greet_user(self):
        print(f\"\\n>> Welcome, {self.first} {self.last}! <<\\n\")

    def describe_user(self):
        print(\"## User Info ##\\n\")
        print(f\"Name: {self.first} {self.last}\")
        print(f\"Age: {self.age}\")
        print(f\"Login Attempts: {self.login_attempts}\")

    def increment_login_attempts(self):
        self.login_attempts += 1

u = User(\"dave\", \"jones\", 37)

u.describe_user()
u.greet_user()
" . 1) ((marker . 738) . -570) ((marker . 756) . -571) ((marker . 755) . -497) ((marker . 1) . -170) ((marker . 1) . -233) ((marker* . 756) . 143) ((marker . 1) . -497) ((marker* . 756) . 65) ((marker . 1) . -497) ((marker . 1) . -537) ((marker . 1) . -568) ((marker . 1) . -568) ((marker . 1) . -568) ((marker . 1) . -568) ((marker . 1) . -568) ((marker . 1) . -568) ((marker . 1) . -568) ((marker . 1) . -568) ((marker . 1) . -24) ((marker . 1) . -568) ((marker . 1) . -568) ((marker . 1) . -24) ((marker . 1) . -496) ((marker . 1) . -496) ((marker . 1) . -24) ((marker . 1) . -568) ((marker . 1) . -496) ((marker . 1) . -496) ((marker . 1) . -496) ((marker . 1) . -496) ((marker . 1) . -24) ((marker . 1) . -496) ((marker . 1) . -203) ((marker . 1) . -203) ((marker . 1) . -203) ((marker . 1) . -203) ((marker . 1) . -203) ((marker . 1) . -24) ((marker . 1) . -203) ((marker . 1) . -203) ((marker . 1) . -24) ((marker . 1) . -203) ((marker . 1) . -203) ((marker . 1) . -24) ((marker . 1) . -284) ((marker . 1) . -284) ((marker . 1) . -203) ((marker . 1) . -284) ((marker . 1) . -284) ((marker . 1) . -284) ((marker . 1) . -496) ((marker . 1) . -496) ((marker . 1) . -284) ((marker . 1) . -496) ((marker . 1) . -496) ((marker . 1) . -496) ((marker . 1) . -496) ((marker . 1) . -501) ((marker . 1) . -497) ((marker . 1) . -501) ((marker . 1) . -501) ((marker . 1) . -202) ((marker . 1) . -501) ((marker . 1) . -501) ((marker . 1) . -202) ((marker . 1) . -297) ((marker . 1) . -326) ((marker . 1) . -170) ((marker . 1) . -207) ((marker . 1) . -233) ((marker . 1) . -170) ((marker . 1) . -233) ((marker . 1) . -233) ((marker . 1) . -170) ((marker . 1) . -233) ((marker . 1) . -233) ((marker . 1) . -170) ((marker . 1) . -233) ((marker . 738) . -570) ((marker . 585) . -292) 571 nil ("
" . 571) ((marker . 756) . -1) ((marker* . 756) . 1) (t 24235 37881 920829 990000) nil (479 . 493) ("lo" . -479) ((marker . 738) . -2) 481 (479 . 481) ("age" . 479) (t 24235 37877 770537 251000) nil (457 . 471) ("Age" . 457) nil (440 . 474) 415 nil ("1" . 518) nil ("1" . 550) nil ("1" . 569) (t 24235 37632 549003 129000) nil ("        print(f\"Birth Year: {self.age}\")
" . 441) ((marker . 756) . -41) ((marker . 738) . -39) ((marker . 1) . -41) ((marker . 1) . -41) ((marker . 1) . -41) ((marker . 1) . -41) ((marker . 1) . -41) ((marker . 1) . -41) ((marker . 1) . -41) ((marker*) . 2) ((marker) . -40) ((marker*) . 28) ((marker) . -14) 480 (t 24235 37617 217738 296000) nil (285 . 286) ("m" . -285) ((marker . 738) . -1) 286 (285 . 286) (t 24235 37600 219893 840000) nil ("
    def greet_user(self):
        print(f\"\\n>> Welcome, {self.first} {self.last}!<<\\n\")
" . 481) ((marker . 738) . -27) ((marker . 756) . -89) ((marker . 755) . -58) ((marker . 1) . -58) ((marker . 738) . -58) ((marker . 1) . -58) ((marker . 1) . -89) ((marker . 1) . -58) ((marker . 1) . -58) ((marker . 1) . -58) ((marker . 1) . -58) (292 . 481) ("
    def describe_user(self):
        print(\"## User Info ##\\n\")
        print(f\"Name: {self.first} {self.last}\")
        print(f\"Age: {self.age}\")
        print(f\"Birth Year: {self.age}\")
" . 203) (392 . 481) 450 (t 24235 37573 968146 156000) nil (1 . 624) ("#!/usr/bin/env python3


class User:
    def __init__(self, first, last, age):
        self.first = first.title()
        self.last = last.title()
        self.age = age
        self.login_attempts = 1

    def describe_user(self):
        print(\"## User Info ##\\n\")
        print(f\"Name: {self.first} {self.last}\")
        print(f\"Age: {self.age}\")
        print(f\"Birth Year: {self.age}\")

    def greet_user(self):
        print(f\"\\n>> Welcome, {self.first} {self.last}!<<\\n\")

    def increment_login_attempts(self):
        self.login_attempts += 1



u1 = User(\"dave\", \"jones\", 37)

u1.describe_user()
u1.greet_user()
" . 1) ((marker . 738) . -521) ((marker . 756) . -554) ((marker . 755) . -554) ((marker . 1) . -554) ((marker* . 756) . 71) ((marker . 1) . -588) ((marker* . 756) . 36) ((marker . 1) . -588) ((marker . 1) . -588) ((marker . 755) . -624) ((marker . 1) . -624) ((marker . 1) . -24) ((marker . 1) . -200) ((marker . 1) . -200) ((marker . 1) . -200) ((marker . 1) . -200) ((marker . 1) . -554) ((marker . 1) . -554) ((marker . 1) . -554) ((marker . 1) . -554) ((marker . 1) . -554) ((marker . 1) . -554) ((marker . 1) . -554) ((marker . 738) . -552) 553 nil (549 . 554) (" +=" . -549) ((marker . 738) . -2) 552 (551 . 552) (" " . -551) ((marker . 738) . -1) ("1" . -552) ((marker . 738) . -1) 553 (549 . 553) (" +" . -549) ((marker . 738) . -1) 551 (549 . 551) (535 . 549) ("log" . -535) ((marker . 738) . -3) 538 (535 . 538) ("o" . -535) ((marker . 738) . -1) 536 (530 . 536) (521 . 530) (t 24235 37562 783197 195000) 518 nil ("        " . 522) ((marker . 755) . -7) ((marker . 1) . -7) ((marker . 1) . -7) ((marker . 1) . -7) ((marker . 1) . -7) ((marker . 1) . -7) ((marker . 1) . -7) ((marker . 1) . -7) ((marker . 1) . -7) 518 nil ("," . -519) ((marker . 738) . -1) (" " . -520) ((marker . 738) . -1) 521 (519 . 521) ("," . -519) 520 (519 . 520) (t 24235 37477 221570 520000) nil (520 . 530) (514 . 519) ("(" . -514) (514 . 516) ("(" . -514) (507 . 515) (486 . 507) ("    " . -486) ((marker . 738) . -4) 490 (482 . 490) ("        " . 481) ((marker . 738) . -8) (489 . 490) (480 . 489) (t 24235 37441 392430 4000) 419 nil (198 . 202) ("=" . -198) 199 (195 . 199) (184 . 195) (apply yas--snippet-revive 179 184 #s(yas--snippet nil nil #s(yas--exit 184 nil) 7 nil nil nil nil)) (apply yas--take-care-of-redo #s(yas--snippet nil nil #s(yas--exit 184 nil) 7 nil nil nil nil)) (179 . 184) ("." . 179) ((marker . 738) . -1) 180 nil (179 . 180) (170 . 179) (t 24235 37431 457648 748000) 160 nil ("
u2.describe_user()
u2.greet_user()

u3.describe_user()
u3.greet_user()
" . 518) ((marker . 756) . -1) ((marker . 755) . -71) ((marker . 1) . -70) nil ("u2 = User(\"mr\", \"big\", 27)
u3 = User(\"laura\", \"black\", 15)
" . 482) ((marker . 738) . -27) ((marker . 756) . -59) ((marker . 755) . -27) ((marker . 738) . -27) ((marker . 1) . -27) ((marker) . -27) 509 (t 24235 37372 946243 993000) nil (nil rear-nonsticky nil 648 . 649) (nil fontified nil 1 . 649) (1 . 649) ("#!/usr/bin/env python3
" . 1) ((marker . 756) . -23) ((marker . 755) . -23) ((marker . 1) . -23) ((marker . 1) . -23) ((marker . 1) . -23) ((marker . 1) . -22) ((marker) . -22) (t 24235 37366 377315 991000) nil (1 . 24) ("#!/usr/bin/env python3

" . -1) ((marker . 738) . -24) ((marker . 756) . -24) ((marker . 1) . -23) ((marker . 738) . -24) ((marker . 1) . -24) ((marker . 1) . -24) 25 nil (24 . 25) (t 24235 37354 74208 625000) (1 . 24) ("#!/usr/bin/env python3

" . -1) ((marker . 738) . -24) ((marker . 756) . -24) ((marker . 1) . -23) ((marker . 738) . -24) 25 (24 . 25) (t 24235 37342 356597 773000) (1 . 24) ("#!/usr/bin/env python3

" . -1) ((marker . 738) . -24) ((marker . 756) . -24) ((marker . 1) . -23) ((marker . 738) . -24) 25 (24 . 25) (t 24235 37310 960529 982000) 24 nil (1 . 24) ("#!/usr/bin/env python3

" . -1) ((marker . 738) . -24) ((marker . 756) . -24) ((marker . 738) . -24) 25 nil (1 . 25) (t 24234 22106 276802 932000)) (emacs-undo-equiv-table (-22 . -26) (-23 . -25) (-29 . -31) (6 . -1) (-16 . -18) (8 . 10) (7 . 11)))