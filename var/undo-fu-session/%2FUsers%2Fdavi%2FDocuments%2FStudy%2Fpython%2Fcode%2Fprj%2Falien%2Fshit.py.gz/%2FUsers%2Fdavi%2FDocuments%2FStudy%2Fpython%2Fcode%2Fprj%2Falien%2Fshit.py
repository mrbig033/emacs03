((buffer-size . 308) (buffer-checksum . "a4486376c76aee7ec17a380d4b0b315d9c6df6fd"))
((emacs-pending-undo-list (1 . 13924) (t . 0)) (emacs-buffer-undo-list nil (11 . 12) 1 (t 24252 53721 810977 573000) nil ("
" . 12) ((marker . 13) . -1) ((marker . 13) . -1) ((marker . 13) . -1) ((marker . 13) . -1) ((marker . 13) . -1) ((marker . 13) . -1) ((marker . 13) . -1) ((marker . 13) . -1) ((marker . 13) . -1) ((marker . 13) . -1) ((marker . 13) . -1) ((marker . 13) . -1) ((marker . 13) . -1) ((marker* . 13) . 1) ((marker . 13) . -1) ((marker . 13) . -1) ((marker . 13) . -1) ((marker . 13) . -1) (t 24252 53718 666155 931000) nil (1 . 12) ("import sys  
" . -1) ((marker . 1) . -13) ((marker* . 13) . 2) ((marker . 1) . -10) ((marker . 1) . -10) ((marker . 12) . -10) ((marker) . -6) ((marker) . -10) ((marker) . -11) ((marker . 1) . -13) ((marker) . -6) ((marker) . -10) ((marker) . -11) 14 (t 24252 53718 176749 903000) nil (11 . 12) nil ("s" . -11) ((marker . 12) . -1) (" " . -12) ((marker . 12) . -1) 13 nil (11 . 13) nil ("a" . -11) ((marker . 12) . -1) (" " . -12) ((marker . 12) . -1) 13 nil (11 . 13) nil (11 . 12) (t 24252 53707 940661 284000) nil ("
        


" . -309) (49 . 50) 13 (t 24252 53707 474353 821000) nil (13 . 48) 32 ("import pygame as p
" . 13) ((marker . 13) . -19) ((marker . 12) . -19) 32 (t 24246 56752 436882 819000)) (emacs-undo-equiv-table))