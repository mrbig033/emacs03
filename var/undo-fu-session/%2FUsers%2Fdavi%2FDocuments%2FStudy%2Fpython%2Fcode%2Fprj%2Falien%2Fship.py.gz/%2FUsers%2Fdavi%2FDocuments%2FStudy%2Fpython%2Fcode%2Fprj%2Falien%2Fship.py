((buffer-size . 465) (buffer-checksum . "62590b673e9beb13788e30d6f9a15ad09f3a1a61"))
((emacs-pending-undo-list (11 . 12) 1 (t 24252 53721 810977 573000) nil ("
" . 12) ((marker) . -1) ((marker) . -1) ((marker) . -1) ((marker) . -1) ((marker) . -1) ((marker) . -1) ((marker) . -1) ((marker) . -1) ((marker) . -1) ((marker) . -1) ((marker) . -1) ((marker*) . 1) (t 24252 53718 666155 931000) nil (1 . 12) ("import sys  
" . -1) ((marker) . -13) ((marker*) . 2) ((marker . 206) . -10) 14 (t 24252 53718 176749 903000) nil (11 . 12) nil ("s" . -11) ((marker . 206) . -1) (" " . -12) ((marker . 206) . -1) 13 nil (11 . 13) nil ("a" . -11) ((marker . 206) . -1) (" " . -12) ((marker . 206) . -1) 13 nil (11 . 13) nil (11 . 12) (t 24252 53707 940661 284000) nil ("
        


" . -309) (49 . 50) 13 (t 24252 53707 474353 821000) nil (13 . 48) 32 ("import pygame as p
" . 13) ((marker) . -19) ((marker) . -19) 32 (t 24246 56752 436882 819000)) (emacs-buffer-undo-list nil (165 . 168) ("r" . -165) ((marker . 206) . -1) ((marker . 165) . -1) ((marker . 165) . -1) ((marker . 165) . -1) ((marker . 165) . -1) ((marker . 165) . -1) ("v" . -166) ((marker . 206) . -1) ((marker . 165) . -1) 167 (165 . 167) ("t" . -165) ((marker . 206) . -1) ((marker . 165) . -1) 166 (163 . 166) (t 24247 1196 296369 326000)) (emacs-undo-equiv-table))