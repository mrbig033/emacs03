((buffer-size . 1156) (buffer-checksum . "a0402fce821501c3deef935138208f3be1b60d16"))
((emacs-pending-undo-list (76 . 77) (nil face font-lock-doc-face 75 . 76) (nil fontified t 75 . 76) (75 . 76) (t 24237 21106 593673 390000) 25 nil ("

" . -1157) ((marker . 76) . -2) ((marker . 77) . -2) ((marker . 1157) . -2) ((marker . 1157) . -2) ((marker . 1157) . -2) ((marker . 1157) . -2) ((marker . 1157) . -2) ((marker . 1157) . -2) ((marker . 1157) . -2) ((marker . 1157) . -2) ((marker . 1157) . -2) ((marker . 1157) . -2) ((marker . 76) . -2) ((marker . 1157) . -2) ((marker . 1157) . -1) ((marker . 1157) . -2) ((marker . 1157) . -1) ((marker . 1157) . -2) ((marker . 1157) . -2) ((marker . 1157) . -2) ((marker . 1157) . -2) ((marker . 1157) . -2) ((marker . 1157) . -2) ((marker . 1157) . -2) ((marker . 1157) . -2) ((marker . 1157) . -2) ((marker . 1157) . -2) ((marker . 1157) . -2) ((marker . 1157) . -2) ((marker . 1157) . -2) ((marker . 1157) . -2) ((marker . 1157) . -2) ((marker . 1157) . -2) ((marker . 1157) . -2) ((marker . 1157) . -2) ((marker . 1157) . -2) ((marker . 1157) . -2) ((marker . 1157) . -2) ((marker . 1157) . -2) ((marker) . -1) ((marker) . -2) ((marker . 1157) . -2) ((marker . 1157) . -2) ((marker) . -2) 1159 (t 24237 21106 17588 527000) nil ("class Battery:
    \"\"\"Model for an eletric car battery.\"\"\"

    def __init__(self, battery_size=75):
        self.battery_size = battery_size

    def describe_battery(self):
        \"\"\"Describe battery size.\"\"\"
        print(f\"This car has a {self.battery_size} kWh battery.\")

    def update_battery(self, charge):
        self.battery_size += charge

    def get_range(self):
        \"\"\"Print a statement about the car's range.\"\"\"

        if self.battery_size == 75:
            range = 260
        elif self.battery_size == 100:
            range = 315

        print(f\"This car can go about {range} miles on a full charge.\")


class ElectricCar(Car):
    \"\"\"Aspects specific to electric vehicles.\"\"\"

    def __init__(self, make, model, year):
        \"\"\"Initialize attributes of the parent class.\"\"\"
        super().__init__(make, model, year)
        self.battery = Battery()
" . 1159) ((marker . 77) . -15) ((marker . 1157) . -639) ((marker) . -495) ((marker) . -496) ((marker) . -499) ((marker) . -500) ((marker . 1157) . -639) ((marker . 1157) . -6) ((marker . 1157) . -633) ((marker . 76) . -6) ((marker) . -495) ((marker) . -496) ((marker) . -499) ((marker) . -500) ((marker) . -471) ((marker) . -472) ((marker) . -475) ((marker) . -476) ((marker) . -479) ((marker) . -480) ((marker) . -435) ((marker) . -436) ((marker) . -439) ((marker) . -440) ((marker) . -379) ((marker) . -380) ((marker) . -383) ((marker) . -384) ((marker) . -354) ((marker) . -355) ((marker) . -317) ((marker) . -318) ((marker) . -321) ((marker) . -322) ((marker) . -279) ((marker) . -280) ((marker) . -212) ((marker) . -213) ((marker) . -216) ((marker) . -217) ((marker) . -175) ((marker) . -176) ((marker) . -179) ((marker) . -180) ((marker) . -143) ((marker) . -144) ((marker) . -101) ((marker) . -102) ((marker) . -105) ((marker) . -106) ((marker) . -60) ((marker) . -61) ((marker) . -15) ((marker) . -16) ((marker . 1157) . -6) ((marker . 1157) . -6) ((marker . 1157) . -6) ((marker . 1157) . -631) ((marker . 1157) . -6) ((marker . 1157) . -632) ((marker . 1157) . -631) ((marker . 1157) . -639) ((marker . 1157) . -632) ((marker . 1157) . -639) ((marker . 1157) . -639) ((marker) . -884) ((marker . 1157) . -639) ((marker . 1157) . -639) ((marker) . -6) ((marker) . -639) ((marker . 1157) . -632) ((marker . 1157) . -639) ((marker . 1157) . -631) ((marker . 1157) . -632) ((marker . 1157) . -6) ((marker . 1157) . -631) 1165 (t 24237 19626 123157 448000) nil (503 . 504) ("(" . -503) (503 . 505) ("(" . -503) (497 . 504) (t 24237 19617 309847 397000) nil (".title()" . 524) (t 24237 19612 704045 452000) nil ("." . -285) 286 (285 . 286) (t 24237 19567 146377 87000) nil (2010 . 2043) ("        self.battery = Battery()" . -2010) 1874 (t 24237 19566 517161 813000) nil ("
" . -2042) 2043 nil ("
" . -2043) 2044 nil ("
my_tesla = ElectricCar(\"tesla\", \"model s\", 2019)

print(my_tesla.get_descriptive_name())
my_tesla.battery.describe_battery()
my_tesla.battery.get_range()

print()

# my_tesla.battery.battery_size = 100

my_tesla.battery.describe_battery()
my_tesla.battery.get_range()
" . 2044) (t 24237 19371 411828 717000) nil (67 . 72) (46 . 67) (28 . 46) (28 . 30) (28 . 29) (nil face font-lock-doc-face 27 . 28) (nil fontified nil 27 . 28) (27 . 28) ("\"" . -27) (27 . 28) ("\"" . -27) (27 . 28) (nil face font-lock-doc-face 26 . 27) (nil fontified nil 26 . 27) (26 . 27) ("\"" . -26) (nil face font-lock-doc-face 26 . 27) (nil fontified nil 26 . 27) (26 . 27) ("\"" . -26) ("\"" . 27) (25 . 27) ("\"" . -25) (25 . 26) ("\"" . -25) (25 . 27) ("\"" . -25) (25 . 26) (24 . 25) (23 . 24) (t 24237 19310 57478 437000) 1 nil ("my_tesla.battery.
" . 2196) (t 24237 19291 557999 362000) nil (794 . 802) nil (793 . 794) (t 24237 19265 491398 788000) nil (";" . 447) (447 . 448) (".title(" . 447) (453 . 454) ("()" . 453) (453 . 454) ("(" . 453) (t 24237 19264 729714 194000) nil (453 . 454) ("(" . 453) (453 . 455) ("(" . 453) (447 . 454) (";" . 447) (447 . 448) (t 24237 19263 339376 535000) nil (";" . 447) (447 . 448) (".title(" . 447) (453 . 454) ("()" . 453) (453 . 454) ("(" . 453) (t 24237 19257 164521 872000) nil (453 . 454) ("(" . -453) (453 . 455) ("(" . -453) (447 . 454) (";" . -447) 448 (447 . 448) (t 24237 19198 212523 977000) nil (nil rear-nonsticky nil 2269 . 2270) (nil fontified nil 1 . 2270) (1 . 2270) ("#!/usr/bin/env python3
" . 1) (t 24237 19189 509704 132000) nil ("
" . -24) 25 (t 24237 19189 19710 47000) nil (1 . 25) (t 24237 19176 431579 42000)) (emacs-buffer-undo-list (77 . 78) (t 24237 21141 555115 627000) nil ("
" . 77) ((marker . 77) . -1) ((marker* . 78) . 1) ((marker . 77) . -1) ((marker . 77) . -1) ((marker . 77) . -1) ((marker . 77) . -1) ((marker . 77) . -1) ((marker . 77) . -1) ((marker . 77) . -1) ((marker . 77) . -1) ((marker . 77) . -1) (t 24237 21140 739725 337000) nil ("

" . -78) ((marker . 77) . -2) ((marker) . -2) 76 (t 24237 21140 254531 925000) nil (76 . 77) (nil face font-lock-doc-face 75 . 76) (75 . 76) (t 24237 21139 424852 443000) nil ("

" . 1157) ((marker . 76) . -2) ((marker . 77) . -2) ((marker . 1157) . -2) ((marker . 1157) . -2) ((marker . 1157) . -2) ((marker . 1157) . -2) ((marker . 1157) . -2) ((marker . 1157) . -2) ((marker . 1157) . -2) ((marker . 1157) . -2) ((marker . 1157) . -2) ((marker . 1157) . -2) ((marker . 76) . -2) ((marker . 1157) . -2) ((marker . 1157) . -1) ((marker . 1157) . -2) ((marker . 1157) . -1) ((marker . 1157) . -2) ((marker . 1157) . -2) ((marker . 1157) . -2) ((marker . 1157) . -2) ((marker . 1157) . -2) ((marker . 1157) . -2) ((marker . 1157) . -2) ((marker . 1157) . -2) ((marker . 1157) . -2) ((marker . 1157) . -2) ((marker . 1157) . -2) ((marker . 1157) . -2) ((marker . 1157) . -2) ((marker . 1157) . -2) ((marker . 1157) . -2) ((marker . 1157) . -2) ((marker . 1157) . -2) ((marker . 1157) . -2) ((marker . 1157) . -2) ((marker . 1157) . -2) ((marker . 1157) . -2) ((marker . 1157) . -2) ((marker . 1157) . -2) ((marker . 1157) . -2) ((marker . 1157) . -2) ((marker) . -1) ((marker) . -2) (t 24237 21139 256400 979000) nil (1157 . 1159) (t 24237 21138 606636 521000) nil ("
" . 75) ((marker . 76) . -1) ((marker . 76) . -1) ((marker . 76) . -1) ((marker . 76) . -1) ((marker . 76) . -1) ((marker . 77) . -1) ((marker . 77) . -1) ((marker . 77) . -1) ((marker . 76) . -1) ((marker . 77) . -1) ((marker . 77) . -1) (nil fontified nil 75 . 76) (nil face nil 75 . 76) ("
" . 76) ((marker . 76) . -1) ((marker . 76) . -1) ((marker* . 76) . 1) ((marker . 77) . -1) ((marker . 77) . -1) ((marker . 77) . -1) ((marker . 77) . -1) ((marker . 77) . -1) (t 24237 21138 430247 839000) nil (76 . 77) (nil face font-lock-doc-face 75 . 76) (nil fontified t 75 . 76) (75 . 76) (t 24237 21106 593673 390000) 25 nil ("

" . -1157) ((marker . 76) . -2) ((marker . 77) . -2) ((marker . 1157) . -2) ((marker . 1157) . -2) ((marker . 1157) . -2) ((marker . 1157) . -2) ((marker . 1157) . -2) ((marker . 1157) . -2) ((marker . 1157) . -2) ((marker . 1157) . -2) ((marker . 1157) . -2) ((marker . 1157) . -2) ((marker . 76) . -2) ((marker . 1157) . -2) ((marker . 1157) . -1) ((marker . 1157) . -2) ((marker . 1157) . -1) ((marker . 1157) . -2) ((marker . 1157) . -2) ((marker . 1157) . -2) ((marker . 1157) . -2) ((marker . 1157) . -2) ((marker . 1157) . -2) ((marker . 1157) . -2) ((marker . 1157) . -2) ((marker . 1157) . -2) ((marker . 1157) . -2) ((marker . 1157) . -2) ((marker . 1157) . -2) ((marker . 1157) . -2) ((marker . 1157) . -2) ((marker . 1157) . -2) ((marker . 1157) . -2) ((marker . 1157) . -2) ((marker . 1157) . -2) ((marker . 1157) . -2) ((marker . 1157) . -2) ((marker . 1157) . -2) ((marker . 1157) . -2) ((marker) . -1) ((marker) . -2) ((marker . 1157) . -2) ((marker . 1157) . -2) ((marker) . -2) 1159 (t 24237 21106 17588 527000) nil ("class Battery:
    \"\"\"Model for an eletric car battery.\"\"\"

    def __init__(self, battery_size=75):
        self.battery_size = battery_size

    def describe_battery(self):
        \"\"\"Describe battery size.\"\"\"
        print(f\"This car has a {self.battery_size} kWh battery.\")

    def update_battery(self, charge):
        self.battery_size += charge

    def get_range(self):
        \"\"\"Print a statement about the car's range.\"\"\"

        if self.battery_size == 75:
            range = 260
        elif self.battery_size == 100:
            range = 315

        print(f\"This car can go about {range} miles on a full charge.\")


class ElectricCar(Car):
    \"\"\"Aspects specific to electric vehicles.\"\"\"

    def __init__(self, make, model, year):
        \"\"\"Initialize attributes of the parent class.\"\"\"
        super().__init__(make, model, year)
        self.battery = Battery()
" . 1159) ((marker . 77) . -15) ((marker . 1157) . -639) ((marker) . -495) ((marker) . -496) ((marker) . -499) ((marker) . -500) ((marker . 1157) . -639) ((marker . 1157) . -6) ((marker . 1157) . -633) ((marker . 76) . -6) ((marker) . -495) ((marker) . -496) ((marker) . -499) ((marker) . -500) ((marker) . -471) ((marker) . -472) ((marker) . -475) ((marker) . -476) ((marker) . -479) ((marker) . -480) ((marker) . -435) ((marker) . -436) ((marker) . -439) ((marker) . -440) ((marker) . -379) ((marker) . -380) ((marker) . -383) ((marker) . -384) ((marker) . -354) ((marker) . -355) ((marker) . -317) ((marker) . -318) ((marker) . -321) ((marker) . -322) ((marker) . -279) ((marker) . -280) ((marker) . -212) ((marker) . -213) ((marker) . -216) ((marker) . -217) ((marker) . -175) ((marker) . -176) ((marker) . -179) ((marker) . -180) ((marker) . -143) ((marker) . -144) ((marker) . -101) ((marker) . -102) ((marker) . -105) ((marker) . -106) ((marker) . -60) ((marker) . -61) ((marker) . -15) ((marker) . -16) ((marker . 1157) . -6) ((marker . 1157) . -6) ((marker . 1157) . -6) ((marker . 1157) . -631) ((marker . 1157) . -6) ((marker . 1157) . -632) ((marker . 1157) . -631) ((marker . 1157) . -639) ((marker . 1157) . -632) ((marker . 1157) . -639) ((marker . 1157) . -639) ((marker) . -884) ((marker . 1157) . -639) ((marker . 1157) . -639) ((marker) . -6) ((marker) . -639) ((marker . 1157) . -632) ((marker . 1157) . -639) ((marker . 1157) . -631) ((marker . 1157) . -632) ((marker . 1157) . -6) ((marker . 1157) . -631) 1165 (t 24237 19626 123157 448000) nil (503 . 504) ("(" . -503) (503 . 505) ("(" . -503) (497 . 504) (t 24237 19617 309847 397000) nil (".title()" . 524) (t 24237 19612 704045 452000) nil ("." . -285) 286 (285 . 286) (t 24237 19567 146377 87000) nil (2010 . 2043) ("        self.battery = Battery()" . -2010) 1874 (t 24237 19566 517161 813000) nil ("
" . -2042) 2043 nil ("
" . -2043) 2044 nil ("
my_tesla = ElectricCar(\"tesla\", \"model s\", 2019)

print(my_tesla.get_descriptive_name())
my_tesla.battery.describe_battery()
my_tesla.battery.get_range()

print()

# my_tesla.battery.battery_size = 100

my_tesla.battery.describe_battery()
my_tesla.battery.get_range()
" . 2044) (t 24237 19371 411828 717000) nil (67 . 72) (46 . 67) (28 . 46) (28 . 30) (28 . 29) (nil face font-lock-doc-face 27 . 28) (nil fontified nil 27 . 28) (27 . 28) ("\"" . -27) (27 . 28) ("\"" . -27) (27 . 28) (nil face font-lock-doc-face 26 . 27) (nil fontified nil 26 . 27) (26 . 27) ("\"" . -26) (nil face font-lock-doc-face 26 . 27) (nil fontified nil 26 . 27) (26 . 27) ("\"" . -26) ("\"" . 27) (25 . 27) ("\"" . -25) (25 . 26) ("\"" . -25) (25 . 27) ("\"" . -25) (25 . 26) (24 . 25) (23 . 24) (t 24237 19310 57478 437000) 1 nil ("my_tesla.battery.
" . 2196) (t 24237 19291 557999 362000) nil (794 . 802) nil (793 . 794) (t 24237 19265 491398 788000) nil (";" . 447) (447 . 448) (".title(" . 447) (453 . 454) ("()" . 453) (453 . 454) ("(" . 453) (t 24237 19264 729714 194000) nil (453 . 454) ("(" . 453) (453 . 455) ("(" . 453) (447 . 454) (";" . 447) (447 . 448) (t 24237 19263 339376 535000) nil (";" . 447) (447 . 448) (".title(" . 447) (453 . 454) ("()" . 453) (453 . 454) ("(" . 453) (t 24237 19257 164521 872000) nil (453 . 454) ("(" . -453) (453 . 455) ("(" . -453) (447 . 454) (";" . -447) 448 (447 . 448) (t 24237 19198 212523 977000) nil (nil rear-nonsticky nil 2269 . 2270) (nil fontified nil 1 . 2270) (1 . 2270) ("#!/usr/bin/env python3
" . 1) (t 24237 19189 509704 132000) nil ("
" . -24) 25 (t 24237 19189 19710 47000) nil (1 . 25) (t 24237 19176 431579 42000)) (emacs-undo-equiv-table (3 . -1) (4 . 6) (5 . -3) (6 . -2)))