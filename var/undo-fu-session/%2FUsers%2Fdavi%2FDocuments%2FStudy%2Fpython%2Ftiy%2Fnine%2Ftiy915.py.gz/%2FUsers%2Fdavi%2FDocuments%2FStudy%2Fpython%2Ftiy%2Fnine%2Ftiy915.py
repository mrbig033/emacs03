((buffer-size . 2098) (buffer-checksum . "dc3ea80c6e1e61815a5539b93f755d8825755e15"))
((emacs-pending-undo-list ("

" . 1) ((marker . 26) . -1) ((marker . 26) . -1) ((marker . 2052) . -1) ((marker . 26) . -1) ((marker . 26) . -1) ((marker . 2052) . -1) ((marker . 1) . -1) ((marker) . -1) (2 . 3) (nil rear-nonsticky t 1 . 2) (t 24237 24289 538013 853000) nil (nil rear-nonsticky nil 1 . 2) ("
" . -2) (1 . 3) (t 24234 22267 258715 108000)) (emacs-buffer-undo-list ("
" . -26) ((marker . 26) . -1) ((marker . 26) . -1) ((marker . 26) . -1) ((marker . 26) . -1) ((marker . 26) . -1) ((marker . 26) . -1) ((marker . 26) . -1) (t 24237 24352 692740 719000) nil (24 . 26) (t 24237 24351 193116 183000) nil (2051 . 2098) ("    print(f\"Winning ticket: {winning_ticket}\")" . -2051) ((marker . 2052) . -45) ((marker . 2052) . -45) ((marker . 2052) . -4) ((marker . 2052) . -4) ((marker . 2052) . -45) ((marker) . -1) ((marker . 2052) . -45) ((marker . 2052) . -45) ((marker . 2052) . -45) ((marker) . -45) ((marker) . -46) ((marker) . -4) ((marker) . -46) ((marker . 2052) . -46) (1350 . 1423) ("possibilities = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 'a', 'b', 'c', 'd', 'e']
" . -1350) ((marker . 1351) . -16) ((marker . 1351) . -16) ((marker . 1351) . -16) ((marker . 1351) . -16) ((marker . 1351) . -16) ((marker . 1351) . -73) (890 . 891) (627 . 696) ("    # Check all elements in the played ticket. If any are not in the 
" . -627) ((marker) . -70) ((marker) . -1) ((marker) . -68) ((marker) . -69) ((marker) . -68) ((marker) . -69) ((marker . 628) . -70) ((marker) . -1) (577 . 578) (52 . 53) 1 (t 24237 24350 679131 4000) nil (nil rear-nonsticky nil 2094 . 2095) (nil fontified nil 25 . 2095) (25 . 2095) nil (24 . 25) (t 24237 24340 623046 118000) nil ("
from random import choice

possibilities = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 'a', 'b', 'c', 'd', 'e']

winning_ticket = []
print(\"Let's see what the winning ticket is...\")

# We don't want to repeat winning numbers or letters, so we'll use a
#   while loop.
while len(winning_ticket) < 4:
    pulled_item = choice(possibilities)

    # Only add the pulled item to the winning ticket if it hasn't
    #   already been pulled.
    if pulled_item not in winning_ticket:
        print(f\"  We pulled a {pulled_item}!\")
        winning_ticket.append(pulled_item)
Output:

Let's see what the winning ticket is...
  We pulled a 10!
  We pulled a a!
  We pulled a 2!
  We pulled a 4!

The final winning ticket is: [10, 'a', 2, 4]
top

9-15: Lottery Analysis
You can use a loop to see how hard it might be to win the kind of lottery you just modeled. Make a list or tuple called my_ticket. Write a loop that keeps pulling numbers until your ticket wins. Print a message reporting how many times the loop had to run to give you a winning ticket.

from random import choice

def get_winning_ticket(possibilities):
    \"\"\"Return a winning ticket from a set of possibilities.\"\"\"
    winning_ticket = []

    # We don't want to repeat winning numbers or letters, so we'll use a
    #   while loop.
    while len(winning_ticket) < 4:
        pulled_item = choice(possibilities)

        # Only add the pulled item to the winning ticket if it hasn't
        #   already been pulled.
        if pulled_item not in winning_ticket:
            winning_ticket.append(pulled_item)

    return winning_ticket

def check_ticket(played_ticket, winning_ticket):
    # Check all elements in the played ticket. If any are not in the 
    #   winning ticket, return False.
    for element in played_ticket:
        if element not in winning_ticket:
            return False

    # We must have a winning ticket!
    return True

def make_random_ticket(possibilities):
    \"\"\"Return a random ticket from a set of possibilities.\"\"\"
    ticket = []
    # We don't want to repeat numbers or letters, so we'll use a while loop.
    while len(ticket) < 4:
        pulled_item = choice(possibilities)

        # Only add the pulled item to the ticket if it hasn't already
        #   been pulled.
        if pulled_item not in ticket:
            ticket.append(pulled_item)

    return ticket


possibilities = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 'a', 'b', 'c', 'd', 'e']
winning_ticket = get_winning_ticket(possibilities)

plays = 0
won = False

# Let's set a max number of tries, in case this takes forever!
max_tries = 1_000_000

while not won:
    new_ticket = make_random_ticket(possibilities)
    won = check_ticket(new_ticket, winning_ticket)
    plays += 1
    if plays >= max_tries:
        break

if won:
    print(\"We have a winning ticket!\")
    print(f\"Your ticket: {new_ticket}\")
    print(f\"Winning ticket: {winning_ticket}\")
    print(f\"It only took {plays} tries to win!\")
else:
    print(f\"Tried {plays} times, without pulling a winner. :(\")
    print(f\"Your ticket: {new_ticket}\")
    print(f\"Winning ticket: {winning_ticket}\")" . 24) ((marker . 26) . -3059) ((marker . 26) . -3105) ((marker . 2052) . -3063) ((marker . 26) . -1) ((marker . 2052) . -3104) ((marker . 24) . -1) ((marker . 24) . -3104) ((marker) . -562) ((marker) . -563) ((marker) . -565) ((marker) . -568) ((marker) . -607) ((marker) . -609) ((marker) . -607) ((marker) . -609) ((marker) . -625) ((marker) . -627) ((marker) . -642) ((marker) . -644) ((marker) . -659) ((marker) . -661) ((marker) . -826) ((marker) . -830) ((marker) . -1035) ((marker) . -1039) ((marker) . -1062) ((marker) . -1065) ((marker) . -1586) ((marker) . -1589) ((marker) . -1703) ((marker) . -1704) ((marker) . -1899) ((marker) . -1902) ((marker) . -3104) ((marker) . -3105) ((marker . 24) . -3104) ((marker . 24) . -2357) ((marker . 24) . -2357) ((marker . 24) . -2165) ((marker . 1) . -2120) ((marker . 24) . -2357) ((marker . 26) . -3063) ((marker . 24) . -2357) ((marker . 24) . -2357) ((marker . 24) . -2165) ((marker . 24) . -2357) ((marker . 24) . -2357) ((marker . 24) . -2165) ((marker . 24) . -2357) ((marker . 24) . -2357) ((marker . 24) . -2165) ((marker . 24) . -556) ((marker . 24) . -556) ((marker . 24) . -556) ((marker . 24) . -564) ((marker . 24) . -27) ((marker . 24) . -556) ((marker . 24) . -556) ((marker . 24) . -1) ((marker . 24) . -1) ((marker . 24) . -3063) ((marker) . -1) ((marker) . -3063) ((marker . 24) . -1) 3087 (t 24237 24318 70135 463000) nil (nil rear-nonsticky nil 3128 . 3129) (nil fontified nil 25 . 3129) (25 . 3129) nil (1 . 25) ("from random import choice

possibilities = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 'a', 'b', 'c', 'd', 'e']

winning_ticket = []
print(\"Let's see what the winning ticket is...\")

# We don't want to repeat winning numbers or letters, so we'll use a
#   while loop.
while len(winning_ticket) < 4:
    pulled_item = choice(possibilities)

    # Only add the pulled item to the winning ticket if it hasn't
    #   already been pulled.
    if pulled_item not in winning_ticket:
        print(f\"  We pulled a {pulled_item}!\")
        winning_ticket.append(pulled_item)
Output:

Let's see what the winning ticket is...
  We pulled a 10!
  We pulled a a!
  We pulled a 2!
  We pulled a 4!

The final winning ticket is: [10, 'a', 2, 4]
top

9-15: Lottery Analysis
You can use a loop to see how hard it might be to win the kind of lottery you just modeled. Make a list or tuple called my_ticket. Write a loop that keeps pulling numbers until your ticket wins. Print a message reporting how many times the loop had to run to give you a winning ticket.

from random import choice

def get_winning_ticket(possibilities):
    \"\"\"Return a winning ticket from a set of possibilities.\"\"\"
    winning_ticket = []

    # We don't want to repeat winning numbers or letters, so we'll use a
    #   while loop.
    while len(winning_ticket) < 4:
        pulled_item = choice(possibilities)

        # Only add the pulled item to the winning ticket if it hasn't
        #   already been pulled.
        if pulled_item not in winning_ticket:
            winning_ticket.append(pulled_item)

    return winning_ticket

def check_ticket(played_ticket, winning_ticket):
    # Check all elements in the played ticket. If any are not in the 
    #   winning ticket, return False.
    for element in played_ticket:
        if element not in winning_ticket:
            return False

    # We must have a winning ticket!
    return True

def make_random_ticket(possibilities):
    \"\"\"Return a random ticket from a set of possibilities.\"\"\"
    ticket = []
    # We don't want to repeat numbers or letters, so we'll use a while loop.
    while len(ticket) < 4:
        pulled_item = choice(possibilities)

        # Only add the pulled item to the ticket if it hasn't already
        #   been pulled.
        if pulled_item not in ticket:
            ticket.append(pulled_item)

    return ticket


possibilities = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 'a', 'b', 'c', 'd', 'e']
winning_ticket = get_winning_ticket(possibilities)

plays = 0
won = False

# Let's set a max number of tries, in case this takes forever!
max_tries = 1_000_000

while not won:
    new_ticket = make_random_ticket(possibilities)
    won = check_ticket(new_ticket, winning_ticket)
    plays += 1
    if plays >= max_tries:
        break

if won:
    print(\"We have a winning ticket!\")
    print(f\"Your ticket: {new_ticket}\")
    print(f\"Winning ticket: {winning_ticket}\")
    print(f\"It only took {plays} tries to win!\")
else:
    print(f\"Tried {plays} times, without pulling a winner. :(\")
    print(f\"Your ticket: {new_ticket}\")
    print(f\"Winning ticket: {winning_ticket}\")" . 1) ((marker . 26) . -26) ((marker . 2052) . -3103) ((marker . 2052) . -3103) ((marker . 1) . -3103) (t 24237 24315 421662 81000) nil (nil rear-nonsticky nil 3104 . 3105) (nil fontified nil 1 . 3105) (1 . 3105) (t 24237 24304 198746 357000) nil ("from random import choice

possibilities = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 'a', 'b', 'c', 'd', 'e']

winning_ticket = []
print(\"Let's see what the winning ticket is...\")

# We don't want to repeat winning numbers or letters, so we'll use a
#   while loop.
while len(winning_ticket) < 4:
    pulled_item = choice(possibilities)

    # Only add the pulled item to the winning ticket if it hasn't
    #   already been pulled.
    if pulled_item not in winning_ticket:
        print(f\"  We pulled a {pulled_item}!\")
        winning_ticket.append(pulled_item)
Output:

Let's see what the winning ticket is...
  We pulled a 10!
  We pulled a a!
  We pulled a 2!
  We pulled a 4!

The final winning ticket is: [10, 'a', 2, 4]
top

9-15: Lottery Analysis
You can use a loop to see how hard it might be to win the kind of lottery you just modeled. Make a list or tuple called my_ticket. Write a loop that keeps pulling numbers until your ticket wins. Print a message reporting how many times the loop had to run to give you a winning ticket.

from random import choice

def get_winning_ticket(possibilities):
    \"\"\"Return a winning ticket from a set of possibilities.\"\"\"
    winning_ticket = []

    # We don't want to repeat winning numbers or letters, so we'll use a
    #   while loop.
    while len(winning_ticket) < 4:
        pulled_item = choice(possibilities)

        # Only add the pulled item to the winning ticket if it hasn't
        #   already been pulled.
        if pulled_item not in winning_ticket:
            winning_ticket.append(pulled_item)

    return winning_ticket

def check_ticket(played_ticket, winning_ticket):
    # Check all elements in the played ticket. If any are not in the 
    #   winning ticket, return False.
    for element in played_ticket:
        if element not in winning_ticket:
            return False

    # We must have a winning ticket!
    return True

def make_random_ticket(possibilities):
    \"\"\"Return a random ticket from a set of possibilities.\"\"\"
    ticket = []
    # We don't want to repeat numbers or letters, so we'll use a while loop.
    while len(ticket) < 4:
        pulled_item = choice(possibilities)

        # Only add the pulled item to the ticket if it hasn't already
        #   been pulled.
        if pulled_item not in ticket:
            ticket.append(pulled_item)

    return ticket


possibilities = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 'a', 'b', 'c', 'd', 'e']
winning_ticket = get_winning_ticket(possibilities)

plays = 0
won = False

# Let's set a max number of tries, in case this takes forever!
max_tries = 1_000_000

while not won:
    new_ticket = make_random_ticket(possibilities)
    won = check_ticket(new_ticket, winning_ticket)
    plays += 1
    if plays >= max_tries:
        break

if won:
    print(\"We have a winning ticket!\")
    print(f\"Your ticket: {new_ticket}\")
    print(f\"Winning ticket: {winning_ticket}\")
    print(f\"It only took {plays} tries to win!\")
else:
    print(f\"Tried {plays} times, without pulling a winner. :(\")
    print(f\"Your ticket: {new_ticket}\")
    print(f\"Winning ticket: {winning_ticket}\")" . 1) ((marker . 26) . -3058) ((marker . 26) . -3104) ((marker . 2052) . -555) ((marker . 24) . -3058) ((marker . 26) . -555) ((marker . 1) . -26) ((marker . 2052) . -3103) ((marker . 1) . -3058) ((marker . 1) . -3103) ((marker . 1) . -2505) ((marker . 1) . -555) (nil fontified t 3058 . 3059) (nil fontified t 3057 . 3058) (nil fontified t 3056 . 3057) (nil fontified t 3031 . 3056) (nil fontified t 3030 . 3031) (nil fontified t 3029 . 3030) (nil fontified t 3028 . 3029) (nil fontified t 3023 . 3028) (nil fontified t 3019 . 3023) (nil fontified t 3018 . 3019) (nil fontified t 3017 . 3018) (nil fontified t 3016 . 3017) (nil fontified t 3006 . 3016) (nil fontified t 2967 . 3006) (nil fontified t 2966 . 2967) (nil fontified t 2965 . 2966) (nil fontified t 2964 . 2965) (nil fontified t 2959 . 2964) (nil fontified t 2954 . 2959) (nil fontified t 2953 . 2954) (nil fontified t 2949 . 2953) (nil fontified t 2948 . 2949) (nil fontified t 2947 . 2948) (nil fontified t 2946 . 2947) (nil fontified t 2912 . 2946) (nil fontified t 2911 . 2912) (nil fontified t 2910 . 2911) (nil fontified t 2909 . 2910) (nil fontified t 2904 . 2909) (nil fontified t 2899 . 2904) (nil fontified t 2898 . 2899) (nil fontified t 2897 . 2898) (nil fontified t 2865 . 2897) (nil fontified t 2864 . 2865) (nil fontified t 2863 . 2864) (nil fontified t 2862 . 2863) (nil fontified t 2857 . 2862) (nil fontified t 2852 . 2857) (nil fontified t 2851 . 2852) (nil fontified t 2850 . 2851) (nil fontified t 2825 . 2850) (nil fontified t 2824 . 2825) (nil fontified t 2823 . 2824) (nil fontified t 2822 . 2823) (nil fontified t 2817 . 2822) (nil fontified t 2812 . 2817) (nil fontified t 2811 . 2812) (nil fontified t 2810 . 2811) (nil fontified t 2785 . 2810) (nil fontified t 2784 . 2785) (nil fontified t 2783 . 2784) (nil fontified t 2778 . 2783) (nil fontified t 2773 . 2778) (nil fontified t 2772 . 2773) (nil fontified t 2768 . 2772) (nil fontified t 2766 . 2768) (nil fontified t 2764 . 2766) (nil fontified t 2759 . 2764) (nil fontified t 2750 . 2759) (nil fontified t 2749 . 2750) (nil fontified t 2739 . 2749) (nil fontified t 2738 . 2739) (nil fontified t 2737 . 2738) (nil fontified t 2730 . 2737) (nil fontified t 2728 . 2730) (nil fontified t 2723 . 2728) (nil fontified t 2722 . 2723) (nil fontified t 2721 . 2722) (nil fontified t 2720 . 2721) (nil fontified t 2719 . 2720) (nil fontified t 2718 . 2719) (nil fontified t 2713 . 2718) (nil fontified t 2708 . 2713) (nil fontified t 2707 . 2708) (nil fontified t 2692 . 2707) (nil fontified t 2691 . 2692) (nil fontified t 2681 . 2691) (nil fontified t 2680 . 2681) (nil fontified t 2667 . 2680) (nil fontified t 2666 . 2667) (nil fontified t 2665 . 2666) (nil fontified t 2662 . 2665) (nil fontified t 2657 . 2662) (nil fontified t 2656 . 2657) (nil fontified t 2643 . 2656) (nil fontified t 2642 . 2643) (nil fontified t 2623 . 2642) (nil fontified t 2622 . 2623) (nil fontified t 2621 . 2622) (nil fontified t 2611 . 2621) (nil fontified t 2606 . 2611) (nil fontified t 2605 . 2606) (nil fontified t 2601 . 2605) (nil fontified t 2598 . 2601) (nil fontified t 2597 . 2598) (nil fontified t 2592 . 2597) (nil fontified t 2590 . 2592) (nil fontified t 2581 . 2590) (nil fontified t 2580 . 2581) (nil fontified t 2579 . 2580) (nil fontified t 2578 . 2579) (nil fontified t 2569 . 2578) (nil fontified t 2512 . 2569) (nil fontified t 2511 . 2512) (nil fontified t 2508 . 2511) (nil fontified t 2506 . 2508) (nil fontified nil 2429 . 2506) (nil fontified nil 2428 . 2429) (nil fontified nil 2427 . 2428) (nil fontified nil 2426 . 2427) (nil fontified nil 2424 . 2426) (nil fontified nil 2423 . 2424) (nil fontified nil 2422 . 2423) (nil fontified nil 2421 . 2422) (nil fontified nil 2419 . 2421) (nil fontified nil 2418 . 2419) (nil fontified nil 2417 . 2418) (nil fontified nil 2416 . 2417) (nil fontified nil 2414 . 2416) (nil fontified nil 2413 . 2414) (nil fontified nil 2412 . 2413) (nil fontified nil 2411 . 2412) (nil fontified nil 2409 . 2411) (nil fontified nil 2408 . 2409) (nil fontified nil 2407 . 2408) (nil fontified nil 2406 . 2407) (nil fontified nil 2225 . 2406) (nil fontified nil 2224 . 2225) (nil fontified nil 2072 . 2224) (nil fontified nil 2071 . 2072) (nil fontified nil 2029 . 2071) (nil fontified nil 2028 . 2029) (nil fontified nil 1999 . 2028) (nil fontified nil 1998 . 1999) (nil fontified nil 1943 . 1998) (nil fontified nil 1942 . 1943) (nil fontified nil 1558 . 1942) (nil fontified t 1557 . 1558) (nil fontified t 1556 . 1557) (nil fontified t 1545 . 1556) (nil fontified t 1544 . 1545) (nil fontified t 1538 . 1544) (nil fontified t 1537 . 1538) (nil fontified t 1534 . 1537) (nil fontified t 1510 . 1534) (nil fontified t 1509 . 1510) (nil fontified t 1494 . 1509) (nil fontified t 1492 . 1494) (nil fontified t 1491 . 1492) (nil fontified t 1488 . 1491) (nil fontified t 1475 . 1488) (nil fontified t 1473 . 1475) (nil fontified t 1465 . 1473) (nil fontified t 1444 . 1465) (nil fontified t 1440 . 1444) (nil fontified t 1430 . 1440) (nil fontified t 1429 . 1430) (nil fontified t 1253 . 1429) (nil fontified t 1252 . 1253) (nil fontified t 1246 . 1252) (nil fontified t 1245 . 1246) (nil fontified t 1237 . 1245) (nil fontified t 1235 . 1237) (nil fontified t 1202 . 1235) (nil fontified t 1201 . 1202) (nil fontified t 1034 . 1201) (nil fontified t 1013 . 1034) (nil fontified t 712 . 1013) (nil fontified t 711 . 712) (nil fontified t 710 . 711) (nil fontified t 709 . 710) (nil fontified t 569 . 709) (nil fontified t 568 . 569) (nil fontified t 563 . 568) (nil fontified t 562 . 563) (nil fontified t 555 . 562) (nil fontified t 554 . 555) (nil fontified t 543 . 554) (nil fontified t 542 . 543) (nil fontified t 536 . 542) (nil fontified t 535 . 536) (nil fontified t 513 . 535) (nil fontified t 512 . 513) (nil fontified t 511 . 512) (nil fontified t 510 . 511) (nil fontified t 501 . 510) (nil fontified t 482 . 501) (nil fontified t 481 . 482) (nil fontified t 480 . 481) (nil fontified t 479 . 480) (nil fontified t 474 . 479) (nil fontified t 465 . 474) (nil fontified t 464 . 465) (nil fontified t 449 . 464) (nil fontified t 447 . 449) (nil fontified t 446 . 447) (nil fontified t 443 . 446) (nil fontified t 430 . 443) (nil fontified t 428 . 430) (nil fontified t 424 . 428) (nil fontified t 403 . 424) (nil fontified t 399 . 403) (nil fontified t 395 . 399) (nil fontified t 393 . 395) (nil fontified t 392 . 393) (nil fontified t 335 . 392) (nil fontified t 333 . 335) (nil fontified t 327 . 333) (nil fontified t 326 . 327) (nil fontified t 313 . 326) (nil fontified t 312 . 313) (nil fontified t 305 . 312) (nil fontified t 304 . 305) (nil fontified t 303 . 304) (nil fontified t 292 . 303) (nil fontified t 287 . 292) (nil fontified t 286 . 287) (nil fontified t 285 . 286) (nil fontified t 284 . 285) (nil fontified t 283 . 284) (nil fontified t 282 . 283) (nil fontified t 281 . 282) (nil fontified t 267 . 281) (nil fontified t 266 . 267) (nil fontified t 263 . 266) (nil fontified t 262 . 263) (nil fontified t 257 . 262) (nil fontified t 245 . 257) (nil fontified t 241 . 245) (nil fontified t 232 . 241) (nil fontified t 231 . 232) (nil fontified t 181 . 231) (nil fontified t 180 . 181) (nil fontified t 174 . 180) (nil fontified t 172 . 174) (nil fontified t 170 . 172) (nil fontified t 169 . 170) (nil fontified t 168 . 169) (nil fontified t 129 . 168) (nil fontified t 128 . 129) (nil fontified t 127 . 128) (nil fontified t 122 . 127) (nil fontified t 121 . 122) (nil fontified t 120 . 121) (nil fontified t 119 . 120) (nil fontified t 118 . 119) (nil fontified t 117 . 118) (nil fontified t 116 . 117) (nil fontified t 102 . 116) (nil fontified t 100 . 102) (nil fontified t 99 . 100) (nil fontified t 98 . 99) (nil fontified t 97 . 98) (nil fontified t 96 . 97) (nil fontified t 95 . 96) (nil fontified t 94 . 95) (nil fontified t 93 . 94) (nil fontified t 92 . 93) (nil fontified t 91 . 92) (nil fontified t 90 . 91) (nil fontified t 89 . 90) (nil fontified t 88 . 89) (nil fontified t 87 . 88) (nil fontified t 86 . 87) (nil fontified t 85 . 86) (nil fontified t 84 . 85) (nil fontified t 83 . 84) (nil fontified t 82 . 83) (nil fontified t 81 . 82) (nil fontified t 80 . 81) (nil fontified t 79 . 80) (nil fontified t 78 . 79) (nil fontified t 77 . 78) (nil fontified t 76 . 77) (nil fontified t 75 . 76) (nil fontified t 74 . 75) (nil fontified t 72 . 74) (nil fontified t 71 . 72) (nil fontified t 70 . 71) (nil fontified t 69 . 70) (nil fontified t 68 . 69) (nil fontified t 67 . 68) (nil fontified t 66 . 67) (nil fontified t 65 . 66) (nil fontified t 64 . 65) (nil fontified t 63 . 64) (nil fontified t 62 . 63) (nil fontified t 61 . 62) (nil fontified t 60 . 61) (nil fontified t 59 . 60) (nil fontified t 58 . 59) (nil fontified t 57 . 58) (nil fontified t 56 . 57) (nil fontified t 55 . 56) (nil fontified t 54 . 55) (nil fontified t 53 . 54) (nil fontified t 52 . 53) (nil fontified t 51 . 52) (nil fontified t 50 . 51) (nil fontified t 49 . 50) (nil fontified t 48 . 49) (nil fontified t 47 . 48) (nil fontified t 46 . 47) (nil fontified t 45 . 46) (nil fontified t 44 . 45) (nil fontified t 43 . 44) (nil fontified t 42 . 43) (nil fontified t 41 . 42) (nil fontified t 28 . 41) (nil fontified t 19 . 28) (nil fontified t 13 . 19) (nil fontified t 5 . 13) (nil fontified t 1 . 5) (nil rear-nonsticky t 3104 . 3105) (t 24237 24294 350457 901000) nil (nil rear-nonsticky nil 3104 . 3105) (nil fontified nil 1 . 3105) (1 . 3105) (t 24237 24290 598804 64000) nil ("

" . 1) ((marker . 26) . -1) ((marker . 26) . -1) ((marker . 2052) . -1) ((marker . 26) . -1) ((marker . 26) . -1) ((marker . 2052) . -1) ((marker . 1) . -1) ((marker) . -1) (2 . 3) (nil rear-nonsticky t 1 . 2) (t 24237 24289 538013 853000) nil (nil rear-nonsticky nil 1 . 2) ("
" . -2) (1 . 3) (t 24234 22267 258715 108000)) (emacs-undo-equiv-table (9 . -1) (-1 . t)))