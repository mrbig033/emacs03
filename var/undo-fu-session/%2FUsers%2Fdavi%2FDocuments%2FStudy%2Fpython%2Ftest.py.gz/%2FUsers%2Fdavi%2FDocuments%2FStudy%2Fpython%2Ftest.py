((buffer-size . 46) (buffer-checksum . "4dca0ea04db75094bae25f960d2f1233f3a51614"))
((emacs-pending-undo-list (366 . 367) (364 . 366) ("." . -364) ((marker . 364) . -1) ((marker . 364) . -1) ((marker . 365) . -1) ((marker . 364) . -1) ((marker . 364) . -1) ((marker . 364) . -1) ...) (emacs-buffer-undo-list (1 . 47) ("#!/usr/bin/env python3

li = [1, 2, 3]

li.ap" . 1) ((marker . 1) . -40) ((marker . 1) . -45) ((marker . 45) . -44) ((marker . 1) . -23) ((marker . 1) . -23) ((marker . 1) . -23) ((marker . 1) . -23) ...) (emacs-undo-equiv-table))