((buffer-size . 655) (buffer-checksum . "1ef6943c9fe735401c48c8e0442e5c6658985dea"))
((emacs-pending-undo-list (" " . 376) nil ("Error" . 377) nil ("Type" . 377) (t 24227 27501 768578 868000) nil (377 . 386) ("Ty" . -377) ((marker . 25) . -2) 379 (376 . 379) (t 24227 27363 224510 65000) nil (243 . 253) (t 24227 27335 545385 530000) nil (407 . 408) (";" . -407) ((marker . 25) . -1) 408 (407 . 408) (399 . 407) ("a" . -399) ((marker . 25) . -1) ("n" . -400) ((marker . 25) . -1) (" " . -401) ((marker . 25) . -1) 402 (387 . 402) (386 . 388) ("\"" . -386) (386 . 387) (apply yas--snippet-revive 380 387 #s(yas--snippet nil nil #s(yas--exit 386 nil) 19 nil nil nil nil)) (apply yas--take-care-of-redo #s(yas--snippet nil nil #s(yas--exit 386 nil) 19 nil nil nil nil)) (380 . 387) ("p" . 380) ((marker . 25) . -1) 381 nil (380 . 381) (367 . 380) (366 . 367) (":" . -366) 367 (360 . 367) ("    " . -360) ((marker . 25) . -4) 364 (351 . 364) (t 24227 27303 380616 802000) 296 nil ("        " . -293) (281 . 293) 292 nil (279 . 280) (":" . -279) 280 (276 . 280) (267 . 276) (t 24227 27178 552477 765000) 214 nil ("        " . -404) ((marker* . 376) . 8) ((marker . 25) . -8) (392 . 404) 400 nil ("            
" . 392) ((marker . 26) . -13) ((marker* . 376) . 1) ((marker . 25) . -11) 403 nil (391 . 404) (390 . 391) (" " . -390) ((marker . 25) . -1) (":" . -391) ((marker . 25) . -1) 392 (391 . 392) (378 . 391) ("nu" . -378) ((marker . 25) . -2) 380 (378 . 380) ("n " . -378) ((marker . 25) . -2) 380 ("= " . -380) ((marker . 25) . -2) 382 ("u" . -382) ((marker . 25) . -1) 383 (382 . 383) (379 . 382) ("=" . -379) 380 (379 . 380) ("n" . -379) ((marker . 25) . -1) 380 (379 . 380) ("u" . -379) ((marker . 25) . -1) 380 (374 . 380) (362 . 374) ("al" . -362) ((marker . 25) . -2) 364 (362 . 364) ("album_title " . 362) ((marker . 490) . -11) ((marker . 448) . -11) ((marker . 448) . -11) ((marker . 25) . -11) (t 24227 27148 943900 561000) nil (373 . 374) (362 . 373) ("al" . -362) ((marker . 25) . -2) 364 (358 . 364) (357 . 358) (" " . -357) ((marker . 25) . -1) ("!" . -358) ((marker . 25) . -1) ("=" . -359) ((marker . 25) . -1) (" " . -360) ((marker . 25) . -1) 361 (357 . 361) (" !=" . -357) ((marker . 25) . -2) 360 (358 . 360) (t 24227 27109 325053 531000) nil (357 . 358) ("(" . -357) ((marker . 25) . -1) ((marker*) . 1) ((marker) . -1) ((marker) . -1) (")" . 358) ((marker*) . 1) ((marker) . -1) (346 . 359) ("ar" . -346) ((marker . 25) . -2) 348 (343 . 348) (334 . 343) (t 24227 27017 369236 658000) 276 nil (1 . 509) ("#!/usr/bin/env python3


def make_album(
    artist_name=None, album_title=None, num_of_songs: int = None
) -> dict:
    while True:
        artist_name = input(\"What is the name of the artist? \").title()
        album_title = input(\"What is of the album? \").title()
        num_of_songs = int(input(\"How many songs in the album? \"))
        break
    return {\"Artist: \": artist_name, \"Album Title: \": album_title, \"Number of Songs: \": str(num_of_songs)}


print(make_album())
" . 1) ((marker . 25) . -348) ((marker . 26) . -455) ((marker . 25) . -348) ((marker . 490) . -359) ((marker* . 376) . 75) ((marker . 1) . -359) ((marker* . 656) . 23) ((marker . 1) . -359) ((marker . 1) . -453) ((marker . 1) . -142) ((marker . 1) . -73) ((marker . 1) . -241) ((marker . 1) . -241) ((marker . 1) . -213) ((marker . 1) . -213) ((marker . 1) . -359) ((marker . 1) . -352) ((marker . 1) . -352) ((marker . 1) . -348) ((marker . 1) . -352) ((marker . 1) . -352) ((marker . 1) . -352) ((marker . 1) . -352) ((marker . 1) . -352) ((marker . 1) . -352) ((marker . 1) . -352) ((marker . 1) . -230) ((marker . 1) . -230) ((marker . 1) . -230) ((marker . 1) . -230) ((marker . 1) . -230) ((marker . 1) . -230) ((marker . 1) . -230) ((marker . 1) . -230) ((marker . 1) . -230) ((marker . 1) . -348) ((marker . 1) . -382) ((marker . 1) . -348) ((marker . 1) . -348) ((marker . 1) . -348) ((marker . 1) . -348) ((marker . 1) . -348) ((marker . 1) . -348) ((marker . 1) . -348) ((marker . 1) . -348) ((marker . 1) . -348) ((marker . 1) . -348) ((marker . 1) . -348) ((marker . 1) . -348) ((marker . 1) . -352) ((marker . 1) . -348) ((marker . 1) . -352) ((marker . 1) . -352) ((marker . 1) . -352) ((marker . 1) . -352) ((marker . 1) . -352) ((marker . 1) . -352) ((marker . 1) . -352) ((marker . 1) . -352) ((marker . 1) . -352) ((marker . 1) . -352) ((marker . 1) . -352) ((marker . 1) . -352) ((marker . 1) . -352) ((marker . 1) . -352) ((marker . 1) . -352) ((marker . 1) . -352) ((marker . 1) . -352) ((marker . 1) . -352) ((marker . 1) . -352) ((marker . 1) . -352) ((marker . 1) . -352) ((marker . 1) . -352) ((marker . 1) . -352) ((marker . 1) . -352) ((marker . 1) . -352) ((marker . 1) . -352) ((marker . 1) . -352) ((marker . 1) . -352) ((marker . 1) . -352) ((marker . 1) . -352) ((marker . 1) . -352) ((marker . 1) . -352) ((marker . 1) . -352) ((marker . 1) . -352) ((marker . 1) . -352) ((marker . 1) . -352) ((marker . 1) . -333) ((marker . 1) . -333) ((marker . 1) . -333) ((marker . 1) . -329) ((marker . 1) . -372) ((marker . 1) . -359) ((marker . 1) . -436) ((marker . 1) . -436) ((marker . 1) . -436) ((marker . 1) . -436) ((marker . 1) . -436) ((marker . 1) . -436) ((marker . 1) . -436) ((marker . 1) . -436) ((marker . 1) . -436) ((marker . 1) . -436) ((marker . 1) . -436) ((marker . 25) . -348) ((marker . 25) . -453) ((marker . 1) . -436) ((marker . 1) . -436) ((marker . 1) . -436) ((marker . 1) . -436) ((marker . 1) . -436) ((marker . 1) . -436) ((marker . 1) . -436) ((marker . 1) . -436) ((marker . 1) . -436) ((marker . 1) . -436) ((marker . 1) . -436) ((marker . 1) . -436) ((marker . 1) . -401) ((marker . 1) . -416) ((marker . 1) . -348) ((marker . 1) . -427) ((marker . 1) . -348) ((marker . 1) . -348) ((marker . 1) . -348) ((marker*) . 24) ((marker) . -454) ((marker*) . 118) ((marker) . -360) 454 nil ("\"" . 454) (t 24227 26994 548518 653000) nil (nil face font-lock-string-face 401 . 403) (nil fontified nil 401 . 403) (401 . 403) (" : " . 401) ((marker . 25) . -1) 403 (401 . 403) (t 24227 26871 1872 723000) nil (nil fontified nil 434 . 436) (nil face font-lock-string-face 434 . 436) (434 . 436) (" : " . 434) ((marker . 25) . -1) 436 (435 . 436) (434 . 435) nil (432 . 433) (431 . 432) (426 . 431) (425 . 426) (419 . 425) (416 . 419) (415 . 417) ("\"" . -415) (415 . 416) ("'" . -415) ((marker . 25) . -1) ("'" . 416) (415 . 417) ("'" . -415) (415 . 416) nil ("+" . 415) ((marker* . 376) . 1) nil (413 . 415) ("," . -413) 414 (413 . 414) (" " . 413) (t 24227 26848 154207 402000) nil (400 . 401) (" " . -400) ((marker . 25) . -1) 401 (400 . 401) (399 . 400) nil ("\"" . 400) nil (369 . 370) (368 . 369) nil (397 . 398) (396 . 397) (388 . 396) (385 . 388) (384 . 386) ("\"" . -384) (384 . 385) ("'" . -384) ((marker . 25) . -1) ("'" . 385) (384 . 386) ("'" . -384) (384 . 385) (382 . 384) (", " . 382) 383 (382 . 383) (" " . -382) ((marker . 25) . -1) 383 ("+" . 383) (t 24227 26823 800438 579000) nil (368 . 369) nil ("," . -381) ((marker . 25) . -1) 382 (381 . 382) (t 24227 26811 942611 64000) nil ("}" . 381) ((marker*) . 1) ((marker) . -1) nil ("{" . 370) ((marker*) . 1) ((marker) . -1) (t 24227 26806 162351 597000) nil (nil face font-lock-string-face 418 . 419) (nil fontified nil 418 . 419) (418 . 419) (360 . 361) 416 (t 24227 26800 399785 667000) nil ("f" . 360) (t 24227 26779 333473 147000) nil (382 . 383) (370 . 371) nil ("{ " . 370) ((marker*) . 2) ((marker) . -1) (" }" . 383) ((marker*) . 1) ((marker) . -2) (t 24227 26776 496215 647000) nil (383 . 385) (370 . 372) 380 nil ("{" . -370) ((marker . 25) . -1) ((marker*) . 1) ((marker) . -1) ((marker) . -1) ("}" . 371) ((marker*) . 1) ((marker) . -1) (370 . 372) ("{" . -370) (362 . 371) nil (360 . 361) (t 24227 26767 645830 717000) nil (406 . 407) (360 . 361) 404 (t 24227 26748 830514 464000) nil ("\"caetano veloso\", \"fina estampa\", 12" . 425) ((marker . 25) . -35) ((marker . 1) . -35) ((marker . 25) . -35) ((marker) . -35) 460 (t 24227 26710 853413 20000) nil (330 . 331) nil (256 . 257) nil (194 . 195) (t 24227 26700 574002 168000) nil (340 . 345) (331 . 340) (t 24227 26691 176981 717000) 274 nil ("
        " . 331) ((marker . 25) . -1) ((marker . 25) . -9) ((marker . 1) . -9) ((marker . 1) . -9) ((marker . 1) . -9) (332 . 340) (t 24227 26690 414256 571000) nil ("        " . -332) ((marker . 25) . -8) ((marker) . -1) ((marker) . -4) ((marker) . -5) ((marker . 1) . -8) ((marker . 1) . -8) ((marker . 1) . -8) 340 (331 . 340) (t 24227 26635 361151 816000) 274 nil ("        " . -336) ((marker . 490) . -8) ((marker . 1) . -8) ((marker . 1) . -8) ((marker . 1) . -8) ((marker . 1) . -8) ((marker . 1) . -8) ((marker . 1) . -8) ((marker . 1) . -8) ((marker . 1) . -8) ((marker . 1) . -8) ((marker . 1) . -8) ((marker . 1) . -8) ((marker . 1) . -8) ((marker . 1) . -8) ((marker . 1) . -8) ((marker . 25) . -8) ((marker . 25) . -8) (332 . 336) 340 nil ("            " . -340) ((marker . 490) . -12) ((marker . 1) . -12) ((marker . 1) . -12) ((marker . 1) . -12) ((marker . 1) . -12) ((marker . 1) . -12) ((marker . 1) . -12) ((marker . 1) . -12) ((marker . 1) . -12) ((marker . 1) . -12) ((marker . 1) . -12) ((marker . 1) . -12) ((marker . 1) . -12) ((marker . 1) . -12) ((marker . 1) . -12) ((marker . 25) . -12) ((marker . 25) . -12) (332 . 340) 344 nil ("        " . -344) ((marker . 490) . -8) ((marker . 1) . -8) ((marker . 1) . -8) ((marker . 1) . -8) ((marker . 1) . -8) ((marker . 1) . -8) ((marker . 1) . -8) ((marker . 1) . -8) ((marker . 1) . -8) ((marker . 1) . -8) ((marker . 1) . -8) ((marker . 1) . -8) ((marker . 1) . -8) ((marker . 1) . -8) ((marker . 1) . -8) ((marker . 25) . -8) ((marker . 25) . -8) (332 . 344) 340 (t 24227 26567 427424 896000) nil (375 . 378) nil (388 . 389) (375 . 376) 386 (t 24227 26518 755739 299000) nil (289 . 292) nil (327 . 328) (289 . 290) 325 (t 24227 26495 352281 822000) nil (367 . 370) (" +" . -367) ((marker . 25) . -1) 369 (368 . 369) nil (353 . 356) (" +" . -353) ((marker . 25) . -1) 355 (354 . 355) (t 24227 26488 756495 496000) nil (366 . 378) ("num" . -366) ((marker . 25) . -3) 369 (365 . 369) (354 . 365) ("alb" . -354) ((marker . 25) . -3) 357 (355 . 357) (354 . 355) ("a" . -354) ((marker . 25) . -1) ("l" . -355) ((marker . 25) . -1) 356 (355 . 356) ("b" . -355) ((marker . 25) . -1) 356 (355 . 356) ("l" . -355) ((marker . 25) . -1) 356 (353 . 356) (342 . 353) ("ar" . -342) ((marker . 25) . -2) 344 (342 . 344) ("aname" . -342) ((marker . 25) . -5) 347 (t 24227 26474 734084 47000) nil (321 . 324) ("i" . -321) ((marker . 25) . -1) ("m" . -322) ((marker . 25) . -1) 323 (321 . 323) ("i" . -321) ((marker . 25) . -1) ("m" . -322) ((marker . 25) . -1) 323 (320 . 323) ("g" . -320) ((marker . 25) . -1) ("u" . -321) ((marker . 25) . -1) ("m" . -322) ((marker . 25) . -1) 323 (315 . 323) ("y" . -315) ((marker . 25) . -1) 316 (311 . 316) (309 . 311) (" " . -309) ((marker . 25) . -1) 310 (296 . 310) ("W" . -296) ((marker . 25) . -1) ("h" . -297) ((marker . 25) . -1) 298 (296 . 298) (apply yas--snippet-revive 289 298 #s(yas--snippet nil nil #s(yas--exit 296 nil) 14 nil nil nil nil)) (apply yas--take-care-of-redo #s(yas--snippet nil nil #s(yas--exit 296 nil) 14 nil nil nil nil)) (289 . 298) ("i" . 289) ((marker . 25) . -1) 290 nil (289 . 290) ("num_of_songs" . 289) nil (274 . 286) ("nu" . -274) ((marker . 25) . -2) 276 (274 . 276) ("songs" . 274) (t 24227 26335 386624 628000) nil (258 . 265) ("ti" . -258) ((marker . 25) . -2) 260 (257 . 260) (242 . 255) (t 24227 26324 75382 284000) nil ("ti9tle " . -242) ((marker . 25) . -7) 249 ("o" . -249) ((marker . 25) . -1) 250 (242 . 250) (t 24227 26320 412489 619000) nil (213 . 224) ("al" . -213) ((marker . 25) . -2) 215 (213 . 215) ("al" . 213) (t 24227 26316 523689 425000) nil (70 . 75) ("name" . -70) ((marker . 25) . -4) 74 (69 . 74) nil (207 . 209) ("rname" . 207) nil (136 . 147) ("ar" . -136) ((marker . 25) . -2) 138 (136 . 138) ("aname" . 136) nil (64 . 69) ("record" . 64) nil (218 . 225) ("Hat " . -218) ((marker . 25) . -4) 222 ("is" . -222) ((marker . 25) . -2) 224 (217 . 224) (apply yas--snippet-revive 210 219 #s(yas--snippet nil nil #s(yas--exit 217 nil) 13 nil nil nil nil)) (apply yas--take-care-of-redo #s(yas--snippet nil nil #s(yas--exit 217 nil) 13 nil nil nil nil)) (210 . 219) ("i" . 210) ((marker . 25) . -1) 211 nil (210 . 211) ("record.title()" . 210) ((marker* . 376) . 14) (t 24227 26281 394661 796000) nil (191 . 193) ("(" . -191) (185 . 192) (t 24227 26232 737217 388000) nil ("r" . 182) nil (181 . 183) nil (173 . 182) (152 . 173) ("A" . -152) ((marker . 25) . -1) ("r" . -153) ((marker . 25) . -1) 154 (152 . 154) (151 . 153) ("\"" . -151) (151 . 152) (150 . 152) ("(" . -150) (147 . 151) ("u" . -147) ((marker . 25) . -1) ("t" . -148) ((marker . 25) . -1) 149 (147 . 149) ("m" . -147) ((marker . 25) . -1) ("p" . -148) ((marker . 25) . -1) ("y" . -149) ((marker . 25) . -1) 150 (145 . 150) ("artist_name.title()" . 145) (t 24227 26190 203393 530000) nil (1 . 304) ("#!/usr/bin/env python3


def make_album(artist_name=None, record=None, num_of_songs: int = None) -> dict:
    while True:
        aname = artist_name.title()
        rname = record.title()
        songs = num_of_songs
        return aname


print(make_album(\"caetano veloso\", \"fina estampa\", 12))
" . 1) ((marker . 25) . -25) ((marker . 26) . -106) ((marker . 25) . -177) ((marker . 490) . -237) ((marker* . 376) . 228) ((marker . 1) . -158) ((marker* . 656) . 79) ((marker . 1) . -177) ((marker . 1) . -208) ((marker . 1) . -74) ((marker . 1) . -74) ((marker . 1) . -74) ((marker . 1) . -138) ((marker . 1) . -138) ((marker . 1) . -138) ((marker . 1) . -138) ((marker . 1) . -138) ((marker . 1) . -138) ((marker . 1) . -138) ((marker . 1) . -138) ((marker . 1) . -138) ((marker . 1) . -138) ((marker . 1) . -138) ((marker . 1) . -138) ((marker . 1) . -138) ((marker . 1) . -138) ((marker . 1) . -138) ((marker . 1) . -138) ((marker . 1) . -138) ((marker . 1) . -138) ((marker . 1) . -138) ((marker . 1) . -138) ((marker . 1) . -138) ((marker . 1) . -138) ((marker . 1) . -138) ((marker . 1) . -138) ((marker . 1) . -138) ((marker . 1) . -138) ((marker . 1) . -138) ((marker . 1) . -138) ((marker . 1) . -138) ((marker . 1) . -138) ((marker . 1) . -138) ((marker . 1) . -138) ((marker . 1) . -138) ((marker . 1) . -138) ((marker . 1) . -138) ((marker . 1) . -138) ((marker . 1) . -138) ((marker . 1) . -138) ((marker . 1) . -138) ((marker . 1) . -150) ((marker . 1) . -150) ((marker . 1) . -174) ((marker . 1) . -174) ((marker . 1) . -174) ((marker . 1) . -174) ((marker . 1) . -130) ((marker . 1) . -130) ((marker . 1) . -233) ((marker . 1) . -132) ((marker . 1) . -237) ((marker . 1) . -237) ((marker . 1) . -237) ((marker . 1) . -237) ((marker . 1) . -237) ((marker . 1) . -237) ((marker . 1) . -237) ((marker . 1) . -237) ((marker . 1) . -237) ((marker . 1) . -237) ((marker . 1) . -237) ((marker . 1) . -237) ((marker . 1) . -237) ((marker . 1) . -237) ((marker . 1) . -237) ((marker . 1) . -237) ((marker . 1) . -237) ((marker . 1) . -237) ((marker . 1) . -237) ((marker . 1) . -237) ((marker . 25) . -237) ((marker . 25) . -68) 69 nil (65 . 70) ("=" . -65) 66 (65 . 66) nil (52 . 57) ("=" . -52) 53 (52 . 53) (t 24227 26155 362375 273000) nil (224 . 229) ("a" . 224) nil (122 . 124) (t 24227 26149 285093 459000) nil ("a" . 121) ((marker . 1) . -1) ((marker . 1) . -1) nil (223 . 224) ("aane" . -223) ((marker . 25) . -4) 227 (216 . 227) (207 . 216) (t 24227 26139 212769 292000) 179 nil ("        if num_of_songs:
            return {
                \"Artist\": artist_name.title(),
                \"Album\": record.title(),
                \"Number of Songs\": num_of_songs,
            }
        else:
            return {
                \"Artist\": artist_name.title(),
                \"Album\": record.title(),
            }
" . 208) ((marker . 25) . -320) ((marker . 26) . -334) ((marker . 25) . -328) ((marker . 1) . -8) ((marker . 1) . -328) ((marker . 25) . -328) 536 (t 24227 26131 558672 55000) nil ("." . -207) ((marker . 25) . -1) 208 (195 . 208) ("nu" . -195) ((marker . 25) . -2) 197 (192 . 197) ("=" . -192) 193 (187 . 193) (178 . 187) (t 24227 26116 55823 313000) 176 nil (171 . 178) ("t" . -171) ((marker . 25) . -1) 172 (170 . 172) ("." . -170) ((marker . 25) . -1) 171 (164 . 171) ("rec" . -164) ((marker . 25) . -3) 167 (164 . 167) ("red" . 164) ((marker . 25) . -3) ((marker . 490) . -3) ((marker . 1) . -3) ((marker . 1) . -2) ((marker . 1) . -3) ((marker . 1) . -3) ((marker . 25) . -3) nil ("n" . 122) ((marker . 1) . -1) ((marker . 1) . -1) (162 . 168) ("=" . 162) (148 . 163) (t 24227 26088 944215 516000) nil ("
        " . 148) ((marker . 26) . -1) ((marker . 25) . -9) ((marker . 490) . -9) ((marker . 1) . -9) ((marker . 1) . -9) ((marker . 1) . -9) ((marker . 1) . -9) ((marker . 25) . -9) ("rname=" . 157) ((marker . 25) . -5) ((marker . 490) . -5) ((marker . 1) . -5) ((marker . 1) . -5) ((marker . 1) . -5) ((marker . 1) . -5) ((marker . 25) . -5) (162 . 163) (" = red" . 162) ((marker . 25) . -6) ((marker . 490) . -6) ((marker . 1) . -6) ((marker . 1) . -5) ((marker . 1) . -6) ((marker . 1) . -6) ((marker . 25) . -6) (122 . 123) nil ("n" . -122) ((marker . 25) . -1) ((marker . 1) . -1) ((marker . 1) . -1) 123 (162 . 168) ("=" . -162) 163 (157 . 163) (148 . 157) (t 24227 26088 944215 516000) 121 nil (141 . 148) ("t" . -141) ((marker . 25) . -1) ((marker) . -1) ((marker . 1) . -1) ((marker . 1) . -1) 142 (141 . 142) (129 . 141) ("ar" . -129) ((marker . 25) . -2) ((marker . 1) . -1) ((marker) . -2) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -2) ((marker . 1) . -1) ((marker) . -2) ((marker . 1) . -2) 131 (129 . 131) ("artist_name." . 129) ((marker) . -11) ((marker) . -12) nil (129 . 141) ("ar" . -129) ((marker . 25) . -2) 131 (129 . 131) ("artist_name." . 129) ((marker . 25) . -10) ((marker . 490) . -10) ((marker* . 376) . 1) ((marker . 1) . -12) ((marker . 1) . -11) ((marker . 1) . -12) ((marker . 1) . -12) ((marker . 1) . -12) ((marker . 1) . -12) ((marker . 1) . -12) ((marker . 1) . -11) ((marker . 1) . -11) ((marker . 1) . -12) ((marker . 1) . -11) ((marker . 1) . -11) ((marker . 1) . -11) ((marker . 1) . -11) ((marker . 1) . -11) ((marker . 1) . -11) ((marker . 1) . -11) ((marker . 1) . -10) ((marker . 1) . -10) ((marker . 1) . -11) ((marker . 1) . -10) ((marker . 1) . -10) ((marker . 1) . -10) ((marker . 1) . -10) ((marker . 1) . -10) ((marker . 1) . -10) ((marker . 25) . -10) (t 24227 26061 600433 594000) nil (129 . 141) ("ar" . -129) ((marker . 25) . -2) 131 (129 . 131) ("artist_name." . 129) ((marker . 25) . -11) ((marker . 490) . -11) ((marker . 1) . -11) ((marker . 1) . -11) ((marker . 1) . -11) ((marker . 25) . -11) (t 24227 26047 378673 390000) nil (129 . 141) ("ar" . -129) ((marker . 25) . -2) 131 (129 . 131) ("artist" . -129) ((marker . 25) . -6) 135 ("_" . -135) ((marker . 25) . -1) 136 ("name" . -136) ((marker . 25) . -4) 140 (".." . -140) ((marker . 25) . -2) 142 (141 . 142) nil (129 . 141) ("art" . -129) ((marker . 25) . -3) 132 (129 . 132) ("art" . 129) ((marker . 490) . -2) ((marker . 1) . -2) ((marker . 1) . -2) ((marker . 25) . -2) (t 24227 25971 604106 18000) nil (126 . 132) ("=" . -126) 127 (122 . 127) (121 . 122) ("name = " . 121) nil (125 . 128) ("=" . -125) 126 (121 . 126) (112 . 121) (t 24227 25916 69442 269000) 107 nil (1 . 505) ("#!/usr/bin/env python3


def make_album(
    artist_name, record, num_of_songs: int = None
) -> dict:
    while True:
        if num_of_songs:
            return {
                \"Artist\": artist_name.title(),
                \"Album\": record.title(),
                \"Number of Songs\": num_of_songs,
            }
        else:
            return {
                \"Artist\": artist_name.title(),
                \"Album\": record.title(),
            }


print(make_album(\"caetano veloso\", \"fina estampa\", 12))
" . 1) ((marker . 25) . -41) ((marker . 26) . -91) ((marker . 25) . -155) ((marker . 490) . -136) ((marker* . 376) . 393) ((marker . 1) . -118) ((marker* . 656) . 58) ((marker . 1) . -126) ((marker . 1) . -438) ((marker . 1) . -510) ((marker . 1) . -118) ((marker . 1) . -91) ((marker . 1) . -136) ((marker . 1) . -116) ((marker . 1) . -136) ((marker . 1) . -136) ((marker . 1) . -136) ((marker . 1) . -136) ((marker . 1) . -136) ((marker . 1) . -136) ((marker . 1) . -136) ((marker . 1) . -161) ((marker . 1) . -126) ((marker . 1) . -350) ((marker . 1) . -350) ((marker . 1) . -350) ((marker . 1) . -155) ((marker . 1) . -155) ((marker . 1) . -155) ((marker . 25) . -155) ((marker . 25) . -64) ((marker . 1) . -155) ((marker . 1) . -130) 65 nil (": str" . 65) nil (": str" . 57) (t 24227 25864 235065 159000) nil ("        " . -461) (449 . 461) ("            " . -424) (408 . 424) ("            " . -377) (361 . 377) ("        " . -352) (340 . 352) ("    " . -334) (326 . 334) ("        " . -324) (312 . 324) ("            " . -279) (263 . 279) ("            " . -238) (222 . 238) ("            " . -191) (175 . 191) ("        " . -166) (154 . 166) ("    " . -137) ((marker . 1) . -4) ((marker) . -4) ((marker . 1) . -4) (129 . 137) 419 (t 24227 25841 56585 229000) nil (118 . 128) nil (117 . 118) (112 . 117) (t 24227 25793 170580 859000) 102 nil (1 . 461) ("#!/usr/bin/env python3


def make_album(
    artist_name: str, record: str, num_of_songs: int = None) -> dict:
    if num_of_songs:
        return {
            \"Artist\": artist_name.title(),
            \"Album\": record.title(),
            \"Number of Songs\": num_of_songs,
        }
    else:
        return {
            \"Artist\": artist_name.title(),
            \"Album\": record.title(),
        }


print(make_album(\"caetano veloso\", \"fina estampa\", 12))
" . 1) ((marker . 25) . -41) ((marker . 26) . -111) ((marker . 25) . -109) 110 nil ("
" . -101) ((marker . 26) . -1) 100 (t 24227 25778 513778 778000) nil (1 . 461) ("#!/usr/bin/env python3


def make_album(artist_name: str, record: str, num_of_songs: int = None) -> dict:
    if num_of_songs:
        return {
            \"Artist\": artist_name.title(),
            \"Album\": record.title(),
            \"Number of Songs\": num_of_songs,
        }
    else:
        return {
            \"Artist\": artist_name.title(),
            \"Album\": record.title(),
        }


print(make_album(\"caetano veloso\", \"fina estampa\", 12))
" . 1) ((marker . 25) . -25) ((marker . 26) . -25) ((marker . 25) . -25) ((marker . 490) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 25) . -25) ((marker . 25) . -95) ((marker*) . 429) ((marker) . -25) ((marker*) . 429) ((marker) . -25) 96 nil (26 . 107) ("def make_album(
    artist_name: str, record: str, num_of_songs: int = None) -> dict:
" . -26) ((marker . 25) . -16) ((marker . 26) . -86) ((marker . 25) . -83) ((marker . 490) . -83) ((marker . 1) . -83) ((marker . 1) . -83) ((marker . 1) . -83) ((marker . 1) . -83) ((marker . 1) . -83) ((marker . 1) . -83) ((marker . 1) . -83) ((marker . 1) . -83) ((marker . 1) . -83) ((marker . 1) . -83) ((marker . 1) . -83) ((marker . 1) . -83) ((marker . 1) . -83) ((marker . 1) . -83) ((marker . 1) . -83) ((marker . 1) . -83) ((marker . 1) . -83) ((marker . 1) . -24) ((marker . 1) . -83) ((marker . 1) . -24) ((marker . 1) . -75) ((marker . 1) . -24) ((marker . 1) . -16) ((marker . 1) . -24) ((marker . 1) . -75) ((marker . 25) . -75) ((marker . 25) . -75) ((marker*) . 11) ((marker) . -76) ((marker*) . 72) ((marker) . -15) nil (1 . 460) ("#!/usr/bin/env python3


def make_album(
    artist_name: str, record: str, num_of_songs: int = None
) -> dict:
    if num_of_songs:
        return {
            \"Artist\": artist_name.title(),
            \"Album\": record.title(),
            \"Number of Songs\": num_of_songs,
        }
    else:
        return {
            \"Artist\": artist_name.title(),
            \"Album\": record.title(),
        }


print(make_album(\"caetano veloso\", \"fina estampa\", 12))
" . 1) ((marker . 25) . -295) ((marker . 26) . -312) ((marker . 25) . -295) (t 24227 25767 961601 929000) nil (1 . 461) ("#!/usr/bin/env python3


def make_album(
    artist_name: str, record: str, num_of_songs: int = None) -> dict:
    if num_of_songs:
        return {
            \"Artist\": artist_name.title(),
            \"Album\": record.title(),
            \"Number of Songs\": num_of_songs,
        }
    else:
        return {
            \"Artist\": artist_name.title(),
            \"Album\": record.title(),
        }


print(make_album(\"caetano veloso\", \"fina estampa\", 12))
" . 1) ((marker . 25) . -41) ((marker . 26) . -111) ((marker . 25) . -108) ((marker . 490) . -108) ((marker . 1) . -108) ((marker . 1) . -108) ((marker . 1) . -108) ((marker . 1) . -108) ((marker . 1) . -108) ((marker . 1) . -108) ((marker . 1) . -108) ((marker . 1) . -108) ((marker . 1) . -108) ((marker . 1) . -108) ((marker . 25) . -108) ((marker . 25) . -100) ((marker) . -391) ((marker) . -392) ((marker) . -395) ((marker) . -396) ((marker) . -354) ((marker) . -355) ((marker) . -358) ((marker) . -359) ((marker) . -362) ((marker) . -363) ((marker) . -311) ((marker) . -312) ((marker) . -315) ((marker) . -316) ((marker) . -319) ((marker) . -320) ((marker) . -294) ((marker) . -295) ((marker) . -298) ((marker) . -299) ((marker) . -284) ((marker) . -285) ((marker) . -274) ((marker) . -275) ((marker) . -278) ((marker) . -279) ((marker) . -229) ((marker) . -230) ((marker) . -233) ((marker) . -234) ((marker) . -237) ((marker) . -238) ((marker) . -192) ((marker) . -193) ((marker) . -196) ((marker) . -197) ((marker) . -200) ((marker) . -201) ((marker) . -149) ((marker) . -150) ((marker) . -153) ((marker) . -154) ((marker) . -157) ((marker) . -158) ((marker) . -132) ((marker) . -133) ((marker) . -136) ((marker) . -137) ((marker) . -111) ((marker) . -112) ((marker . 1) . -108) ((marker . 1) . -108) ((marker . 1) . -108) ((marker . 1) . -108) ((marker . 1) . -108) ((marker . 1) . -108) ((marker . 1) . -108) ((marker . 1) . -49) ((marker . 1) . -108) ((marker . 1) . -49) ((marker) . -111) ((marker) . -112) ((marker) . -41) ((marker) . -42) ((marker . 1) . -100) ((marker . 1) . -49) ((marker . 1) . -41) ((marker . 1) . -49) ((marker*) . 359) ((marker) . -101) ((marker*) . 420) ((marker) . -40) ((marker . 1) . -100) 101 nil ("
" . -101) ((marker . 26) . -1) 50 (t 24227 25752 890658 333000) nil (1 . 461) ("#!/usr/bin/env python3


def make_album(
    artist_name: str, record: str, num_of_songs: int = None) -> dict:
    if num_of_songs:
        return {
            \"Artist\": artist_name.title(),
            \"Album\": record.title(),
            \"Number of Songs\": num_of_songs,
        }
    else:
        return {
            \"Artist\": artist_name.title(),
            \"Album\": record.title(),
        }


print(make_album(\"caetano veloso\", \"fina estampa\", 12))
" . 1) ((marker . 25) . -41) ((marker . 26) . -111) ((marker . 25) . -401) ((marker . 490) . -302) ((marker* . 376) . 3) ((marker . 1) . -402) ((marker . 1) . -401) ((marker . 1) . -402) ((marker . 1) . -402) ((marker . 1) . -402) ((marker . 1) . -402) ((marker . 1) . -402) ((marker . 1) . -402) ((marker . 1) . -402) ((marker . 1) . -149) ((marker . 1) . -402) ((marker . 1) . -149) ((marker . 1) . -402) ((marker . 1) . -294) ((marker* . 656) . 58) ((marker . 1) . -294) ((marker . 1) . -294) ((marker . 1) . -294) ((marker . 420) . -294) ((marker . 420) . -400) ((marker . 1) . -302) ((marker . 1) . -302) ((marker . 1) . -401) ((marker . 1) . -302) ((marker . 1) . -302) ((marker . 25) . -456) ((marker . 25) . -109) ((marker . 1) . -302) ((marker . 1) . -362) ((marker . 1) . -403) ((marker . 1) . -459) ((marker . 1) . -192) ((marker . 1) . -403) ((marker . 1) . -403) ((marker . 1) . -192) ((marker . 1) . -362) ((marker . 1) . -132) ((marker . 1) . -456) ((marker . 1) . -455) ((marker . 1) . -111) ((marker . 1) . -456) ((marker . 1) . -456) ((marker . 1) . -111) ((marker . 1) . -132) ((marker . 1) . -455) ((marker . 1) . -455) ((marker . 1) . -401) ((marker . 1) . -401) 110 nil ("
" . -101) ((marker . 26) . -1) 42 (t 24227 25745 871712 503000) nil ("    # return {\"Artist\": artist_name.title(), \"Album\": record.title()}
" . 403) ((marker . 26) . -70) ((marker . 1) . -70) ((marker* . 656) . 70) ((marker . 25) . -4) 407 (t 24227 25740 792850 801000) nil (526 . 528) (nil fontified nil 524 . 526) (nil face font-lock-string-face 524 . 526) (524 . 526) ("," . -524) 525 (524 . 525) (t 24227 25727 586432 681000) nil ("            \"Number of Songs\": num_of_songs,
" . 393) ((marker . 26) . -45) ((marker . 25) . -12) 405 (t 24227 25710 504022 863000) nil (nil rear-nonsticky nil 303 . 304) (296 . 448) 312 ("        return 
" . 296) ((marker . 26) . -16) ((marker . 25) . -16) ((marker* . 376) . 1) ((marker . 25) . -8) ((marker . 1) . -8) ((marker . 1) . -8) ((marker) . -8) ((marker) . -8) 312 nil (304 . 311) (295 . 304) (294 . 295) (":" . -294) 295 (290 . 295) ("pass" . 290) (t 24227 25671 417987 738000) nil (1 . 419) ("#!/usr/bin/env python3


def make_album(artist_name: str, record: str, num_of_songs: int = None) -> dict:
    if num_of_songs:
        return {
            \"Artist\": artist_name.title(),
            \"Album\": record.title(),
            \"Number of Songs\": num_of_songs,
        }
    pass
    # return {\"Artist\": artist_name.title(), \"Album\": record.title()}


print(make_album(\"caetano veloso\", \"fina estampa\"))
" . 1) ((marker . 25) . -25) ((marker . 26) . -106) ((marker* . 376) . 321) ((marker . 25) . -90) 91 nil (89 . 92) ("=" . -89) 90 (86 . 90) ("m" . -86) ((marker . 25) . -1) 87 (84 . 87) (":" . -84) 85 (84 . 85) ("=" . 84) (t 24227 25650 948752 993000) nil (1 . 406) ("#!/usr/bin/env python3


def make_album(artist_name: str, record: str, num_of_songs=None) -> dict:
    if num_of_songs:
        return {\"Artist\": artist_name.title(), \"Album\": record.title(), \"Number of Songs\": num_of_songs}
    pass
    # return {\"Artist\": artist_name.title(), \"Album\": record.title()}


print(make_album(\"caetano veloso\", \"fina estampa\"))
" . 1) ((marker . 25) . -120) ((marker . 26) . -225) ((marker . 490) . -128) ((marker* . 376) . 135) ((marker . 1) . -128) ((marker . 1) . -128) ((marker . 25) . -128) ((marker . 25) . -222) 223 nil (212 . 224) ("num" . -212) ((marker . 25) . -3) 215 (212 . 215) (nil fontified nil 210 . 212) (nil face font-lock-string-face 210 . 212) (210 . 212) (":" . -210) 211 (210 . 211) (194 . 209) (193 . 195) ("\"" . -193) (191 . 194) ("," . -191) 192 (191 . 192) (t 24227 25608 493014 374000) nil (1 . 326) ("#!/usr/bin/env python3


def make_album(artist_name: str, record: str, num_of_songs=None) -> dict:
    if num_of_songs:
        return {\"Artist\": artist_name.title(), \"Album\": record.title()}        
    pass
    # return {\"Artist\": artist_name.title(), \"Album\": record.title()}


print(make_album(\"caetano veloso\", \"fina estampa\"))
" . 1) ((marker . 25) . -120) ((marker . 26) . -200) ((marker . 1) . -200) ((marker . 1) . -200) ((marker . 25) . -128) ((marker . 1) . -200) ((marker . 1) . -200) ((marker . 1) . -200) ((marker . 1) . -200) ((marker . 1) . -200) ((marker . 1) . -200) ((marker . 490) . -198) ((marker . 1) . -200) ((marker . 1) . -200) ((marker . 1) . -200) ((marker . 1) . -200) ((marker . 1) . -200) ((marker . 1) . -200) ((marker . 1) . -200) ((marker . 1) . -200) ((marker . 1) . -200) ((marker . 1) . -200) ((marker . 1) . -200) ((marker . 1) . -200) ((marker . 1) . -200) ((marker . 1) . -200) ((marker . 1) . -200) ((marker . 1) . -200) ((marker . 1) . -200) ((marker . 1) . -128) ((marker . 1) . -128) ((marker* . 376) . 134) ((marker . 1) . -128) ((marker . 1) . -128) ((marker . 1) . -128) ((marker . 1) . -128) ((marker . 1) . -128) ((marker . 1) . -128) ((marker . 1) . -128) ((marker . 1) . -128) ((marker . 1) . -128) ((marker . 1) . -128) ((marker . 1) . -128) ((marker . 1) . -128) ((marker . 1) . -128) ((marker . 1) . -128) ((marker . 1) . -128) ((marker . 1) . -128) ((marker . 1) . -128) ((marker . 1) . -128) ((marker . 1) . -128) ((marker . 1) . -198) ((marker . 1) . -198) ((marker . 1) . -198) ((marker . 25) . -128) ((marker . 25) . -128) ((marker . 1) . -128) ((marker . 1) . -120) ((marker . 1) . -128) ((marker . 1) . -128) ((marker . 1) . -128) ((marker . 1) . -128) 129 (t 24227 25602 962699 629000) nil ("    " . -129) ((marker . 25) . -4) ((marker . 1) . -4) ((marker . 1) . -4) ((marker . 1) . -4) ((marker . 1) . -4) ((marker . 1) . -4) ((marker . 1) . -4) ((marker . 1) . -4) ((marker . 1) . -4) ((marker . 1) . -4) ((marker . 1) . -4) ((marker . 1) . -4) ((marker . 1) . -4) ((marker . 1) . -4) ((marker . 1) . -4) ((marker . 1) . -4) ((marker . 1) . -4) ((marker . 1) . -4) ((marker . 1) . -4) ((marker . 1) . -4) ((marker . 1) . -4) ((marker . 1) . -4) ((marker . 25) . -4) ((marker . 25) . -4) ((marker . 1) . -4) ((marker . 1) . -4) ((marker . 1) . -4) ((marker . 1) . -4) ((marker . 1) . -4) (121 . 129) 125 (t 24227 25582 492050 578000) nil (189 . 196) nil (188 . 189) (t 24227 25517 279512 9000) nil (" " . 125) (t 24227 25515 530225 913000) nil (125 . 126) (t 24227 25508 275484 372000) nil (121 . 125) (t 24227 25260 505990 240000) nil (nil rear-nonsticky nil 183 . 184) (nil fontified nil 121 . 184) (121 . 184) nil ("        " . -121) 129 (120 . 129) 104 nil ("
" . 121) nil ("        " . -121) 129 nil (120 . 129) (119 . 120) (107 . 119) ("nu" . -107) 109 (104 . 109) (99 . 104) 35 nil (113 . 115) 116 nil (104 . 108) (99 . 104) 92 nil ("
" . -167) ("p" . -168) 169 (168 . 169) (167 . 168) ("
" . -167) ("p" . -168) 169 (168 . 169) (167 . 168) (t 24227 25222 329287 567000) 157 nil (79 . 84) ("f" . -79) ("o" . -80) 81 (72 . 81) ("n" . -72) ("u" . -73) ("m" . -74) 75 (72 . 75) ("genre" . 72) (t 24227 25163 641654 237000) nil (77 . 82) ("=" . -77) 78 (72 . 78) nil (73 . 74) nil (70 . 72) ("," . -70) 71 (70 . 71) nil ("," . -71) (" " . -72) 73 (71 . 73) (", " . 71) 72 (71 . 72) (t 24227 24572 557559 6000) nil ("," . 70) (70 . 71) (", " . 70) nil (70 . 72) ("," . -70) 71 (70 . 71) (t 24227 24572 557559 6000) nil ("f" . 94) (nil rear-nonsticky t 94 . 95) nil (nil rear-nonsticky nil 94 . 95) (nil fontified nil 94 . 95) (94 . 95) 93 nil ("f" . 94) (nil rear-nonsticky t 94 . 95) (t 24227 24571 74682 219000) nil (nil rear-nonsticky nil 94 . 95) (nil fontified nil 94 . 95) (94 . 95) 93 (t 24227 24565 410195 660000) nil ("f" . 93) (t 24227 24534 551211 778000) nil ("}" . 148) ("{" . 134) 149 (t 24227 24531 322567 790000) nil (131 . 132) (125 . 126) 129 (t 24227 24527 6407 259000) nil ("n" . 125) nil ("\\" . 125) (t 24227 24523 635548 418000) nil ("}" . 123) ("{" . 104) (t 24227 24506 18910 478000) nil (104 . 105) nil ("{" . 104) (t 24227 24506 18910 478000) nil ("\"" . 152) (t 24227 24505 40870 942000) nil ("\"" . 127) (t 24227 24503 680981 934000) nil ("\"" . 125) (t 24227 24499 32788 858000) nil (101 . 102) ("!" . 101) nil (101 . 102) (t 24227 24461 566937 60000) nil (124 . 125) (t 24227 24457 136820 934000) nil (126 . 127) ("!" . 126) nil (126 . 127) nil (124 . 126) nil (93 . 94) nil ("f" . 92) nil (92 . 93) ("def fun(args):
    
" . 92) ("           " . 107) (apply yas--snippet-revive 92 123 #s(yas--snippet nil (#s(yas--field 1 96 99 nil nil nil nil #s(yas--field 2 100 104 nil nil nil nil #s(yas--exit 122 nil))) #s(yas--field 2 100 104 nil nil nil nil #s(yas--exit 122 nil))) #s(yas--exit 122 nil) 7 nil #s(yas--field 1 96 99 nil nil nil nil #s(yas--field 2 100 104 nil nil nil nil #s(yas--exit 122 nil))) nil nil)) nil (apply yas--take-care-of-redo #s(yas--snippet nil (#s(yas--field 1 96 99 nil nil nil nil #s(yas--field 2 100 104 nil nil nil nil #s(yas--exit 122 nil))) #s(yas--field 2 100 104 nil nil nil nil #s(yas--exit 122 nil))) #s(yas--exit 122 nil) 7 nil #s(yas--field 1 96 99 nil nil nil nil #s(yas--field 2 100 104 nil nil nil nil #s(yas--exit 122 nil))) nil nil)) nil (107 . 122) (t 24227 24431 290139 775000) nil ("               " . 107) 95 nil (apply yas--snippet-revive 92 123 #s(yas--snippet nil (#s(yas--field 1 96 99 nil nil nil nil #s(yas--field 2 100 104 nil nil nil nil #s(yas--exit 122 nil))) #s(yas--field 2 100 104 nil nil nil nil #s(yas--exit 122 nil))) #s(yas--exit 122 nil) 7 nil #s(yas--field 1 96 99 nil nil nil nil #s(yas--field 2 100 104 nil nil nil nil #s(yas--exit 122 nil))) nil nil)) nil (apply yas--take-care-of-redo #s(yas--snippet nil (#s(yas--field 1 96 99 nil nil nil nil #s(yas--field 2 100 104 nil nil nil nil #s(yas--exit 122 nil))) #s(yas--field 2 100 104 nil nil nil nil #s(yas--exit 122 nil))) #s(yas--exit 122 nil) 7 nil #s(yas--field 1 96 99 nil nil nil nil #s(yas--field 2 100 104 nil nil nil nil #s(yas--exit 122 nil))) nil nil)) (107 . 118) (92 . 112) ("f" . 92) 93 nil (92 . 93) (t 24227 24427 393809 267000) nil ("f" . 93) (t 24227 24405 892693 106000) nil (93 . 94) (t 24227 24395 737157 805000) nil (nil face font-lock-string-face 149 . 150) (nil fontified nil 149 . 150) (149 . 150) (92 . 93) 147 nil ("{ " . 92) (" }" . 150) (nil face (rainbow-delimiters-depth-1-face) 151 . 152) (nil face nil 150 . 151) (t 24227 24392 871687 696000) nil (nil face font-lock-string-face 150 . 152) (nil fontified nil 150 . 152) (150 . 152) (92 . 94) 147 (t 24227 24390 343446 588000) nil ("f" . 92) (t 24227 23977 806244 37000) nil (75 . 79) ("Dict[str, str]" . 75) (nil rear-nonsticky t 88 . 89) (t 24227 23963 629146 57000) nil (nil rear-nonsticky nil 88 . 89) (nil fontified nil 75 . 89) (75 . 89) 79 ("dict" . 75) 79 nil ("Dict[str, str]" . 150) nil ("\"" . 164) nil (nil rear-nonsticky nil 164 . 165) (nil fontified nil 150 . 165) (150 . 165) (t 24227 23914 873318 291000) nil ("    album = {\"name\": artist_name.title(), \"album\": record.title()}
" . 81) 145 nil (212 . 214) ("(" . -212) (200 . 213) (199 . 201) ("{" . -199) (199 . 200) (190 . 199) ("n" . -190) 191 (190 . 191) (t 24227 23888 352665 827000) nil (187 . 189) ("(" . -187) (181 . 188) (";" . -181) ("t" . -182) 183 (181 . 183) (170 . 181) ("ar" . -170) 172 (170 . 172) nil (169 . 171) ("{" . -169) (169 . 170) (168 . 169) (t 24227 23861 771571 813000) nil (167 . 168) (t 24227 23852 461158 825000) nil (167 . 168) nil ("\"" . 167) (t 24227 23852 461158 825000) nil (132 . 138) ("album_title" . 132) 142 nil (61 . 65) (59 . 61) ("album_title" . 59) 69 (t 24227 23836 42893 388000) nil (":" . 177) (t 24227 23834 914086 961000) nil (177 . 178) (";" . 177) (177 . 178) (":" . 177) (t 24227 23834 421620 615000) nil (177 . 178) (";" . -177) 178 (177 . 178) (":" . 177) (t 24227 23801 450643 529000) nil (177 . 178) (":" . 177) (t 24227 23799 110894 222000) nil (177 . 178) (";" . -177) 178 (177 . 178) (t 24227 23792 719065 278000) nil (":" . 177) (t 24227 23791 50323 846000) nil (177 . 178) (":" . 177) nil (177 . 178) (":" . 177) (t 24227 23739 425989 195000) nil (143 . 177) nil ("title.title()}
    return f\"Artist" . 143) 177 (t 24227 23739 425989 195000) nil (177 . 178) (":" . 177) nil (177 . 178) (":" . 177) (t 24227 23739 425989 195000) nil (177 . 178) (":" . 177) (t 24227 23733 220751 832000) nil (177 . 178) (":" . -177) 178 (177 . 178) (":" . 177) (t 24227 23680 22730 860000) nil (177 . 178) (":" . 177) (t 24227 23679 343487 880000) nil (177 . 178) (":" . -177) 178 (t 24227 23664 650996 505000) nil (177 . 178) (":" . 177) nil (177 . 178) (":" . 177) (t 24227 23658 975345 305000) nil (177 . 178) (":" . 177) nil (177 . 178) (":" . 177) (t 24227 23641 497237 967000) nil (177 . 178) (":" . 177) (t 24227 23606 692397 809000) nil (178 . 181) ("\"

" . 178) 180 nil (177 . 178) (t 24227 23572 616604 46000)) (emacs-buffer-undo-list nil (" " . 376) nil ("E" . -377) ((marker . 25) . -1) 378 (377 . 378) ("e" . -377) ((marker . 25) . -1) ("r" . -378) ((marker . 25) . -1) ("r" . -379) ((marker . 25) . -1) 380 (377 . 380) ("s" . -377) ((marker . 25) . -1) ("u" . -378) ((marker . 25) . -1) ("m" . -379) 380 (377 . 380) (376 . 377) (t 24227 27608 819705 69000) nil ("
            " . 420) ((marker . 25) . -13) ((marker . 25) . -13) ((marker . 420) . -13) ((marker . 420) . -13) ((marker . 25) . -13) ("while True:" . 433) ((marker . 25) . -11) ((marker . 25) . -11) ((marker . 420) . -11) ((marker . 420) . -11) ((marker . 25) . -11) ("
                " . 444) ((marker . 25) . -1) ((marker . 25) . -17) ((marker . 420) . -17) ((marker . 420) . -17) ((marker . 25) . -16) nil ("
            num_of_songs = int(input(\"How many songs in the album? \"))
" . 461) ((marker . 26) . -1) ((marker . 25) . -71) ((marker . 420) . -1) ((marker . 420) . -71) (532 . 533) (nil rear-nonsticky t 473 . 474) nil (445 . 462) nil ("                " . 445) (461 . 473) (t 24227 27573 38755 365000) nil ("            " . -461) ((marker . 25) . -12) (445 . 461) 457 nil ("                
" . 445) ((marker . 26) . -17) ((marker . 420) . -17) ((marker . 25) . -12) 457 (t 24227 27570 764015 222000) nil (nil rear-nonsticky nil 473 . 474) ("
" . -532) (461 . 533) 460 (t 24227 27567 230045 280000) nil (444 . 461) (433 . 444) (420 . 433) (t 24227 27529 819355 71000) 392 nil (" " . 376) nil ("Error" . 377) nil ("Type" . 377) (t 24227 27501 768578 868000) nil (377 . 386) ("Ty" . -377) ((marker . 25) . -2) 379 (376 . 379) (t 24227 27363 224510 65000) nil (243 . 253) (t 24227 27335 545385 530000) nil (407 . 408) (";" . -407) ((marker . 25) . -1) 408 (407 . 408) (399 . 407) ("a" . -399) ((marker . 25) . -1) ("n" . -400) ((marker . 25) . -1) (" " . -401) ((marker . 25) . -1) 402 (387 . 402) (386 . 388) ("\"" . -386) (386 . 387) (apply yas--snippet-revive 380 387 #s(yas--snippet nil nil #s(yas--exit 386 nil) 19 nil nil nil nil)) (apply yas--take-care-of-redo #s(yas--snippet nil nil #s(yas--exit 386 nil) 19 nil nil nil nil)) (380 . 387) ("p" . 380) ((marker . 25) . -1) 381 nil (380 . 381) (367 . 380) (366 . 367) (":" . -366) 367 (360 . 367) ("    " . -360) ((marker . 25) . -4) 364 (351 . 364) (t 24227 27303 380616 802000) 296 nil ("        " . -293) (281 . 293) 292 nil (279 . 280) (":" . -279) 280 (276 . 280) (267 . 276) (t 24227 27178 552477 765000) 214 nil ("        " . -404) ((marker* . 376) . 8) ((marker . 25) . -8) (392 . 404) 400 nil ("            
" . 392) ((marker . 26) . -13) ((marker* . 376) . 1) ((marker . 25) . -11) 403 nil (391 . 404) (390 . 391) (" " . -390) ((marker . 25) . -1) (":" . -391) ((marker . 25) . -1) 392 (391 . 392) (378 . 391) ("nu" . -378) ((marker . 25) . -2) 380 (378 . 380) ("n " . -378) ((marker . 25) . -2) 380 ("= " . -380) ((marker . 25) . -2) 382 ("u" . -382) ((marker . 25) . -1) 383 (382 . 383) (379 . 382) ("=" . -379) 380 (379 . 380) ("n" . -379) ((marker . 25) . -1) 380 (379 . 380) ("u" . -379) ((marker . 25) . -1) 380 (374 . 380) (362 . 374) ("al" . -362) ((marker . 25) . -2) 364 (362 . 364) ("album_title " . 362) ((marker . 490) . -11) ((marker . 448) . -11) ((marker . 448) . -11) ((marker . 25) . -11) (t 24227 27148 943900 561000) nil (373 . 374) (362 . 373) ("al" . -362) ((marker . 25) . -2) 364 (358 . 364) (357 . 358) (" " . -357) ((marker . 25) . -1) ("!" . -358) ((marker . 25) . -1) ("=" . -359) ((marker . 25) . -1) (" " . -360) ((marker . 25) . -1) 361 (357 . 361) (" !=" . -357) ((marker . 25) . -2) 360 (358 . 360) (t 24227 27109 325053 531000) nil (357 . 358) ("(" . -357) ((marker . 25) . -1) ((marker*) . 1) ((marker) . -1) ((marker) . -1) (")" . 358) ((marker*) . 1) ((marker) . -1) (346 . 359) ("ar" . -346) ((marker . 25) . -2) 348 (343 . 348) (334 . 343) (t 24227 27017 369236 658000) 276 nil (1 . 509) ("#!/usr/bin/env python3


def make_album(
    artist_name=None, album_title=None, num_of_songs: int = None
) -> dict:
    while True:
        artist_name = input(\"What is the name of the artist? \").title()
        album_title = input(\"What is of the album? \").title()
        num_of_songs = int(input(\"How many songs in the album? \"))
        break
    return {\"Artist: \": artist_name, \"Album Title: \": album_title, \"Number of Songs: \": str(num_of_songs)}


print(make_album())
" . 1) ((marker . 25) . -348) ((marker . 26) . -455) ((marker . 25) . -348) ((marker . 490) . -359) ((marker* . 376) . 75) ((marker . 1) . -359) ((marker* . 656) . 23) ((marker . 1) . -359) ((marker . 1) . -453) ((marker . 1) . -142) ((marker . 1) . -73) ((marker . 1) . -241) ((marker . 1) . -241) ((marker . 1) . -213) ((marker . 1) . -213) ((marker . 1) . -359) ((marker . 1) . -352) ((marker . 1) . -352) ((marker . 1) . -348) ((marker . 1) . -352) ((marker . 1) . -352) ((marker . 1) . -352) ((marker . 1) . -352) ((marker . 1) . -352) ((marker . 1) . -352) ((marker . 1) . -352) ((marker . 1) . -230) ((marker . 1) . -230) ((marker . 1) . -230) ((marker . 1) . -230) ((marker . 1) . -230) ((marker . 1) . -230) ((marker . 1) . -230) ((marker . 1) . -230) ((marker . 1) . -230) ((marker . 1) . -348) ((marker . 1) . -382) ((marker . 1) . -348) ((marker . 1) . -348) ((marker . 1) . -348) ((marker . 1) . -348) ((marker . 1) . -348) ((marker . 1) . -348) ((marker . 1) . -348) ((marker . 1) . -348) ((marker . 1) . -348) ((marker . 1) . -348) ((marker . 1) . -348) ((marker . 1) . -348) ((marker . 1) . -352) ((marker . 1) . -348) ((marker . 1) . -352) ((marker . 1) . -352) ((marker . 1) . -352) ((marker . 1) . -352) ((marker . 1) . -352) ((marker . 1) . -352) ((marker . 1) . -352) ((marker . 1) . -352) ((marker . 1) . -352) ((marker . 1) . -352) ((marker . 1) . -352) ((marker . 1) . -352) ((marker . 1) . -352) ((marker . 1) . -352) ((marker . 1) . -352) ((marker . 1) . -352) ((marker . 1) . -352) ((marker . 1) . -352) ((marker . 1) . -352) ((marker . 1) . -352) ((marker . 1) . -352) ((marker . 1) . -352) ((marker . 1) . -352) ((marker . 1) . -352) ((marker . 1) . -352) ((marker . 1) . -352) ((marker . 1) . -352) ((marker . 1) . -352) ((marker . 1) . -352) ((marker . 1) . -352) ((marker . 1) . -352) ((marker . 1) . -352) ((marker . 1) . -352) ((marker . 1) . -352) ((marker . 1) . -352) ((marker . 1) . -352) ((marker . 1) . -333) ((marker . 1) . -333) ((marker . 1) . -333) ((marker . 1) . -329) ((marker . 1) . -372) ((marker . 1) . -359) ((marker . 1) . -436) ((marker . 1) . -436) ((marker . 1) . -436) ((marker . 1) . -436) ((marker . 1) . -436) ((marker . 1) . -436) ((marker . 1) . -436) ((marker . 1) . -436) ((marker . 1) . -436) ((marker . 1) . -436) ((marker . 1) . -436) ((marker . 25) . -348) ((marker . 25) . -453) ((marker . 1) . -436) ((marker . 1) . -436) ((marker . 1) . -436) ((marker . 1) . -436) ((marker . 1) . -436) ((marker . 1) . -436) ((marker . 1) . -436) ((marker . 1) . -436) ((marker . 1) . -436) ((marker . 1) . -436) ((marker . 1) . -436) ((marker . 1) . -436) ((marker . 1) . -401) ((marker . 1) . -416) ((marker . 1) . -348) ((marker . 1) . -427) ((marker . 1) . -348) ((marker . 1) . -348) ((marker . 1) . -348) ((marker*) . 24) ((marker) . -454) ((marker*) . 118) ((marker) . -360) 454 nil ("\"" . 454) (t 24227 26994 548518 653000) nil (nil face font-lock-string-face 401 . 403) (nil fontified nil 401 . 403) (401 . 403) (" : " . 401) ((marker . 25) . -1) 403 (401 . 403) (t 24227 26871 1872 723000) nil (nil fontified nil 434 . 436) (nil face font-lock-string-face 434 . 436) (434 . 436) (" : " . 434) ((marker . 25) . -1) 436 (435 . 436) (434 . 435) nil (432 . 433) (431 . 432) (426 . 431) (425 . 426) (419 . 425) (416 . 419) (415 . 417) ("\"" . -415) (415 . 416) ("'" . -415) ((marker . 25) . -1) ("'" . 416) (415 . 417) ("'" . -415) (415 . 416) nil ("+" . 415) ((marker* . 376) . 1) nil (413 . 415) ("," . -413) 414 (413 . 414) (" " . 413) (t 24227 26848 154207 402000) nil (400 . 401) (" " . -400) ((marker . 25) . -1) 401 (400 . 401) (399 . 400) nil ("\"" . 400) nil (369 . 370) (368 . 369) nil (397 . 398) (396 . 397) (388 . 396) (385 . 388) (384 . 386) ("\"" . -384) (384 . 385) ("'" . -384) ((marker . 25) . -1) ("'" . 385) (384 . 386) ("'" . -384) (384 . 385) (382 . 384) (", " . 382) 383 (382 . 383) (" " . -382) ((marker . 25) . -1) 383 ("+" . 383) (t 24227 26823 800438 579000) nil (368 . 369) nil ("," . -381) ((marker . 25) . -1) 382 (381 . 382) (t 24227 26811 942611 64000) nil ("}" . 381) ((marker*) . 1) ((marker) . -1) nil ("{" . 370) ((marker*) . 1) ((marker) . -1) (t 24227 26806 162351 597000) nil (nil face font-lock-string-face 418 . 419) (nil fontified nil 418 . 419) (418 . 419) (360 . 361) 416 (t 24227 26800 399785 667000) nil ("f" . 360) (t 24227 26779 333473 147000) nil (382 . 383) (370 . 371) nil ("{ " . 370) ((marker*) . 2) ((marker) . -1) (" }" . 383) ((marker*) . 1) ((marker) . -2) (t 24227 26776 496215 647000) nil (383 . 385) (370 . 372) 380 nil ("{" . -370) ((marker . 25) . -1) ((marker*) . 1) ((marker) . -1) ((marker) . -1) ("}" . 371) ((marker*) . 1) ((marker) . -1) (370 . 372) ("{" . -370) (362 . 371) nil (360 . 361) (t 24227 26767 645830 717000) nil (406 . 407) (360 . 361) 404 (t 24227 26748 830514 464000) nil ("\"caetano veloso\", \"fina estampa\", 12" . 425) ((marker . 25) . -35) ((marker . 1) . -35) ((marker . 25) . -35) ((marker) . -35) 460 (t 24227 26710 853413 20000) nil (330 . 331) nil (256 . 257) nil (194 . 195) (t 24227 26700 574002 168000) nil (340 . 345) (331 . 340) (t 24227 26691 176981 717000) 274 nil ("
        " . 331) ((marker . 25) . -1) ((marker . 25) . -9) ((marker . 1) . -9) ((marker . 1) . -9) ((marker . 1) . -9) (332 . 340) (t 24227 26690 414256 571000) nil ("        " . -332) ((marker . 25) . -8) ((marker) . -1) ((marker) . -4) ((marker) . -5) ((marker . 1) . -8) ((marker . 1) . -8) ((marker . 1) . -8) 340 (331 . 340) (t 24227 26635 361151 816000) 274 nil ("        " . -336) ((marker . 490) . -8) ((marker . 1) . -8) ((marker . 1) . -8) ((marker . 1) . -8) ((marker . 1) . -8) ((marker . 1) . -8) ((marker . 1) . -8) ((marker . 1) . -8) ((marker . 1) . -8) ((marker . 1) . -8) ((marker . 1) . -8) ((marker . 1) . -8) ((marker . 1) . -8) ((marker . 1) . -8) ((marker . 1) . -8) ((marker . 25) . -8) ((marker . 25) . -8) (332 . 336) 340 nil ("            " . -340) ((marker . 490) . -12) ((marker . 1) . -12) ((marker . 1) . -12) ((marker . 1) . -12) ((marker . 1) . -12) ((marker . 1) . -12) ((marker . 1) . -12) ((marker . 1) . -12) ((marker . 1) . -12) ((marker . 1) . -12) ((marker . 1) . -12) ((marker . 1) . -12) ((marker . 1) . -12) ((marker . 1) . -12) ((marker . 1) . -12) ((marker . 25) . -12) ((marker . 25) . -12) (332 . 340) 344 nil ("        " . -344) ((marker . 490) . -8) ((marker . 1) . -8) ((marker . 1) . -8) ((marker . 1) . -8) ((marker . 1) . -8) ((marker . 1) . -8) ((marker . 1) . -8) ((marker . 1) . -8) ((marker . 1) . -8) ((marker . 1) . -8) ((marker . 1) . -8) ((marker . 1) . -8) ((marker . 1) . -8) ((marker . 1) . -8) ((marker . 1) . -8) ((marker . 25) . -8) ((marker . 25) . -8) (332 . 344) 340 (t 24227 26567 427424 896000) nil (375 . 378) nil (388 . 389) (375 . 376) 386 (t 24227 26518 755739 299000) nil (289 . 292) nil (327 . 328) (289 . 290) 325 (t 24227 26495 352281 822000) nil (367 . 370) (" +" . -367) ((marker . 25) . -1) 369 (368 . 369) nil (353 . 356) (" +" . -353) ((marker . 25) . -1) 355 (354 . 355) (t 24227 26488 756495 496000) nil (366 . 378) ("num" . -366) ((marker . 25) . -3) 369 (365 . 369) (354 . 365) ("alb" . -354) ((marker . 25) . -3) 357 (355 . 357) (354 . 355) ("a" . -354) ((marker . 25) . -1) ("l" . -355) ((marker . 25) . -1) 356 (355 . 356) ("b" . -355) ((marker . 25) . -1) 356 (355 . 356) ("l" . -355) ((marker . 25) . -1) 356 (353 . 356) (342 . 353) ("ar" . -342) ((marker . 25) . -2) 344 (342 . 344) ("aname" . -342) ((marker . 25) . -5) 347 (t 24227 26474 734084 47000) nil (321 . 324) ("i" . -321) ((marker . 25) . -1) ("m" . -322) ((marker . 25) . -1) 323 (321 . 323) ("i" . -321) ((marker . 25) . -1) ("m" . -322) ((marker . 25) . -1) 323 (320 . 323) ("g" . -320) ((marker . 25) . -1) ("u" . -321) ((marker . 25) . -1) ("m" . -322) ((marker . 25) . -1) 323 (315 . 323) ("y" . -315) ((marker . 25) . -1) 316 (311 . 316) (309 . 311) (" " . -309) ((marker . 25) . -1) 310 (296 . 310) ("W" . -296) ((marker . 25) . -1) ("h" . -297) ((marker . 25) . -1) 298 (296 . 298) (apply yas--snippet-revive 289 298 #s(yas--snippet nil nil #s(yas--exit 296 nil) 14 nil nil nil nil)) (apply yas--take-care-of-redo #s(yas--snippet nil nil #s(yas--exit 296 nil) 14 nil nil nil nil)) (289 . 298) ("i" . 289) ((marker . 25) . -1) 290 nil (289 . 290) ("num_of_songs" . 289) nil (274 . 286) ("nu" . -274) ((marker . 25) . -2) 276 (274 . 276) ("songs" . 274) (t 24227 26335 386624 628000) nil (258 . 265) ("ti" . -258) ((marker . 25) . -2) 260 (257 . 260) (242 . 255) (t 24227 26324 75382 284000) nil ("ti9tle " . -242) ((marker . 25) . -7) 249 ("o" . -249) ((marker . 25) . -1) 250 (242 . 250) (t 24227 26320 412489 619000) nil (213 . 224) ("al" . -213) ((marker . 25) . -2) 215 (213 . 215) ("al" . 213) (t 24227 26316 523689 425000) nil (70 . 75) ("name" . -70) ((marker . 25) . -4) 74 (69 . 74) nil (207 . 209) ("rname" . 207) nil (136 . 147) ("ar" . -136) ((marker . 25) . -2) 138 (136 . 138) ("aname" . 136) nil (64 . 69) ("record" . 64) nil (218 . 225) ("Hat " . -218) ((marker . 25) . -4) 222 ("is" . -222) ((marker . 25) . -2) 224 (217 . 224) (apply yas--snippet-revive 210 219 #s(yas--snippet nil nil #s(yas--exit 217 nil) 13 nil nil nil nil)) (apply yas--take-care-of-redo #s(yas--snippet nil nil #s(yas--exit 217 nil) 13 nil nil nil nil)) (210 . 219) ("i" . 210) ((marker . 25) . -1) 211 nil (210 . 211) ("record.title()" . 210) ((marker* . 376) . 14) (t 24227 26281 394661 796000) nil (191 . 193) ("(" . -191) (185 . 192) (t 24227 26232 737217 388000) nil ("r" . 182) nil (181 . 183) nil (173 . 182) (152 . 173) ("A" . -152) ((marker . 25) . -1) ("r" . -153) ((marker . 25) . -1) 154 (152 . 154) (151 . 153) ("\"" . -151) (151 . 152) (150 . 152) ("(" . -150) (147 . 151) ("u" . -147) ((marker . 25) . -1) ("t" . -148) ((marker . 25) . -1) 149 (147 . 149) ("m" . -147) ((marker . 25) . -1) ("p" . -148) ((marker . 25) . -1) ("y" . -149) ((marker . 25) . -1) 150 (145 . 150) ("artist_name.title()" . 145) (t 24227 26190 203393 530000) nil (1 . 304) ("#!/usr/bin/env python3


def make_album(artist_name=None, record=None, num_of_songs: int = None) -> dict:
    while True:
        aname = artist_name.title()
        rname = record.title()
        songs = num_of_songs
        return aname


print(make_album(\"caetano veloso\", \"fina estampa\", 12))
" . 1) ((marker . 25) . -25) ((marker . 26) . -106) ((marker . 25) . -177) ((marker . 490) . -237) ((marker* . 376) . 228) ((marker . 1) . -158) ((marker* . 656) . 79) ((marker . 1) . -177) ((marker . 1) . -208) ((marker . 1) . -74) ((marker . 1) . -74) ((marker . 1) . -74) ((marker . 1) . -138) ((marker . 1) . -138) ((marker . 1) . -138) ((marker . 1) . -138) ((marker . 1) . -138) ((marker . 1) . -138) ((marker . 1) . -138) ((marker . 1) . -138) ((marker . 1) . -138) ((marker . 1) . -138) ((marker . 1) . -138) ((marker . 1) . -138) ((marker . 1) . -138) ((marker . 1) . -138) ((marker . 1) . -138) ((marker . 1) . -138) ((marker . 1) . -138) ((marker . 1) . -138) ((marker . 1) . -138) ((marker . 1) . -138) ((marker . 1) . -138) ((marker . 1) . -138) ((marker . 1) . -138) ((marker . 1) . -138) ((marker . 1) . -138) ((marker . 1) . -138) ((marker . 1) . -138) ((marker . 1) . -138) ((marker . 1) . -138) ((marker . 1) . -138) ((marker . 1) . -138) ((marker . 1) . -138) ((marker . 1) . -138) ((marker . 1) . -138) ((marker . 1) . -138) ((marker . 1) . -138) ((marker . 1) . -138) ((marker . 1) . -138) ((marker . 1) . -138) ((marker . 1) . -150) ((marker . 1) . -150) ((marker . 1) . -174) ((marker . 1) . -174) ((marker . 1) . -174) ((marker . 1) . -174) ((marker . 1) . -130) ((marker . 1) . -130) ((marker . 1) . -233) ((marker . 1) . -132) ((marker . 1) . -237) ((marker . 1) . -237) ((marker . 1) . -237) ((marker . 1) . -237) ((marker . 1) . -237) ((marker . 1) . -237) ((marker . 1) . -237) ((marker . 1) . -237) ((marker . 1) . -237) ((marker . 1) . -237) ((marker . 1) . -237) ((marker . 1) . -237) ((marker . 1) . -237) ((marker . 1) . -237) ((marker . 1) . -237) ((marker . 1) . -237) ((marker . 1) . -237) ((marker . 1) . -237) ((marker . 1) . -237) ((marker . 1) . -237) ((marker . 25) . -237) ((marker . 25) . -68) 69 nil (65 . 70) ("=" . -65) 66 (65 . 66) nil (52 . 57) ("=" . -52) 53 (52 . 53) (t 24227 26155 362375 273000) nil (224 . 229) ("a" . 224) nil (122 . 124) (t 24227 26149 285093 459000) nil ("a" . 121) ((marker . 1) . -1) ((marker . 1) . -1) nil (223 . 224) ("aane" . -223) ((marker . 25) . -4) 227 (216 . 227) (207 . 216) (t 24227 26139 212769 292000) 179 nil ("        if num_of_songs:
            return {
                \"Artist\": artist_name.title(),
                \"Album\": record.title(),
                \"Number of Songs\": num_of_songs,
            }
        else:
            return {
                \"Artist\": artist_name.title(),
                \"Album\": record.title(),
            }
" . 208) ((marker . 25) . -320) ((marker . 26) . -334) ((marker . 25) . -328) ((marker . 1) . -8) ((marker . 1) . -328) ((marker . 25) . -328) 536 (t 24227 26131 558672 55000) nil ("." . -207) ((marker . 25) . -1) 208 (195 . 208) ("nu" . -195) ((marker . 25) . -2) 197 (192 . 197) ("=" . -192) 193 (187 . 193) (178 . 187) (t 24227 26116 55823 313000) 176 nil (171 . 178) ("t" . -171) ((marker . 25) . -1) 172 (170 . 172) ("." . -170) ((marker . 25) . -1) 171 (164 . 171) ("rec" . -164) ((marker . 25) . -3) 167 (164 . 167) ("red" . 164) ((marker . 25) . -3) ((marker . 490) . -3) ((marker . 1) . -3) ((marker . 1) . -2) ((marker . 1) . -3) ((marker . 1) . -3) ((marker . 25) . -3) nil ("n" . 122) ((marker . 1) . -1) ((marker . 1) . -1) (162 . 168) ("=" . 162) (148 . 163) (t 24227 26088 944215 516000) nil ("
        " . 148) ((marker . 26) . -1) ((marker . 25) . -9) ((marker . 490) . -9) ((marker . 1) . -9) ((marker . 1) . -9) ((marker . 1) . -9) ((marker . 1) . -9) ((marker . 25) . -9) ("rname=" . 157) ((marker . 25) . -5) ((marker . 490) . -5) ((marker . 1) . -5) ((marker . 1) . -5) ((marker . 1) . -5) ((marker . 1) . -5) ((marker . 25) . -5) (162 . 163) (" = red" . 162) ((marker . 25) . -6) ((marker . 490) . -6) ((marker . 1) . -6) ((marker . 1) . -5) ((marker . 1) . -6) ((marker . 1) . -6) ((marker . 25) . -6) (122 . 123) nil ("n" . -122) ((marker . 25) . -1) ((marker . 1) . -1) ((marker . 1) . -1) 123 (162 . 168) ("=" . -162) 163 (157 . 163) (148 . 157) (t 24227 26088 944215 516000) 121 nil (141 . 148) ("t" . -141) ((marker . 25) . -1) ((marker) . -1) ((marker . 1) . -1) ((marker . 1) . -1) 142 (141 . 142) (129 . 141) ("ar" . -129) ((marker . 25) . -2) ((marker . 1) . -1) ((marker) . -2) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -2) ((marker . 1) . -1) ((marker) . -2) ((marker . 1) . -2) 131 (129 . 131) ("artist_name." . 129) ((marker) . -11) ((marker) . -12) nil (129 . 141) ("ar" . -129) ((marker . 25) . -2) 131 (129 . 131) ("artist_name." . 129) ((marker . 25) . -10) ((marker . 490) . -10) ((marker* . 376) . 1) ((marker . 1) . -12) ((marker . 1) . -11) ((marker . 1) . -12) ((marker . 1) . -12) ((marker . 1) . -12) ((marker . 1) . -12) ((marker . 1) . -12) ((marker . 1) . -11) ((marker . 1) . -11) ((marker . 1) . -12) ((marker . 1) . -11) ((marker . 1) . -11) ((marker . 1) . -11) ((marker . 1) . -11) ((marker . 1) . -11) ((marker . 1) . -11) ((marker . 1) . -11) ((marker . 1) . -10) ((marker . 1) . -10) ((marker . 1) . -11) ((marker . 1) . -10) ((marker . 1) . -10) ((marker . 1) . -10) ((marker . 1) . -10) ((marker . 1) . -10) ((marker . 1) . -10) ((marker . 25) . -10) (t 24227 26061 600433 594000) nil (129 . 141) ("ar" . -129) ((marker . 25) . -2) 131 (129 . 131) ("artist_name." . 129) ((marker . 25) . -11) ((marker . 490) . -11) ((marker . 1) . -11) ((marker . 1) . -11) ((marker . 1) . -11) ((marker . 25) . -11) (t 24227 26047 378673 390000) nil (129 . 141) ("ar" . -129) ((marker . 25) . -2) 131 (129 . 131) ("artist" . -129) ((marker . 25) . -6) 135 ("_" . -135) ((marker . 25) . -1) 136 ("name" . -136) ((marker . 25) . -4) 140 (".." . -140) ((marker . 25) . -2) 142 (141 . 142) nil (129 . 141) ("art" . -129) ((marker . 25) . -3) 132 (129 . 132) ("art" . 129) ((marker . 490) . -2) ((marker . 1) . -2) ((marker . 1) . -2) ((marker . 25) . -2) (t 24227 25971 604106 18000) nil (126 . 132) ("=" . -126) 127 (122 . 127) (121 . 122) ("name = " . 121) nil (125 . 128) ("=" . -125) 126 (121 . 126) (112 . 121) (t 24227 25916 69442 269000) 107 nil (1 . 505) ("#!/usr/bin/env python3


def make_album(
    artist_name, record, num_of_songs: int = None
) -> dict:
    while True:
        if num_of_songs:
            return {
                \"Artist\": artist_name.title(),
                \"Album\": record.title(),
                \"Number of Songs\": num_of_songs,
            }
        else:
            return {
                \"Artist\": artist_name.title(),
                \"Album\": record.title(),
            }


print(make_album(\"caetano veloso\", \"fina estampa\", 12))
" . 1) ((marker . 25) . -41) ((marker . 26) . -91) ((marker . 25) . -155) ((marker . 490) . -136) ((marker* . 376) . 393) ((marker . 1) . -118) ((marker* . 656) . 58) ((marker . 1) . -126) ((marker . 1) . -438) ((marker . 1) . -510) ((marker . 1) . -118) ((marker . 1) . -91) ((marker . 1) . -136) ((marker . 1) . -116) ((marker . 1) . -136) ((marker . 1) . -136) ((marker . 1) . -136) ((marker . 1) . -136) ((marker . 1) . -136) ((marker . 1) . -136) ((marker . 1) . -136) ((marker . 1) . -161) ((marker . 1) . -126) ((marker . 1) . -350) ((marker . 1) . -350) ((marker . 1) . -350) ((marker . 1) . -155) ((marker . 1) . -155) ((marker . 1) . -155) ((marker . 25) . -155) ((marker . 25) . -64) ((marker . 1) . -155) ((marker . 1) . -130) 65 nil (": str" . 65) nil (": str" . 57) (t 24227 25864 235065 159000) nil ("        " . -461) (449 . 461) ("            " . -424) (408 . 424) ("            " . -377) (361 . 377) ("        " . -352) (340 . 352) ("    " . -334) (326 . 334) ("        " . -324) (312 . 324) ("            " . -279) (263 . 279) ("            " . -238) (222 . 238) ("            " . -191) (175 . 191) ("        " . -166) (154 . 166) ("    " . -137) ((marker . 1) . -4) ((marker) . -4) ((marker . 1) . -4) (129 . 137) 419 (t 24227 25841 56585 229000) nil (118 . 128) nil (117 . 118) (112 . 117) (t 24227 25793 170580 859000) 102 nil (1 . 461) ("#!/usr/bin/env python3


def make_album(
    artist_name: str, record: str, num_of_songs: int = None) -> dict:
    if num_of_songs:
        return {
            \"Artist\": artist_name.title(),
            \"Album\": record.title(),
            \"Number of Songs\": num_of_songs,
        }
    else:
        return {
            \"Artist\": artist_name.title(),
            \"Album\": record.title(),
        }


print(make_album(\"caetano veloso\", \"fina estampa\", 12))
" . 1) ((marker . 25) . -41) ((marker . 26) . -111) ((marker . 25) . -109) 110 nil ("
" . -101) ((marker . 26) . -1) 100 (t 24227 25778 513778 778000) nil (1 . 461) ("#!/usr/bin/env python3


def make_album(artist_name: str, record: str, num_of_songs: int = None) -> dict:
    if num_of_songs:
        return {
            \"Artist\": artist_name.title(),
            \"Album\": record.title(),
            \"Number of Songs\": num_of_songs,
        }
    else:
        return {
            \"Artist\": artist_name.title(),
            \"Album\": record.title(),
        }


print(make_album(\"caetano veloso\", \"fina estampa\", 12))
" . 1) ((marker . 25) . -25) ((marker . 26) . -25) ((marker . 25) . -25) ((marker . 490) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 1) . -25) ((marker . 25) . -25) ((marker . 25) . -95) ((marker*) . 429) ((marker) . -25) ((marker*) . 429) ((marker) . -25) 96 nil (26 . 107) ("def make_album(
    artist_name: str, record: str, num_of_songs: int = None) -> dict:
" . -26) ((marker . 25) . -16) ((marker . 26) . -86) ((marker . 25) . -83) ((marker . 490) . -83) ((marker . 1) . -83) ((marker . 1) . -83) ((marker . 1) . -83) ((marker . 1) . -83) ((marker . 1) . -83) ((marker . 1) . -83) ((marker . 1) . -83) ((marker . 1) . -83) ((marker . 1) . -83) ((marker . 1) . -83) ((marker . 1) . -83) ((marker . 1) . -83) ((marker . 1) . -83) ((marker . 1) . -83) ((marker . 1) . -83) ((marker . 1) . -83) ((marker . 1) . -83) ((marker . 1) . -24) ((marker . 1) . -83) ((marker . 1) . -24) ((marker . 1) . -75) ((marker . 1) . -24) ((marker . 1) . -16) ((marker . 1) . -24) ((marker . 1) . -75) ((marker . 25) . -75) ((marker . 25) . -75) ((marker*) . 11) ((marker) . -76) ((marker*) . 72) ((marker) . -15) nil (1 . 460) ("#!/usr/bin/env python3


def make_album(
    artist_name: str, record: str, num_of_songs: int = None
) -> dict:
    if num_of_songs:
        return {
            \"Artist\": artist_name.title(),
            \"Album\": record.title(),
            \"Number of Songs\": num_of_songs,
        }
    else:
        return {
            \"Artist\": artist_name.title(),
            \"Album\": record.title(),
        }


print(make_album(\"caetano veloso\", \"fina estampa\", 12))
" . 1) ((marker . 25) . -295) ((marker . 26) . -312) ((marker . 25) . -295) (t 24227 25767 961601 929000) nil (1 . 461) ("#!/usr/bin/env python3


def make_album(
    artist_name: str, record: str, num_of_songs: int = None) -> dict:
    if num_of_songs:
        return {
            \"Artist\": artist_name.title(),
            \"Album\": record.title(),
            \"Number of Songs\": num_of_songs,
        }
    else:
        return {
            \"Artist\": artist_name.title(),
            \"Album\": record.title(),
        }


print(make_album(\"caetano veloso\", \"fina estampa\", 12))
" . 1) ((marker . 25) . -41) ((marker . 26) . -111) ((marker . 25) . -108) ((marker . 490) . -108) ((marker . 1) . -108) ((marker . 1) . -108) ((marker . 1) . -108) ((marker . 1) . -108) ((marker . 1) . -108) ((marker . 1) . -108) ((marker . 1) . -108) ((marker . 1) . -108) ((marker . 1) . -108) ((marker . 1) . -108) ((marker . 25) . -108) ((marker . 25) . -100) ((marker) . -391) ((marker) . -392) ((marker) . -395) ((marker) . -396) ((marker) . -354) ((marker) . -355) ((marker) . -358) ((marker) . -359) ((marker) . -362) ((marker) . -363) ((marker) . -311) ((marker) . -312) ((marker) . -315) ((marker) . -316) ((marker) . -319) ((marker) . -320) ((marker) . -294) ((marker) . -295) ((marker) . -298) ((marker) . -299) ((marker) . -284) ((marker) . -285) ((marker) . -274) ((marker) . -275) ((marker) . -278) ((marker) . -279) ((marker) . -229) ((marker) . -230) ((marker) . -233) ((marker) . -234) ((marker) . -237) ((marker) . -238) ((marker) . -192) ((marker) . -193) ((marker) . -196) ((marker) . -197) ((marker) . -200) ((marker) . -201) ((marker) . -149) ((marker) . -150) ((marker) . -153) ((marker) . -154) ((marker) . -157) ((marker) . -158) ((marker) . -132) ((marker) . -133) ((marker) . -136) ((marker) . -137) ((marker) . -111) ((marker) . -112) ((marker . 1) . -108) ((marker . 1) . -108) ((marker . 1) . -108) ((marker . 1) . -108) ((marker . 1) . -108) ((marker . 1) . -108) ((marker . 1) . -108) ((marker . 1) . -49) ((marker . 1) . -108) ((marker . 1) . -49) ((marker) . -111) ((marker) . -112) ((marker) . -41) ((marker) . -42) ((marker . 1) . -100) ((marker . 1) . -49) ((marker . 1) . -41) ((marker . 1) . -49) ((marker*) . 359) ((marker) . -101) ((marker*) . 420) ((marker) . -40) ((marker . 1) . -100) 101 nil ("
" . -101) ((marker . 26) . -1) 50 (t 24227 25752 890658 333000) nil (1 . 461) ("#!/usr/bin/env python3


def make_album(
    artist_name: str, record: str, num_of_songs: int = None) -> dict:
    if num_of_songs:
        return {
            \"Artist\": artist_name.title(),
            \"Album\": record.title(),
            \"Number of Songs\": num_of_songs,
        }
    else:
        return {
            \"Artist\": artist_name.title(),
            \"Album\": record.title(),
        }


print(make_album(\"caetano veloso\", \"fina estampa\", 12))
" . 1) ((marker . 25) . -41) ((marker . 26) . -111) ((marker . 25) . -401) ((marker . 490) . -302) ((marker* . 376) . 3) ((marker . 1) . -402) ((marker . 1) . -401) ((marker . 1) . -402) ((marker . 1) . -402) ((marker . 1) . -402) ((marker . 1) . -402) ((marker . 1) . -402) ((marker . 1) . -402) ((marker . 1) . -402) ((marker . 1) . -149) ((marker . 1) . -402) ((marker . 1) . -149) ((marker . 1) . -402) ((marker . 1) . -294) ((marker* . 656) . 58) ((marker . 1) . -294) ((marker . 1) . -294) ((marker . 1) . -294) ((marker . 420) . -294) ((marker . 420) . -400) ((marker . 1) . -302) ((marker . 1) . -302) ((marker . 1) . -401) ((marker . 1) . -302) ((marker . 1) . -302) ((marker . 25) . -456) ((marker . 25) . -109) ((marker . 1) . -302) ((marker . 1) . -362) ((marker . 1) . -403) ((marker . 1) . -459) ((marker . 1) . -192) ((marker . 1) . -403) ((marker . 1) . -403) ((marker . 1) . -192) ((marker . 1) . -362) ((marker . 1) . -132) ((marker . 1) . -456) ((marker . 1) . -455) ((marker . 1) . -111) ((marker . 1) . -456) ((marker . 1) . -456) ((marker . 1) . -111) ((marker . 1) . -132) ((marker . 1) . -455) ((marker . 1) . -455) ((marker . 1) . -401) ((marker . 1) . -401) 110 nil ("
" . -101) ((marker . 26) . -1) 42 (t 24227 25745 871712 503000) nil ("    # return {\"Artist\": artist_name.title(), \"Album\": record.title()}
" . 403) ((marker . 26) . -70) ((marker . 1) . -70) ((marker* . 656) . 70) ((marker . 25) . -4) 407 (t 24227 25740 792850 801000) nil (526 . 528) (nil fontified nil 524 . 526) (nil face font-lock-string-face 524 . 526) (524 . 526) ("," . -524) 525 (524 . 525) (t 24227 25727 586432 681000) nil ("            \"Number of Songs\": num_of_songs,
" . 393) ((marker . 26) . -45) ((marker . 25) . -12) 405 (t 24227 25710 504022 863000) nil (nil rear-nonsticky nil 303 . 304) (296 . 448) 312 ("        return 
" . 296) ((marker . 26) . -16) ((marker . 25) . -16) ((marker* . 376) . 1) ((marker . 25) . -8) ((marker . 1) . -8) ((marker . 1) . -8) ((marker) . -8) ((marker) . -8) 312 nil (304 . 311) (295 . 304) (294 . 295) (":" . -294) 295 (290 . 295) ("pass" . 290) (t 24227 25671 417987 738000) nil (1 . 419) ("#!/usr/bin/env python3


def make_album(artist_name: str, record: str, num_of_songs: int = None) -> dict:
    if num_of_songs:
        return {
            \"Artist\": artist_name.title(),
            \"Album\": record.title(),
            \"Number of Songs\": num_of_songs,
        }
    pass
    # return {\"Artist\": artist_name.title(), \"Album\": record.title()}


print(make_album(\"caetano veloso\", \"fina estampa\"))
" . 1) ((marker . 25) . -25) ((marker . 26) . -106) ((marker* . 376) . 321) ((marker . 25) . -90) 91 nil (89 . 92) ("=" . -89) 90 (86 . 90) ("m" . -86) ((marker . 25) . -1) 87 (84 . 87) (":" . -84) 85 (84 . 85) ("=" . 84) (t 24227 25650 948752 993000) nil (1 . 406) ("#!/usr/bin/env python3


def make_album(artist_name: str, record: str, num_of_songs=None) -> dict:
    if num_of_songs:
        return {\"Artist\": artist_name.title(), \"Album\": record.title(), \"Number of Songs\": num_of_songs}
    pass
    # return {\"Artist\": artist_name.title(), \"Album\": record.title()}


print(make_album(\"caetano veloso\", \"fina estampa\"))
" . 1) ((marker . 25) . -120) ((marker . 26) . -225) ((marker . 490) . -128) ((marker* . 376) . 135) ((marker . 1) . -128) ((marker . 1) . -128) ((marker . 25) . -128) ((marker . 25) . -222) 223 nil (212 . 224) ("num" . -212) ((marker . 25) . -3) 215 (212 . 215) (nil fontified nil 210 . 212) (nil face font-lock-string-face 210 . 212) (210 . 212) (":" . -210) 211 (210 . 211) (194 . 209) (193 . 195) ("\"" . -193) (191 . 194) ("," . -191) 192 (191 . 192) (t 24227 25608 493014 374000) nil (1 . 326) ("#!/usr/bin/env python3


def make_album(artist_name: str, record: str, num_of_songs=None) -> dict:
    if num_of_songs:
        return {\"Artist\": artist_name.title(), \"Album\": record.title()}        
    pass
    # return {\"Artist\": artist_name.title(), \"Album\": record.title()}


print(make_album(\"caetano veloso\", \"fina estampa\"))
" . 1) ((marker . 25) . -120) ((marker . 26) . -200) ((marker . 1) . -200) ((marker . 1) . -200) ((marker . 25) . -128) ((marker . 1) . -200) ((marker . 1) . -200) ((marker . 1) . -200) ((marker . 1) . -200) ((marker . 1) . -200) ((marker . 1) . -200) ((marker . 490) . -198) ((marker . 1) . -200) ((marker . 1) . -200) ((marker . 1) . -200) ((marker . 1) . -200) ((marker . 1) . -200) ((marker . 1) . -200) ((marker . 1) . -200) ((marker . 1) . -200) ((marker . 1) . -200) ((marker . 1) . -200) ((marker . 1) . -200) ((marker . 1) . -200) ((marker . 1) . -200) ((marker . 1) . -200) ((marker . 1) . -200) ((marker . 1) . -200) ((marker . 1) . -200) ((marker . 1) . -128) ((marker . 1) . -128) ((marker* . 376) . 134) ((marker . 1) . -128) ((marker . 1) . -128) ((marker . 1) . -128) ((marker . 1) . -128) ((marker . 1) . -128) ((marker . 1) . -128) ((marker . 1) . -128) ((marker . 1) . -128) ((marker . 1) . -128) ((marker . 1) . -128) ((marker . 1) . -128) ((marker . 1) . -128) ((marker . 1) . -128) ((marker . 1) . -128) ((marker . 1) . -128) ((marker . 1) . -128) ((marker . 1) . -128) ((marker . 1) . -128) ((marker . 1) . -128) ((marker . 1) . -198) ((marker . 1) . -198) ((marker . 1) . -198) ((marker . 25) . -128) ((marker . 25) . -128) ((marker . 1) . -128) ((marker . 1) . -120) ((marker . 1) . -128) ((marker . 1) . -128) ((marker . 1) . -128) ((marker . 1) . -128) 129 (t 24227 25602 962699 629000) nil ("    " . -129) ((marker . 25) . -4) ((marker . 1) . -4) ((marker . 1) . -4) ((marker . 1) . -4) ((marker . 1) . -4) ((marker . 1) . -4) ((marker . 1) . -4) ((marker . 1) . -4) ((marker . 1) . -4) ((marker . 1) . -4) ((marker . 1) . -4) ((marker . 1) . -4) ((marker . 1) . -4) ((marker . 1) . -4) ((marker . 1) . -4) ((marker . 1) . -4) ((marker . 1) . -4) ((marker . 1) . -4) ((marker . 1) . -4) ((marker . 1) . -4) ((marker . 1) . -4) ((marker . 1) . -4) ((marker . 25) . -4) ((marker . 25) . -4) ((marker . 1) . -4) ((marker . 1) . -4) ((marker . 1) . -4) ((marker . 1) . -4) ((marker . 1) . -4) (121 . 129) 125 (t 24227 25582 492050 578000) nil (189 . 196) nil (188 . 189) (t 24227 25517 279512 9000) nil (" " . 125) (t 24227 25515 530225 913000) nil (125 . 126) (t 24227 25508 275484 372000) nil (121 . 125) (t 24227 25260 505990 240000) nil (nil rear-nonsticky nil 183 . 184) (nil fontified nil 121 . 184) (121 . 184) nil ("        " . -121) 129 (120 . 129) 104 nil ("
" . 121) nil ("        " . -121) 129 nil (120 . 129) (119 . 120) (107 . 119) ("nu" . -107) 109 (104 . 109) (99 . 104) 35 nil (113 . 115) 116 nil (104 . 108) (99 . 104) 92 nil ("
" . -167) ("p" . -168) 169 (168 . 169) (167 . 168) ("
" . -167) ("p" . -168) 169 (168 . 169) (167 . 168) (t 24227 25222 329287 567000) 157 nil (79 . 84) ("f" . -79) ("o" . -80) 81 (72 . 81) ("n" . -72) ("u" . -73) ("m" . -74) 75 (72 . 75) ("genre" . 72) (t 24227 25163 641654 237000) nil (77 . 82) ("=" . -77) 78 (72 . 78) nil (73 . 74) nil (70 . 72) ("," . -70) 71 (70 . 71) nil ("," . -71) (" " . -72) 73 (71 . 73) (", " . 71) 72 (71 . 72) (t 24227 24572 557559 6000) nil ("," . 70) (70 . 71) (", " . 70) nil (70 . 72) ("," . -70) 71 (70 . 71) (t 24227 24572 557559 6000) nil ("f" . 94) (nil rear-nonsticky t 94 . 95) nil (nil rear-nonsticky nil 94 . 95) (nil fontified nil 94 . 95) (94 . 95) 93 nil ("f" . 94) (nil rear-nonsticky t 94 . 95) (t 24227 24571 74682 219000) nil (nil rear-nonsticky nil 94 . 95) (nil fontified nil 94 . 95) (94 . 95) 93 (t 24227 24565 410195 660000) nil ("f" . 93) (t 24227 24534 551211 778000) nil ("}" . 148) ("{" . 134) 149 (t 24227 24531 322567 790000) nil (131 . 132) (125 . 126) 129 (t 24227 24527 6407 259000) nil ("n" . 125) nil ("\\" . 125) (t 24227 24523 635548 418000) nil ("}" . 123) ("{" . 104) (t 24227 24506 18910 478000) nil (104 . 105) nil ("{" . 104) (t 24227 24506 18910 478000) nil ("\"" . 152) (t 24227 24505 40870 942000) nil ("\"" . 127) (t 24227 24503 680981 934000) nil ("\"" . 125) (t 24227 24499 32788 858000) nil (101 . 102) ("!" . 101) nil (101 . 102) (t 24227 24461 566937 60000) nil (124 . 125) (t 24227 24457 136820 934000) nil (126 . 127) ("!" . 126) nil (126 . 127) nil (124 . 126) nil (93 . 94) nil ("f" . 92) nil (92 . 93) ("def fun(args):
    
" . 92) ("           " . 107) (apply yas--snippet-revive 92 123 #s(yas--snippet nil (#s(yas--field 1 96 99 nil nil nil nil #s(yas--field 2 100 104 nil nil nil nil #s(yas--exit 122 nil))) #s(yas--field 2 100 104 nil nil nil nil #s(yas--exit 122 nil))) #s(yas--exit 122 nil) 7 nil #s(yas--field 1 96 99 nil nil nil nil #s(yas--field 2 100 104 nil nil nil nil #s(yas--exit 122 nil))) nil nil)) nil (apply yas--take-care-of-redo #s(yas--snippet nil (#s(yas--field 1 96 99 nil nil nil nil #s(yas--field 2 100 104 nil nil nil nil #s(yas--exit 122 nil))) #s(yas--field 2 100 104 nil nil nil nil #s(yas--exit 122 nil))) #s(yas--exit 122 nil) 7 nil #s(yas--field 1 96 99 nil nil nil nil #s(yas--field 2 100 104 nil nil nil nil #s(yas--exit 122 nil))) nil nil)) nil (107 . 122) (t 24227 24431 290139 775000) nil ("               " . 107) 95 nil (apply yas--snippet-revive 92 123 #s(yas--snippet nil (#s(yas--field 1 96 99 nil nil nil nil #s(yas--field 2 100 104 nil nil nil nil #s(yas--exit 122 nil))) #s(yas--field 2 100 104 nil nil nil nil #s(yas--exit 122 nil))) #s(yas--exit 122 nil) 7 nil #s(yas--field 1 96 99 nil nil nil nil #s(yas--field 2 100 104 nil nil nil nil #s(yas--exit 122 nil))) nil nil)) nil (apply yas--take-care-of-redo #s(yas--snippet nil (#s(yas--field 1 96 99 nil nil nil nil #s(yas--field 2 100 104 nil nil nil nil #s(yas--exit 122 nil))) #s(yas--field 2 100 104 nil nil nil nil #s(yas--exit 122 nil))) #s(yas--exit 122 nil) 7 nil #s(yas--field 1 96 99 nil nil nil nil #s(yas--field 2 100 104 nil nil nil nil #s(yas--exit 122 nil))) nil nil)) (107 . 118) (92 . 112) ("f" . 92) 93 nil (92 . 93) (t 24227 24427 393809 267000) nil ("f" . 93) (t 24227 24405 892693 106000) nil (93 . 94) (t 24227 24395 737157 805000) nil (nil face font-lock-string-face 149 . 150) (nil fontified nil 149 . 150) (149 . 150) (92 . 93) 147 nil ("{ " . 92) (" }" . 150) (nil face (rainbow-delimiters-depth-1-face) 151 . 152) (nil face nil 150 . 151) (t 24227 24392 871687 696000) nil (nil face font-lock-string-face 150 . 152) (nil fontified nil 150 . 152) (150 . 152) (92 . 94) 147 (t 24227 24390 343446 588000) nil ("f" . 92) (t 24227 23977 806244 37000) nil (75 . 79) ("Dict[str, str]" . 75) (nil rear-nonsticky t 88 . 89) (t 24227 23963 629146 57000) nil (nil rear-nonsticky nil 88 . 89) (nil fontified nil 75 . 89) (75 . 89) 79 ("dict" . 75) 79 nil ("Dict[str, str]" . 150) nil ("\"" . 164) nil (nil rear-nonsticky nil 164 . 165) (nil fontified nil 150 . 165) (150 . 165) (t 24227 23914 873318 291000) nil ("    album = {\"name\": artist_name.title(), \"album\": record.title()}
" . 81) 145 nil (212 . 214) ("(" . -212) (200 . 213) (199 . 201) ("{" . -199) (199 . 200) (190 . 199) ("n" . -190) 191 (190 . 191) (t 24227 23888 352665 827000) nil (187 . 189) ("(" . -187) (181 . 188) (";" . -181) ("t" . -182) 183 (181 . 183) (170 . 181) ("ar" . -170) 172 (170 . 172) nil (169 . 171) ("{" . -169) (169 . 170) (168 . 169) (t 24227 23861 771571 813000) nil (167 . 168) (t 24227 23852 461158 825000) nil (167 . 168) nil ("\"" . 167) (t 24227 23852 461158 825000) nil (132 . 138) ("album_title" . 132) 142 nil (61 . 65) (59 . 61) ("album_title" . 59) 69 (t 24227 23836 42893 388000) nil (":" . 177) (t 24227 23834 914086 961000) nil (177 . 178) (";" . 177) (177 . 178) (":" . 177) (t 24227 23834 421620 615000) nil (177 . 178) (";" . -177) 178 (177 . 178) (":" . 177) (t 24227 23801 450643 529000) nil (177 . 178) (":" . 177) (t 24227 23799 110894 222000) nil (177 . 178) (";" . -177) 178 (177 . 178) (t 24227 23792 719065 278000) nil (":" . 177) (t 24227 23791 50323 846000) nil (177 . 178) (":" . 177) nil (177 . 178) (":" . 177) (t 24227 23739 425989 195000) nil (143 . 177) nil ("title.title()}
    return f\"Artist" . 143) 177 (t 24227 23739 425989 195000) nil (177 . 178) (":" . 177) nil (177 . 178) (":" . 177) (t 24227 23739 425989 195000) nil (177 . 178) (":" . 177) (t 24227 23733 220751 832000) nil (177 . 178) (":" . -177) 178 (177 . 178) (":" . 177) (t 24227 23680 22730 860000) nil (177 . 178) (":" . 177) (t 24227 23679 343487 880000) nil (177 . 178) (":" . -177) 178 (t 24227 23664 650996 505000) nil (177 . 178) (":" . 177) nil (177 . 178) (":" . 177) (t 24227 23658 975345 305000) nil (177 . 178) (":" . 177) nil (177 . 178) (":" . 177) (t 24227 23641 497237 967000) nil (177 . 178) (":" . 177) (t 24227 23606 692397 809000) nil (178 . 181) ("\"

" . 178) 180 nil (177 . 178) (t 24227 23572 616604 46000)) (emacs-undo-equiv-table (6 . 8) (4 . 10) (-82 . -84) (-101 . -103) (-43 . -45) (-33 . -35) (5 . 9) (3 . -1) (-81 . -83)))